UPDATE `businesses` 
SET 
  `pinpoint_location` = ST_GeomFromText('POINT(28.2293 -25.7479)', 1), 
  `status` = 'approved' 
WHERE `businesses`.`id` = 3;
