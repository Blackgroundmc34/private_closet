-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2025 at 11:15 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `private_closet_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL COMMENT 'User booking the appointment',
  `business_id` bigint(20) UNSIGNED NOT NULL COMMENT 'Business the appointment is with',
  `appointment_datetime` datetime NOT NULL,
  `store_location_details` varchar(255) DEFAULT NULL COMMENT 'Specific store if business has multiple locations',
  `status` enum('requested','confirmed','cancelled_by_user','cancelled_by_business','completed','no_show') NOT NULL DEFAULT 'requested',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Booking appointments with businesses';

-- --------------------------------------------------------

--
-- Table structure for table `businesses`
--

CREATE TABLE `businesses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL COMMENT 'Links to the owner user account',
  `business_name` varchar(150) NOT NULL,
  `registration_number` varchar(100) DEFAULT NULL COMMENT 'Optional company registration number',
  `start_date` date DEFAULT NULL COMMENT 'Date the business started if not registered',
  `description` text DEFAULT NULL,
  `physical_address` text DEFAULT NULL,
  `pinpoint_location` point NOT NULL COMMENT 'For map integration (requires spatial index)',
  `operating_hours` varchar(255) DEFAULT NULL,
  `contact_phone_1` varchar(20) DEFAULT NULL,
  `contact_phone_2` varchar(20) DEFAULT NULL,
  `shelf_template_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Chosen shelf template',
  `status` enum('pending_review','approved','rejected','suspended') NOT NULL DEFAULT 'pending_review',
  `allows_appointments` tinyint(1) NOT NULL DEFAULT 0,
  `allows_layby` tinyint(1) NOT NULL DEFAULT 0,
  `allows_reservations` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores details for supplier/brand owner businesses';

-- --------------------------------------------------------

--
-- Table structure for table `business_categories`
--

CREATE TABLE `business_categories` (
  `business_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Pivot table linking businesses to the types of fashion/accessories they offer';

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(110) NOT NULL COMMENT 'URL-friendly name',
  `description` text DEFAULT NULL,
  `parent_category_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'For sub-categories',
  `type` enum('fashion','accessories','pre_owned') NOT NULL COMMENT 'Broad type based on PDF',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Product and business categories (e.g., Streetwear, Shoes)';

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `parent_category_id`, `type`, `created_at`) VALUES
(1, 'Street wear', 'street-wear', NULL, NULL, 'fashion', '2025-05-10 20:29:07'),
(2, 'Shoes', 'shoes', NULL, NULL, 'fashion', '2025-05-10 20:29:07'),
(3, 'Handbags', 'handbags', NULL, NULL, 'accessories', '2025-05-10 20:29:07'),
(4, 'Formal Wear', 'formal-wear', NULL, NULL, 'fashion', '2025-05-10 20:29:07'),
(9, 'Tops', 'tops', NULL, NULL, 'fashion', '2025-05-10 20:46:19'),
(10, 'Bottoms', 'bottoms', NULL, NULL, 'fashion', '2025-05-10 20:46:19'),
(11, 'Footwear', 'footwear', NULL, NULL, 'fashion', '2025-05-10 20:46:19'),
(12, 'Bags', 'bags', NULL, NULL, 'accessories', '2025-05-10 20:46:19');

-- --------------------------------------------------------

--
-- Table structure for table `comment_likes`
--

CREATE TABLE `comment_likes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL COMMENT 'User who liked the comment',
  `comment_id` bigint(20) UNSIGNED NOT NULL COMMENT 'The comment that was liked',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Records likes on post comments';

-- --------------------------------------------------------

--
-- Table structure for table `conversations`
--

CREATE TABLE `conversations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `last_message_at` timestamp NULL DEFAULT NULL COMMENT 'Timestamp of the last message for sorting',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Represents a private chat session between users';

--
-- Dumping data for table `conversations`
--

INSERT INTO `conversations` (`id`, `last_message_at`, `created_at`, `updated_at`) VALUES
(1, '2025-05-09 19:57:52', '2025-05-09 19:57:52', '2025-05-09 19:57:52'),
(2, '2025-05-10 19:37:22', '2025-05-09 20:17:56', '2025-05-10 19:37:22'),
(3, '2025-05-10 21:04:25', '2025-05-10 21:04:25', '2025-05-10 21:04:25');

-- --------------------------------------------------------

--
-- Table structure for table `conversation_participants`
--

CREATE TABLE `conversation_participants` (
  `conversation_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_read_at` timestamp NULL DEFAULT NULL COMMENT 'Track when user last read messages in this convo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Links users to conversations';

--
-- Dumping data for table `conversation_participants`
--

INSERT INTO `conversation_participants` (`conversation_id`, `user_id`, `joined_at`, `last_read_at`) VALUES
(2, 1, '2025-05-09 20:17:56', '2025-05-10 19:07:56'),
(2, 2, '2025-05-09 20:17:56', '2025-05-10 19:37:19'),
(3, 2, '2025-05-10 21:04:25', '2025-05-10 21:04:25'),
(3, 4, '2025-05-10 21:04:25', '2025-05-10 21:04:25');

-- --------------------------------------------------------

--
-- Table structure for table `favorite_products`
--

CREATE TABLE `favorite_products` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores user favorite/wishlisted products';

-- --------------------------------------------------------

--
-- Table structure for table `follows`
--

CREATE TABLE `follows` (
  `follower_user_id` bigint(20) UNSIGNED NOT NULL COMMENT 'The user who is following',
  `following_user_id` bigint(20) UNSIGNED NOT NULL COMMENT 'The user being followed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Tracks user following relationships';

--
-- Dumping data for table `follows`
--

INSERT INTO `follows` (`follower_user_id`, `following_user_id`, `created_at`) VALUES
(2, 1, '2025-05-09 19:57:17'),
(3, 1, '2025-05-10 18:57:47');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `conversation_id` bigint(20) UNSIGNED NOT NULL,
  `sender_user_id` bigint(20) UNSIGNED NOT NULL,
  `message_text` text DEFAULT NULL,
  `media_url` varchar(255) DEFAULT NULL,
  `media_type` enum('image','video','file') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Individual messages within a conversation';

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `conversation_id`, `sender_user_id`, `message_text`, `media_url`, `media_type`, `created_at`) VALUES
(1, 2, 2, 'hi', NULL, NULL, '2025-05-09 20:46:20'),
(2, 2, 1, 'hello', NULL, NULL, '2025-05-09 20:48:38'),
(3, 2, 2, 'how are you doing', NULL, NULL, '2025-05-09 21:26:19'),
(4, 2, 2, 'hi', NULL, NULL, '2025-05-09 21:53:15'),
(5, 2, 1, 'Hello how are you', NULL, NULL, '2025-05-10 18:46:18'),
(6, 2, 2, 'Im good and you?', NULL, NULL, '2025-05-10 18:50:19'),
(7, 2, 1, 'good', NULL, NULL, '2025-05-10 18:50:39'),
(8, 2, 2, 'hhh', NULL, NULL, '2025-05-10 19:37:22');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) NOT NULL COMMENT 'Using UUID for potentially high volume',
  `user_id` bigint(20) UNSIGNED NOT NULL COMMENT 'The recipient user',
  `type` varchar(50) NOT NULL COMMENT 'e.g., new_follower, post_like, order_shipped, new_message, promotion',
  `message` text NOT NULL,
  `related_entity_type` varchar(50) DEFAULT NULL COMMENT 'e.g., user, post, order',
  `related_entity_id` varchar(36) DEFAULT NULL COMMENT 'ID of the related entity (can be user ID, post ID, order ID etc.) - Use VARCHAR for flexibility with UUIDs/BIGINTs',
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores notifications for users';

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `type`, `message`, `related_entity_type`, `related_entity_id`, `is_read`, `created_at`) VALUES
('035d8390afd1517053273b5c6b02b5aa2dc7', 1, 'new_follower', 'Doe started following you.', 'user', '3', 0, '2025-05-10 18:57:47'),
('50b4f4bf8c929bebe49a3e814de7392298d4', 1, 'new_follower', 'mabuza started following you.', 'user', '2', 0, '2025-05-09 19:57:17'),
('858e8fa87e85f503930d9e90744463717150', 1, 'new_follower', 'Doe started following you.', 'user', '3', 0, '2025-05-10 18:57:31');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL COMMENT 'The user who placed the order',
  `total_amount` decimal(12,2) NOT NULL,
  `status` enum('pending','processing','shipped','delivered','cancelled','refunded','reserved','reservation_expired','awaiting_payment') NOT NULL DEFAULT 'pending',
  `shipping_address` text DEFAULT NULL,
  `billing_address` text DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_status` enum('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
  `payment_gateway_ref` varchar(255) DEFAULT NULL COMMENT 'Reference from payment provider',
  `shipping_method` varchar(100) DEFAULT NULL,
  `shipping_cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tracking_number` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL COMMENT 'Optional notes from the customer',
  `reserved_until` timestamp NULL DEFAULT NULL COMMENT 'Timestamp for item reservation expiry',
  `reservation_qr_code` varchar(255) DEFAULT NULL COMMENT 'Data or identifier for QR code generation',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores customer orders';

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `business_id` bigint(20) UNSIGNED NOT NULL COMMENT 'Business fulfilling this item',
  `quantity` int(10) UNSIGNED NOT NULL,
  `price_at_time_of_order` decimal(10,2) NOT NULL COMMENT 'Price per item when ordered',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Individual items within an order';

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores tokens for password reset requests';

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL COMMENT 'The user who created the post',
  `description` text DEFAULT NULL COMMENT 'Caption for the post',
  `media_url` varchar(255) DEFAULT NULL COMMENT 'URL of the image or video',
  `media_type` enum('image','video') DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `visibility` enum('public','private','followers') NOT NULL DEFAULT 'public' COMMENT 'Closet visibility',
  `allow_comments` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='User-generated posts (Closet/Red Carpet)';

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `description`, `media_url`, `media_type`, `location`, `visibility`, `allow_comments`, `created_at`, `updated_at`) VALUES
(1, 1, 'I love this', 'uploads/posts/post_681a72658bd263.56064732.jpeg', 'image', NULL, 'public', 1, '2025-05-06 20:34:45', '2025-05-06 20:34:45'),
(2, 1, 'test 2', 'uploads/posts/post_681a7651d45164.55434754.jpeg', 'image', NULL, 'public', 1, '2025-05-06 20:51:29', '2025-05-06 20:51:29'),
(3, 1, 'Test 3', 'uploads/posts/post_681a76a4aa40f0.66416214.jpeg', 'image', NULL, 'public', 1, '2025-05-06 20:52:52', '2025-05-06 20:52:52'),
(5, 1, 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters,', 'uploads/posts/post_681e5607d5b296.24335635.mp4', 'video', NULL, 'public', 1, '2025-05-09 19:22:47', '2025-05-09 19:22:47'),
(6, 1, 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters,', 'uploads/posts/post_681e56281f9715.45946875.png', 'image', NULL, 'public', 1, '2025-05-09 19:23:20', '2025-05-09 19:23:20'),
(7, 2, 'hi', 'uploads/posts/681e7305b4e267.22485031.png', 'image', NULL, 'public', 1, '2025-05-09 21:26:29', '2025-05-09 21:26:29'),
(8, 1, 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the l', 'uploads/posts/681f9f60a8c1c3.84015788.jpeg', 'image', 'Gauteng', 'public', 1, '2025-05-10 18:48:00', '2025-05-10 18:48:00'),
(9, 2, 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the l', 'uploads/posts/681f9fcce78974.72014502.jpeg', 'image', 'France', 'public', 1, '2025-05-10 18:49:48', '2025-05-10 18:49:48');

-- --------------------------------------------------------

--
-- Table structure for table `post_comments`
--

CREATE TABLE `post_comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `comment_text` text NOT NULL,
  `parent_comment_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'For threaded replies',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Comments on posts';

--
-- Dumping data for table `post_comments`
--

INSERT INTO `post_comments` (`id`, `user_id`, `post_id`, `comment_text`, `parent_comment_id`, `created_at`, `updated_at`) VALUES
(1, 1, 3, 'hi', NULL, '2025-05-09 21:06:47', '2025-05-09 21:06:47'),
(2, 1, 3, 'hh', NULL, '2025-05-09 22:02:48', '2025-05-09 22:02:48'),
(3, 1, 6, 'First comment', NULL, '2025-05-10 18:43:22', '2025-05-10 18:43:22'),
(4, 1, 1, 'okay', NULL, '2025-05-10 18:44:39', '2025-05-10 18:44:39');

-- --------------------------------------------------------

--
-- Table structure for table `post_likes`
--

CREATE TABLE `post_likes` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Records likes on posts';

--
-- Dumping data for table `post_likes`
--

INSERT INTO `post_likes` (`user_id`, `post_id`, `created_at`) VALUES
(1, 1, '2025-05-10 18:44:33'),
(1, 3, '2025-05-09 21:06:42'),
(1, 6, '2025-05-09 22:03:17'),
(1, 8, '2025-05-10 18:48:12'),
(2, 1, '2025-05-10 20:50:49'),
(2, 7, '2025-05-09 21:26:37'),
(2, 8, '2025-05-10 19:35:52');

-- --------------------------------------------------------

--
-- Table structure for table `post_product_tags`
--

CREATE TABLE `post_product_tags` (
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Links posts to products mentioned/shown';

-- --------------------------------------------------------

--
-- Table structure for table `post_user_tags`
--

CREATE TABLE `post_user_tags` (
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `tagged_user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Links posts to users tagged in them';

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `business_id` bigint(20) UNSIGNED NOT NULL COMMENT 'The business selling this product',
  `name` varchar(255) NOT NULL,
  `slug` varchar(270) NOT NULL COMMENT 'URL-friendly name',
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock_quantity` int(11) NOT NULL DEFAULT 0,
  `sku` varchar(100) DEFAULT NULL COMMENT 'Stock Keeping Unit',
  `category_id` int(10) UNSIGNED DEFAULT NULL,
  `status` enum('active','inactive','draft','out_of_stock') NOT NULL DEFAULT 'draft',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Products offered by businesses';

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Pivot table linking products to categories (Many-to-Many)';

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `alt_text` varchar(255) DEFAULT NULL,
  `display_order` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores images associated with products';

-- --------------------------------------------------------

--
-- Table structure for table `product_reviews`
--

CREATE TABLE `product_reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `rating` tinyint(3) UNSIGNED NOT NULL COMMENT 'e.g., 1 to 5 stars',
  `comment` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='User reviews and ratings for products';

-- --------------------------------------------------------

--
-- Table structure for table `shelf_templates`
--

CREATE TABLE `shelf_templates` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `preview_image_url` varchar(255) DEFAULT NULL,
  `item_limit` int(10) UNSIGNED NOT NULL DEFAULT 30,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Price for using this template',
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Available shelf/store page templates for businesses';

-- --------------------------------------------------------

--
-- Table structure for table `stylist_tips`
--

CREATE TABLE `stylist_tips` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tipper_user_id` bigint(20) UNSIGNED NOT NULL COMMENT 'User giving the tip',
  `stylist_user_id` bigint(20) UNSIGNED NOT NULL COMMENT 'Stylist receiving the tip',
  `order_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Optional: Link tip to a specific order',
  `amount` decimal(10,2) NOT NULL,
  `message` varchar(255) DEFAULT NULL,
  `status` enum('pending','paid','failed') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Records tips given to stylists';

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `role` enum('user','supplier','brand_owner','stylist','admin') NOT NULL DEFAULT 'user',
  `profile_bio` text DEFAULT NULL,
  `profile_picture_url` varchar(255) DEFAULT NULL,
  `stylist_wallet_balance` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'For stylist tips',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_verified` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Email verification status',
  `last_login_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores all user accounts and their roles';

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `full_name`, `role`, `profile_bio`, `profile_picture_url`, `stylist_wallet_balance`, `is_active`, `is_verified`, `last_login_at`, `created_at`, `updated_at`) VALUES
(1, 'Zitha', 'zithazweloj@gmail.com', '$2y$10$wsMwHM0LFs5R2GSHLlYFEeDywczIabgrkS5/0syvZWRxhOVFjnxCK', 'Innocent Zwelo', 'user', '', 'uploads/avatars/avatar_1_1746819363.png', 0.00, 1, 0, NULL, '2025-05-05 20:47:01', '2025-05-09 19:36:03'),
(2, 'mabuza', 'mabuza@gmail.com', '$2y$10$AFbcx.0w3O5jeE7u0C0uIuMrfNkjgfDYoQI8SFv4kdu/m6xPDvFU.', 'Innocent', 'user', '', 'uploads/avatars/avatar_2_1746905860.jpeg', 0.00, 1, 0, NULL, '2025-05-06 18:10:54', '2025-05-10 19:37:40'),
(3, 'Doe', 'james@gmail.com', '$2y$10$w6Vdt09539IeubvSp5yxWecsBssRg3YQ7b9q4Pshu.dLws9BBkKQu', 'James', 'user', 'asdsueihekandfsvbhjxzdsfoxcbjckjbdfgfoibdgfoivbk', 'uploads/avatars/avatar_3_1746903498.jpeg', 0.00, 1, 0, NULL, '2025-05-10 18:54:17', '2025-05-10 18:58:18'),
(4, 'monasane', 'monasane@gmail.com', '$2y$10$vYgUIrFYdG22jl9cp7d3GuqwmefZMiFzaKEPXK/HD.rvHz47U5OUy', 'Innocent Zwelo', 'supplier', '', 'uploads/avatars/avatar_4_1746906656.png', 0.00, 1, 0, NULL, '2025-05-10 19:49:01', '2025-05-10 19:50:56');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `business_id` (`business_id`),
  ADD KEY `idx_appointment_datetime` (`appointment_datetime`),
  ADD KEY `idx_appointment_status` (`status`);

--
-- Indexes for table `businesses`
--
ALTER TABLE `businesses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD KEY `shelf_template_id` (`shelf_template_id`),
  ADD KEY `idx_business_name` (`business_name`),
  ADD SPATIAL KEY `idx_business_location` (`pinpoint_location`);

--
-- Indexes for table `business_categories`
--
ALTER TABLE `business_categories`
  ADD PRIMARY KEY (`business_id`,`category_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `parent_category_id` (`parent_category_id`),
  ADD KEY `idx_category_slug` (`slug`);

--
-- Indexes for table `comment_likes`
--
ALTER TABLE `comment_likes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_user_comment_like` (`user_id`,`comment_id`),
  ADD KEY `idx_comment_like_comment` (`comment_id`);

--
-- Indexes for table `conversations`
--
ALTER TABLE `conversations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conversation_participants`
--
ALTER TABLE `conversation_participants`
  ADD PRIMARY KEY (`conversation_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `favorite_products`
--
ALTER TABLE `favorite_products`
  ADD PRIMARY KEY (`user_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `follows`
--
ALTER TABLE `follows`
  ADD PRIMARY KEY (`follower_user_id`,`following_user_id`),
  ADD KEY `following_user_id` (`following_user_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `conversation_id` (`conversation_id`),
  ADD KEY `sender_user_id` (`sender_user_id`),
  ADD KEY `idx_message_created` (`created_at`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_notification_user_read` (`user_id`,`is_read`,`created_at`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_order_status` (`status`),
  ADD KEY `idx_order_user` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `idx_order_item_product` (`product_id`),
  ADD KEY `idx_order_item_business` (`business_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`),
  ADD KEY `idx_password_reset_token` (`token`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_post_visibility` (`visibility`),
  ADD KEY `idx_post_created` (`created_at`);

--
-- Indexes for table `post_comments`
--
ALTER TABLE `post_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `idx_comment_parent` (`parent_comment_id`);

--
-- Indexes for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD PRIMARY KEY (`user_id`,`post_id`),
  ADD KEY `post_id` (`post_id`);

--
-- Indexes for table `post_product_tags`
--
ALTER TABLE `post_product_tags`
  ADD PRIMARY KEY (`post_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `post_user_tags`
--
ALTER TABLE `post_user_tags`
  ADD PRIMARY KEY (`post_id`,`tagged_user_id`),
  ADD KEY `tagged_user_id` (`tagged_user_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD UNIQUE KEY `sku` (`sku`),
  ADD KEY `business_id` (`business_id`),
  ADD KEY `idx_product_name` (`name`),
  ADD KEY `idx_product_slug` (`slug`),
  ADD KEY `idx_product_status` (`status`),
  ADD KEY `fk_product_category` (`category_id`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`product_id`,`category_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_product_image_order` (`product_id`,`display_order`);

--
-- Indexes for table `product_reviews`
--
ALTER TABLE `product_reviews`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_user_product_review` (`user_id`,`product_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `idx_review_rating` (`rating`);

--
-- Indexes for table `shelf_templates`
--
ALTER TABLE `shelf_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stylist_tips`
--
ALTER TABLE `stylist_tips`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tipper_user_id` (`tipper_user_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `idx_tip_stylist` (`stylist_user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_user_role` (`role`),
  ADD KEY `idx_user_email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `businesses`
--
ALTER TABLE `businesses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `comment_likes`
--
ALTER TABLE `comment_likes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `conversations`
--
ALTER TABLE `conversations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `post_comments`
--
ALTER TABLE `post_comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_reviews`
--
ALTER TABLE `product_reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shelf_templates`
--
ALTER TABLE `shelf_templates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stylist_tips`
--
ALTER TABLE `stylist_tips`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `businesses`
--
ALTER TABLE `businesses`
  ADD CONSTRAINT `businesses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `businesses_ibfk_2` FOREIGN KEY (`shelf_template_id`) REFERENCES `shelf_templates` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `business_categories`
--
ALTER TABLE `business_categories`
  ADD CONSTRAINT `business_categories_ibfk_1` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `business_categories_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`parent_category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `comment_likes`
--
ALTER TABLE `comment_likes`
  ADD CONSTRAINT `fk_comment_likes_comment` FOREIGN KEY (`comment_id`) REFERENCES `post_comments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_comment_likes_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `conversation_participants`
--
ALTER TABLE `conversation_participants`
  ADD CONSTRAINT `conversation_participants_ibfk_1` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `conversation_participants_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `favorite_products`
--
ALTER TABLE `favorite_products`
  ADD CONSTRAINT `favorite_products_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `favorite_products_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `follows`
--
ALTER TABLE `follows`
  ADD CONSTRAINT `follows_ibfk_1` FOREIGN KEY (`follower_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `follows_ibfk_2` FOREIGN KEY (`following_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`sender_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `order_items_ibfk_3` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`);

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `post_comments`
--
ALTER TABLE `post_comments`
  ADD CONSTRAINT `post_comments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `post_comments_ibfk_2` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `post_comments_ibfk_3` FOREIGN KEY (`parent_comment_id`) REFERENCES `post_comments` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD CONSTRAINT `post_likes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `post_likes_ibfk_2` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `post_product_tags`
--
ALTER TABLE `post_product_tags`
  ADD CONSTRAINT `post_product_tags_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `post_product_tags_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `post_user_tags`
--
ALTER TABLE `post_user_tags`
  ADD CONSTRAINT `post_user_tags_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `post_user_tags_ibfk_2` FOREIGN KEY (`tagged_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_product_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD CONSTRAINT `product_categories_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_categories_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_reviews`
--
ALTER TABLE `product_reviews`
  ADD CONSTRAINT `product_reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_reviews_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `stylist_tips`
--
ALTER TABLE `stylist_tips`
  ADD CONSTRAINT `stylist_tips_ibfk_1` FOREIGN KEY (`tipper_user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `stylist_tips_ibfk_2` FOREIGN KEY (`stylist_user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `stylist_tips_ibfk_3` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
