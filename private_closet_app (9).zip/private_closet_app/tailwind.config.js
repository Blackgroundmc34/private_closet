/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["./**/*.php"],
    theme: {
      extend: {
        colors: {
          primary: '#000000',
          secondary: '#FFD700', // Gold/Yellow
        },
      },
    },
    plugins: [],
  };
  