<?php
// File: public/boardroom.php
// Purpose: Assembles the Boardroom (Messaging) page.
// NOTE: For dynamic, real-time features, AJAX calls should be directed to
// MessageController actions (e.g., /boardroom/send, /boardroom/ajax/messages)
// This script can still serve the initial page load if not using a full router to MessageController::showBoardroom().
// However, it's recommended to transition fully to the MessageController for consistency.

// --- 1. Setup & Load Core Files ---
require_once __DIR__ . '/../app/bootstrap.php'; // Handles session_start, $pdo, APP_URL, helpers

// --- Load MessageModel ---
require_once __DIR__ . '/../app/Models/MessageModel.php';
// Assuming utilities.php (with escape_html) is loaded by bootstrap.php

// --- 2. Authentication Check ---
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_to'] = APP_URL . '/boardroom.php'; 
    header('Location: ' . APP_URL . '/login'); 
    exit;
}
$loggedInUserId = (int)$_SESSION['user_id'];

// --- 3. Define Page Specific Variables ---
$pageTitle = "Boardroom - Private Closet";
$conversations = [];
$selectedConversationId = null;
$messages = [];
$recipient = null; 
$sendMessageStatus = ''; 
$pageContentError = null;
$initialLastMessageTimestamp = 0;


// --- 4. Instantiate Model ---
if (!isset($pdo)) {
    // This should ideally be caught by bootstrap.php or a global error handler
    error_log("Database connection is not available in boardroom.php. Ensure bootstrap.php sets up \$pdo.");
    die("Database connection is not available. Please check configuration.");
}
$messageModel = new MessageModel($pdo);

// --- 5. Handle Actions (e.g., sending a message, starting a new conversation) ---
// NOTE: Sending messages should ideally be handled by an AJAX call to MessageController::handleSendMessage()
// For backward compatibility or non-JS scenarios, this POST handling can remain, but it will cause a full page reload.

// Start new conversation (e.g., from a user profile link: boardroom.php?start_with_user=USER_ID)
if (isset($_GET['start_with_user']) && is_numeric($_GET['start_with_user'])) {
    $otherUserId = (int)$_GET['start_with_user'];
    if ($otherUserId !== $loggedInUserId) {
        $conversationId = $messageModel->findOrCreateConversation($loggedInUserId, $otherUserId);
        if ($conversationId) {
            // Redirect to this conversation to load messages
            header('Location: ' . APP_URL . '/boardroom.php?conversation_id=' . $conversationId);
            exit;
        } else {
            $sendMessageStatus = "Could not start a conversation with that user.";
            // Potentially set a flash message if using a flash message system
        }
    }
}


// Handle sending a new message (Non-AJAX fallback)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'send_message') {
    // CSRF token validation would go here
    $messageText = trim($_POST['message_text'] ?? '');
    $conversationIdForSend = filter_input(INPUT_POST, 'conversation_id', FILTER_VALIDATE_INT);

    if (!empty($messageText) && $conversationIdForSend) {
        if ($messageModel->isUserParticipant($loggedInUserId, $conversationIdForSend)) {
            $newMessage = $messageModel->sendMessage($conversationIdForSend, $loggedInUserId, $messageText);
            if ($newMessage) {
                // Refresh the page to show the new message and clear POST data
                // This is a full page reload, AJAX method in MessageController is preferred.
                header('Location: ' . APP_URL . '/boardroom.php?conversation_id=' . $conversationIdForSend);
                exit;
            } else {
                $sendMessageStatus = "Failed to send message. Please try again.";
            }
        } else {
             $sendMessageStatus = "You are not authorized to send messages to this conversation.";
        }
        $selectedConversationId = $conversationIdForSend; 
    } elseif (empty($messageText)) {
        $sendMessageStatus = "Message cannot be empty.";
        $selectedConversationId = $conversationIdForSend;
    } else {
        $sendMessageStatus = "Invalid request to send message.";
    }
    // Store $sendMessageStatus in session flash if redirecting, or pass to view.
    // For simplicity, if it reaches here with $sendMessageStatus, it will be displayed on current page load.
}


// --- 6. Load Data for Display ---
try {
    $conversations = $messageModel->getUserConversations($loggedInUserId);

    if (isset($_GET['conversation_id']) && is_numeric($_GET['conversation_id'])) {
        $currentSelectedConvId = (int)$_GET['conversation_id'];
        if ($messageModel->isUserParticipant($loggedInUserId, $currentSelectedConvId)) {
            $selectedConversationId = $currentSelectedConvId;
        } else {
            // User is trying to access a conversation they are not part of.
            // Redirect to base boardroom or show an error.
            // For now, just nullify to prevent loading messages.
            $selectedConversationId = null; 
            $pageContentError = "You are not authorized to view this conversation.";
            // Or: header('Location: ' . APP_URL . '/boardroom.php'); exit;
        }
    } elseif (!empty($conversations)) {
        // Default to the first conversation if none is selected via GET
        // To avoid issues with page reloads, redirect to a URL with conversation_id
        header('Location: ' . APP_URL . '/boardroom.php?conversation_id=' . $conversations[0]['conversation_id']);
        exit;
    }

    if ($selectedConversationId && !$pageContentError) {
        $messages = $messageModel->getMessages($selectedConversationId, $loggedInUserId);
        $recipient = $messageModel->getRecipientDetails($selectedConversationId, $loggedInUserId);
        if(!empty($messages)) {
            $lastMessage = end($messages); // Get the last message
            $initialLastMessageTimestamp = $lastMessage['message_timestamp'] ?? 0; // Get its timestamp
        }
    }

} catch (\Exception $e) {
    error_log("Error in Boardroom data loading (boardroom.php): " . $e->getMessage());
    $pageContentError = "An error occurred while loading your messages. Please try again later.";
}


// --- 7. Include Header ---
$viewPath = __DIR__ . '/../app/Views/';
require_once $viewPath . 'layouts/_header.php'; 

// --- 8. Include Page Content ---
// The variables $conversations, $selectedConversationId, $messages, $recipient, 
// $loggedInUserId, $sendMessageStatus, $initialLastMessageTimestamp, $pageContentError will be available 
// in boardroom_content.php.
if (isset($pageContentError) && $pageContentError) {
    echo '<div class="container mx-auto px-4 py-8"><p class="text-red-500">' . htmlspecialchars($pageContentError) . '</p></div>';
} else {
    // Pass APP_URL to the view for JavaScript to use in AJAX calls
    $viewData = [
        'conversations' => $conversations,
        'selectedConversationId' => $selectedConversationId,
        'messages' => $messages,
        'recipient' => $recipient,
        'loggedInUserId' => $loggedInUserId,
        'sendMessageStatus' => $sendMessageStatus,
        'initialLastMessageTimestamp' => $initialLastMessageTimestamp,
        'appUrl' => APP_URL // Make APP_URL available to the view
    ];
    // Extract data for boardroom_content.php
    extract($viewData);
    require_once $viewPath . 'social/boardroom_content.php';
}

// --- 9. Include Footer ---
require_once $viewPath . 'layouts/_footer.php';

?>