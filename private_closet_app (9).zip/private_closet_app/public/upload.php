<?php
// File: public/upload.php
// Purpose: Provides a page for users to upload files and create posts.

// --- 1. Setup & Load Core Files ---
require_once __DIR__ . '/../app/bootstrap.php';
require_once __DIR__ . '/../app/Models/PostModel.php'; 

// --- Check if user is logged in ---
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_to'] = APP_URL . '/upload.php'; 
    if (defined('APP_URL')) { 
        header('Location: ' . APP_URL . '/login'); 
    } else {
        header('Location: /login'); 
    }
    exit;
}

// --- 2. Define Page Specific Variables ---
$pageTitle = "Upload New Post - Private Closet";
$uploadMessage = '';
$uploadStatus = ''; // 'success' or 'error'

// --- 3. Handle File Upload (POST Request) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // --- CSRF Token Validation (Highly Recommended - Implement this) ---
    
    if (isset($_FILES['mediaFile']) && $_FILES['mediaFile']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['mediaFile'];
        $description = isset($_POST['description']) ? trim($_POST['description']) : null;
        $visibility = isset($_POST['visibility']) ? $_POST['visibility'] : 'public';

        $allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif', 'video/mp4'];
        $maxFileSize = 5 * 1024 * 1024; // 5 MB

        if (!in_array($file['type'], $allowedMimeTypes)) {
            $uploadMessage = "Invalid file type. Allowed types: JPEG, PNG, GIF, MP4.";
            $uploadStatus = 'error';
        } elseif ($file['size'] > $maxFileSize) {
            $uploadMessage = "File is too large. Maximum size is " . ($maxFileSize / 1024 / 1024) . " MB.";
            $uploadStatus = 'error';
        } else {
            $fileName = basename($file['name']);
            $safeFileName = preg_replace('/[^A-Za-z0-9_.-]/', '_', $fileName);
            $fileExtension = strtolower(pathinfo($safeFileName, PATHINFO_EXTENSION));
            $uniqueFileName = uniqid('post_', true) . '.' . $fileExtension;
            
            // ***** CORRECTED UPLOAD DIRECTORY *****
            // __DIR__ is C:\xampp\htdocs\private_closet_app\public
            // We want to save into C:\xampp\htdocs\private_closet_app\public\uploads\posts\
            $uploadDir = __DIR__ . '/uploads/posts/'; 
            // ***** END CORRECTION *****

            if (!is_dir($uploadDir)) {
                if (!mkdir($uploadDir, 0755, true)) { // Create recursive if not exists
                    $uploadMessage = "Error: Could not create upload directory. Path: " . htmlspecialchars($uploadDir) . ". Check permissions.";
                    $uploadStatus = 'error';
                }
            }

            if ($uploadStatus !== 'error') { 
                $uploadPath = $uploadDir . $uniqueFileName;

                if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
                    if (isset($pdo) && class_exists('PostModel')) {
                        $postModel = new PostModel($pdo);
                        $userId = (int)$_SESSION['user_id']; 
                        
                        $mediaType = null;
                        if (strpos($file['type'], 'image/') === 0) $mediaType = 'image';
                        elseif (strpos($file['type'], 'video/') === 0) $mediaType = 'video';

                        // This path is relative to the public directory, which is correct for web access.
                        $mediaUrlForDb = 'uploads/posts/' . $uniqueFileName; 

                        $postId = $postModel->createPost($userId, $description, $mediaUrlForDb, $mediaType, $visibility);

                        if ($postId) {
                            $uploadMessage = "Post created successfully! ";
                            if (defined('APP_URL')) {
                                $uploadMessage .= "<a href='" . APP_URL . "/post/" . $postId . "' class='font-semibold underline hover:text-indigo-800'>View Post</a>";
                            }
                            $uploadStatus = 'success';
                        } else {
                            $uploadMessage = "File uploaded, but failed to create post entry in the database. Please try again. Check server logs for more details.";
                            $uploadStatus = 'error';
                            if (file_exists($uploadPath)) unlink($uploadPath); 
                        }
                    } else {
                        $uploadMessage = "File uploaded, but the database connection or PostModel is not available. Post not saved.";
                        $uploadStatus = 'error';
                        if (file_exists($uploadPath)) unlink($uploadPath); 
                    }
                } else {
                    $uploadMessage = "Failed to move uploaded file. Target: " . htmlspecialchars($uploadPath) . ". Check server permissions or path configuration.";
                    $uploadStatus = 'error';
                }
            }
        }
    } elseif (isset($_FILES['mediaFile']['error']) && $_FILES['mediaFile']['error'] !== UPLOAD_ERR_NO_FILE) {
        // ... (existing error handling for other upload errors) ...
        $uploadErrors = [
            UPLOAD_ERR_INI_SIZE   => "The uploaded file exceeds the server's maximum upload size limit (upload_max_filesize).",
            UPLOAD_ERR_FORM_SIZE  => "The uploaded file exceeds the form's maximum file size limit (MAX_FILE_SIZE).",
            UPLOAD_ERR_PARTIAL    => "The uploaded file was only partially uploaded. Please try again.",
            UPLOAD_ERR_NO_TMP_DIR => "Server configuration error: Missing a temporary folder for uploads.",
            UPLOAD_ERR_CANT_WRITE => "Server error: Failed to write file to disk. Check permissions.",
            UPLOAD_ERR_EXTENSION  => "A PHP extension stopped the file upload. Contact the administrator.",
        ];
        $errorCode = $_FILES['mediaFile']['error'];
        $uploadMessage = $uploadErrors[$errorCode] ?? "An unknown error occurred during file upload (Code: {$errorCode}).";
        $uploadStatus = 'error';

    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') { 
        $uploadMessage = "Please select a media file to upload.";
        $uploadStatus = 'error';
    }
}

// --- 4. Include Header ---
$viewPath = __DIR__ . '/../app/Views/';
require_once $viewPath . 'layouts/_header.php'; 
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-2xl font-bold mb-6 text-gray-800">Create New Post</h1>

    <?php if ($uploadMessage): ?>
        <div class="mb-4 p-4 rounded-md <?php echo $uploadStatus === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
            <?php echo $uploadMessage; ?>
        </div>
    <?php endif; ?>

    <form action="<?php echo defined('APP_URL') ? (APP_URL . '/upload.php') : '/upload.php'; ?>" method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded-lg shadow-md">
        <div class="mb-4">
            <label for="mediaFile" class="block text-sm font-medium text-gray-700 mb-1">Media File (Image or Video):</label>
            <input type="file" name="mediaFile" id="mediaFile" required class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
            <p class="text-xs text-gray-500 mt-1">Allowed types: JPG, PNG, GIF, MP4. Max size: 5MB.</p>
        </div>
        <div class="mb-4">
            <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Description/Caption:</label>
            <textarea name="description" id="description" rows="4" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" placeholder="Tell us about your item..."></textarea>
        </div>
        <div class="mb-6">
            <label for="visibility" class="block text-sm font-medium text-gray-700 mb-1">Visibility:</label>
            <select name="visibility" id="visibility" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                <option value="public" selected>Public</option>
                <option value="followers">Followers Only</option>
                <option value="private">Private (Only Me)</option>
            </select>
        </div>
        <div>
            <button type="submit" class="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                Upload Post
            </button>
        </div>
    </form>
</div>

<?php
// --- 5. Include Footer ---
require_once $viewPath . 'layouts/_footer.php';
?>
