<?php
// File: public/index.php
if (defined('DEBUG_MODE') && DEBUG_MODE) { // Assuming DEBUG_MODE is true in your config.php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
}
// Purpose: Acts as the Front Controller. All public requests are routed through this file.

// --- 1. Bootstrap Application ---
require_once __DIR__ . '/../app/bootstrap.php'; // Handles sessions, DB, config, helpers

// --- 2. Define Publicly Accessible Routes ---
$publicRoutes = [
    '',             // Root/homepage
    'showroom',
    'login',
    'register',
    'forgot-password',
    'reset-password',
    'product',
    'cart', // Cart is public
    'reels', // Reels are public
    'search' // Search is public
    // Add other public routes like 'about', 'contact', 'terms', etc.
];

// --- 3. Get Route Information ---
$request_uri = $_SERVER['REQUEST_URI'] ?? '/';
$script_name = $_SERVER['SCRIPT_NAME']; // Path to index.php
$script_dir = str_replace('\\', '/', dirname($script_name));
$base_path = ($script_dir === '/') ? '' : rtrim($script_dir, '/'); // e.g. /private_closet_app/public
$requestPath = parse_url($request_uri, PHP_URL_PATH); // e.g. /private_closet_app/public/cart/add

// Calculate the route relative to the base_path
if ($base_path && strpos($requestPath, $base_path) === 0) {
    $route = substr($requestPath, strlen($base_path)); // e.g. /cart/add
} else {
    $route = $requestPath; // e.g. /cart/add if base_path is empty (app in root)
}

$route = trim($route, '/'); // e.g. cart/add
$routeParts = ($route === '') ? [] : explode('/', $route);
$currentRouteBase = $routeParts[0] ?? ''; // e.g., 'cart'
$requestMethod = $_SERVER['REQUEST_METHOD'];

// Enhanced Logging for routing diagnostics
error_log(
    "INDEX.PHP START: Request URI='{$request_uri}', BasePath='{$base_path}', " .
    "RouteBeforeTrim='{$requestPath}', RouteAfterTrim='{$route}', " .
    "RoutePartsCount=" . count($routeParts) . ", CurrentRouteBase='{$currentRouteBase}', Method='{$requestMethod}'"
);
if (!empty($routeParts)) {
    for ($i = 0; $i < count($routeParts); $i++) {
        error_log("INDEX.PHP RouteParts[{$i}]: " . ($routeParts[$i] ?? 'N/A'));
    }
}


// --- 4. Authentication Check for Protected Routes ---
$isLoggedIn = isset($_SESSION['user_id']);

if (
    !in_array($currentRouteBase, $publicRoutes) && !$isLoggedIn &&
    !in_array($currentRouteBase, ['login', 'register'])
) { // Allow access to login/register
    error_log("INDEX: Auth check failed for route '{$currentRouteBase}'. User not logged in. Redirecting to login.");
    $_SESSION['redirect_to'] = $_SERVER['REQUEST_URI']; // Save intended destination
    redirect(APP_URL . '/login');
    exit; // Ensure script stops after redirect
}

// --- 5. Load Controller Classes ---
require_once __DIR__ . '/../app/Controllers/ShopController.php';
require_once __DIR__ . '/../app/Controllers/UserController.php';
require_once __DIR__ . '/../app/Controllers/PostController.php';
require_once __DIR__ . '/../app/Controllers/AuthController.php';
require_once __DIR__ . '/../app/Controllers/ErrorController.php';
require_once __DIR__ . '/../app/Controllers/MessageController.php';
require_once __DIR__ . '/../app/Controllers/SupplierController.php';
require_once __DIR__ . '/../app/Controllers/SearchController.php';
require_once __DIR__ . '/../app/Controllers/AdminController.php';
require_once __DIR__ . '/../app/Controllers/CartController.php';

// --- 6. Instantiate Controllers ---
try {
    if (!isset($pdo) || !($pdo instanceof PDO)) {
        throw new RuntimeException('Database connection ($pdo) is not established or is not a valid PDO object. Check app/database.php and app/bootstrap.php.');
    }
    $errorController = new ErrorController();
    $shopController = new ShopController($pdo);
    $userController = new UserController($pdo);
    $postController = new PostController($pdo);
    $authController = new AuthController($pdo);
    $messageController = new MessageController($pdo);
    $supplierController = new SupplierController($pdo);
    $searchController = new SearchController($pdo);
    $cartController = new CartController($pdo); // Instantiate CartController
    if (class_exists('AdminController')) { // Conditionally instantiate AdminController
        $adminController = new AdminController($pdo);
    }


} catch (Throwable $e) {
    error_log("INDEX: CRITICAL - Controller Instantiation Error: " . $e->getMessage() . "\n" . $e->getTraceAsString());
    http_response_code(500);
    echo "<h1>Application Error</h1><p>An error occurred during application initialization. Please try again later.</p>";
    if (defined('DEBUG_MODE') && DEBUG_MODE) {
        echo "<hr><h3>Debug Information (Controller Instantiation):</h3><pre>" . htmlspecialchars($e->getMessage()) . "\n" . htmlspecialchars($e->getTraceAsString()) . "</pre>";
    }
    exit;
}

// --- 7. Route Dispatching ---
try {
    error_log("INDEX.PHP ROUTING: Attempting to route for currentRouteBase = '{$currentRouteBase}'");

    switch ($currentRouteBase) {
        case '':
        case 'showroom':
            $shopController->showroom();
            break;

        case 'reels':
            if ($postController && method_exists($postController, 'showReelsFeed')) {
                error_log("INDEX.PHP: Routing to PostController->showReelsFeed()");
                $postController->showReelsFeed();
            } else {
                error_log("INDEX.PHP: /reels route hit, but PostController or showReelsFeed method is missing or not callable.");
                $errorController->notFound("Reels feature is currently unavailable.");
            }
            break;

        case 'search':
            $searchController->index();
            break;

        case 'admin':
            if (!isset($adminController)) {
                $errorController->serverError("Admin module not available.");
                break;
            }
            $adminAction = $routeParts[1] ?? 'dashboard';
            error_log("INDEX.PHP ADMIN ROUTING: adminAction = '{$adminAction}'");
            switch ($adminAction) {
                case 'dashboard':
                    $errorController->notFound("Admin dashboard not implemented yet.");
                    break;
                case 'categories':
                    $categoryAction = $routeParts[2] ?? 'list';
                    if ($categoryAction === 'list' && $requestMethod === 'GET' && method_exists($adminController, 'listCategories')) {
                        $adminController->listCategories();
                    } elseif ($categoryAction === 'add' && $requestMethod === 'GET' && method_exists($adminController, 'showAddCategoryForm')) {
                        $adminController->showAddCategoryForm();
                    } elseif ($categoryAction === 'add' && $requestMethod === 'POST' && method_exists($adminController, 'handleAddCategory')) {
                        $adminController->handleAddCategory();
                    } else {
                        $errorController->notFound("Invalid admin category action: " . htmlspecialchars($categoryAction));
                    }
                    break;
                default:
                    $errorController->notFound("Invalid admin action: " . htmlspecialchars($adminAction));
                    break;
            }
            break;

        case 'product':
            $identifier = $routeParts[1] ?? null;
            if ($identifier) {
                $shopController->productDetail($identifier);
            } else {
                $errorController->notFound("Product identifier missing for route: " . htmlspecialchars($route));
            }
            break;

        case 'profile':
            $username = $routeParts[1] ?? null;
            $action = $routeParts[2] ?? null; // Check for a third part, e.g., 'orders'

            if ($username) {
                if ($action === 'orders') {
                    // Route to a new method in UserController for displaying orders
                    if (method_exists($userController, 'showUserOrders')) {
                        error_log("INDEX.PHP: Routing to UserController->showUserOrders() for user: {$username}");
                        $userController->showUserOrders($username);
                    } else {
                        error_log("INDEX.PHP: Method showUserOrders not found in UserController.");
                        $errorController->notFound("User orders page not available.");
                    }
                } else if ($action === null) {
                    // Original profile view
                    error_log("INDEX.PHP: Routing to UserController->profile() for user: {$username}");
                    $userController->profile($username);
                } else {
                    // Unknown action under profile
                    $errorController->notFound("Invalid profile action: " . htmlspecialchars($action));
                }
            } elseif ($isLoggedIn && isset($_SESSION['username'])) {
                // If accessing /profile without a username and logged in, redirect to own profile
                redirect(APP_URL . '/profile/' . $_SESSION['username']);
            } else {
                // If no username and not logged in, or trying an invalid path like /profile/
                $_SESSION['redirect_to'] = APP_URL . '/profile'; // Or just redirect to login
                redirect(APP_URL . '/login');
            }
            break;

        case 'login':
            if ($isLoggedIn) {
                redirect(APP_URL . '/showroom');
            }
            if ($requestMethod === 'POST') {
                $authController->handleLogin();
            } else {
                $authController->showLogin();
            }
            break;

        case 'register':
            if ($isLoggedIn) {
                redirect(APP_URL . '/showroom');
            }
            if ($requestMethod === 'POST') {
                $authController->handleRegister();
            } else {
                $authController->showRegister();
            }
            break;

        case 'logout':
            $authController->logout();
            break;

        case 'upload': // For social post creation
            if (!$isLoggedIn) {
                redirect(APP_URL . '/login');
            }
            if ($requestMethod === 'POST') {
                $postController->handleUpload();
            } else {
                $postController->showUploadForm();
            }
            break;

        case 'closets': // User's social feed
            if (!$isLoggedIn) {
                redirect(APP_URL . '/login');
            }
            if (method_exists($userController, 'showClosetFeed')) {
                $userController->showClosetFeed();
            } else {
                $errorController->notFound("Closet feed route not implemented.");
            }
            break;

        case 'explore': // NEW ROUTE FOR EXPLORING
            if (isset($routeParts[1]) && $routeParts[1] === 'users') {
                if (!$isLoggedIn) {
                    $_SESSION['redirect_to'] = APP_URL . '/explore/users';
                    redirect(APP_URL . '/login');
                    exit;
                }
                // Ensure UserController instance is available
                if (isset($userController) && method_exists($userController, 'showExploreUsersPage')) {
                    $userController->showExploreUsersPage();
                } else {
                    $errorController->serverError("User exploration feature is currently unavailable.");
                }
            } else {
                $errorController->notFound("Invalid explore route: /" . htmlspecialchars($route));
            }
            break;

        case 'post': // Social post interactions
            $postIdSegment = $routeParts[1] ?? null;
            if ($postIdSegment !== null && is_numeric($postIdSegment)) {
                $postId = (int) $postIdSegment;
                $action = $routeParts[2] ?? null; // e.g., 'edit', 'delete', 'toggle-like', 'add-comment'

                if ($requestMethod === 'GET' && $action === null) { // View single post: GET /post/{id}
                    $postController->show($postId);
                } elseif ($requestMethod === 'GET' && $action === 'edit') { // Show edit form: GET /post/{id}/edit
                    if (!$isLoggedIn) {
                        redirect(APP_URL . '/login');
                    }
                    if (method_exists($postController, 'showEditForm')) {
                        $postController->showEditForm($postId);
                    } else {
                        $errorController->notFound("Edit post form feature not available.");
                    }
                } elseif ($requestMethod === 'POST' && $action === 'update') { // Handle edit form submission: POST /post/{id}/update
                    if (!$isLoggedIn) {
                        redirect(APP_URL . '/login');
                    }
                    if (method_exists($postController, 'handleUpdate')) {
                        $postController->handleUpdate($postId);
                    } else {
                        $errorController->notFound("Update post feature not available.");
                    }
                } elseif ($requestMethod === 'POST' && $action === 'delete') { // Delete post: POST /post/{id}/delete
                    if (!$isLoggedIn) {
                        redirect(APP_URL . '/login');
                    }
                    if (method_exists($postController, 'handleDelete')) {
                        $postController->handleDelete($postId);
                    } else {
                        $errorController->notFound("Delete post feature not available.");
                    }
                } elseif ($requestMethod === 'POST' && $action === 'toggle-like') { // AJAX: POST /post/{id}/toggle-like
                    $postController->handleToggleLike($postId);
                } elseif ($requestMethod === 'POST' && $action === 'add-comment') { // AJAX: POST /post/{id}/add-comment
                    $postController->handleAddComment($postId);
                } else {
                    $errorController->notFound("Invalid action or method for post route: " . htmlspecialchars($route));
                }
            } else {
                $errorController->notFound("Invalid or missing post identifier for route: " . htmlspecialchars($route));
            }
            break;

        case 'boardroom': // Messaging feature
            if (!$isLoggedIn) {
                redirect(APP_URL . '/login');
            }
            $action = $routeParts[1] ?? 'show';

            if ($requestMethod === 'GET' && $action === 'show') {
                $messageController->showBoardroom();
            } elseif ($requestMethod === 'POST' && $action === 'send') {
                $messageController->handleSendMessage();
            } elseif ($requestMethod === 'GET' && $action === 'ajax' && isset($routeParts[2])) {
                $ajaxAction = $routeParts[2];
                if ($ajaxAction === 'messages') {
                    $messageController->ajaxFetchNewMessages();
                } elseif ($ajaxAction === 'conversations') {
                    $messageController->ajaxFetchUserConversations();
                } else {
                    $errorController->notFound("Invalid AJAX action for boardroom: " . htmlspecialchars($route));
                }
            } else {
                $errorController->notFound("Invalid boardroom action or method: " . htmlspecialchars($route));
            }
            break;

        case 'user': // User actions like follow/unfollow
            if (!$isLoggedIn) {
                $_SESSION['redirect_to'] = $_SERVER['REQUEST_URI'];
                redirect(APP_URL . '/login');
            }
            $usernameParam = $routeParts[1] ?? null;
            $userAction = $routeParts[2] ?? null;

            if ($usernameParam && $userAction && $requestMethod === 'POST') {
                if ($userAction === 'follow' && method_exists($userController, 'handleFollowUser')) {
                    $userController->handleFollowUser($usernameParam);
                } elseif ($userAction === 'unfollow' && method_exists($userController, 'handleUnfollowUser')) {
                    $userController->handleUnfollowUser($usernameParam);
                } else {
                    $errorController->notFound("User action '" . htmlspecialchars($userAction) . "' not implemented.");
                }
            } else {
                $errorController->notFound("Invalid user route structure or method for user actions: " . htmlspecialchars($route));
            }
            break;

        case 'users': // New base route for user-related AJAX actions
            if (isset($routeParts[1]) && $routeParts[1] === 'search' && $requestMethod === 'GET') {
                if (!isset($_SESSION['user_id'])) { // Basic auth check
                    http_response_code(401);
                    header('Content-Type: application/json');
                    echo json_encode(['success' => false, 'message' => 'Authentication required.']);
                    exit;
                }
                // Ensure UserController instance is available
                if (isset($userController) && method_exists($userController, 'ajaxSearchUsers')) {
                    $userController->ajaxSearchUsers();
                } else {
                    http_response_code(500);
                    header('Content-Type: application/json');
                    echo json_encode(['success' => false, 'message' => 'User search feature unavailable (controller issue).']);
                }
            } else {
                $errorController->notFound("Invalid user action.");
            }
            break;


        case 'settings': // User settings pages
            if (!$isLoggedIn) {
                $_SESSION['redirect_to'] = $_SERVER['REQUEST_URI'];
                redirect(APP_URL . '/login');
            }
            $settingAction = $routeParts[1] ?? 'index';

            switch ($settingAction) {
                case 'index':
                    if (method_exists($userController, 'showSettingsIndex')) {
                        $userController->showSettingsIndex();
                    } else {
                        $errorController->notFound("Settings index page not available.");
                    }
                    break;
                case 'profile':
                    if ($requestMethod === 'POST' && method_exists($userController, 'handleProfileSettings')) {
                        $userController->handleProfileSettings();
                    } elseif ($requestMethod === 'GET' && method_exists($userController, 'showProfileSettings')) {
                        $userController->showProfileSettings();
                    } else {
                        $errorController->notFound("Profile settings feature not available.");
                    }
                    break;
                case 'account':
                    if ($requestMethod === 'POST' && method_exists($userController, 'handleAccountSettings')) {
                        $userController->handleAccountSettings();
                    } elseif ($requestMethod === 'GET' && method_exists($userController, 'showAccountSettings')) {
                        $userController->showAccountSettings();
                    } else {
                        $errorController->notFound("Account settings feature not available for method: " . htmlspecialchars($requestMethod));
                    }
                    break;
                case 'notifications':
                    $notificationSubAction = $routeParts[2] ?? null; // e.g. 'mark-read'
                    if ($requestMethod === 'POST' && $notificationSubAction === 'mark-read' && method_exists($userController, 'markNotificationRead')) {
                        $userController->markNotificationRead();
                    } elseif ($requestMethod === 'POST' && $notificationSubAction === 'mark-all-read' && method_exists($userController, 'markAllNotificationsRead')) {
                        $userController->markAllNotificationsRead();
                    } elseif ($requestMethod === 'GET' && $notificationSubAction === null && method_exists($userController, 'showNotifications')) {
                        $userController->showNotifications();
                    } else {
                        $errorController->notFound("Notifications settings page or action not available.");
                    }
                    break;
                default:
                    $errorController->notFound("Invalid settings page: /settings/" . htmlspecialchars($settingAction));
                    break;
            }
            break;

        case 'supplier':
            // ... (authentication and business ID check as before) ...
            $supplierAction = $routeParts[1] ?? 'dashboard';
            error_log("INDEX.PHP ADMIN ROUTING: adminAction = '{$adminAction}'"); // This log seems to be a copy-paste error from 'admin' case, should be supplierAction
            // Corrected log:
            error_log("INDEX.PHP SUPPLIER ROUTING: supplierAction = '{$supplierAction}'");


            switch ($supplierAction) {
                case 'dashboard':
                    if (method_exists($supplierController, 'dashboard')) {
                        $supplierController->dashboard();
                    } else {
                        // Fallback if dashboard method doesn't exist, though it's a primary action
                        $_SESSION['flash_message'] = ['type' => 'info', 'text' => 'Supplier dashboard is currently routing to product list.'];
                        redirect(APP_URL . '/supplier/products');
                    }
                    break;
                case 'products':
                    $productAction = $routeParts[2] ?? 'list';
                    // ... (existing product actions code) ...
                    // No change needed here based on the log
                    break;
                case 'orders': // Supplier Order Management Routes
                    $orderSubAction = $routeParts[2] ?? 'list';
                    $actionHandled = false;

                    if ($orderSubAction === 'list' && $requestMethod === 'GET') {
                        $supplierController->listSupplierOrders();
                        $actionHandled = true;
                    } elseif ($orderSubAction === 'view' && isset($routeParts[3]) && is_numeric($routeParts[3])) {
                        $orderId = (int) $routeParts[3];
                        if ($requestMethod === 'GET') {
                            $supplierController->viewSupplierOrderDetail($orderId);
                            $actionHandled = true;
                        } else {
                            // Method not allowed for viewing details
                            $errorController->serverError("Invalid request method for viewing supplier order details.", 405);
                            $actionHandled = true;
                        }
                    } elseif ($orderSubAction === 'update' && isset($routeParts[3]) && is_numeric($routeParts[3])) {
                        $orderId = (int) $routeParts[3];
                        if ($requestMethod === 'POST') {
                            $supplierController->handleSupplierOrderUpdate($orderId);
                            $actionHandled = true;
                        } else {
                            // Method not allowed for updating
                            $errorController->serverError("Invalid request method for updating supplier order.", 405);
                            $actionHandled = true;
                        }
                    }

                    if (!$actionHandled) {
                        // This block is reached if none of the specific sub-actions matched
                        // or if a method mismatch occurred that wasn't explicitly handled by an error above.
                        error_log("INDEX.PHP SUPPLIER_ORDERS: No specific supplier order action matched for subAction '{$orderSubAction}' and method '{$requestMethod}'. Route: " . htmlspecialchars($route));
                        $errorController->notFound("Invalid supplier order action or method for route: " . htmlspecialchars($route));
                    }
                    break;
                default:
                    $errorController->notFound("Invalid supplier action: " . htmlspecialchars($supplierAction));
                    break;
            }
            break;

        case 'cart':
            $cartAction = $routeParts[1] ?? 'view';
            error_log("INDEX.PHP CART_CASE: Base='{$currentRouteBase}', Action='{$cartAction}', Method='{$requestMethod}', FullRoute='{$route}'");

            $actionHandled = false;
            if ($cartAction === 'add' && $requestMethod === 'POST') {
                error_log("INDEX.PHP CART_CASE: Matched /cart/add POST. Calling CartController->add().");
                $cartController->add();
                $actionHandled = true;
            } elseif ($cartAction === 'view' && $requestMethod === 'GET') {
                error_log("INDEX.PHP CART_CASE: Matched /cart or /cart/view GET. Calling CartController->view().");
                $cartController->view();
                $actionHandled = true;
            } elseif ($cartAction === 'update' && $requestMethod === 'POST') {
                error_log("INDEX.PHP CART_CASE: Matched /cart/update POST. Calling CartController->update().");
                $cartController->update();
                $actionHandled = true;
            } elseif ($cartAction === 'remove' && $requestMethod === 'POST') {
                error_log("INDEX.PHP CART_CASE: Matched /cart/remove POST. Calling CartController->remove().");
                $cartController->remove();
                $actionHandled = true;
            }

            if (!$actionHandled) {
                error_log("INDEX.PHP CART_CASE: No specific cart action matched. Calling ErrorController->notFound() for route: " . htmlspecialchars($route));
                $errorController->notFound("Invalid cart action or method for route: " . htmlspecialchars($route));
            }
            break;

        case 'checkout':
            if (!$isLoggedIn) {
                $_SESSION['redirect_to'] = APP_URL . '/checkout';
                redirect(APP_URL . '/login');
                exit;
            }
            $checkoutStep = $routeParts[1] ?? 'shipping';
            if (!isset($shopController)) {
                $shopController = new ShopController($pdo);
            } // Should be instantiated already
            switch ($checkoutStep) {
                case 'shipping':
                    if ($requestMethod === 'POST') {
                        $shopController->handleCheckoutShipping();
                    } else {
                        $shopController->showCheckoutShipping();
                    }
                    break;
                case 'payment':
                    if ($requestMethod === 'POST') {
                        $shopController->handleCheckoutPayment();
                    } else {
                        $shopController->showCheckoutPayment();
                    }
                    break;
                case 'review':
                    $shopController->showCheckoutReview();
                    break;
                case 'place-order':
                    if ($requestMethod === 'POST') {
                        $shopController->placeOrder();
                    } else {
                        redirect(APP_URL . '/checkout/review');
                    }
                    break;
                default:
                    $errorController->notFound("Invalid checkout step: " . htmlspecialchars($checkoutStep));
                    break;
            }
            break;
        case 'order':
            $orderAction = $routeParts[1] ?? null;
            $orderId = $_GET['order_id'] ?? ($routeParts[2] ?? null);
            if ($orderAction === 'success' && $orderId) {
                if (!isset($shopController)) {
                    $shopController = new ShopController($pdo);
                } // Should be instantiated
                $shopController->showOrderConfirmation();
            } else {
                $errorController->notFound("Invalid order page request.");
            }
            break;

        //users explore


        default:
            error_log("INDEX.PHP ROUTING: Hit DEFAULT case for currentRouteBase = '{$currentRouteBase}', FullRoute = '{$route}'. Calling ErrorController->notFound().");
            $errorController->notFound("Route not found: /" . htmlspecialchars($route));
            break;
    }
} catch (Throwable $e) {
    error_log("INDEX: CRITICAL - Route Dispatching Error: " . $e->getMessage() . "\n" . $e->getTraceAsString());
    if (isset($errorController) && method_exists($errorController, 'serverError')) {
        $errorController->serverError("An unexpected application error occurred.", 500, $e);
    } else {
        http_response_code(500);
        echo "<h1>Application Error</h1><p>An unexpected error occurred. Please try again later.</p>";
    }
    if (defined('DEBUG_MODE') && DEBUG_MODE && (headers_sent() === false)) {
        echo "<hr><h3>Debug Information (Routing/Dispatch):</h3><pre>" . htmlspecialchars($e->getMessage()) . "\n" . htmlspecialchars($e->getTraceAsString()) . "</pre>";
    }
    exit;
}
?>