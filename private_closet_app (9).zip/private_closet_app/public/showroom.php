<?php
// File: public/showroom.php
// Purpose: Assembles the Showroom page using partials and controller logic.

// --- 1. Setup & Load Core Files ---
// Bootstrap file handles error reporting, session, DB connection ($pdo), helpers.
require_once __DIR__ . '/../app/bootstrap.php';

// --- Load Models ---
require_once __DIR__ . '/../app/Models/ProductModel.php';
require_once __DIR__ . '/../app/Models/CategoryModel.php';
require_once __DIR__ . '/../app/Models/FavoriteProductModel.php'; // Added for favorite status
// Assuming utilities.php (with escape_html, format_price) is loaded by bootstrap.php

// --- 2. Define Page Specific Variables ---
$pageTitle = "Showroom - Private Closet";
$app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : ''; // Ensure APP_URL is available

// --- 3. Initialize Variables for the View ---
$products = [];
$categoriesForView = []; // For the category filter dropdown
$currentPage = 1;
$totalPages = 1;
$itemsPerPage = 12; // Or get from config
$filters = []; // To store active filters
$loggedInUserId = $_SESSION['user_id'] ?? null; // Get logged-in user ID
$isLoggedIn = (bool)$loggedInUserId; // Boolean flag for view convenience
$csrf_token = ''; // Will be set later

// --- 4. Handle Request Parameters (Filters, Sort, Pagination) ---
$filters['category'] = isset($_GET['category']) ? filter_input(INPUT_GET, 'category', FILTER_VALIDATE_INT) : null;

$allowedSortOptions = ['newest', 'price_asc', 'price_desc', 'popular'];
$sortInput = $_GET['sort'] ?? 'newest';
$filters['sort'] = in_array($sortInput, $allowedSortOptions, true) ? $sortInput : 'newest';

$priceInput = isset($_GET['price']) ? trim($_GET['price']) : null;
$filters['price'] = $priceInput !== null ? filter_var($priceInput, FILTER_SANITIZE_FULL_SPECIAL_CHARS) : null;
if ($filters['price'] !== null && preg_match('/[^\d\-\.,]/', $filters['price'])) {
    $filters['price'] = null;
}

$currentPage = isset($_GET['page']) ? filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) : 1;
if ($currentPage === false || $currentPage === null) {
    $currentPage = 1;
}
$offset = ($currentPage - 1) * $itemsPerPage;

// --- 5. Load Data (Controller-like Logic) ---
if (!isset($pdo)) {
    error_log("Critical: PDO connection object (\$pdo) not available in showroom.php.");
    // In a real app, you might want to show a user-friendly error page via a layout
    die("A database error occurred. Please try again later.");
}

try {
    // Instantiate Models
    $productModel = new ProductModel($pdo);
    $categoryModel = new CategoryModel($pdo);
    $favoriteProductModel = new FavoriteProductModel($pdo); // Instantiate FavoriteProductModel

    // Ensure CSRF token is available (bootstrap.php should ideally handle session_start())
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    $csrf_token = $_SESSION['csrf_token'];

    // Fetch all categories for the filter dropdown
    $allCategoriesDb = $categoryModel->getAll(); // Renamed to avoid conflict later
    if ($allCategoriesDb) {
        // Format for the view: the view expects $categories to be an array of category arrays.
        // If $categoryModel->getAll() already returns this format, no special reformatting is needed here.
        // The original code used id => name, but the view seems to iterate an array of category arrays.
        // $categoriesForView = $allCategoriesDb; // Assuming getAll() returns array of arrays
        foreach ($allCategoriesDb as $category) {
            $categoriesForView[] = $category; // Build an indexed array of category arrays
        }
    }

    // Fetch products based on filters and pagination
    $products = $productModel->getShowroomProducts($filters, $itemsPerPage, $offset);

    
    // Add 'is_favorited' status to each product
    if ($loggedInUserId && !empty($products)) {
        foreach ($products as $key => $product) {
            // Ensure product ID exists before checking favorite status
            if (isset($product['id'])) {
                $products[$key]['is_favorited'] = $favoriteProductModel->isFavorited((int)$loggedInUserId, (int)$product['id']);
            } else {
                $products[$key]['is_favorited'] = false; // Default if product ID is missing
            }
        }
    } elseif (!empty($products)) { // If not logged in, no products are favorited by current "user"
        foreach ($products as $key => $product) {
            $products[$key]['is_favorited'] = false;
        }
    }

    // Get total number of products matching filters for pagination
    $totalProducts = $productModel->countShowroomProducts($filters);
    $totalPages = ($totalProducts > 0) ? (int)ceil($totalProducts / $itemsPerPage) : 1;
    if ($currentPage > $totalPages) {
        $currentPage = $totalPages > 0 ? $totalPages : 1; // Ensure currentPage is at least 1
        $offset = ($currentPage - 1) * $itemsPerPage;
        // Optionally re-fetch products if page was out of bounds and data might be stale
        // $products = $productModel->getShowroomProducts($filters, $itemsPerPage, $offset);
        // And re-apply favorite status if products are re-fetched
    }

} catch (\PDOException $e) {
    error_log("Database Error in showroom.php: " . $e->getMessage());
    // Consider using a more user-friendly error display mechanism
    $errorMessage = (defined('DEBUG_MODE') && DEBUG_MODE) ? htmlspecialchars($e->getMessage()) : "An error occurred while fetching data. Please try again later.";
    $viewPath = __DIR__ . '/../app/Views/'; // Define for consistent path usage
    if (file_exists($viewPath . 'layouts/_header.php')) require $viewPath . 'layouts/_header.php';
    echo "<div class='container mx-auto p-4'><p class='text-red-500'><strong>Database Error:</strong> {$errorMessage}</p></div>";
    if (file_exists($viewPath . 'layouts/_footer.php')) require $viewPath . 'layouts/_footer.php';
    exit;
} catch (\Exception $e) {
    error_log("General Error in showroom.php: " . $e->getMessage());
    $errorMessage = (defined('DEBUG_MODE') && DEBUG_MODE) ? htmlspecialchars($e->getMessage()) : "An unexpected error occurred. Please try again later.";
    $viewPath = __DIR__ . '/../app/Views/'; // Define for consistent path usage
    if (file_exists($viewPath . 'layouts/_header.php')) require $viewPath . 'layouts/_header.php';
    echo "<div class='container mx-auto p-4'><p class='text-red-500'><strong>Error:</strong> {$errorMessage}</p></div>";
    if (file_exists($viewPath . 'layouts/_footer.php')) require $viewPath . 'layouts/_footer.php';
    exit;
}

// --- 6. Include Header ---
$viewPath = __DIR__ . '/../app/Views/';
// $pageTitle, $isLoggedIn, $csrf_token, $app_url, $loggedInUserId are now set and will be available to header
require_once $viewPath . 'layouts/_header.php';

// --- 7. Include Page Content ---
// Pass the processed categories to the view, your view expects $categories
$categories = $categoriesForView;
// The variables $products (now with 'is_favorited'), $categories, $currentPage,
// $totalPages, $filters, $csrf_token, $loggedInUserId, $isLoggedIn, and $app_url
// will be available in showroom_content.php.
require_once $viewPath . 'shop/showroom_content.php';

// --- 8. Include Footer ---
require_once $viewPath . 'layouts/_footer.php';

?>