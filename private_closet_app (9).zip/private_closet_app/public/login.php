<?php
// File: public/login.php
// Purpose: Handles the login page display and form submission by delegating to AuthController.

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Bootstrap should be included first. It sets up $pdo, APP_URL, error reporting, etc.
require_once __DIR__ . '/../app/bootstrap.php';

// Ensure $pdo is available (should be set by bootstrap.php or its included database.php)
if (!isset($pdo) || !($pdo instanceof PDO)) {
    error_log("PDO connection is not available or invalid in login.php. Check bootstrap.php.");
    // In a real app, you might show a user-friendly error page here.
    die("A critical database connection error occurred. Please try again later or contact support.");
}

// Ensure AuthController class definition is loaded.
// This path should point to your actual AuthController file.
require_once __DIR__ . '/../app/Controllers/AuthController.php';

// Check if the AuthController class was successfully loaded.
if (!class_exists('AuthController')) {
    error_log("AuthController class not found in login.php. Check the require_once path.");
    die("The authentication system is currently unavailable. Please try again later.");
}

// Instantiate the AuthController
$authController = new AuthController($pdo);

// If the user is already logged in, redirect them.
// (This check is also present in your index.php router for the /login route, which is good).
if (isset($_SESSION['user_id'])) {
    // Determine redirect destination: intended page or a default (e.g., showroom or dashboard).
    // APP_URL should be defined in bootstrap.php.
    $redirectTo = $_SESSION['redirect_to'] ?? (defined('APP_URL') ? APP_URL . '/showroom' : '/showroom.php');
    unset($_SESSION['redirect_to']); // Clear the stored intended destination.

    // Use a helper function for redirection if available (e.g., from utilities.php)
    if (function_exists('redirect')) {
        redirect($redirectTo);
    } else {
        // Fallback to standard PHP header redirect.
        // Ensure no output before this header call.
        if (!headers_sent()) {
            header("Location: " . $redirectTo);
            exit;
        } else {
            // If headers are already sent, provide a meta refresh or a link as a fallback.
            echo '<p>You are already logged in. Redirecting...</p>';
            echo '<meta http-equiv="refresh" content="0;url=' . htmlspecialchars($redirectTo) . '">';
            echo '<a href="' . htmlspecialchars($redirectTo) . '">Click here if you are not redirected.</a>';
            exit;
        }
    }
}

// Handle the request based on its method (GET or POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // For POST requests, delegate to AuthController's handleLogin method.
    // This method in AuthController.php is expected to handle the form submission,
    // validate credentials, set session variables, and then either redirect
    // on success or re-display the login form with errors on failure.
    // It does not return a value for this script to process further.
    $authController->handleLogin(); // AuthController::handleLogin() uses $_POST internally.
} else {
    // For GET requests, delegate to AuthController's showLogin method.
    // This method is expected to display the login form.
    $authController->showLogin();
}

// No further HTML or view loading should happen here in login.php,
// as AuthController's showLogin() or handleLogin() (on error)
// are responsible for rendering the complete page (header, content, footer).

?>
