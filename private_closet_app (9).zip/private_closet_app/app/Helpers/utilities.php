<?php
// File: app/Helpers/utilities.php
// Purpose: Store reusable utility functions.

if (!function_exists('escape_html')) {
    /**
     * Escapes HTML special characters to prevent XSS attacks.
     *
     * @param string|null $string The string to escape.
     * @return string The escaped string.
     */
    function escape_html(?string $string): string {
        if ($string === null) {
            return '';
        }
        return htmlspecialchars($string, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

if (!function_exists('redirect')) {
    /**
     * Redirects the user to a specified URL.
     *
     * @param string $url The URL to redirect to.
     * @return void
     */
    function redirect(string $url): void {
        if (!headers_sent()) {
            header("Location: " . $url);
            exit; // Stop script execution after redirect
        } else {
            // Fallback if headers are already sent (should ideally not happen)
            // Log this occurrence as it indicates an issue elsewhere.
            error_log("Redirect failed: Headers already sent. URL: " . $url);
            echo "<script type='text/javascript'>window.location.href='" . addslashes($url) . "';</script>";
            echo "<noscript><meta http-equiv='refresh' content='0;url=" . htmlspecialchars($url) . "'></noscript>";
            exit;
        }
    }
}

if (!function_exists('format_price')) {
    /**
     * Simple function to format a price (example).
     *
     * @param float $price The price value.
     * @param string $currencySymbol The currency symbol (default: R for ZAR).
     * @return string Formatted price string.
     */
    function format_price(float $price, string $currencySymbol = 'R'): string {
        return $currencySymbol . number_format($price, 2, '.', ',');
    }
}

// --- Add other helper functions as needed ---
?>