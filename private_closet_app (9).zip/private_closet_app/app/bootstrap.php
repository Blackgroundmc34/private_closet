<?php
// File: app/bootstrap.php
// Purpose: Initializes the application environment.
// In app/bootstrap.php
// Make sure DEBUG_MODE is true in your app/config.php
if (defined('DEBUG_MODE') && DEBUG_MODE) {
    ini_set('display_errors', 1); // Show errors in the browser
    ini_set('display_startup_errors', 1); // Show startup errors
    error_reporting(E_ALL); // Report all PHP errors, warnings, and notices
} else {
    ini_set('display_errors', 0); // Don't show errors in browser for production
    error_reporting(0);
    // In production, you'd configure PHP to log errors to a file:
    // ini_set('log_errors', 1);
    // ini_set('error_log', '/path/to/your/php-error.log');
}
// Ensure session is started (if not already done before this point by other includes)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// --- 1. Error Reporting (Development vs Production) ---
// Load configuration first to check debug mode
require_once __DIR__ . '/config.php';

if (defined('DEBUG_MODE') && DEBUG_MODE) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(0);
    // TODO: Configure error logging for production
}

// --- 2. Start Session ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// --- 3. Load Core Files ---
// Config was loaded above
require_once __DIR__ . '/database.php'; // Establishes $pdo connection
require_once __DIR__ . '/Helpers/utilities.php'; // Load helper functions

// --- 4. Autoloading (Optional but Recommended) ---
// require_once __DIR__ . '/../vendor/autoload.php';


// --- 5. Define Base URL Constant ---
// Ensure APP_URL points to the public directory URL, NO TRAILING SLASH
if (!defined('APP_URL')) {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || ($_SERVER['SERVER_PORT'] ?? 80) == 443) ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    // SCRIPT_NAME is the path to index.php relative to document root
    // dirname() gives the directory containing index.php (e.g., /private_closet_app/public)
    $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
    // Remove trailing slash if it's not the root '/'
    $baseUrl = rtrim($protocol . $host . $scriptDir, '/');
    define('APP_URL', $baseUrl);
}


// --- 6. Return Database Connection (or use global/registry) ---
if (!isset($pdo)) {
     trigger_error("PDO connection object (\$pdo) not established in database.php.", E_USER_ERROR);
}
// Relying on $pdo being in global scope for now

?>
