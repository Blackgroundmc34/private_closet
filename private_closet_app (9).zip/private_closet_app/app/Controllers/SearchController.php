 <?php
// File: app/Controllers/SearchController.php

require_once __DIR__ . '/../Models/ProductModel.php';
require_once __DIR__ . '/../Helpers/utilities.php'; // For escape_html

class SearchController {
    private $pdo;
    private $productModel;
    private $viewPath = __DIR__ . '/../Views/';

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->productModel = new ProductModel($pdo);
    }

    /**
     * Handles displaying the search page and search results.
     */
    public function index() {
        $pageTitle = "Search Results - Private Closet";
        $searchQuery = trim(filter_input(INPUT_GET, 'q', FILTER_SANITIZE_SPECIAL_CHARS) ?? '');
        
        $products = [];
        $totalProducts = 0;
        $totalPages = 0;
        $currentPage = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, ['options' => ['default' => 1, 'min_range' => 1]]);
        $resultsPerPage = 12; // Number of products per page

        if (!empty($searchQuery)) {
            $pageTitle = "Search: " . escape_html($searchQuery) . " - Private Closet";
            $offset = ($currentPage - 1) * $resultsPerPage;
            
            // Fetch products matching the search query
            $products = $this->productModel->searchProducts($searchQuery, $resultsPerPage, $offset);
            $totalProducts = $this->productModel->countSearchedProducts($searchQuery);
            $totalPages = ceil($totalProducts / $resultsPerPage);
        }

        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('search/search_results_content', [
            'searchQuery' => $searchQuery,
            'products' => $products,
            'totalProducts' => $totalProducts,
            'currentPage' => $currentPage,
            'totalPages' => $totalPages,
            'resultsPerPage' => $resultsPerPage
        ]);
        $this->loadView('layouts/_footer');
    }

    private function loadView(string $viewName, array $data = []) {
        $filePath = rtrim($this->viewPath, '/\\') . DIRECTORY_SEPARATOR . ltrim($viewName, '/\\') . '.php';
        $filePath = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $filePath);

        if (file_exists($filePath)) {
            // Make common variables available to all views loaded by this controller
            $data['app_url'] = $data['app_url'] ?? (defined('APP_URL') ? APP_URL : '');
            $data['isLoggedIn'] = $data['isLoggedIn'] ?? isset($_SESSION['user_id']);
            $data['userRole'] = $data['userRole'] ?? ($_SESSION['user_role'] ?? null);
            $data['csrf_token'] = $data['csrf_token'] ?? ($_SESSION['csrf_token'] ?? '');
            
            extract($data);
            require $filePath;
        } else {
            error_log("SearchController::loadView - View file not found: " . $filePath);
            // Fallback error display
            http_response_code(500);
            echo "<h1>Application Error</h1><p>A required view file ('" . htmlspecialchars($viewName) . ".php') was not found.</p>";
            if (defined('DEBUG_MODE') && DEBUG_MODE) {
                echo "<p>Attempted path: " . htmlspecialchars($filePath) . "</p>";
            }
            exit;
        }
    }
}
?>
