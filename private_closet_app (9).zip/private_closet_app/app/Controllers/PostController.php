<?php
// File: app/Controllers/PostController.php

require_once __DIR__ . '/../Models/PostModel.php';
require_once __DIR__ . '/../Helpers/utilities.php'; // For escape_html, redirect
require_once __DIR__ . '/../Models/PostCommentModel.php';

class PostController {
    private $pdo;
    private $postModel;
    private $postCommentModel;
    private $viewPath = __DIR__ . '/../Views/';
    private $app_url; // <<< DECLARED PROPERTY to fix the deprecation notice

    // Define upload constants or get them from a config file
    private const UPLOAD_DIR_RELATIVE = 'uploads/posts/';
    private const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB
    private const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/gif'];
    private const ALLOWED_VIDEO_TYPES = ['video/mp4', 'video/quicktime', 'video/webm', 'video/x-matroska'];


    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->postModel = new PostModel($pdo);
        // Access APP_URL after it's potentially defined (e.g., in a config file)
        $this->app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : ''; // This was line 21
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    private function outputJson($data, $statusCode = 200) {
        if (ob_get_length() > 0) { ob_end_clean(); }
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        // Ensure data is UTF-8 encoded before json_encode
        array_walk_recursive($data, function (&$item) {
            if (is_string($item) && !mb_check_encoding($item, 'UTF-8')) {
                $item = mb_convert_encoding($item, 'UTF-8', 'UTF-8'); // Or use 'auto' for source encoding if unsure
            }
        });
        $jsonResponse = json_encode($data);
        if ($jsonResponse === false) {
            $jsonErrorMsg = json_last_error_msg();
            error_log("PostController::outputJson - json_encode FAILED: " . $jsonErrorMsg);
            // Basic escaping for the error message in the JSON response itself.
            $escapedErrorMsg = addslashes($jsonErrorMsg);
            echo '{"success":false,"message":"Server error: Could not encode JSON. Details: ' . $escapedErrorMsg . '"}';
        } else {
            echo $jsonResponse;
        }
        exit;
    }

    public function show(int $postId) {
        if ($postId <= 0) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid post ID.'];
            redirect($this->app_url . '/');
            return;
        }
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        $post = $this->postModel->findById($postId, $loggedInUserId);

        if (!$post) {
            http_response_code(404);
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => "Post not found."];
            redirect($this->app_url . '/');
            return;
        }

        $comments = $this->postModel->getComments($postId);
        $pageTitle = escape_html(substr($post['description'] ?? ('Post by ' . ($post['author_username'] ?? 'User')), 0, 40)) . "... | Private Closet";
        $flashMessage = $_SESSION['flash_message'] ?? null;
        if ($flashMessage) unset($_SESSION['flash_message']);

        $data = [
            'post' => $post,
            'comments' => $comments,
            // loggedInUserId, isLoggedIn, app_url, default_avatar_path are injected by loadView
        ];
        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle, 'flashMessage' => $flashMessage]); // Pass flash message to header too if needed there
        $this->loadView('posts/show_content', $data);
        $this->loadView('layouts/_footer');
    }

    public function handleToggleLike(int $postId) {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->outputJson(['success' => false, 'message' => 'Invalid request method.'], 405);
            return;
        }
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) {
            $this->outputJson(['success' => false, 'message' => 'Authentication required to like posts.'], 401);
            return;
        }
        if ($postId <= 0) {
            $this->outputJson(['success' => false, 'message' => 'Invalid post ID provided.'], 400);
            return;
        }
        $result = $this->postModel->toggleLike($postId, (int)$loggedInUserId);
        $this->outputJson($result, $result['success'] ? 200 : ($result['message'] === 'Post not found.' ? 404 : 400) );
    }

    public function handleAddComment(int $postId) {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->outputJson(['success' => false, 'message' => 'Invalid request method.'], 405);
            return;
        }
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) {
            $this->outputJson(['success' => false, 'message' => 'Authentication required to comment.'], 401);
            return;
        }
        if ($postId <= 0) {
            $this->outputJson(['success' => false, 'message' => 'Invalid post ID for comment.'], 400);
            return;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        $commentText = isset($input['comment_text']) ? trim($input['comment_text']) : '';

        if (empty($commentText)) {
            $this->outputJson(['success' => false, 'message' => 'Comment text cannot be empty.'], 400);
            return;
        }
        if (mb_strlen($commentText) > 1000) { // Use mb_strlen for multibyte strings
            $this->outputJson(['success' => false, 'message' => 'Comment is too long (max 1000 characters).'], 400);
            return;
        }

        $postData = $this->postModel->findById($postId);
        if (!$postData) {
            $this->outputJson(['success' => false, 'message' => 'Post not found.'], 404);
            return;
        }
        if (!($postData['allow_comments'] ?? true)) {
            $this->outputJson(['success' => false, 'message' => 'Comments are disabled for this post.'], 403);
            return;
        }

        $newCommentData = $this->postModel->addComment($postId, (int)$loggedInUserId, $commentText);

        if ($newCommentData) {
            $this->outputJson(['success' => true, 'comment' => $newCommentData, 'message' => 'Comment added successfully.']);
        } else {
            $this->outputJson(['success' => false, 'message' => 'Failed to add comment due to a server error.'], 500);
        }
    }

    public function showUploadForm() {
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) {
            $_SESSION['redirect_to'] = $this->app_url . '/upload'; // Assuming /upload is the correct path
            redirect($this->app_url . '/login'); // Assuming /login is the correct path
            return;
        }
        $pageTitle = "Create New Post | Share Your Moments";
        $flashMessage = $_SESSION['flash_message'] ?? null;
        if ($flashMessage) unset($_SESSION['flash_message']);

        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle, 'flashMessage' => $flashMessage]);
        $this->loadView('posts/create_post_form'); // No specific data needed beyond what loadView provides
        $this->loadView('layouts/_footer');
    }

    public function handleUpload() {
        error_log("PostController::handleUpload - Method Reached.");
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'You must be logged in to create a post.'];
            redirect($this->app_url . '/login');
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid request method.'];
            redirect($this->app_url . '/upload');
            return;
        }

        $description = trim($_POST['description'] ?? '');
        $location = trim($_POST['location'] ?? '');
        $allowComments = isset($_POST['allow_comments']); // Checkbox value if 'on' or '1', not present if unchecked.
        // $visibility = $_POST['visibility'] ?? 'public';

        if (empty($description) && (empty($_FILES['media_file']) || $_FILES['media_file']['error'] == UPLOAD_ERR_NO_FILE)) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'A post must have a description or media.'];
            redirect($this->app_url . '/upload');
            return;
        }
        if (mb_strlen($description) > 2000) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Description is too long (max 2000 characters).'];
            redirect($this->app_url . '/upload');
            return;
        }

        $mediaUrlRelative = null;
        $mediaType = null;
        $publicRootPath = null; // Define for later use if file is uploaded

        if (isset($_FILES['media_file']) && $_FILES['media_file']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['media_file'];
            $fileName = $file['name'];
            $fileTmpName = $file['tmp_name'];
            $fileSize = $file['size'];
            $fileMimeType = mime_content_type($fileTmpName);

            $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

            error_log("PostController::handleUpload - File Info: Name={$fileName}, MIME={$fileMimeType}, Size={$fileSize}, Tmp={$fileTmpName}, Ext={$fileExt}");

            if ($fileSize > self::MAX_FILE_SIZE) {
                $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'File is too large. Max size is ' . (self::MAX_FILE_SIZE / 1024 / 1024) . 'MB.'];
                redirect($this->app_url . '/upload');
                return;
            }

            if (in_array($fileMimeType, self::ALLOWED_IMAGE_TYPES)) {
                $mediaType = 'image';
            } elseif (in_array($fileMimeType, self::ALLOWED_VIDEO_TYPES)) {
                $mediaType = 'video';
            } else {
                $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid file type. Allowed: JPG, PNG, GIF, MP4, MOV, WEBM, MKV. Detected: ' . escape_html($fileMimeType)];
                redirect($this->app_url . '/upload');
                return;
            }

            $uniqueFileName = uniqid('post_', true) . "." . $fileExt;

            // Construct absolute path to public directory's root
            // This assumes your DOCUMENT_ROOT is C:/xampp/htdocs and SCRIPT_NAME for entry point is /private_closet_app/public/index.php
            $docRoot = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR);
            $scriptDir = dirname($_SERVER['SCRIPT_NAME']); // e.g., /private_closet_app/public or / if public is doc root
            
            // This logic assumes that SCRIPT_NAME points to your front controller in the public directory.
            // If APP_URL is http://localhost/private_closet_app/public, then publicRootPath should be C:/xampp/htdocs/private_closet_app/public
            $publicRootPath = $docRoot . $scriptDir;
            $publicRootPath = rtrim($publicRootPath, DIRECTORY_SEPARATOR);


            $uploadDirAbsolute = $publicRootPath . DIRECTORY_SEPARATOR . ltrim(self::UPLOAD_DIR_RELATIVE, DIRECTORY_SEPARATOR . '/');


            if (!file_exists($uploadDirAbsolute)) {
                if (!mkdir($uploadDirAbsolute, 0775, true)) {
                    error_log("PostController::handleUpload - Failed to create upload directory: {$uploadDirAbsolute}");
                    $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Server error: Could not create upload directory. Check permissions for path: ' . escape_html($uploadDirAbsolute) ];
                    redirect($this->app_url . '/upload');
                    return;
                }
            }

            $destinationPath = $uploadDirAbsolute . DIRECTORY_SEPARATOR . $uniqueFileName;
            $mediaUrlRelative = str_replace(DIRECTORY_SEPARATOR, '/', self::UPLOAD_DIR_RELATIVE) . $uniqueFileName;

            error_log("PostController::handleUpload - Attempting to move '{$fileTmpName}' to '{$destinationPath}'");

            if (move_uploaded_file($fileTmpName, $destinationPath)) {
                error_log("PostController::handleUpload - File uploaded successfully to: {$destinationPath}");
            } else {
                $uploadError = error_get_last();
                error_log("PostController::handleUpload - Failed to move uploaded file. Error: " . ($uploadError['message'] ?? 'Unknown error based on error_get_last'). ". Check write permissions for {$uploadDirAbsolute}");
                $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Failed to upload file. Server configuration issue.'];
                $mediaUrlRelative = null;
                $mediaType = null;
                if (empty($description)) {
                    redirect($this->app_url . '/upload');
                    return;
                }
            }
        } elseif (isset($_FILES['media_file']) && $_FILES['media_file']['error'] !== UPLOAD_ERR_NO_FILE) {
            $uploadErrorMessages = [
                UPLOAD_ERR_INI_SIZE   => 'The uploaded file exceeds the upload_max_filesize directive in php.ini.',
                UPLOAD_ERR_FORM_SIZE  => 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.',
                UPLOAD_ERR_PARTIAL    => 'The uploaded file was only partially uploaded.',
                UPLOAD_ERR_NO_TMP_DIR => 'Missing a temporary folder.',
                UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
                UPLOAD_ERR_EXTENSION  => 'A PHP extension stopped the file upload.',
            ];
            $phpUploadError = $_FILES['media_file']['error'];
            $errorMessage = $uploadErrorMessages[$phpUploadError] ?? 'Unknown file upload error.';
            error_log("PostController::handleUpload - PHP Upload Error Code: {$phpUploadError} - {$errorMessage}");
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => $errorMessage];
            redirect($this->app_url . '/upload');
            return;
        }

        $newPostId = $this->postModel->createPost(
            (int)$loggedInUserId,
            $description,
            $mediaUrlRelative,
            $mediaType,
            empty($location) ? null : $location,
            $allowComments
            // $visibility
        );

        if ($newPostId) {
            $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'Post created successfully!'];
            redirect($this->app_url . '/post/' . $newPostId);
        } else {
            if ($publicRootPath && $mediaUrlRelative && file_exists($publicRootPath . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $mediaUrlRelative))) {
                unlink($publicRootPath . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $mediaUrlRelative));
                error_log("PostController::handleUpload - Deleted orphaned uploaded file: {$mediaUrlRelative} due to DB save failure.");
            }
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Failed to create post in database. Please try again.'];
            redirect($this->app_url . '/upload');
        }
    }

    public function showReelsFeed() {
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        // $isLoggedIn is automatically passed by loadView

        $postsPerPage = 5;
        $currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        if ($currentPage < 1) {
            $currentPage = 1;
        }
        $offset = ($currentPage - 1) * $postsPerPage;

        $totalReels = $this->postModel->countReels();
        $totalPages = ($totalReels > 0) ? (int)ceil($totalReels / $postsPerPage) : 1;

        $reels = $this->postModel->getReels($postsPerPage, $offset, $loggedInUserId);

        $pageTitle = "Reels | Watch Popular Videos";
        $flashMessage = $_SESSION['flash_message'] ?? null;
        if ($flashMessage) {
            unset($_SESSION['flash_message']);
        }

        $data = [
            'reels' => $reels,
            'currentPage' => $currentPage,
            'totalPages' => $totalPages,
            // 'loggedInUserId', 'isLoggedIn', 'app_url', 'default_avatar_path' injected by loadView
        ];

        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle, 'flashMessage' => $flashMessage]);
        $this->loadView('posts/reels_feed_content', $data);
        $this->loadView('layouts/_footer');
    }

    private function loadView(string $viewName, array $data = []) {
        $filePath = rtrim($this->viewPath, '/') . '/' . ltrim($viewName, '/') . '.php';

        // Make commonly needed variables available to all views by default
        // These will overwrite any keys with the same name in the $data array passed to loadView
        $data['app_url'] = $this->app_url;
        $data['loggedInUserId'] = $_SESSION['user_id'] ?? null;
        $data['isLoggedIn'] = (bool)($data['loggedInUserId'] ?? null);
        $data['default_avatar_path'] = defined('DEFAULT_AVATAR_PATH') ? DEFAULT_AVATAR_PATH : 'assets/images/default_avatar.png';
        
        // Pass flash message to $data if it's not already set from controller method
        if (!isset($data['flashMessage']) && isset($_SESSION['flash_message'])) {
             $data['flashMessage'] = $_SESSION['flash_message'];
             unset($_SESSION['flash_message']); // Clear it after assigning to view
        }


        if (file_exists($filePath)) {
            extract($data);
            require $filePath;
        } else {
            $errorMessage = "View file not found: {$filePath}";
            error_log("PostController::loadView - " . $errorMessage);
            if (defined('DEBUG_MODE') && DEBUG_MODE) {
                echo "<p style='color:red;font-weight:bold; background:white; padding:10px; border:1px solid red;'>View Error: " . htmlspecialchars($errorMessage, ENT_QUOTES, 'UTF-8') . "</p>";
            } else {
                echo "<p>Error: Could not load page content.</p>";
            }
        }
    }

    public function ajaxGetPostComments(int $postId) {
        header('Content-Type: application/json');
        // Basic validation
        if ($postId <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid post ID.']);
            exit;
        }

        // You might want to check if the post itself exists and is public/accessible
        // $post = $this->postModel->findPostById($postId);
        // if (!$post || $post['visibility'] === 'private' && $post['user_id'] !== ($_SESSION['user_id'] ?? null) ) {
        //     echo json_encode(['success' => false, 'message' => 'Post not found or access denied.']);
        //     exit;
        // }

        $comments = $this->postCommentModel->getCommentsByPostId($postId);

        if ($comments !== false) { // Check for explicit false for DB error, empty array is valid
            echo json_encode(['success' => true, 'comments' => $comments]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Could not retrieve comments.']);
        }
        exit;
    }

    /**
     * Handles AJAX request to add a comment to a post.
     */
    public function ajaxAddPostComment(int $postId) {
        header('Content-Type: application/json');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
            exit;
        }

        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['success' => false, 'message' => 'Please log in to comment.', 'redirectToLogin' => true]);
            exit;
        }
        $userId = (int)$_SESSION['user_id'];

        // Get JSON data from request body
        $inputJSON = file_get_contents('php://input');
        $input = json_decode($inputJSON, TRUE); //convert JSON into array

        // CSRF Check (if sending via headers or as part of JSON body)
        // Example: $clientCsrfToken = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? $input['csrf_token'] ?? null;
        // if (!$clientCsrfToken || !hash_equals($_SESSION['csrf_token'] ?? '', $clientCsrfToken)) {
        //     echo json_encode(['success' => false, 'message' => 'Invalid security token.']);
        //     exit;
        // }

        $commentText = trim($input['comment_text'] ?? '');

        if (empty($commentText)) {
            echo json_encode(['success' => false, 'message' => 'Comment text cannot be empty.']);
            exit;
        }
        if (mb_strlen($commentText) > 1000) { // Example max length
            echo json_encode(['success' => false, 'message' => 'Comment is too long (max 1000 characters).']);
            exit;
        }

        $newCommentData = $this->postCommentModel->addComment($postId, $userId, $commentText);

        if ($newCommentData) {
            // Optionally, update the comment count on the post itself
            $this->postModel->incrementCommentCount($postId); // You'd need this method in PostModel
            
            echo json_encode(['success' => true, 'comment' => $newCommentData, 'message' => 'Comment posted!']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to post comment. Please try again.']);
        }
        exit;
    }
    
}
?>