<?php
// File: app/Controllers/UserController.php

require_once __DIR__ . '/../Models/UserModel.php';
require_once __DIR__ . '/../Models/PostModel.php';
require_once __DIR__ . '/../Helpers/utilities.php';

class UserController {
    private $pdo;
    private $userModel;
    private $postModel;
    private $viewPath = __DIR__ . '/../Views/';
    private $app_url;
    private $default_avatar_full_url;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->userModel = new UserModel($pdo);
        $this->postModel = new PostModel($pdo);

        $this->app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
        $default_avatar_path_rel = defined('DEFAULT_AVATAR_PATH') ? DEFAULT_AVATAR_PATH : 'assets/images/default_avatar.png';
        $this->default_avatar_full_url = $this->app_url . '/' . ltrim($default_avatar_path_rel, '/');
    }

    // ... (all your existing methods like profile, handleFollowUser, showClosetFeed, etc.) ...

    /**
     * Handles AJAX requests to search for users by username.
     * Used by the boardroom modal for starting new conversations.
     */
    public function ajaxSearchUsers() {
        // Ensure user is logged in to use this feature
        if (!isset($_SESSION['user_id'])) {
            http_response_code(401); // Unauthorized
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Authentication required.']);
            exit;
        }
        $loggedInUserId = (int)$_SESSION['user_id'];
        $searchTerm = trim($_GET['username'] ?? '');

        // Basic validation for search term length
        if (strlen($searchTerm) < 1) { // You might want to set a minimum length like 2 or 3
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'users' => [], 'message' => 'Search term too short.']);
            exit;
        }

        // Call the UserModel method to search for users
        // The UserModel's searchUsersByUsername should handle preparing full profile picture URLs
        $users = $this->userModel->searchUsersByUsername($searchTerm, $loggedInUserId, 7); // Limit to 7 results, for example

        header('Content-Type: application/json');
        if ($users !== false) {
            echo json_encode(['success' => true, 'users' => $users]);
        } else {
            // This case might occur if searchUsersByUsername itself returns false due to an error
            echo json_encode(['success' => false, 'message' => 'Error fetching users from the database.']);
        }
        exit;
    }


    public function profile(string $username) {
        $user = $this->userModel->findByUsername($username);
        if (!$user) {
            http_response_code(404);
            $this->loadView('layouts/_header', ['pageTitle' => 'User Not Found']);
            $this->loadView('errors/404_content', ['message' => "The profile for '@" . escape_html($username) . "' could not be found."]);
            $this->loadView('layouts/_footer');
            exit;
        }
        $currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $postsPerPage = 5;
        $userId = (int)$user['id'];
        $totalPosts = $this->userModel->countUserPosts($userId);
        $totalPages = $totalPosts > 0 ? (int)ceil($totalPosts / $postsPerPage) : 1;
        if ($currentPage < 1) $currentPage = 1;
        if ($currentPage > $totalPages && $totalPages > 0) $currentPage = $totalPages; // Fix to prevent going beyond existing pages
        
        $offset = ($currentPage - 1) * $postsPerPage;
        $posts = $this->userModel->getUserPosts($userId, $postsPerPage, $offset);

        $loggedInUserId = $_SESSION['user_id'] ?? null;
        $isOwnProfile = ($loggedInUserId === $userId);
        
        $followerCount = $this->userModel->getFollowerCount($userId);
        $followingCount = $this->userModel->getFollowingCount($userId);
        $isViewerFollowing = false;
        if ($loggedInUserId && !$isOwnProfile) {
            $isViewerFollowing = $this->userModel->isFollowing($loggedInUserId, $userId);
        }

        $pageTitle = escape_html($user['username']) . "'s Profile - Private Closet";
        
        $data = [
            'user' => $user,
            'posts' => $posts,
            'isOwnProfile' => $isOwnProfile,
            'currentPage' => $currentPage,
            'totalPages' => $totalPages,
            'followerCount' => $followerCount,
            'followingCount' => $followingCount,
            'isViewerFollowing' => $isViewerFollowing
        ];
        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('user/profile_content', $data);
        $this->loadView('layouts/_footer');
    }

    public function handleFollowUser(string $usernameToFollow) {
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'You must be logged in to follow users.'];
            redirect($this->app_url . '/login');
            exit;
        }
        $userToFollow = $this->userModel->findByUsername($usernameToFollow);
        if (!$userToFollow) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'User not found.'];
            redirect($_SERVER['HTTP_REFERER'] ?? $this->app_url . '/showroom');
            exit;
        }
        if ($loggedInUserId === (int)$userToFollow['id']) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'You cannot follow yourself.'];
            redirect($this->app_url . '/profile/' . $usernameToFollow);
            exit;
        }
        if ($this->userModel->followUser($loggedInUserId, (int)$userToFollow['id'])) {
            $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'You are now following ' . escape_html($usernameToFollow) . '.'];
            $notificationMessage = escape_html($_SESSION['username'] ?? 'Someone') . ' started following you.';
            $this->userModel->createNotification((int)$userToFollow['id'], 'new_follower', $notificationMessage, 'user', (string)$loggedInUserId);
        } else {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Could not follow ' . escape_html($usernameToFollow) . '. You might already be following them or a server error occurred.'];
        }
        redirect($this->app_url . '/profile/' . $usernameToFollow);
        exit;
    }

    public function handleUnfollowUser(string $usernameToUnfollow) {
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'You must be logged in to unfollow users.'];
            redirect($this->app_url . '/login');
            exit;
        }
        $userToUnfollow = $this->userModel->findByUsername($usernameToUnfollow);
        if (!$userToUnfollow) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'User not found.'];
            redirect($_SERVER['HTTP_REFERER'] ?? $this->app_url . '/showroom');
            exit;
        }
        if ($this->userModel->unfollowUser($loggedInUserId, (int)$userToUnfollow['id'])) {
            $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'You have unfollowed ' . escape_html($usernameToUnfollow) . '.'];
        } else {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Could not unfollow ' . escape_html($usernameToUnfollow) . '. You might not have been following them or a server error occurred.'];
        }
        redirect($this->app_url . '/profile/' . $usernameToUnfollow);
        exit;
    }

    public function showSettingsIndex() {
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) {
            $_SESSION['redirect_to'] = $_SERVER['REQUEST_URI'];
            redirect($this->app_url . '/login');
            exit;
        }
        $pageTitle = "Settings - Private Closet";
        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('user/settings_index_content', ['errors' => [], 'oldInput' => []] );
        $this->loadView('layouts/_footer');
    }

    public function showProfileSettings() {
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) {
            $_SESSION['redirect_to'] = $this->app_url . '/settings/profile';
            redirect($this->app_url . '/login');
            exit;
        }

        $currentUser = $this->userModel->findById($loggedInUserId);

        if (!$currentUser) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Could not load your profile data. Please log in again.'];
            redirect($this->app_url . '/logout');
            exit;
        }

        $pageTitle = "Edit Profile - Settings";
        $errors = $_SESSION['settings_errors'] ?? []; unset($_SESSION['settings_errors']);
        $oldInputFromSession = $_SESSION['settings_old_input'] ?? []; unset($_SESSION['settings_old_input']);
        
        $oldInput = !empty($oldInputFromSession) ? $oldInputFromSession : $currentUser;

        $data = [
            'currentUser' => $currentUser,
            'errors' => $errors,
            'oldInput' => $oldInput
        ];

        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('user/settings_profile_content', $data);
        $this->loadView('layouts/_footer');
    }
    
    public function handleProfileSettings() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect($this->app_url . '/settings/profile'); exit; }
        
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) { redirect($this->app_url . '/login'); exit; }

        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
            $_SESSION['settings_errors']['general'] = 'Invalid security token. Please try again.';
            $_SESSION['settings_old_input'] = $_POST;
            redirect($this->app_url . '/settings/profile');
            exit;
        }

        $input = $_POST;
        $errors = [];
        $updateData = [];

        $fullName = trim($input['full_name'] ?? '');
        if (empty($fullName)) {
            $errors['full_name'] = 'Full Name cannot be empty.';
        } else {
            $updateData['full_name'] = $fullName;
        }

        $email = filter_var(trim($input['email'] ?? ''), FILTER_VALIDATE_EMAIL);
        if (!$email) {
            $errors['email'] = 'A valid Email is required.';
        } else {
            $userByEmail = $this->userModel->findByEmail($email);
            if ($userByEmail && $userByEmail['id'] != $loggedInUserId) {
                $errors['email'] = 'This email address is already in use by another account.';
            } else {
                $updateData['email'] = $email;
            }
        }
        
        $profileBio = trim($input['profile_bio'] ?? '');
        $updateData['profile_bio'] = $profileBio;

        $newProfilePicturePath = null;
        if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['profile_picture'];
            $allowedMimes = ['image/jpeg', 'image/png', 'image/gif'];
            $maxSize = 2 * 1024 * 1024; // 2MB

            if (!in_array($file['type'], $allowedMimes)) {
                $errors['profile_picture'] = 'Invalid file type. Only JPG, PNG, GIF allowed.';
            } elseif ($file['size'] > $maxSize) {
                $errors['profile_picture'] = 'File is too large. Max 2MB.';
            } else {
                $fileName = basename($file['name']);
                $safeFileName = preg_replace('/[^A-Za-z0-9_.-]/', '_', $fileName);
                $fileExtension = strtolower(pathinfo($safeFileName, PATHINFO_EXTENSION));
                $uniqueFileName = 'avatar_' . $loggedInUserId . '_' . time() . '.' . $fileExtension;
                
                $avatarUploadDirRelative = 'uploads/avatars/';
                $publicRootPath = defined('APP_ROOT_PATH') ? (rtrim(APP_ROOT_PATH, '/\\') . '/public') : (dirname(__DIR__, 2) . '/public');
                $avatarUploadDirPhysical = rtrim($publicRootPath, '/\\') . '/' . $avatarUploadDirRelative;

                if (!is_dir($avatarUploadDirPhysical)) {
                    if (!mkdir($avatarUploadDirPhysical, 0775, true)) {
                        $errors['profile_picture'] = 'Could not create avatar directory.';
                        error_log("Failed to create directory: " . $avatarUploadDirPhysical);
                    }
                }
                
                if (empty($errors['profile_picture'])) {
                    $targetFilePath = $avatarUploadDirPhysical . $uniqueFileName;
                    if (move_uploaded_file($file['tmp_name'], $targetFilePath)) {
                        $newProfilePicturePath = $avatarUploadDirRelative . $uniqueFileName;
                        $updateData['profile_picture_url'] = $newProfilePicturePath;
                    } else {
                        $errors['profile_picture'] = 'Failed to move uploaded avatar.';
                        error_log("Failed to move avatar: from " . $file['tmp_name'] . " to " . $targetFilePath);
                    }
                }
            }
        } elseif (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] !== UPLOAD_ERR_NO_FILE) {
            $errors['profile_picture'] = 'An error occurred during file upload (Error code: ' . $_FILES['profile_picture']['error'] . ').';
        }

        if (empty($errors)) {
            if (!empty($updateData)) {
                if ($newProfilePicturePath) {
                    $currentUserData = $this->userModel->findById($loggedInUserId);
                    if ($currentUserData && !empty($currentUserData['profile_picture_url'])) {
                        $publicRootPath = defined('APP_ROOT_PATH') ? (rtrim(APP_ROOT_PATH, '/\\') . '/public') : (dirname(__DIR__, 2) . '/public');
                        $oldAvatarPhysicalPath = rtrim($publicRootPath, '/\\') . '/' . ltrim($currentUserData['profile_picture_url'], '/');
                        if (file_exists($oldAvatarPhysicalPath) && is_file($oldAvatarPhysicalPath)) {
                            @unlink($oldAvatarPhysicalPath);
                        }
                    }
                }

                $success = $this->userModel->updateUserProfile($loggedInUserId, $updateData);
                if ($success) {
                    $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'Profile updated successfully!'];
                    if (isset($updateData['email'])) { $_SESSION['email'] = $updateData['email']; } // Update session email if changed
                    if (isset($updateData['profile_picture_url'])) { // Update session profile pic URL if changed
                        $_SESSION['user_profile_pic_url'] = $this->app_url . '/' . ltrim($updateData['profile_picture_url'], '/');
                    }
                    redirect($this->app_url . '/settings/profile');
                    exit;
                } else {
                    $errors['general'] = 'Failed to update profile due to a server error. Please try again.';
                }
            } else if (!isset($_FILES['profile_picture']) || $_FILES['profile_picture']['error'] === UPLOAD_ERR_NO_FILE) {
                 $_SESSION['flash_message'] = ['type' => 'info', 'text' => 'No changes were made to your profile.'];
                 redirect($this->app_url . '/settings/profile');
                 exit;
            }
        }

        $_SESSION['settings_errors'] = $errors;
        $oldRepopulate = $input;
        if ($newProfilePicturePath && isset($input['profile_picture'])) unset($oldRepopulate['profile_picture']);
        $_SESSION['settings_old_input'] = $oldRepopulate;

        redirect($this->app_url . '/settings/profile');
        exit;
    }

    public function showAccountSettings() {
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) {
            $_SESSION['redirect_to'] = $_SERVER['REQUEST_URI'];
            redirect($this->app_url . '/login');
            exit;
        }
        $pageTitle = "Account Settings - Private Closet";
        $errors = $_SESSION['account_settings_errors'] ?? []; unset($_SESSION['account_settings_errors']);
        unset($_SESSION['account_settings_old_input']);
        $data = ['errors' => $errors];
        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('user/settings_account_content', $data);
        $this->loadView('layouts/_footer');
    }

    public function handleAccountSettings() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect($this->app_url . '/settings/account'); exit; }
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) { redirect($this->app_url . '/login'); exit; }
        
        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
             $_SESSION['account_settings_errors']['general'] = 'Invalid security token. Please try again.';
             redirect($this->app_url . '/settings/account');
             exit;
        }

        $input = $_POST;
        $errors = [];
        $currentPassword = $input['current_password'] ?? '';
        $newPassword = $input['new_password'] ?? '';
        $confirmPassword = $input['confirm_password'] ?? '';
        if (empty($currentPassword)) $errors['current_password'] = 'Current password is required.';
        if (empty($newPassword)) $errors['new_password'] = 'New password is required.';
        elseif (strlen($newPassword) < 8) $errors['new_password'] = 'New password must be at least 8 characters.';
        if ($newPassword !== $confirmPassword) $errors['confirm_password'] = 'New passwords do not match.';
        
        if (empty($errors)) {
            $userForPasswordCheck = $this->userModel->findById($loggedInUserId);
            if ($userForPasswordCheck && $this->userModel->verifyPassword($currentPassword, $userForPasswordCheck['password_hash'])) {
                $success = $this->userModel->updatePassword($loggedInUserId, $newPassword);
                if ($success) {
                    $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'Password changed successfully!'];
                    redirect($this->app_url . '/settings/account');
                    exit;
                } else {
                    $errors['general'] = 'Failed to change password due to a server error.';
                }
            } else {
                $errors['current_password'] = 'Incorrect current password.';
            }
        }
        $_SESSION['account_settings_errors'] = $errors;
        redirect($this->app_url . '/settings/account');
        exit;
    }

    public function showNotifications() {
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) {
            $_SESSION['redirect_to'] = $this->app_url . '/settings/notifications';
            redirect($this->app_url . '/login');
            exit;
        }
        $pageTitle = "Notifications - Private Closet";
        $notifications = $this->userModel->getUserNotifications($loggedInUserId, 20);
        
        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('user/notifications_content', ['notifications' => $notifications]);
        $this->loadView('layouts/_footer');
    }

    public function markNotificationRead() {
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) {
            redirect($this->app_url . '/login');
            exit;
        }
        $notificationId = $_REQUEST['notification_id'] ?? null;
        if ($notificationId) {
            $this->userModel->markNotificationAsRead((string)$notificationId, $loggedInUserId);
        }
        $redirectTo = $_SERVER['HTTP_REFERER'] ?? ($this->app_url . '/settings/notifications');
        redirect($redirectTo);
        exit;
    }

    public function markAllNotificationsRead() {
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) {
            redirect($this->app_url . '/login');
            exit;
        }
        $this->userModel->markAllNotificationsAsRead($loggedInUserId);
        $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'All notifications marked as read.'];
        redirect($this->app_url . '/settings/notifications');
        exit;
    }

    public function showClosetFeed() {
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) {
            $_SESSION['redirect_to'] = $this->app_url . '/closets';
            redirect($this->app_url . '/login');
            exit;
        }

        $pageTitle = "Closets - Your Feed";
        $posts = [];
        $followedUserIds = $this->userModel->getFollowedUserIds($loggedInUserId);

        $currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        if ($currentPage < 1) $currentPage = 1;
        $postsPerPage = 5;
        $totalPosts = 0;
        $totalPages = 1;

        if (!empty($followedUserIds)) {
            $totalPosts = $this->postModel->countPostsFromUsers($followedUserIds);
            $totalPages = ($totalPosts > 0) ? (int)ceil($totalPosts / $postsPerPage) : 1;
            if ($currentPage > $totalPages && $totalPages > 0) $currentPage = $totalPages; // Fix
            
            $offset = ($currentPage - 1) * $postsPerPage;
            $posts = $this->postModel->getPostsFromUsers($followedUserIds, $postsPerPage, $offset);
        }
        
        $suggestedFriends = $this->userModel->getSuggestedFriends($loggedInUserId, 3);

        $data = [
            'posts' => $posts,
            'currentPage' => $currentPage,
            'totalPages' => $totalPages,
            'feedType' => 'closets',
            'suggestedFriends' => $suggestedFriends,
        ];

        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('social/closets_feed_content', $data);
        $this->loadView('layouts/_footer');
    }
    
    public function showUserOrders(string $username) {
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        $profileUser = $this->userModel->findByUsername($username);

        if (!$profileUser) {
            $this->loadView('layouts/_header', ['pageTitle' => 'User Not Found']);
            $this->loadView('errors/404_content', ['message' => "Profile for '@" . escape_html($username) . "' not found."]);
            $this->loadView('layouts/_footer');
            return;
        }
        
        if (!$loggedInUserId || $loggedInUserId !== (int)$profileUser['id']) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'You can only view your own order history.'];
            redirect($this->app_url . '/profile/' . $username); 
            exit;
        }

        if (!class_exists('OrderModel')) {
            require_once __DIR__ . '/../Models/OrderModel.php';
        }
        $orderModel = new OrderModel($this->pdo);
        
        $orders = $orderModel->findOrdersByUserId($loggedInUserId); 

        if (!method_exists($orderModel, 'findOrdersByUserId')) {
            error_log("UserController::showUserOrders - OrderModel::findOrdersByUserId method does not exist. (This is a dev check)");
        }

        $pageTitle = "Order History - " . escape_html($profileUser['username']);
        $data = [
            'profileUser' => $profileUser,
            'orders' => $orders,
        ];
        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('user/orders_content', $data);
        $this->loadView('layouts/_footer');
    }

    public function showExploreUsersPage() {
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) {
            $_SESSION['redirect_to'] = $this->app_url . '/explore/users';
            redirect($this->app_url . '/login');
            exit;
        }

        $pageTitle = "Explore People - Private Closet";

        $currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        if ($currentPage < 1) $currentPage = 1;
        $usersPerPage = 12; 
        
        $totalUsers = $this->userModel->countExplorableUsers($loggedInUserId);
        $totalPages = ($totalUsers > 0) ? (int)ceil($totalUsers / $usersPerPage) : 1;
        if ($currentPage > $totalPages && $totalPages > 0) $currentPage = $totalPages; // Fix
        
        $offset = ($currentPage - 1) * $usersPerPage;
        
        $usersToExplore = $this->userModel->getExplorableUsers($loggedInUserId, $usersPerPage, $offset);

        $followedByUser = $this->userModel->getFollowedUserIds($loggedInUserId);
        foreach ($usersToExplore as &$user) {
            $user['is_followed_by_viewer'] = in_array($user['id'], $followedByUser);
        }
        unset($user);

        $data = [
            'usersToExplore' => $usersToExplore,
            'currentPage' => $currentPage,
            'totalPages' => $totalPages,
        ];

        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('user/explore_users_content', $data);
        $this->loadView('layouts/_footer');
    }

    private function loadView(string $viewName, array $data = []) {
        $filePath = rtrim($this->viewPath, '/') . '/' . ltrim($viewName, '/') . '.php';
        $filePath = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $filePath);

        $data['app_url'] = $data['app_url'] ?? $this->app_url;
        $data['isLoggedIn'] = $data['isLoggedIn'] ?? isset($_SESSION['user_id']);
        $data['loggedInUserId'] = $data['loggedInUserId'] ?? ($_SESSION['user_id'] ?? null);
        $data['userRole'] = $data['userRole'] ?? ($_SESSION['user_role'] ?? null);
        $data['csrf_token'] = $data['csrf_token'] ?? ($_SESSION['csrf_token'] ?? ''); // Ensure CSRF is passed
        $data['default_avatar_full_url'] = $data['default_avatar_full_url'] ?? $this->default_avatar_full_url;
        
        if (!isset($data['flashMessage']) && isset($_SESSION['flash_message'])) {
             $data['flashMessage'] = $_SESSION['flash_message'];
             unset($_SESSION['flash_message']); 
        }

        if (file_exists($filePath)) {
            extract($data); 
            require $filePath; 
        } else {
            error_log("UserController::loadView - View file not found: {$filePath}");
            trigger_error("View file not found: " . $filePath, E_USER_ERROR);
        }
    }

    
    
}
?>