<?php
// File: app/Controllers/ShopController.php
// Purpose: Handles requests related to the shop (showroom, product details, cart, checkout, order viewing/tracking).

require_once __DIR__ . '/../Models/ProductModel.php';
require_once __DIR__ . '/../Models/CartModel.php';
require_once __DIR__ . '/../Models/OrderModel.php';
require_once __DIR__ . '/../Models/CategoryModel.php';
require_once __DIR__ . '/../Helpers/utilities.php';
require_once __DIR__ . '/../Models/ProductReviewModel.php'; // Correctly included
require_once __DIR__ . '/../Models/FavoriteProductModel.php';

class ShopController {
    private $pdo;
    private $productModel;
    private $cartModel;
    private $orderModel;
    private $categoryModel;
    private $productReviewModel; // <-- Declare the property
    private $favoriteProductModel; // <-- ADD THIS PROPERTY
    private $viewPath = __DIR__ . '/../Views/';
    private $app_url;
    private $default_avatar_full_url;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->productModel = new ProductModel($pdo);
        $this->cartModel = new CartModel($pdo);
        $this->orderModel = new OrderModel($pdo);
        $this->categoryModel = new CategoryModel($pdo);
        $this->productReviewModel = new ProductReviewModel($pdo); // <-- Instantiate the model
        $this->favoriteProductModel = new FavoriteProductModel($pdo); // <-- INSTANTIATE

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $this->app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
        $default_avatar_path_rel = defined('DEFAULT_AVATAR_PATH') ? DEFAULT_AVATAR_PATH : 'assets/images/default_avatar.png';
        $this->default_avatar_full_url = $this->app_url . '/' . ltrim($default_avatar_path_rel, '/');
    }

    private function loadView(string $viewName, array $data = []) {
        $filePath = rtrim($this->viewPath, '/\\') . DIRECTORY_SEPARATOR . ltrim($viewName, '/\\') . '.php';
        $filePath = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $filePath);

        $data['app_url'] = $data['app_url'] ?? $this->app_url;
        $data['isLoggedIn'] = $data['isLoggedIn'] ?? isset($_SESSION['user_id']);
        $data['loggedInUserId'] = $data['loggedInUserId'] ?? ($_SESSION['user_id'] ?? null);
        $data['userRole'] = $data['userRole'] ?? ($_SESSION['user_role'] ?? null);
        // Ensure CSRF token is generated and passed if not already in data
        if (!isset($data['csrf_token'])) {
            if (empty($_SESSION['csrf_token'])) {
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            }
            $data['csrf_token'] = $_SESSION['csrf_token'];
        }
        $data['default_avatar_full_url'] = $data['default_avatar_full_url'] ?? $this->default_avatar_full_url;
        $data['pageTitle'] = $data['pageTitle'] ?? 'Private Closet';

        if (!isset($data['flashMessage']) && isset($_SESSION['flash_message'])) {
             $data['flashMessage'] = $_SESSION['flash_message'];
             unset($_SESSION['flash_message']);
        }

        if (file_exists($filePath)) {
            extract($data);
            require $filePath;
        } else {
            error_log("ShopController::loadView - CRITICAL: View file not found: " . $filePath);
            http_response_code(500);
            $errorMessage = "A required view file ('" . htmlspecialchars($viewName) . ".php') could not be loaded.";
            if (defined('DEBUG_MODE') && DEBUG_MODE) {
                $errorMessage .= " Attempted path: " . htmlspecialchars($filePath);
            }
            // Consider using a more graceful error display method if available, e.g., via ErrorController
            echo "<h1>Application Error</h1><p>{$errorMessage} Please contact support.</p>";
            exit;
        }
    }

    public function showroom() {
        $categoryFilter = filter_input(INPUT_GET, 'category', FILTER_VALIDATE_INT);
        $sortInput = filter_input(INPUT_GET, 'sort', FILTER_SANITIZE_SPECIAL_CHARS);
        $priceInput = filter_input(INPUT_GET, 'price', FILTER_SANITIZE_SPECIAL_CHARS);

        $allowedSorts = ['newest', 'price_asc', 'price_desc', 'popular'];
        $sort = in_array($sortInput, $allowedSorts, true) ? $sortInput : 'newest';

        $filters = [
            'category' => $categoryFilter ?: null,
            'sort' => $sort,
            'price' => $priceInput
        ];

        $page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, ['options' => ['default' => 1, 'min_range' => 1]]);
        $limit = 12;
        $offset = ($page - 1) * $limit;

        $products = $this->productModel->getShowroomProducts($filters, $limit, $offset);
        $totalProducts = $this->productModel->countShowroomProducts($filters);
        $totalPages = ($totalProducts > 0) ? (int)ceil($totalProducts / $limit) : 1;
        if ($page > $totalPages && $totalPages > 0) {
            $page = $totalPages;
            // $offset = ($page - 1) * $limit; // Re-calculating offset if page changed
            // $products = $this->productModel->getShowroomProducts($filters, $limit, $offset); // Re-fetch if necessary
        }

        $categories = $this->categoryModel->getAll();
        $pageTitle = "Showroom - Private Closet";
        $data = [
            'products' => $products,
            'categories' => $categories,
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'filters' => $filters
        ];

        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('shop/showroom_content', $data);
        $this->loadView('layouts/_footer');
    }

    public function productDetail($identifier) {
        if (empty($identifier)) {
            error_log("ShopController::productDetail - Identifier is empty.");
            http_response_code(400);
            $this->loadView('layouts/_header', ['pageTitle' => 'Error']);
            $this->loadView('errors/404_content', ['message' => 'Product identifier missing.']);
            $this->loadView('layouts/_footer');
            return;
        }

        $product = $this->productModel->findProductByIdOrSlug($identifier); // Ensure this method fetches images and business info

        if (!$product || !is_array($product) || empty($product['id'])) { // Check for product ID as essential
            error_log("ShopController::productDetail - Product not found or invalid for identifier: " . htmlspecialchars($identifier));
            http_response_code(404);
            $this->loadView('layouts/_header', ['pageTitle' => 'Product Not Found']);
            $this->loadView('errors/404_content', ['message' => 'Sorry, the product you are looking for could not be found.']);
            $this->loadView('layouts/_footer');
            return;
        }

        // Ensure product array has default keys expected by the view, even if some data is missing from DB
        $product = array_merge([
            'name' => 'Unknown Product', 'description' => 'No description available.', 'price' => 0.00,
            'stock_quantity' => 0, 'category_name' => 'Uncategorized', 'status' => 'inactive',
            'slug' => $identifier, // Fallback slug
            'sku' => null, 'images' => [], 'business' => ['name' => 'N/A', 'profile_url' => '#']
        ], $product);

        if (!is_array($product['images'])) {
            $product['images'] = [];
        }
        // Image URL preparation should ideally be handled more robustly, possibly in the ProductModel
        // or by ensuring prepareFullUrl is available and used correctly.
        // The view 'product_detail_content.php' already has logic to prefix relative URLs.

        // --- Fetch reviews for the product ---
        $reviews = $this->productReviewModel->getReviewsByProductId((int)$product['id']); // <-- Fetch actual reviews

        $pageTitle = htmlspecialchars($product['name']) . " - Private Closet";
        $data = [
            'product' => $product,
            'reviews' => $reviews, // <-- Pass fetched reviews to the view
            // loggedInUserId and csrf_token are automatically added by loadView if not present
        ];

        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('shop/product_detail_content', $data);
        $this->loadView('layouts/_footer');
    }

    public function handleProductReview(int $productId) {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect($this->app_url . '/product/' . $productId);
            exit;
        }

        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid request. Please try again. (CSRF mismatch)'];
            redirect($this->app_url . '/product/' . $productId . '#reviews');
            exit;
        }

        if (!isset($_SESSION['user_id'])) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'You must be logged in to submit a review.'];
            $_SESSION['review_old_input'] = $_POST;
            redirect($this->app_url . '/login?redirect_to=' . urlencode($this->app_url . '/product/' . $productId . '#reviews'));
            exit;
        }
        $userId = (int)$_SESSION['user_id'];

        $rating = filter_input(INPUT_POST, 'rating', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 5]]);
        $reviewText = trim($_POST['review_text'] ?? '');
        $submittedProductId = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);

        $errors = [];
        if ($submittedProductId !== $productId) {
            $errors['general'] = 'Product ID mismatch.';
        }
        if ($rating === false) {
            $errors['rating'] = 'Please select a rating between 1 and 5 stars.';
        }
        if (empty($reviewText)) {
            $errors['review_text'] = 'Please enter your review.';
        } elseif (mb_strlen($reviewText) > 2000) {
            $errors['review_text'] = 'Your review is too long (max 2000 characters).';
        }

        // Check if ProductReviewModel is loaded and then if user has reviewed
        if ($this->productReviewModel && $this->productReviewModel->hasUserReviewedProduct($userId, $productId)) { // refers to this line (line 650 in original)
            $errors['general'] = 'You have already reviewed this product.';
        }

        if (!empty($errors)) {
            $_SESSION['review_errors'] = $errors;
            $_SESSION['review_old_input'] = $_POST;
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Please correct the errors in your review.'];
        } else {
            $success = $this->productReviewModel->createReview($userId, $productId, $rating, $reviewText);
            if ($success) {
                $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'Thank you! Your review has been submitted.'];
                unset($_SESSION['review_old_input'], $_SESSION['review_errors']);
            } else {
                $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Sorry, there was an issue submitting your review. Please try again.'];
                $_SESSION['review_errors']['general'] = 'Database error during review submission.';
                $_SESSION['review_old_input'] = $_POST; // Keep old input on DB error for retry
            }
        }
        // Attempt to get product slug for a cleaner redirect URL
        $productForRedirect = $this->productModel->findProductByIdOrSlug($productId);
        $redirectIdentifier = $productForRedirect['slug'] ?? $productId;

        redirect($this->app_url . '/product/' . $redirectIdentifier . '#reviews');
        exit;
    }

    // ... Your existing showCart, checkout methods, order methods ...
    // Make sure they also use $this->loadView correctly

    public function showCart() {
        $cartItems = $this->cartModel->getItems();
        $cartTotals = $this->cartModel->getTotals();
        $pageTitle = "Shopping Cart - Private Closet";
        $data = [
            'cartItems' => $cartItems,
            'cartTotals' => $cartTotals,
        ];
        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('shop/cart_content', $data);
        $this->loadView('layouts/_footer');
    }

    public function showCheckoutShipping() {
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['redirect_to'] = $this->app_url . '/checkout/shipping';
            redirect($this->app_url . '/login');
            exit;
        }
        if ($this->cartModel->isEmpty()) {
            $_SESSION['flash_message'] = ['type' => 'warning', 'text' => 'Your cart is empty. Please add items before proceeding to checkout.'];
            redirect($this->app_url . '/cart');
            exit;
        }

        $oldInput = $_SESSION['checkout_shipping_address'] ?? [];
        $errors = $_SESSION['checkout_errors'] ?? [];
        unset($_SESSION['checkout_errors']);

        $pageTitle = "Checkout - Shipping - Private Closet";
        $orderSummary = $this->cartModel->getTotals();

        $data = [
            'errors' => $errors,
            'oldInput' => $oldInput,
            'orderSummary' => $orderSummary,
        ];

        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('shop/checkout_shipping_content', $data);
        $this->loadView('layouts/_footer');
    }

    public function handleCheckoutShipping() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect($this->app_url . '/checkout/shipping');
            exit;
        }
        if (!isset($_SESSION['user_id']) || $this->cartModel->isEmpty()) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'You must be logged in and have items in your cart to proceed.'];
            redirect($this->app_url . '/cart');
            exit;
        }

        if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            $_SESSION['checkout_errors']['general'] = 'Invalid security token. Please refresh the page and try again.';
            error_log("CSRF token mismatch in handleCheckoutShipping.");
            redirect($this->app_url . '/checkout/shipping');
            exit;
        }

        $input = $_POST;
        $errors = [];

        if (empty(trim($input['full_name'] ?? ''))) $errors['full_name'] = 'Full Name is required.';
        if (empty(trim($input['address_line_1'] ?? ''))) $errors['address_line_1'] = 'Street Address is required.';
        if (empty(trim($input['city'] ?? ''))) $errors['city'] = 'City is required.';
        if (empty(trim($input['province'] ?? ''))) $errors['province'] = 'Province is required.';
        if (empty(trim($input['postal_code'] ?? ''))) $errors['postal_code'] = 'Postal Code is required.';
        if (empty(trim($input['phone'] ?? ''))) $errors['phone'] = 'Phone Number is required.';

        if (!empty($errors)) {
            $_SESSION['checkout_errors'] = $errors;
            $_SESSION['checkout_shipping_address'] = $input;
            error_log("handleCheckoutShipping validation errors: " . print_r($errors, true));
            redirect($this->app_url . '/checkout/shipping');
            exit;
        }

        $_SESSION['checkout_shipping_address'] = [
            'full_name' => trim($input['full_name']),
            'address_line_1' => trim($input['address_line_1']),
            'address_line_2' => trim($input['address_line_2'] ?? ''),
            'city' => trim($input['city']),
            'province' => trim($input['province']),
            'postal_code' => trim($input['postal_code']),
            'phone' => trim($input['phone']),
        ];
        unset($_SESSION['checkout_errors']);
        $_SESSION['cart_totals_for_summary'] = $this->cartModel->getTotals();
        error_log("handleCheckoutShipping successful. Redirecting to payment.");
        redirect($this->app_url . '/checkout/payment');
        exit;
    }

    public function showCheckoutPayment() {
        if (!isset($_SESSION['user_id'])) { redirect($this->app_url . '/login'); exit; }
        if (!isset($_SESSION['checkout_shipping_address'])) {
            $_SESSION['flash_message'] = ['type' => 'warning', 'text' => 'Please complete shipping details first.'];
            redirect($this->app_url . '/checkout/shipping');
            exit;
        }
        if ($this->cartModel->isEmpty()) {
            $_SESSION['flash_message'] = ['type' => 'warning', 'text' => 'Your cart is empty.'];
            redirect($this->app_url . '/cart'); exit;
        }

        $shippingAddress = $_SESSION['checkout_shipping_address'];
        $orderSummary = $_SESSION['cart_totals_for_summary'] ?? $this->cartModel->getTotals();

        $errors = $_SESSION['checkout_errors'] ?? [];
        unset($_SESSION['checkout_errors']);
        $oldInput = $_SESSION['checkout_payment_input'] ?? [];

        $pageTitle = "Checkout - Payment - Private Closet";
        $data = [
            'orderSummary' => $orderSummary,
            'shippingAddress' => $shippingAddress,
            'errors' => $errors,
            'oldInput' => $oldInput,
        ];

        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('shop/checkout_payment_content', $data);
        $this->loadView('layouts/_footer');
    }

    public function handleCheckoutPayment() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect($this->app_url . '/checkout/payment'); exit; }
        if (!isset($_SESSION['user_id']) || !isset($_SESSION['checkout_shipping_address']) || $this->cartModel->isEmpty()) {
            redirect($this->app_url . '/cart'); exit;
        }
        if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            $_SESSION['checkout_errors']['general'] = 'Invalid security token. Please try again.';
            error_log("CSRF token mismatch in handleCheckoutPayment.");
            redirect($this->app_url . '/checkout/payment');
            exit;
        }

        $input = $_POST;
        $_SESSION['checkout_payment_input'] = $input;
        $errors = [];

        $paymentMethod = $input['payment_method'] ?? '';
        $billingOption = $input['billing_address_option'] ?? 'same';

        if (empty($paymentMethod) || !in_array($paymentMethod, ['card', 'eft_secure', 'manual_eft'])) {
            $errors['payment_method'] = 'Please select a valid payment method.';
        }
        if (!in_array($billingOption, ['same', 'different'])) {
            $errors['billing_address_option'] = 'Invalid billing address option.';
        }

        $billingAddress = $_SESSION['checkout_shipping_address'];
        if ($billingOption === 'different') {
            if (empty(trim($input['billing_full_name'] ?? ''))) $errors['billing_full_name'] = 'Billing Full Name is required for different billing address.';
            if (empty(trim($input['billing_address_line_1'] ?? ''))) $errors['billing_address_line_1'] = 'Billing Street Address is required.';
            if (empty(trim($input['billing_city'] ?? ''))) $errors['billing_city'] = 'Billing City is required.';
            // Add province, postal_code validation for billing if needed

            if (empty($errors)) {
                $billingAddress = [
                    'full_name' => trim($input['billing_full_name']),
                    'address_line_1' => trim($input['billing_address_line_1'] ?? ''),
                    'address_line_2' => trim($input['billing_address_line_2'] ?? ''),
                    'city' => trim($input['billing_city'] ?? ''),
                    'province' => trim($input['billing_province'] ?? ''),
                    'postal_code' => trim($input['billing_postal_code'] ?? ''),
                    'phone' => trim($input['billing_phone'] ?? ($shippingAddress['phone'] ?? '')),
                ];
            }
        }

        if (!empty($errors)) {
            $_SESSION['checkout_errors'] = $errors;
            redirect($this->app_url . '/checkout/payment');
            exit;
        }

        $_SESSION['checkout_payment_method'] = $paymentMethod;
        $_SESSION['checkout_billing_option'] = $billingOption;
        if ($billingOption === 'different') {
            $_SESSION['checkout_billing_address'] = $billingAddress;
        } else {
            unset($_SESSION['checkout_billing_address']);
        }
        unset($_SESSION['checkout_errors']);
        unset($_SESSION['checkout_payment_input']);
        redirect($this->app_url . '/checkout/review');
        exit;
    }

     public function showCheckoutReview() {
        if (!isset($_SESSION['user_id'])) { redirect($this->app_url . '/login'); exit; }
        if (!isset($_SESSION['checkout_shipping_address'])) { redirect($this->app_url . '/checkout/shipping'); exit; }
        if (!isset($_SESSION['checkout_payment_method'])) { redirect($this->app_url . '/checkout/payment'); exit; }
        if ($this->cartModel->isEmpty()) {
             $_SESSION['flash_message'] = ['type' => 'warning', 'text' => 'Your cart is empty. Cannot review order.'];
            redirect($this->app_url . '/cart'); exit;
        }

        $shippingAddress = $_SESSION['checkout_shipping_address'];
        $billingAddressOption = $_SESSION['checkout_billing_option'] ?? 'same';
        $billingAddress = ($billingAddressOption === 'different' && isset($_SESSION['checkout_billing_address']))
            ? $_SESSION['checkout_billing_address']
            : $shippingAddress;
        $paymentMethod = $_SESSION['checkout_payment_method'];
        $cartItems = $this->cartModel->getItems();
        $orderSummary = $this->cartModel->getTotals();

        if (empty($cartItems)) {
            $_SESSION['flash_message'] = ['type' => 'warning', 'text' => 'Your cart became empty. Please add items.'];
            redirect($this->app_url . '/cart');
            exit;
        }

        $pageTitle = "Checkout - Review Order - Private Closet";
        $data = [
            'shippingAddress' => $shippingAddress,
            'billingAddress' => $billingAddress,
            'paymentMethod' => $paymentMethod,
            'cartItems' => $cartItems,
            'orderSummary' => $orderSummary,
        ];

        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('shop/checkout_review_content', $data);
        $this->loadView('layouts/_footer');
    }

    public function placeOrder() {
        error_log("ShopController::placeOrder - Method started. Request Method: " . $_SERVER['REQUEST_METHOD']);

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            error_log("ShopController::placeOrder - Invalid request method. Redirecting to review.");
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid request to place order.'];
            redirect($this->app_url . '/checkout/review');
            exit;
        }

        error_log("ShopController::placeOrder - CSRF Token Check. POST: " . ($_POST['csrf_token'] ?? 'NOT SET') . " | SESSION: " . ($_SESSION['csrf_token'] ?? 'NOT SET'));
        if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid security token. Order not placed. Please try again.'];
            error_log("ShopController::placeOrder - CSRF token mismatch. Redirecting to review.");
            redirect($this->app_url . '/checkout/review');
            exit;
        }

        if (!isset($_SESSION['user_id'])) {
            error_log("ShopController::placeOrder - User not logged in. Redirecting to login.");
            $_SESSION['redirect_to'] = $this->app_url . '/checkout/review';
            redirect($this->app_url . '/login');
            exit;
        }

        if (!isset($_SESSION['checkout_shipping_address']) || !isset($_SESSION['checkout_payment_method']) || $this->cartModel->isEmpty()) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Your checkout session has expired or your cart is empty. Please start over.'];
            error_log("ShopController::placeOrder - Missing session data or empty cart.");
            redirect($this->app_url . '/cart');
            exit;
        }

        $userId = (int)$_SESSION['user_id'];
        $shippingAddress = $_SESSION['checkout_shipping_address'];
        $billingAddressOption = $_SESSION['checkout_billing_option'] ?? 'same';
        $billingAddress = ($billingAddressOption === 'different' && isset($_SESSION['checkout_billing_address']))
            ? $_SESSION['checkout_billing_address']
            : $shippingAddress;
        $paymentMethod = $_SESSION['checkout_payment_method'];
        $cartItems = $this->cartModel->getItems();
        $orderTotals = $this->cartModel->getTotals();

        if (empty($cartItems)) {
             $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Your cart is empty. Cannot place order.'];
             error_log("ShopController::placeOrder - Cart is empty right before creating order for UserID: {$userId}.");
             redirect($this->app_url . '/cart');
             exit;
        }

        error_log("ShopController::placeOrder - All checks passed. UserID: {$userId}, PM: {$paymentMethod}, Items: " . count($cartItems));

        $initialOrderStatus = 'awaiting_payment'; // Default for manual methods or if pre-auth fails
        $paymentStatus = 'pending'; // Default payment status
        $paymentGatewayRef = null;


        if ($paymentMethod === 'card' || $paymentMethod === 'eft_secure') {
            // SIMULATE PAYMENT GATEWAY INTERACTION
            // In a real scenario, you would call your payment gateway API here.
            // For simulation, we'll assume success and generate a reference.
            $paymentIsSuccessful = true; // TODO: Replace with actual payment gateway call

            if ($paymentIsSuccessful) {
                $initialOrderStatus = 'processing'; // Or 'pending' if further verification needed
                $paymentStatus = 'paid';
                $paymentGatewayRef = 'SIM_PAYMENT_' . strtoupper($paymentMethod) . '_' . bin2hex(random_bytes(8));
                error_log("ShopController::placeOrder - Simulated successful payment for {$paymentMethod}. Ref: {$paymentGatewayRef}");
            } else {
                $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Payment via ' . htmlspecialchars(ucfirst(str_replace('_', ' ', $paymentMethod))) . ' failed at the gateway. Please try again or choose a different method.'];
                error_log("ShopController::placeOrder - Simulated FAILED payment for {$paymentMethod}.");
                redirect($this->app_url . '/checkout/payment');
                exit;
            }
        } elseif ($paymentMethod === 'manual_eft') {
            $initialOrderStatus = 'awaiting_payment'; // User needs to make manual payment
            $paymentStatus = 'pending';
            error_log("ShopController::placeOrder - Order set to 'awaiting_payment' for Manual EFT. UserID: {$userId}");
        } else {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid payment method selected. Order not placed.'];
            error_log("ShopController::placeOrder - Invalid payment method '{$paymentMethod}'. Redirecting to payment selection.");
            redirect($this->app_url . '/checkout/payment');
            exit;
        }

        $orderData = [
            'user_id' => $userId,
            'shipping_address_json' => json_encode($shippingAddress),
            'billing_address_json' => json_encode($billingAddress),
            'payment_method' => $paymentMethod,
            'payment_status' => $paymentStatus, // Use the determined payment status
            'total_amount' => $orderTotals['grand_total'], // Use grand_total from cart
            'sub_total' => $orderTotals['sub_total'],
            'shipping_cost' => $orderTotals['shipping_cost'],
            'status' => $initialOrderStatus, // Use the determined order status
            'payment_gateway_ref' => $paymentGatewayRef, // Null if not applicable
            'items' => $cartItems // Pass cart items to createOrder
        ];

        $orderId = $this->orderModel->createOrder($orderData);


        if ($orderId) {
            error_log("ShopController::placeOrder - Order created successfully with ID: {$orderId}. Clearing cart.");
            $this->cartModel->clear();
            unset(
                $_SESSION['checkout_shipping_address'], $_SESSION['checkout_billing_option'],
                $_SESSION['checkout_billing_address'], $_SESSION['checkout_payment_method'],
                $_SESSION['checkout_errors'], $_SESSION['checkout_payment_input'],
                $_SESSION['cart_totals_for_summary']
            );
            // Set a success flash message which the order confirmation page can display
            $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'Your order (#' . $orderId . ') has been successfully placed!'];
            redirect($this->app_url . '/order/success?order_id=' . $orderId);
            exit;
        } else {
            // OrderModel::createOrder should ideally set a flash message if it fails.
            if (!isset($_SESSION['flash_message'])) {
                 $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'There was a problem creating your order. Please try again or contact support if the issue persists.'];
            }
            error_log("ShopController::placeOrder - OrderModel::createOrder returned false for user ID: {$userId}.");
            redirect($this->app_url . '/checkout/review');
            exit;
        }
    }


    public function showOrderConfirmation() {
        if (!isset($_SESSION['user_id'])) { redirect($this->app_url . '/login'); exit; }

        $loggedInUserId = (int)$_SESSION['user_id'];
        $orderId = filter_input(INPUT_GET, 'order_id', FILTER_VALIDATE_INT);

        if (!$orderId) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid order ID provided.'];
            redirect($this->app_url . '/profile/' . ($_SESSION['username'] ?? '') . '/orders'); // Redirect to user's order list
            exit;
        }

        $order = $this->orderModel->findOrderByIdForUser($orderId, $loggedInUserId); // Ensure this method exists

        if (!$order) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Order not found or you do not have permission to view it.'];
            redirect($this->app_url . '/profile/' . ($_SESSION['username'] ?? '') . '/orders');
            exit;
        }

        $pageTitle = "Order Confirmed - #" . escape_html($order['id'] ?? $orderId);
        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('shop/order_confirmation_content', ['order' => $order]);
        $this->loadView('layouts/_footer');
    }


    public function showOrderDetail(int $orderId) {
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) {
            $_SESSION['redirect_to'] = $this->app_url . '/order/detail/' . $orderId;
            redirect($this->app_url . '/login');
            exit;
        }

        $order = $this->orderModel->findOrderByIdForUser($orderId, $loggedInUserId); // Ensure this method exists and fetches items

        if (!$order) {
            $pageTitle = 'Order Not Found';
            $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
            $this->loadView('errors/404_content', ['message' => 'The requested order could not be found or you do not have permission to view it.']);
            $this->loadView('layouts/_footer');
            exit;
        }

        $pageTitle = "Order Details - #" . escape_html($order['id'] ?? $orderId);
        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('shop/order_detail_content', ['order' => $order]);
        $this->loadView('layouts/_footer');
    }


    public function showOrderTracking(int $orderId) {
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) {
            $_SESSION['redirect_to'] = $this->app_url . '/order/track/' . $orderId;
            redirect($this->app_url . '/login');
            exit;
        }

        // Use a method that fetches order details including tracking specifically for a user
        $order = $this->orderModel->findOrderByIdForUser($orderId, $loggedInUserId);

        if (!$order) {
            $pageTitle = 'Order Not Found';
            $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
            $this->loadView('errors/404_content', ['message' => 'The requested order could not be found or you do not have permission to view its tracking.']);
            $this->loadView('layouts/_footer');
            exit;
        }
        
        // Ensure these fields are present, possibly fetched by the model or default them
        $order['shipping_provider'] = $order['shipping_provider'] ?? 'Not yet specified';
        $order['tracking_number'] = $order['tracking_number'] ?? 'Not yet available';

        $pageTitle = "Track Order - #" . escape_html($order['id'] ?? $orderId);
        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('shop/order_track_content', ['order' => $order]);
        $this->loadView('layouts/_footer');
    }

    public function toggleFavorite() {
        header('Content-Type: application/json'); // Ensure JSON response

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
            exit;
        }

        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['success' => false, 'message' => 'Please log in to add favorites.', 'redirectToLogin' => true]);
            exit;
        }

        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
            echo json_encode(['success' => false, 'message' => 'Invalid security token. Please refresh and try again.']);
            exit;
        }

        $productId = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
        $userId = (int)$_SESSION['user_id'];

        if (!$productId) {
            echo json_encode(['success' => false, 'message' => 'Invalid product ID.']);
            exit;
        }

        // Check if product exists (optional but good for robustness)
        // if (!$this->productModel->findProductByIdOrSlug($productId)) {
        //     echo json_encode(['success' => false, 'message' => 'Product not found.']);
        //     exit;
        // }

        $isCurrentlyFavorited = $this->favoriteProductModel->isFavorited($userId, $productId);

        if ($isCurrentlyFavorited) {
            $success = $this->favoriteProductModel->removeFavorite($userId, $productId);
            if ($success) {
                echo json_encode(['success' => true, 'isFavorited' => false, 'message' => 'Removed from favorites.']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to remove from favorites.']);
            }
        } else {
            $success = $this->favoriteProductModel->addFavorite($userId, $productId);
            if ($success) {
                echo json_encode(['success' => true, 'isFavorited' => true, 'message' => 'Added to favorites!']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to add to favorites.']);
            }
        }
        exit;
    }

}
?>