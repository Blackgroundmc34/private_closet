<?php
// File: app/Controllers/MessageController.php

require_once __DIR__ . '/../Models/MessageModel.php';
require_once __DIR__ . '/../Models/UserModel.php'; // Optional, if needed for more user details
require_once __DIR__ . '/../Helpers/utilities.php';

class MessageController {
    private $pdo;
    private $messageModel;
    private $userModel; // UserModel can be null if class doesn't exist
    private $viewPath = __DIR__ . '/../Views/';

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->messageModel = new MessageModel($pdo);
        if (class_exists('UserModel')) {
            $this->userModel = new UserModel($pdo);
        }
    }

    private function outputJson($data, $statusCode = 200) {
        if (ob_get_length() > 0) { // Clear output buffer if anything was outputted before (e.g. notices)
            ob_end_clean();
        }
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');

        // Ensure data is UTF-8 safe before encoding
        // This is a basic attempt; more complex data might need deeper sanitization
        array_walk_recursive($data, function (&$item) {
            if (is_string($item) && !mb_check_encoding($item, 'UTF-8')) {
                $item = mb_convert_encoding($item, 'UTF-8', 'UTF-8'); // Convert assuming it's already somewhat UTF-8 like
            }
        });

        $jsonResponse = json_encode($data);

        if ($jsonResponse === false) {
            $jsonErrorMsg = json_last_error_msg();
            error_log("MessageController::outputJson - json_encode FAILED: " . $jsonErrorMsg . " Data that failed: " . substr(print_r($data, true), 0, 1000));
            // Fallback to a known safe JSON error response
            http_response_code(500); // Already set if $statusCode was 500
            echo '{"success":false,"message":"Server error: Could not encode JSON response. Details: ' . escape_html($jsonErrorMsg) . '"}';
        } else {
            echo $jsonResponse;
        }
        exit;
    }

    public function handleSendMessage() {
        error_log('MessageController::handleSendMessage - Request received.');
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            error_log('MessageController::handleSendMessage - Incorrect method: ' . $_SERVER['REQUEST_METHOD']);
            $this->outputJson(['success' => false, 'message' => 'Invalid request method.'], 405);
        }

        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) {
            error_log('MessageController::handleSendMessage - User not authenticated.');
            $this->outputJson(['success' => false, 'message' => 'Authentication required.'], 401);
        }
        $loggedInUserId = (int)$loggedInUserId;

        $messageText = trim($_POST['message_text'] ?? '');
        $conversationId = filter_input(INPUT_POST, 'conversation_id', FILTER_VALIDATE_INT);

        error_log("MessageController::handleSendMessage - UserID:{$loggedInUserId}, ConvoID:{$conversationId}, TextLen:" . strlen($messageText));

        if (!$conversationId || $conversationId <= 0) {
            error_log('MessageController::handleSendMessage - Invalid Conversation ID: ' . print_r($conversationId, true));
            $this->outputJson(['success' => false, 'message' => 'Invalid conversation ID provided.'], 400);
        }
        if (empty($messageText)) {
            error_log('MessageController::handleSendMessage - Message text is empty.');
            $this->outputJson(['success' => false, 'message' => 'Message cannot be empty.'], 400);
        }
        if (!$this->messageModel->isUserParticipant($loggedInUserId, $conversationId)) {
            error_log('MessageController::handleSendMessage - User {$loggedInUserId} not participant in convo {$conversationId}.');
            $this->outputJson(['success' => false, 'message' => 'You are not a participant in this conversation.'], 403);
        }

        try {
            $newMessage = $this->messageModel->sendMessage($conversationId, $loggedInUserId, $messageText);

            if ($newMessage && is_array($newMessage)) {
                error_log('MessageController::handleSendMessage - Message processed by model successfully.');
                $this->outputJson(['success' => true, 'message' => 'Message sent.', 'data' => $newMessage]);
            } else {
                error_log('MessageController::handleSendMessage - Model sendMessage returned null or non-array. Check model logs. Return: ' . print_r($newMessage, true));
                $this->outputJson(['success' => false, 'message' => 'Failed to send message; server could not process it.'], 500);
            }
        } catch (Throwable $e) {
            error_log('MessageController::handleSendMessage - EXCEPTION: ' . $e->getMessage() . "\nTRACE:\n" . $e->getTraceAsString());
            $this->outputJson(['success' => false, 'message' => 'A server error occurred while sending the message.'], 500);
        }
    }

    public function showBoardroom() {
        error_log("MessageController::showBoardroom - Method Reached");
        $loggedInUserId = $_SESSION['user_id'] ?? null;
        if (!$loggedInUserId) { $_SESSION['redirect_to'] = APP_URL . '/boardroom'; redirect(APP_URL . '/login'); }
        $loggedInUserId = (int)$loggedInUserId;

        $pageTitle = "Boardroom - Private Closet";
        $conversations = []; $selectedConversationId = null; $messages = []; $recipient = null;
        $pageContentError = null; $initialLastMessageTimestamp = 0;
        $flashMessage = $_SESSION['flash_message'] ?? null; unset($_SESSION['flash_message']);

        try {
            if (isset($_GET['start_with_user']) && is_numeric($_GET['start_with_user'])) {
                $otherUserId = (int)$_GET['start_with_user'];
                if ($otherUserId !== $loggedInUserId) {
                    $newConversationId = $this->messageModel->findOrCreateConversation($loggedInUserId, $otherUserId);
                    if ($newConversationId) { redirect(APP_URL . '/boardroom?conversation_id=' . $newConversationId); }
                    else { $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Could not start or find conversation.']; redirect(APP_URL . '/boardroom'); }
                } else { $_SESSION['flash_message'] = ['type' => 'warning', 'text' => 'Cannot message yourself.']; redirect(APP_URL . '/boardroom'); }
            }
            $conversations = $this->messageModel->getUserConversations($loggedInUserId);
            if (isset($_GET['conversation_id']) && is_numeric($_GET['conversation_id'])) {
                $currentSelectedConvId = (int)$_GET['conversation_id'];
                if ($this->messageModel->isUserParticipant($loggedInUserId, $currentSelectedConvId)) { $selectedConversationId = $currentSelectedConvId; }
                else { $flashMessage = ['type' => 'error', 'text' => 'You are not part of this conversation.']; } // Don't unset selectedConversationId, let view handle
            }
            if ($selectedConversationId) {
                $messages = $this->messageModel->getMessages($selectedConversationId, $loggedInUserId);
                $recipient = $this->messageModel->getRecipientDetails($selectedConversationId, $loggedInUserId);
                if (!empty($messages)) { $lastMessage = end($messages); $initialLastMessageTimestamp = $lastMessage['message_timestamp'] ?? 0; }
                else { $this->messageModel->markMessagesAsRead($selectedConversationId, $loggedInUserId); } // Mark as read even if empty
            }
        } catch (Throwable $e) { error_log("MessageController::showBoardroom Exception: " . $e->getMessage() . "\n" . $e->getTraceAsString()); $pageContentError = "Error loading messages. Please check logs."; }

        $dataForView = [
            'conversations' => $conversations,
            'selectedConversationId' => $selectedConversationId,
            'messages' => $messages,
            'recipient' => $recipient,
            'loggedInUserId' => $loggedInUserId,
            'pageContentError' => $pageContentError,
            'initialLastMessageTimestamp' => $initialLastMessageTimestamp,
            'appUrl' => APP_URL, // Crucial for JavaScript
            'flashMessage' => $flashMessage
        ];

        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        if ($pageContentError && defined('DEBUG_MODE') && DEBUG_MODE) { echo '<div class="text-red-500 p-4">APP ERROR: ' . htmlspecialchars($pageContentError) . ' (Check PHP error logs)</div>'; }
        elseif($pageContentError) { echo '<div class="text-red-500 p-4">' . htmlspecialchars($pageContentError) . '</div>';}
        $this->loadView('social/boardroom_content', $dataForView);
        $this->loadView('layouts/_footer');
    }

    public function ajaxFetchNewMessages() {
        $loggedInUserId = (int)($_SESSION['user_id'] ?? 0);
        if (!$loggedInUserId) { $this->outputJson(['success' => false, 'message' => 'Authentication required.'], 401); }
        $conversationId = filter_input(INPUT_GET, 'conversation_id', FILTER_VALIDATE_INT);
        $lastTimestamp = filter_input(INPUT_GET, 'last_timestamp', FILTER_VALIDATE_INT); // Allow 0

        if (!$conversationId || $lastTimestamp === false || $lastTimestamp === null) { // last_timestamp can be 0
            $this->outputJson(['success' => false, 'message' => 'Missing or invalid parameters for fetching messages.'], 400);
        }
        if (!$this->messageModel->isUserParticipant($loggedInUserId, $conversationId)) {
            $this->outputJson(['success' => false, 'message' => 'Access denied to fetch messages for this conversation.'], 403);
        }
        try {
            $newMessages = $this->messageModel->getNewMessagesAfter($conversationId, $loggedInUserId, (string)$lastTimestamp);
            $this->outputJson(['success' => true, 'data' => $newMessages]);
        } catch (Throwable $e) {
            error_log("MessageController::ajaxFetchNewMessages Exception: " . $e->getMessage());
            $this->outputJson(['success' => false, 'message' => 'Server error while fetching new messages.'], 500);
        }
    }

    public function ajaxFetchUserConversations() {
        $loggedInUserId = (int)($_SESSION['user_id'] ?? 0);
        if (!$loggedInUserId) { $this->outputJson(['success' => false, 'message' => 'Authentication required.'], 401); }
        try {
            $conversations = $this->messageModel->getUserConversations($loggedInUserId);
            $this->outputJson(['success' => true, 'data' => $conversations]);
        } catch (Throwable $e) {
            error_log("MessageController::ajaxFetchUserConversations Exception: " . $e->getMessage());
            $this->outputJson(['success' => false, 'message' => 'Server error while fetching conversations.'], 500);
        }
    }

    private function loadView(string $viewName, array $data = []) {
        $filePath = rtrim($this->viewPath, '/') . '/' . $viewName . '.php';
        $filePath = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $filePath);
        if (file_exists($filePath)) {
            extract($data);
            require $filePath;
        } else {
            error_log("MessageController::loadView - View file not found: " . $filePath);
            if (defined('DEBUG_MODE') && DEBUG_MODE) {
                echo "<p style='color:red; background:white; padding:10px; border:1px solid red;'>View file not found: " . htmlspecialchars($filePath) . "</p>";
            }
        }
    }
}
?>