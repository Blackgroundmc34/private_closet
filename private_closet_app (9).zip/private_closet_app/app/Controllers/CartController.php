<?php
// File: app/Controllers/CartController.php

require_once __DIR__ . '/../Models/CartModel.php';
require_once __DIR__ . '/../Models/ProductModel.php'; 
require_once __DIR__ . '/../Helpers/utilities.php';   

class CartController {
    private $pdo;
    private $cartModel;
    private $productModel; 
    private $viewPath = __DIR__ . '/../Views/';

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->cartModel = new CartModel($pdo); 
        $this->productModel = new ProductModel($pdo);

        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
    }

    private function sendJsonResponse(array $data, int $statusCode = 200): void {
        // Clear output buffer to prevent PHP notices/warnings from breaking JSON
        if (ob_get_level() > 0) {
            ob_end_clean();
        }
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        // Ensure data is UTF-8 encoded before json_encode
        array_walk_recursive($data, function (&$item) {
            if (is_string($item) && !mb_check_encoding($item, 'UTF-8')) {
                $item = mb_convert_encoding($item, 'UTF-8', 'UTF-8'); 
            }
        });
        $jsonResponse = json_encode($data);
        if ($jsonResponse === false) {
            $jsonErrorMsg = json_last_error_msg();
            error_log("CartController::sendJsonResponse - json_encode FAILED: " . $jsonErrorMsg);
            // Fallback to a known safe JSON error response
            http_response_code(500); 
            echo '{"success":false,"message":"Server error: Could not encode JSON response. Details: ' . htmlspecialchars($jsonErrorMsg) . '"}';
        } else {
            echo $jsonResponse;
        }
        exit;
    }

    public function add() {
        // Set header at the very beginning if possible, though sendJsonResponse will also set it.
        // header('Content-Type: application/json'); 

        try {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                $this->sendJsonResponse(['success' => false, 'message' => 'Invalid request method.'], 405);
            }

            if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
                error_log("CartController::add - CSRF token validation failed. SESSION: " . ($_SESSION['csrf_token'] ?? 'Not Set') . " POST: " . ($_POST['csrf_token'] ?? 'Not Set'));
                $this->sendJsonResponse(['success' => false, 'message' => 'Invalid security token. Please refresh and try again.'], 403);
            }

            $productId = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
            $quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT, ['options' => ['default' => 1, 'min_range' => 1]]);

            if (!$productId) {
                $this->sendJsonResponse(['success' => false, 'message' => 'Product ID is required and must be numeric.'], 400);
            }
            
            $productDetailsFromForm = [
                'name' => filter_input(INPUT_POST, 'product_name', FILTER_SANITIZE_SPECIAL_CHARS),
                'price' => filter_input(INPUT_POST, 'product_price', FILTER_VALIDATE_FLOAT),
                'image' => filter_input(INPUT_POST, 'product_image', FILTER_SANITIZE_URL),
                'slug' => filter_input(INPUT_POST, 'product_slug', FILTER_SANITIZE_SPECIAL_CHARS),
                'business_name' => filter_input(INPUT_POST, 'business_name', FILTER_SANITIZE_SPECIAL_CHARS)
            ];

            if (empty($productDetailsFromForm['name']) || $productDetailsFromForm['price'] === false) {
                 error_log("CartController::add - Missing essential product details from form for product ID: {$productId}. Data: " . print_r($_POST, true));
                 $this->sendJsonResponse(['success' => false, 'message' => 'Essential product information is missing. Cannot add to cart.'], 400);
            }

            $productFromDb = $this->productModel->findProductByIdOrSlug($productId);
            if (!$productFromDb) {
                $this->sendJsonResponse(['success' => false, 'message' => 'Product not found in database.'], 404);
            }
            if (($productFromDb['stock_quantity'] ?? 0) < $quantity) {
                $this->sendJsonResponse(['success' => false, 'message' => 'Not enough stock available. Only ' . ($productFromDb['stock_quantity'] ?? 0) . ' left.'], 400);
            }
            $productDetailsFromForm['price'] = (float)$productFromDb['price'];

            $options = []; // Example: $options = ['size' => $_POST['size'], 'color' => $_POST['color']];

            $success = $this->cartModel->addItem($productId, $quantity, $productDetailsFromForm, $options);

            if ($success) {
                $totals = $this->cartModel->getTotals();
                $this->sendJsonResponse([
                    'success' => true,
                    'message' => htmlspecialchars($productDetailsFromForm['name']) . ' added to cart!',
                    'cart_item_count' => $totals['item_count']
                ]);
            } else {
                // Check for flash message set by CartModel for specific errors like out of stock
                $flashMessage = $_SESSION['flash_message']['text'] ?? 'Could not add item to cart. Please try again.';
                unset($_SESSION['flash_message']); // Clear it
                $this->sendJsonResponse(['success' => false, 'message' => $flashMessage], 500);
            }

        } catch (Throwable $e) {
            error_log("CartController::add Exception: " . $e->getMessage() . "\nTrace: " . $e->getTraceAsString());
            $this->sendJsonResponse(['success' => false, 'message' => 'An unexpected server error occurred while adding to cart.'], 500);
        }
    }

    public function view() {
        // ... (view method remains the same as previously provided)
        $cartItemsWithDetails = $this->cartModel->getItems(); 
        $cartTotals = $this->cartModel->getTotals();
        
        $pageTitle = "Shopping Cart - Private Closet";
        $data = [
            'cartItems' => $cartItemsWithDetails,
            'cartTotals' => $cartTotals,
            'pageTitle' => $pageTitle,
        ];

        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('shop/cart_content', $data);
        $this->loadView('layouts/_footer');
    }

    public function update() {
        // ... (update method remains the same, ensure CSRF and robust error handling)
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(APP_URL . '/cart'); 
            return;
        }
        // Basic CSRF Check
        if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid security token.'];
            redirect(APP_URL . '/cart');
            return;
        }

        $cartItemId = filter_input(INPUT_POST, 'cart_item_id', FILTER_SANITIZE_SPECIAL_CHARS); 
        $quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);

        if (!$cartItemId || $quantity === false) { 
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid data for cart update.'];
            redirect(APP_URL . '/cart');
            return;
        }

        if ($this->cartModel->updateItem($cartItemId, $quantity)) {
            $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'Cart updated successfully.'];
        } else {
            // CartModel might set a more specific flash message for out of stock
            if (!isset($_SESSION['flash_message'])) {
                 $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Could not update cart item.'];
            }
        }
        redirect(APP_URL . '/cart');
    }

    public function remove() {
        // ... (remove method remains the same, ensure CSRF)
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(APP_URL . '/cart');
            return;
        }
        // Basic CSRF Check
        if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid security token.'];
            redirect(APP_URL . '/cart');
            return;
        }

        $cartItemId = filter_input(INPUT_POST, 'cart_item_id', FILTER_SANITIZE_SPECIAL_CHARS);

        if (!$cartItemId) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid item for removal.'];
            redirect(APP_URL . '/cart');
            return;
        }

        if ($this->cartModel->removeItem($cartItemId)) {
            $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'Item removed from cart.'];
        } else {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Could not remove item from cart.'];
        }
        redirect(APP_URL . '/cart');
    }

    private function loadView(string $viewName, array $data = []) {
        // ... (loadView method remains the same)
        $filePath = rtrim($this->viewPath, '/\\') . DIRECTORY_SEPARATOR . ltrim($viewName, '/\\') . '.php';
        $filePath = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $filePath);

        if (file_exists($filePath)) {
            $data['app_url'] = $data['app_url'] ?? (defined('APP_URL') ? APP_URL : '');
            $data['isLoggedIn'] = $data['isLoggedIn'] ?? isset($_SESSION['user_id']);
            $data['userRole'] = $data['userRole'] ?? ($_SESSION['user_role'] ?? null);
            $data['csrf_token'] = $data['csrf_token'] ?? ($_SESSION['csrf_token'] ?? '');
            
            extract($data);
            require $filePath;
        } else {
            error_log("CartController::loadView - View file not found: " . $filePath);
            http_response_code(500);
            echo "<h1>Application Error</h1><p>A required view file ('" . htmlspecialchars($viewName) . ".php') was not found.</p>";
            if (defined('DEBUG_MODE') && DEBUG_MODE) {
                echo "<p>Attempted path: " . htmlspecialchars($filePath) . "</p>";
            }
            exit;
        }
    }
}
