<?php
// File: app/Controllers/AdminController.php

require_once __DIR__ . '/../Models/CategoryModel.php';
require_once __DIR__ . '/../Helpers/utilities.php'; // For escape_html, redirect

class AdminController {
    private $pdo;
    private $categoryModel;
    private $viewPath = __DIR__ . '/../Views/';

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->categoryModel = new CategoryModel($pdo);
    }

    /**
     * Middleware to check if the user is an admin.
     * Redirects if not an admin.
     */
    private function isAdmin(): void {
        if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'admin') {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Access Denied. Administrator privileges required.'];
            redirect(APP_URL . '/login'); // Or to a general dashboard
            exit;
        }
    }

    /**
     * Displays the form to add a new category.
     */
    public function showAddCategoryForm() {
        $this->isAdmin(); // Ensure only admin can access

        $pageTitle = "Admin - Add New Category";
        $allCategories = $this->categoryModel->getAll(); // For parent category dropdown

        $errors = $_SESSION['add_category_errors'] ?? [];
        $oldInput = $_SESSION['add_category_old_input'] ?? [];
        unset($_SESSION['add_category_errors'], $_SESSION['add_category_old_input']);

        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('admin/category_add_form_content', [
            'allCategories' => $allCategories,
            'errors' => $errors,
            'oldInput' => $oldInput
        ]);
        $this->loadView('layouts/_footer');
    }

    /**
     * Handles the submission of the new category form.
     */
    public function handleAddCategory() {
        $this->isAdmin(); // Ensure only admin can access

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(APP_URL . '/admin/categories/add');
            exit;
        }

        // CSRF Token Validation
        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid request (CSRF token mismatch). Please try again.'];
            redirect(APP_URL . '/admin/categories/add');
            exit;
        }

        $input = $_POST;
        $errors = [];

        $name = trim($input['name'] ?? '');
        $type = trim($input['type'] ?? '');
        $description = trim($input['description'] ?? null);
        $parentCategoryIdStr = trim($input['parent_category_id'] ?? '');
        $parentCategoryId = !empty($parentCategoryIdStr) ? filter_var($parentCategoryIdStr, FILTER_VALIDATE_INT) : null;

        // Validation
        if (empty($name)) {
            $errors['name'] = 'Category name is required.';
        } elseif (mb_strlen($name) > 100) {
            $errors['name'] = 'Category name cannot exceed 100 characters.';
        }

        $allowedTypes = ['fashion', 'accessories', 'pre_owned']; // From your DB schema
        if (empty($type)) {
            $errors['type'] = 'Category type is required.';
        } elseif (!in_array($type, $allowedTypes)) {
            $errors['type'] = 'Invalid category type selected.';
        }

        if ($parentCategoryId === false) { // filter_var returns false on failure
            $errors['parent_category_id'] = 'Invalid parent category selected.';
            $parentCategoryId = null; // Reset to null
        }

        if (!empty($errors)) {
            $_SESSION['add_category_errors'] = $errors;
            $_SESSION['add_category_old_input'] = $input;
            redirect(APP_URL . '/admin/categories/add');
            exit;
        }

        // Attempt to create category
        $newCategoryId = $this->categoryModel->createCategory($name, $type, $description, $parentCategoryId);

        if ($newCategoryId) {
            $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'Category "' . htmlspecialchars($name) . '" added successfully!'];
            redirect(APP_URL . '/admin/categories'); // Redirect to a category list page (to be created)
        } else {
            $_SESSION['add_category_errors']['general'] = 'Failed to add category. A database error occurred or type was invalid.';
            $_SESSION['add_category_old_input'] = $input;
            redirect(APP_URL . '/admin/categories/add');
        }
    }
    
    /**
     * Placeholder for listing categories (you'll need a view for this)
     */
    public function listCategories() {
        $this->isAdmin();
        $pageTitle = "Admin - Manage Categories";
        $allCategories = $this->categoryModel->getAll();

        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        // Create app/Views/admin/category_list_content.php to display categories
        $this->loadView('admin/category_list_content', ['categories' => $allCategories]); 
        $this->loadView('layouts/_footer');
    }


    private function loadView(string $viewName, array $data = []) {
        $filePath = rtrim($this->viewPath, '/\\') . DIRECTORY_SEPARATOR . ltrim($viewName, '/\\') . '.php';
        $filePath = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $filePath);

        if (file_exists($filePath)) {
            $data['app_url'] = $data['app_url'] ?? (defined('APP_URL') ? APP_URL : '');
            $data['isLoggedIn'] = $data['isLoggedIn'] ?? isset($_SESSION['user_id']);
            $data['userRole'] = $data['userRole'] ?? ($_SESSION['user_role'] ?? null);
            $data['csrf_token'] = $data['csrf_token'] ?? ($_SESSION['csrf_token'] ?? '');
            extract($data);
            require $filePath;
        } else {
            error_log("AdminController::loadView - View file not found: " . $filePath);
            http_response_code(500);
            echo "<h1>Application Error</h1><p>A required view file ('" . htmlspecialchars($viewName) . ".php') was not found.</p>";
            if (defined('DEBUG_MODE') && DEBUG_MODE) {
                echo "<p>Attempted path: " . htmlspecialchars($filePath) . "</p>";
            }
            exit;
        }
    }
}
?>
