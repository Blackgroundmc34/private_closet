<?php
// File: app/Controllers/ErrorController.php

class ErrorController {
    private $viewPath = __DIR__ . '/../Views/';
    // You might pass PDO here if your error logging involves the database
    // private $pdo;

    public function __construct(/* PDO $pdo = null */) {
        // $this->pdo = $pdo;
    }

    private function outputJsonError(string $message, int $statusCode) {
        // Ensure no prior output interferes with JSON
        if (ob_get_length() > 0) { ob_end_clean(); }
        header('Content-Type: application/json; charset=utf-8');
        http_response_code($statusCode);
        echo json_encode(['success' => false, 'message' => $message]);
        exit;
    }

    private function loadView(string $viewName, array $data = []) {
        $fullViewPath = rtrim($this->viewPath, '/') . '/' . $viewName . '.php';
        if (file_exists($fullViewPath)) {
            // Ensure APP_URL is available in views if not explicitly passed
            $data['app_url'] = $data['app_url'] ?? (defined('APP_URL') ? APP_URL : '');
            $data['isLoggedIn'] = $data['isLoggedIn'] ?? isset($_SESSION['user_id']);
            $data['loggedInUserId'] = $data['loggedInUserId'] ?? ($_SESSION['user_id'] ?? null);
            
            extract($data);
            require $fullViewPath;
        } else {
            // Fallback if a specific error view itself is missing
            $logMessage = "ErrorController::loadView - View file not found: {$fullViewPath}";
            error_log($logMessage);
            echo "<h1>Error</h1><p>An error occurred, and the error page component '{$viewName}' could not be loaded.</p>";
            if (isset($data['message'])) {
                echo "<p>Original Message: " . htmlspecialchars($data['message']) . "</p>";
            }
             if (defined('DEBUG_MODE') && DEBUG_MODE) {
                echo "<p style='color:red; background-color:white; padding:5px;'>Debug: " . htmlspecialchars($logMessage) . "</p>";
            }
        }
    }

    public function notFound(string $routeInfo = '') {
        $message = "Sorry, the page you were looking for could not be found.";
        if ($routeInfo) {
            $message .= " (Route: /" . htmlspecialchars($routeInfo) . ")";
        }
        
        error_log("ErrorController::notFound - Message: {$message}"); // Log the 404 error

        if (is_ajax_request()) {
            $this->outputJsonError($message, 404);
        }

        http_response_code(404);
        $pageTitle = "Page Not Found";
        
        // Attempt to load header/footer for a consistent look
        if (file_exists($this->viewPath . 'layouts/_header.php')) {
            $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        } else {
            echo "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"UTF-8\"><title>{$pageTitle}</title></head><body>"; // Minimal HTML
        }
        
        $this->loadView('errors/404_content', ['message' => $message, 'pageTitle' => $pageTitle]);
        
        if (file_exists($this->viewPath . 'layouts/_footer.php')) {
            $this->loadView('layouts/_footer');
        } else {
            echo "</body></html>";
        }
        exit;
    }

    /**
     * Handles server errors.
     *
     * @param string $message The primary error message to display.
     * @param int $statusCode The HTTP status code to set. Defaults to 500.
     * @param ?Throwable $exception The exception/error object for detailed logging. Defaults to null.
     */
    public function serverError(string $message = 'An unexpected server error occurred.', int $statusCode = 500, ?Throwable $exception = null) {
        // Log the primary message and status code
        error_log("ErrorController::serverError - Message: " . $message . " (Status: {$statusCode})"); 

        // If an exception object is provided, log its details
        if ($exception !== null) {
            error_log("ErrorController::serverError - Exception Type: " . get_class($exception));
            error_log("ErrorController::serverError - Exception Message: " . $exception->getMessage());
            error_log("ErrorController::serverError - Exception File: " . $exception->getFile() . " on line " . $exception->getLine());
            error_log("ErrorController::serverError - Exception Trace: \n" . $exception->getTraceAsString());
        }

        if (is_ajax_request()) {
            // For AJAX, provide a generic message or more details if DEBUG_MODE is on
            $ajaxMessage = (defined('DEBUG_MODE') && DEBUG_MODE && $exception) ? $exception->getMessage() : $message;
            $this->outputJsonError($ajaxMessage, $statusCode);
        }
        
        http_response_code($statusCode);
        $pageTitle = "Server Error";

        // Display a user-friendly message. In debug mode, more details can be shown.
        $displayMessage = $message;
        if (defined('DEBUG_MODE') && DEBUG_MODE) {
            if ($exception) {
                $displayMessage .= "<br><br><strong>Debug Details:</strong><br>Type: " . get_class($exception) . "<br>Message: " . htmlspecialchars($exception->getMessage()) . "<br>File: " . htmlspecialchars($exception->getFile()) . " on line " . $exception->getLine();
            }
        }


        if (file_exists($this->viewPath . 'layouts/_header.php')) {
            $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        } else {
            echo "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"UTF-8\"><title>{$pageTitle}</title></head><body>";
        }

        // Use the 500_content.php view
        $this->loadView('errors/500_content', ['errorMessage' => $displayMessage, 'pageTitle' => $pageTitle]);
        
        if (file_exists($this->viewPath . 'layouts/_footer.php')) {
            $this->loadView('layouts/_footer');
        } else {
            echo "</body></html>";
        }
        exit;
    }
}

// Helper function (can be in utilities.php or bootstrap.php if not already defined)
if (!function_exists('is_ajax_request')) {
    function is_ajax_request() {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
}

?>
