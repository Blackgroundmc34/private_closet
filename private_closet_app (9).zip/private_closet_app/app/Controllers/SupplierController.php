<?php
// File: app/Controllers/SupplierController.php

require_once __DIR__ . '/../Models/ProductModel.php';
require_once __DIR__ . '/../Models/BusinessModel.php';
require_once __DIR__ . '/../Models/CategoryModel.php';
require_once __DIR__ . '/../Models/OrderModel.php';   // Added
require_once __DIR__ . '/../Models/UserModel.php';    // Added for notifications

require_once __DIR__ . '/../Helpers/utilities.php';

if (!class_exists('SupplierController')) {

    class SupplierController {
        private $pdo;
        private $productModel;
        private $businessModel;
        private $categoryModel;
        private $orderModel; // Added
        private $userModel;  // Added
        private $viewPath = __DIR__ . '/../Views/';
        private $app_url;
        private $default_avatar_full_url;

        private const UPLOAD_DIR_PRODUCTS = 'uploads/products/'; 
        private const MAX_PRODUCT_IMAGE_SIZE = 5 * 1024 * 1024; 
        private const ALLOWED_PRODUCT_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/gif'];

        public function __construct(PDO $pdo) {
            $this->pdo = $pdo;
            // Instantiate all models, ensuring class_exists checks are robust
            if (class_exists('ProductModel')) $this->productModel = new ProductModel($pdo); 
                else { error_log("SupplierController FATAL: ProductModel class not found."); die("Critical error: P01."); }
            if (class_exists('BusinessModel')) $this->businessModel = new BusinessModel($pdo); 
                else { error_log("SupplierController FATAL: BusinessModel class not found."); die("Critical error: B01."); }
            if (class_exists('CategoryModel')) $this->categoryModel = new CategoryModel($pdo); 
                else { error_log("SupplierController FATAL: CategoryModel class not found."); die("Critical error: C01."); }
            if (class_exists('OrderModel')) $this->orderModel = new OrderModel($pdo); 
                else { error_log("SupplierController FATAL: OrderModel class not found."); die("Critical error: O01."); }
            if (class_exists('UserModel')) $this->userModel = new UserModel($pdo); 
                else { error_log("SupplierController FATAL: UserModel class not found."); die("Critical error: U01."); }
            
            if (session_status() === PHP_SESSION_NONE) session_start();

            $this->app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
            $default_avatar_path_rel = defined('DEFAULT_AVATAR_PATH') ? DEFAULT_AVATAR_PATH : 'assets/images/default_avatar.png';
            $this->default_avatar_full_url = $this->app_url . '/' . ltrim($default_avatar_path_rel, '/');
        }

        private function checkSupplierRoleAndGetBusinessId(bool $redirectIfNoBusiness = true): ?int {
            if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'supplier') {
                $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Access denied. Suppliers only.'];
                redirect($this->app_url . '/login');
                exit;
            }
            $userId = (int)$_SESSION['user_id'];
            $business = $this->businessModel->getBusinessByUserId($userId);

            if (!$business || !isset($business['id']) || ($business['status'] ?? 'pending') !== 'approved') {
                if ($redirectIfNoBusiness) {
                    $message = 'Your business profile is not yet approved or is incomplete.';
                    if (!$business) { $message = 'Business profile not found. Please create or complete your business profile.'; }
                    else if (($business['status'] ?? 'pending') !== 'approved') { $message = 'Your business profile status is currently "' . escape_html($business['status'] ?? 'pending') . '". Certain features are disabled until approved.';}
                    $_SESSION['flash_message'] = ['type' => 'warning', 'text' => $message];
                    redirect($this->app_url . '/supplier/dashboard'); 
                    exit;
                }
                return null;
            }
            return (int)$business['id'];
        }

        public function dashboard() {
            $supplierUserId = $_SESSION['user_id'] ?? null;
            if (!$supplierUserId || ($_SESSION['user_role'] ?? '') !== 'supplier') {
                $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Access denied.'];
                redirect($this->app_url . '/login'); exit;
            }
            $pageTitle = "Supplier Dashboard";
            $business = $this->businessModel->getBusinessByUserId($supplierUserId); 
            $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
            $this->loadView('supplier/dashboard_content', ['business' => $business]);
            $this->loadView('layouts/_footer');
        }

 public function listProducts() {
            error_log("DEBUG: SupplierController::listProducts() - Start of method."); // ADD THIS LINE

            $businessId = $this->checkSupplierRoleAndGetBusinessId(true);
            error_log("DEBUG: SupplierController::listProducts() - Business ID obtained: " . ($businessId ?? 'NULL')); // ADD THIS LINE

            if ($businessId === null) {
                // This block implies redirection should have happened. If you see this log,
                // and no redirect, there's a problem with redirect() helper or headers already sent.
                error_log("DEBUG: SupplierController::listProducts() - Business ID is NULL, redirection should have occurred."); // ADD THIS LINE
                return; // Prevent further execution if businessId is not valid
            }

            $pageTitle = "My Products - Supplier Dashboard";
            error_log("DEBUG: SupplierController::listProducts() - Calling getProductsByBusinessId({$businessId})."); // ADD THIS LINE
            $products = $this->productModel->getProductsByBusinessId($businessId);
            error_log("DEBUG: SupplierController::listProducts() - Products fetched: " . count($products) . " items."); // ADD THIS LINE

            // Test if $products is an array and safe to iterate
            if (!is_array($products)) {
                error_log("ERROR: SupplierController::listProducts() - products is not an array. Type: " . gettype($products)); // ADD THIS
                // Optionally set a flash message and redirect or show an error view
                $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Failed to load products data.'];
                redirect($this->app_url . '/supplier/dashboard'); // Redirect to dashboard on critical data error
                exit;
            }

            $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
            error_log("DEBUG: SupplierController::listProducts() - Header loaded. Preparing to load product_list_content."); // ADD THIS LINE
            $this->loadView('supplier/product_list_content', ['products' => $products, 'flashMessage' => $this->flashMessage ?? null]); // Pass flashMessage if not already
            error_log("DEBUG: SupplierController::listProducts() - product_list_content loaded. Preparing to load footer."); // ADD THIS LINE
            $this->loadView('layouts/_footer');
            error_log("DEBUG: SupplierController::listProducts() - Footer loaded. Method finished."); // ADD THIS LINE
        }
        
        public function showAddProductForm() {
            $this->checkSupplierRoleAndGetBusinessId(true);
            $pageTitle = "Add New Product";
            $categories = $this->categoryModel->getAll();
            $errors = $_SESSION['add_product_errors'] ?? [];
            $oldInput = $_SESSION['add_product_old_input'] ?? [];
            unset($_SESSION['add_product_errors'], $_SESSION['add_product_old_input']);
            
            $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
            $this->loadView('supplier/add_product_form_content', [
                'errors' => $errors, 'oldInput' => $oldInput, 'categories' => $categories
            ]);
            $this->loadView('layouts/_footer');
        }
        
        public function handleAddProduct() {
            $businessId = $this->checkSupplierRoleAndGetBusinessId(true);
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect($this->app_url . '/supplier/products/add'); exit; }
            if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
                 $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid request. Please try again.'];
                 redirect($this->app_url . '/supplier/products/add'); exit;
            }
            
            $input = $_POST; $files = $_FILES; $errors = []; $imagesData = []; $uploadedFilePaths = [];
            $name = trim($input['name'] ?? ''); if (empty($name)) $errors['name'] = 'Product name is required.';
            if (mb_strlen($name) > 255) $errors['name'] = 'Product name max 255 chars.';
            $description = trim($input['description'] ?? ''); if (empty($description)) $errors['description'] = 'Description required.';
            $price = filter_var($input['price'] ?? '', FILTER_VALIDATE_FLOAT); if ($price === false || $price <= 0) $errors['price'] = 'Valid positive price required.';
            $stockQuantity = filter_var($input['stock_quantity'] ?? '', FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]); if ($stockQuantity === false) $errors['stock_quantity'] = 'Valid stock quantity required.';
            $sku = trim($input['sku'] ?? '') ?: null;
            if ($sku !== null) { if (mb_strlen($sku) > 100) $errors['sku'] = 'SKU max 100 chars.'; elseif ($this->productModel->isSkuTaken($sku)) $errors['sku'] = 'SKU already in use.';}
            $categoryId = !empty($input['category_id']) ? (int)$input['category_id'] : null;
            if ($categoryId !== null && !$this->categoryModel->findById($categoryId)) { $errors['category_id'] = 'Selected category invalid.';}

            if (isset($files['primary_image']) && $files['primary_image']['error'] === UPLOAD_ERR_OK) {
                $relativePath = $this->handleProductImageUpload($files['primary_image'], 'primary_image', $errors);
                if ($relativePath) { $imagesData[] = ['url' => $relativePath, 'is_primary' => true, 'alt_text' => $name . " primary image"]; $uploadedFilePaths[] = $relativePath; }
            } elseif (isset($files['primary_image']) && $files['primary_image']['error'] !== UPLOAD_ERR_NO_FILE) { $errors['primary_image'] = 'Err primary img (Code: '.$files['primary_image']['error'].')';}
            for ($i = 1; $i <= 3; $i++) { $formFieldName = "additional_image_$i"; if (isset($files[$formFieldName]) && $files[$formFieldName]['error'] === UPLOAD_ERR_OK) { $relativePath = $this->handleProductImageUpload($files[$formFieldName], $formFieldName, $errors); if ($relativePath) { $imagesData[] = ['url' => $relativePath, 'is_primary' => false, 'alt_text' => $name . " add img " . $i]; $uploadedFilePaths[] = $relativePath;}} elseif (isset($files[$formFieldName]) && $files[$formFieldName]['error'] !== UPLOAD_ERR_NO_FILE) {$errors[$formFieldName] = "Err add img $i (Code: ".$files[$formFieldName]['error'].')';}}
            
            if (!empty($errors)) { $_SESSION['add_product_errors'] = $errors; $_SESSION['add_product_old_input'] = $input; $this->cleanupUploadedFiles($uploadedFilePaths); redirect($this->app_url . '/supplier/products/add'); exit;}
            
            $productId = $this->productModel->createProduct($businessId, $name, $description, (float)$price, (int)$stockQuantity, $categoryId, 'active', $imagesData, $sku);
            if ($productId) { $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'Product "' . escape_html($name) . '" added successfully!']; redirect($this->app_url . '/supplier/products');}
            else { $this->cleanupUploadedFiles($uploadedFilePaths); $_SESSION['add_product_errors']['general'] = 'Failed to add product. DB error.'; $_SESSION['add_product_old_input'] = $input; redirect($this->app_url . '/supplier/products/add');}
        }

        public function showEditProductForm(int $productId) {
            $businessId = $this->checkSupplierRoleAndGetBusinessId(true);
            $product = $this->productModel->findProductByIdAndBusinessId($productId, $businessId);
            if (!$product) { $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Product not found or no permission to edit it.']; redirect($this->app_url . '/supplier/products'); exit; }
            $pageTitle = "Edit Product: " . escape_html($product['name']);
            $categories = $this->categoryModel->getAll();
            $errors = $_SESSION['edit_product_errors'] ?? [];
            $oldInput = $_SESSION['edit_product_old_input'] ?? $product; 
            unset($_SESSION['edit_product_errors'], $_SESSION['edit_product_old_input']);
            $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
            $this->loadView('supplier/edit_product_form_content', ['product' => $product, 'errors' => $errors, 'oldInput' => $oldInput, 'categories' => $categories]);
            $this->loadView('layouts/_footer');
        }

        public function handleEditProduct(int $productId) {
            $businessId = $this->checkSupplierRoleAndGetBusinessId(true);
            if ($_SERVER['REQUEST_METHOD'] !== 'POST' || (int)($_POST['product_id'] ?? 0) !== $productId) { $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid request.']; redirect($this->app_url . '/supplier/products/edit/' . $productId); exit;}
            if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) { $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid security token.']; redirect($this->app_url . '/supplier/products/edit/' . $productId); exit;}
            
            $input = $_POST; $files = $_FILES; $errors = []; $updateData = [];
            $imageOps = ['delete_images' => isset($input['delete_images']) && is_array($input['delete_images']) ? array_map('intval', $input['delete_images']) : [], 'set_primary_image_id' => isset($input['set_primary_image']) && is_numeric($input['set_primary_image']) ? (int)$input['set_primary_image'] : null, 'new_images_data' => []];
            $uploadedFilePathsForCleanup = [];

            $updateData['name'] = trim($input['name'] ?? ''); if (empty($updateData['name'])) $errors['name'] = 'Name required.';
            $updateData['description'] = trim($input['description'] ?? ''); if (empty($updateData['description'])) $errors['description'] = 'Description required.';
            $updateData['price'] = filter_var($input['price'] ?? '', FILTER_VALIDATE_FLOAT); if ($updateData['price'] === false || $updateData['price'] <= 0) $errors['price'] = 'Valid price required.';
            $updateData['stock_quantity'] = filter_var($input['stock_quantity'] ?? '', FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]); if ($updateData['stock_quantity'] === false) $errors['stock_quantity'] = 'Valid stock required.';
            $updateData['sku'] = trim($input['sku'] ?? '') ?: null; if ($updateData['sku'] !== null) { if (mb_strlen($updateData['sku']) > 100) $errors['sku'] = 'SKU too long.'; elseif ($this->productModel->isSkuTaken($updateData['sku'], $productId)) $errors['sku'] = 'SKU in use.';}
            $updateData['category_id'] = !empty($input['category_id']) ? (int)$input['category_id'] : null; if ($updateData['category_id'] !== null && !$this->categoryModel->findById($updateData['category_id'])) { $errors['category_id'] = 'Invalid category.';}
            $updateData['status'] = $input['status'] ?? 'active'; if (!in_array($updateData['status'], ['active', 'inactive', 'draft', 'out_of_stock'])) { $errors['status'] = 'Invalid status.';}

            if (isset($files['primary_image']) && $files['primary_image']['error'] === UPLOAD_ERR_OK) { $relativePath = $this->handleProductImageUpload($files['primary_image'], 'primary_image', $errors); if ($relativePath) { $imageOps['new_images_data'][] = ['url' => $relativePath, 'is_primary' => true, 'alt_text' => $updateData['name'] . ' primary']; $uploadedFilePathsForCleanup[] = $relativePath;}} elseif (isset($files['primary_image']) && $files['primary_image']['error'] !== UPLOAD_ERR_NO_FILE) { $errors['primary_image'] = 'Err primary img (Code: '.$files['primary_image']['error'].')';}
            for ($i = 1; $i <= 3; $i++) { $formFieldName = "new_additional_image_$i"; if (isset($files[$formFieldName]) && $files[$formFieldName]['error'] === UPLOAD_ERR_OK) { $relativePath = $this->handleProductImageUpload($files[$formFieldName], $formFieldName, $errors); if ($relativePath) { $imageOps['new_images_data'][] = ['url' => $relativePath, 'is_primary' => false, 'alt_text' => $updateData['name'] . " add img " . $i]; $uploadedFilePathsForCleanup[] = $relativePath;}} elseif (isset($files[$formFieldName]) && $files[$formFieldName]['error'] !== UPLOAD_ERR_NO_FILE) {$errors[$formFieldName] = "Err add img $i (Code: ".$files[$formFieldName]['error'].')';}}
            
            if (!empty($errors)) { $_SESSION['edit_product_errors'] = $errors; $_SESSION['edit_product_old_input'] = $input; $this->cleanupUploadedFiles($uploadedFilePathsForCleanup); redirect($this->app_url . '/supplier/products/edit/' . $productId); exit;}
            
            $success = $this->productModel->updateProduct($productId, $businessId, $updateData, $imageOps);
            if ($success) { $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'Product updated!']; redirect($this->app_url . '/supplier/products');}
            else { $_SESSION['edit_product_errors']['general'] = 'Failed to update product.'; $_SESSION['edit_product_old_input'] = $input; $this->cleanupUploadedFiles($uploadedFilePathsForCleanup); redirect($this->app_url . '/supplier/products/edit/' . $productId);}
        }

        public function handleDeleteProduct(int $productId) {
            $businessId = $this->checkSupplierRoleAndGetBusinessId(true);
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') { $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid request method.']; redirect($this->app_url . '/supplier/products'); exit; }
            if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) { $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid security token.']; redirect($this->app_url . '/supplier/products'); exit; }
            if ((int)($_POST['product_id'] ?? 0) !== $productId) { $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Product ID mismatch.']; redirect($this->app_url . '/supplier/products'); exit;}

            if ($this->productModel->deleteProduct($productId, $businessId)) {
                $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'Product deleted successfully.'];
            } else {
                $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Failed to delete product.'];
            }
            redirect($this->app_url . '/supplier/products');
        }
        
        // --- Supplier Order Management Methods ---
        public function listSupplierOrders() {
            $businessId = $this->checkSupplierRoleAndGetBusinessId(true);
            $pageTitle = "My Business Orders";
            $currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            if ($currentPage < 1) $currentPage = 1;
            $ordersPerPage = 10;
            $filters = []; 
            if (!empty($_GET['status_filter'])) { $filters['status'] = trim($_GET['status_filter']); }
            $offset = ($currentPage - 1) * $ordersPerPage;

            $orders = $this->orderModel->getOrdersByBusinessId($businessId, $ordersPerPage, $offset, $filters);
            $totalOrders = $this->orderModel->countOrdersByBusinessId($businessId, $filters);
            $totalPages = ($totalOrders > 0) ? (int)ceil($totalOrders / $ordersPerPage) : 1;
            if ($currentPage > $totalPages && $totalPages > 0) $currentPage = $totalPages; // Ensure current page is not out of bounds

            $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
            $this->loadView('supplier/order_list_content', [
                'orders' => $orders,
                'currentPage' => $currentPage,
                'totalPages' => $totalPages,
                'filters' => $filters 
            ]);
            $this->loadView('layouts/_footer');
        }

        public function viewSupplierOrderDetail(int $orderId) {
            $businessId = $this->checkSupplierRoleAndGetBusinessId(true);
            $order = $this->orderModel->getOrderDetailsForSupplier($orderId, $businessId);

            if (!$order) { 
                $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Order not found or it does not pertain to your business.']; 
                redirect($this->app_url . '/supplier/orders'); 
                exit; 
            }
            
            $pageTitle = "Order Details (Supplier View) - #" . escape_html($order['id'] ?? $orderId);
            $errors = $_SESSION['order_update_errors'] ?? []; 
            unset($_SESSION['order_update_errors']);

            $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
            $this->loadView('supplier/order_detail_supplier_content', [
                'order' => $order,
                'errors' => $errors
            ]);
            $this->loadView('layouts/_footer');
        }

        public function handleSupplierOrderUpdate(int $orderId) {
            $businessId = $this->checkSupplierRoleAndGetBusinessId(true);
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') { $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid request.']; redirect($this->app_url . '/supplier/orders/view/' . $orderId); exit; }
            if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) { $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid security token.']; redirect($this->app_url . '/supplier/orders/view/' . $orderId); exit; }
            
            $order = $this->orderModel->getOrderDetailsForSupplier($orderId, $businessId);
            if (!$order) { $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Order not found/relevant. Update failed.']; redirect($this->app_url . '/supplier/orders'); exit; }

            $newStatus = trim($_POST['order_status'] ?? '');
            $trackingNumber = trim($_POST['tracking_number'] ?? '') ?: null; 
            $shippingProvider = trim($_POST['shipping_provider'] ?? '') ?: null;
            $errors = [];
            $allowedStatuses = ['processing', 'shipped', 'delivered', 'on-hold', 'cancelled']; 
            if (empty($newStatus) || !in_array($newStatus, $allowedStatuses)) { $errors['order_status'] = 'Invalid order status selected.';}
            if ($newStatus === 'shipped' && empty($trackingNumber)) { $errors['tracking_number'] = 'Tracking number required if Shipped.';}
            if ($newStatus === 'shipped' && empty($shippingProvider)) { $errors['shipping_provider'] = 'Shipping provider required if Shipped.';}

            if (!empty($errors)) { 
                $_SESSION['order_update_errors'] = $errors; 
                $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Please correct the errors below to update the order.']; 
                redirect($this->app_url . '/supplier/orders/view/' . $orderId); exit;
            }
            
            $success = $this->orderModel->updateOrderStatus($orderId, $newStatus, $trackingNumber, $shippingProvider);
            if ($success) {
                $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'Order #' . $orderId . ' status updated to ' . escape_html(ucfirst($newStatus)) . '.'];
                
                $customerUserId = (int)$order['user_id'];
                $notificationMessage = "Your order #{$orderId} has been updated. New status: " . escape_html(ucfirst(str_replace('_', ' ', $newStatus))) . ".";
                if ($newStatus === 'shipped' && $trackingNumber) { $notificationMessage .= " Tracking: " . escape_html($trackingNumber) . ($shippingProvider ? " via " . escape_html($shippingProvider) : "") . "."; }
                if($this->userModel) { // Ensure userModel is instantiated
                    $this->userModel->createNotification($customerUserId, 'order_update', $notificationMessage, 'order', (string)$orderId);
                }
            } else { 
                $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Failed to update order status. A database error occurred.'];
            }
            redirect($this->app_url . '/supplier/orders/view/' . $orderId);
        }
        
        private function handleProductImageUpload(array $file, string $formFieldName, array &$errors): ?string {
            $publicDir = realpath(__DIR__ . '/../../public'); 
            if (!$publicDir) { $errors[$formFieldName] = 'Server error: Public dir not found.'; error_log("CRITICAL: Public directory not found for uploads."); return null; }
            $uploadDirRelative = rtrim(self::UPLOAD_DIR_PRODUCTS, '/\\') . DIRECTORY_SEPARATOR;
            $uploadDirAbsolute = $publicDir . DIRECTORY_SEPARATOR . $uploadDirRelative;
            $uploadDirAbsolute = rtrim(str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $uploadDirAbsolute), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
            if (!file_exists($uploadDirAbsolute)) { if (!mkdir($uploadDirAbsolute, 0775, true)) { $errors[$formFieldName] = 'Server error: Cannot create image dir.'; return null;}}
            if (!is_writable($uploadDirAbsolute)) { $errors[$formFieldName] = 'Server error: Image dir not writable.'; return null;}
            $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $safeFileNameBase = preg_replace('/[^A-Za-z0-9_.-]/', '_', pathinfo($file['name'], PATHINFO_FILENAME));
            if(empty($safeFileNameBase)) $safeFileNameBase = 'image';
            $uniqueFileName = $safeFileNameBase . '_' . ($_SESSION['user_id'] ?? 'guest') . '_' . bin2hex(random_bytes(6)) . '.' . $fileExtension;
            $destinationPath = $uploadDirAbsolute . $uniqueFileName;
            if ($file['size'] > self::MAX_PRODUCT_IMAGE_SIZE) { $errors[$formFieldName] = 'File too large. Max '.(self::MAX_PRODUCT_IMAGE_SIZE/1024/1024).'MB.'; return null;}
            $detectedMimeType = mime_content_type($file['tmp_name']);
            if (!in_array($file['type'], self::ALLOWED_PRODUCT_IMAGE_TYPES) && !in_array($detectedMimeType, self::ALLOWED_PRODUCT_IMAGE_TYPES) ) { $errors[$formFieldName] = 'Invalid file type.'; return null;}
            if (move_uploaded_file($file['tmp_name'], $destinationPath)) { return str_replace('\\', '/', $uploadDirRelative . $uniqueFileName); }
            else { $errors[$formFieldName] = 'Failed to move uploaded file.'; return null; }
        }

        private function cleanupUploadedFiles(array $filePaths) {
            if (empty($filePaths)) return; $publicDir = realpath(__DIR__ . '/../../public'); if (!$publicDir) return;
            foreach ($filePaths as $relativePath) { if (empty($relativePath)) continue; $absolutePath = $publicDir . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relativePath); if (file_exists($absolutePath) && is_file($absolutePath)) { @unlink($absolutePath);}}
        }
        
        private function loadView(string $viewName, array $data = []) {
            $filePath = rtrim($this->viewPath, '/\\') . DIRECTORY_SEPARATOR . ltrim($viewName, '/\\') . '.php';
            $filePath = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $filePath);
            $data['app_url'] = $data['app_url'] ?? $this->app_url;
            $data['isLoggedIn'] = $data['isLoggedIn'] ?? isset($_SESSION['user_id']);
            $data['loggedInUserId'] = $data['loggedInUserId'] ?? ($_SESSION['user_id'] ?? null);
            $data['userRole'] = $data['userRole'] ?? ($_SESSION['user_role'] ?? null);
            $data['csrf_token'] = $data['csrf_token'] ?? ($_SESSION['csrf_token'] ?? '');
            $data['default_avatar_full_url'] = $data['default_avatar_full_url'] ?? $this->default_avatar_full_url;
            $data['pageTitle'] = $data['pageTitle'] ?? 'Supplier Section'; // Changed default title
            if (!isset($data['flashMessage']) && isset($_SESSION['flash_message'])) { $data['flashMessage'] = $_SESSION['flash_message']; unset($_SESSION['flash_message']);}
            if (file_exists($filePath)) { extract($data); require $filePath; }
            else { error_log("View file not found: {$filePath}"); http_response_code(500); echo "Error loading view: ".basename($filePath); exit;}
        }
    } 
}
?>