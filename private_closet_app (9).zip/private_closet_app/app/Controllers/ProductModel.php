<?php
// File: app/Models/ProductModel.php

class ProductModel {
    private $pdo;
    private $app_url;
    private $default_avatar_full_url; // Though not used in createProduct directly

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
        $default_avatar_path = defined('DEFAULT_AVATAR_PATH') ? DEFAULT_AVATAR_PATH : 'assets/images/default_avatar.png';
        $this->default_avatar_full_url = $this->app_url . '/' . ltrim($default_avatar_path, '/');
    }

    // ... (Your existing methods like getShowroomProducts, findProductByIdOrSlug, getProductsByBusinessId, etc.)

    public function createProduct(
        int $businessId,
        string $name,
        string $description,
        float $price,
        int $stockQuantity,
        ?int $categoryId,
        string $status = 'active',
        array $imagesData = [], // Expects [['url' => 'path', 'is_primary' => bool, 'alt_text' => '...']]
        ?string $sku = null
    ): int|false {
        $slug = $this->generateUniqueSlug($name); // Use a helper for robust slug generation

        $sql = "INSERT INTO products (business_id, name, slug, description, price, stock_quantity, sku, category_id, status, created_at, updated_at)
                VALUES (:business_id, :name, :slug, :description, :price, :stock_quantity, :sku, :category_id, :status, NOW(), NOW())";

        try {
            $this->pdo->beginTransaction();

            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':business_id', $businessId, PDO::PARAM_INT);
            $stmt->bindParam(':name', $name, PDO::PARAM_STR);
            $stmt->bindParam(':slug', $slug, PDO::PARAM_STR);
            $stmt->bindParam(':description', $description, PDO::PARAM_STR);
            $stmt->bindParam(':price', $price); // PDO typically handles float/decimal correctly
            $stmt->bindParam(':stock_quantity', $stockQuantity, PDO::PARAM_INT);
            $stmt->bindParam(':sku', $sku, $sku === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
            $stmt->bindParam(':category_id', $categoryId, $categoryId === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
            $stmt->bindParam(':status', $status, PDO::PARAM_STR);

            if (!$stmt->execute()) {
                $this->pdo->rollBack();
                error_log("ProductModel::createProduct - Product insert failed: " . implode(" | ", $stmt->errorInfo()) . " SQL: " . $sql . " Params: " . print_r(get_defined_vars(),true) );
                return false;
            }
            $productId = (int)$this->pdo->lastInsertId();
            if ($productId === 0) { // Should not happen with auto-increment if insert succeeded
                 $this->pdo->rollBack();
                 error_log("ProductModel::createProduct - lastInsertId returned 0 after product insert.");
                 return false;
            }


            if (!empty($imagesData) && $this->tableExists('product_images')) {
                $sqlImage = "INSERT INTO product_images (product_id, image_url, alt_text, is_primary, display_order)
                             VALUES (:product_id, :image_url, :alt_text, :is_primary, :display_order)";
                $stmtImage = $this->pdo->prepare($sqlImage);
                $order = 0;
                foreach ($imagesData as $img) {
                    $isPrimary = isset($img['is_primary']) ? (bool)$img['is_primary'] : false;
                    $altText = $img['alt_text'] ?? $name; // Default alt text

                    $stmtImage->bindParam(':product_id', $productId, PDO::PARAM_INT);
                    $stmtImage->bindParam(':image_url', $img['url']);
                    $stmtImage->bindParam(':alt_text', $altText);
                    $stmtImage->bindParam(':is_primary', $isPrimary, PDO::PARAM_BOOL);
                    $stmtImage->bindParam(':display_order', $order, PDO::PARAM_INT);

                    if (!$stmtImage->execute()) {
                        $this->pdo->rollBack();
                        error_log("ProductModel::createProduct - Image insert failed for product ID {$productId}: " . implode(" | ", $stmtImage->errorInfo()));
                        return false;
                    }
                    $order++;
                }
            }

            $this->pdo->commit();
            return $productId;

        } catch (PDOException $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            error_log("ProductModel::createProduct PDOException: " . $e->getMessage() . " | Product Name: " . $name);
            return false;
        }
    }

    // Helper method to generate a unique slug
    private function generateUniqueSlug(string $name, string $tableName = 'products', string $columnName = 'slug'): string {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name), '-'));
        if (empty($slug)) { // Handle cases where name might only contain special characters
            $slug = 'product-' . bin2hex(random_bytes(4));
        }

        $originalSlug = $slug;
        $counter = 1;
        while ($this->slugExists($slug, $tableName, $columnName)) {
            $slug = $originalSlug . '-' . $counter++;
        }
        return $slug;
    }

    // Helper method to check if a slug exists
    private function slugExists(string $slug, string $tableName, string $columnName): bool {
        $sql = "SELECT 1 FROM {$tableName} WHERE {$columnName} = :slug LIMIT 1";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':slug', $slug);
            $stmt->execute();
            return $stmt->fetchColumn() !== false;
        } catch (PDOException $e) {
            error_log("Error checking slug existence: " . $e->getMessage());
            // Fail safe: assume it exists to prevent accidental duplicates if DB error
            return true;
        }
    }


    // Helper to check if a table exists
    private function tableExists(string $tableName): bool {
        try {
            // Query INFORMATION_SCHEMA.TABLES for better reliability if permissions allow
            // For simplicity, using a direct query, but this might throw an error if table doesn't exist.
            $result = $this->pdo->query("SELECT 1 FROM `{$tableName}` LIMIT 1");
        } catch (PDOException $e) { // Catch PDOException specifically
            // Check if error code indicates "table not found" (e.g., '42S02' for MySQL)
            if ($e->getCode() == '42S02') { // General SQLSTATE for table not found
                return false;
            }
            // Log other errors but potentially assume false or re-throw
            error_log("ProductModel::tableExists - Error checking table '{$tableName}': " . $e->getMessage());
            return false; // Or handle differently based on desired behavior
        }
        return $result !== false;
    }

    // Ensure your prepareFullUrl and prepareProfilePicUrl methods are present if used elsewhere in the model
     private function prepareFullUrl(?string $relativePath): string {
        if (empty($relativePath)) return '';
        if (preg_match('/^https?:\/\//', $relativePath)) {
            return $relativePath;
        }
        return $this->app_url . '/' . ltrim($relativePath, '/');
    }

    private function prepareProfilePicUrl(?string $relativePath): string {
        if (empty($relativePath)) return $this->default_avatar_full_url; // Ensure this is defined
        if (preg_match('/^https?:\/\//', $relativePath)) {
            return $relativePath;
        }
        return $this->app_url . '/' . ltrim($relativePath, '/');
    }


    // ... (Your other existing methods: getShowroomProducts, countShowroomProducts, findProductByIdOrSlug, getProductsByBusinessId)

    /**
     * Submits a new review for a product.
     * @param int $productId
     * @param int $userId
     * @param int $rating
     * @param string $comment
     * @return bool True on success, false on failure (e.g., duplicate review, DB error).
     */
    public function submitProductReview(int $productId, int $userId, int $rating, string $comment): bool {
        error_log("ProductModel::submitProductReview - Attempting to submit review for ProductID: {$productId}, UserID: {$userId}, Rating: {$rating}"); // NEW LOG

        // Prevent duplicate reviews from the same user for the same product
        $sqlCheck = "SELECT COUNT(*) FROM product_reviews WHERE user_id = :user_id AND product_id = :product_id";
        try {
            $stmtCheck = $this->pdo->prepare($sqlCheck);
            $stmtCheck->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmtCheck->bindParam(':product_id', $productId, PDO::PARAM_INT);
            $stmtCheck->execute();
            if ((int)$stmtCheck->fetchColumn() > 0) {
                error_log("ProductModel::submitProductReview - User {$userId} already reviewed product {$productId}. Returning false."); // NEW LOG
                return false; // Already reviewed
            }
        } catch (PDOException $e) {
            error_log("ProductModel::submitProductReview - PDOException checking for existing review: " . $e->getMessage()); // NEW LOG
            return false;
        }


        $sql = "INSERT INTO product_reviews (product_id, user_id, rating, comment, created_at, updated_at)
                VALUES (:product_id, :user_id, :rating, :comment, NOW(), NOW())";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':rating', $rating, PDO::PARAM_INT);
            $stmt->bindParam(':comment', $comment, PDO::PARAM_STR);

            $executeResult = $stmt->execute(); // NEW: Store result
            if ($executeResult) {
                error_log("ProductModel::submitProductReview - Insert successful. Rows affected: " . $stmt->rowCount()); // NEW LOG
            } else {
                error_log("ProductModel::submitProductReview - Insert failed. ErrorInfo: " . implode(" | ", $stmt->errorInfo())); // NEW LOG
            }
            return $executeResult;
        } catch (PDOException $e) {
            error_log("ProductModel::submitProductReview - PDOException during insert: " . $e->getMessage()); // NEW LOG
            return false;
        }
    }

    /**
     * Fetches reviews for a given product ID.
     * @param int $productId
     * @return array List of reviews.
     */
    public function getProductReviews(int $productId): array {
        $sql = "SELECT pr.id, pr.user_id, u.username, pr.rating, pr.comment AS comment_text, pr.created_at
                FROM product_reviews pr
                JOIN users u ON pr.user_id = u.id
                WHERE pr.product_id = :product_id
                ORDER BY pr.created_at DESC";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (PDOException $e) {
            error_log("ProductModel::getProductReviews PDOException: " . $e->getMessage());
            return [];
        }
    }

    public function getProductByIdOrSlug(string $identifier): ?array {
        // Determine if identifier is numeric (ID) or string (slug)
        $field = is_numeric($identifier) ? 'p.id' : 'p.slug';
        $sql = "SELECT p.*, 
                       b.business_name as business_name, 
                       b.id as business_id 
                       /* Add other business fields you need, e.g., b.profile_url if you create that concept */
                FROM products p
                LEFT JOIN businesses b ON p.business_id = b.id
                WHERE {$field} = :identifier";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':identifier', $identifier, is_numeric($identifier) ? PDO::PARAM_INT : PDO::PARAM_STR);
        $stmt->execute();
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($product) {
            // Fetch images
            $imgSql = "SELECT image_url, alt_text, is_primary FROM product_images WHERE product_id = :product_id ORDER BY is_primary DESC, display_order ASC";
            $imgStmt = $this->pdo->prepare($imgSql);
            $imgStmt->bindParam(':product_id', $product['id'], PDO::PARAM_INT);
            $imgStmt->execute();
            $product['images'] = $imgStmt->fetchAll(PDO::FETCH_ASSOC);

            // Placeholder for business profile URL - you'd construct this based on your app's routing
            if (isset($product['business_name'])) {
                 // Example: $product['business']['profile_url'] = (defined('APP_URL') ? APP_URL : '') . '/store/' . ($product['business_id'] ?? $product['business_name']);
                 $product['business']['name'] = $product['business_name']; // As view expects $product['business']['name']
            }
        }
        return $product ?: null;
    }
}