<?php
// File: app/Controllers/AuthController.php

require_once __DIR__ . '/../Models/UserModel.php';
require_once __DIR__ . '/../Models/PasswordResetModel.php'; 
// Ensure BusinessModel path is correct relative to this file
if (file_exists(__DIR__ . '/../Models/BusinessModel.php')) {
    require_once __DIR__ . '/../Models/BusinessModel.php'; // For supplier registration
}
require_once __DIR__ . '/../Helpers/utilities.php'; // For redirect() and other helpers

class AuthController {
    private $pdo;
    private $userModel;
    private $businessModel = null; // Initialize as null
     private $passwordResetModel;
     private $app_url; 
    private $viewPath = __DIR__ . '/../Views/';

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->userModel = new UserModel($pdo);
         $this->passwordResetModel = new PasswordResetModel($pdo);

        // Instantiate BusinessModel only if the file exists
        if (class_exists('BusinessModel')) {
            $this->businessModel = new BusinessModel($pdo);
        } else {
            error_log("AuthController WARNING: BusinessModel class not found or file not included. Supplier features may be affected.");
            // Depending on requirements, you might throw an exception or disable supplier functionality
        }

        // Ensure session is started for all auth actions
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        $this->app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
        if (empty($this->app_url)) {
            // Fallback if APP_URL is not defined, though it should be.
            // This helps prevent the reset link from being broken.
            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || ($_SERVER['SERVER_PORT'] ?? 80) == 443) ? "https://" : "http://";
            $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
            $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
            $base_path = ($scriptDir === '/' || $scriptDir === '.') ? '' : rtrim($scriptDir, '/');
            $this->app_url = rtrim($protocol . $host . $base_path, '/');
             error_log("AuthController Warning: APP_URL constant was not defined. Guessed app_url as: " . $this->app_url);
        }
    }

    /**
     * Displays the registration form.
     * Generates CSRF token if needed.
     */
    public function showRegister() {
        // --- Generate CSRF token ---
        // Ensure a token exists in the session for the form
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            error_log("AuthController::showRegister - Generated new CSRF token."); // Optional log
        }
        // --- End CSRF token generation ---

        $pageTitle = "Register - Private Closet";
        // Get errors and old input from session if they exist
        $errors = $_SESSION['register_errors'] ?? [];
        $oldInput = $_SESSION['register_old_input'] ?? [];
        unset($_SESSION['register_errors'], $_SESSION['register_old_input']); // Clear flash data

        // Prepare view data (loadView will add CSRF token automatically)
        $data = [
            'errors' => $errors,
            'oldInput' => $oldInput
        ];

        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('auth/register_content', $data); // loadView adds CSRF token
        $this->loadView('layouts/_footer');
    }

    /**
     * Handles registration form submission.
     * Includes CSRF validation.
     */
    public function handleRegister() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(APP_URL . '/register');
            exit;
        }

        // --- CSRF Check ---
        // Use hash_equals for timing-attack safe comparison
        if (empty($_POST['csrf_token']) || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            error_log("CSRF token validation failed during registration."); // Log the failure
            // Set a user-friendly error message
            $_SESSION['register_errors']['general'] = 'Invalid security token. Please try submitting the form again.';
            $_SESSION['register_old_input'] = $_POST; // Keep input
            // Invalidate the used session token (optional but good practice)
            // unset($_SESSION['csrf_token']); // Or generate a new one
            redirect(APP_URL . '/register');
            exit;
        }
        // --- End CSRF Check ---

        $errors = [];
        $input = $_POST; // Keep raw input for repopulating form

        // --- Basic User Validation ---
        $role = trim($input['role'] ?? '');
        $fullName = trim($input['full_name'] ?? '');
        $username = trim($input['username'] ?? '');
        $email = filter_var(trim($input['email'] ?? ''), FILTER_SANITIZE_EMAIL); // Sanitize first
        $password = $input['password'] ?? '';
        $passwordConfirm = $input['password_confirmation'] ?? '';

        if (empty($fullName)) $errors['full_name'] = 'Full Name is required.';
        if (!in_array($role, ['user', 'supplier', 'stylist'])) $errors['role'] = 'Invalid role selected.';

        if (empty($username)) {
            $errors['username'] = 'Username is required.';
        } elseif (!preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username)) {
            $errors['username'] = 'Username must be 3-20 characters (letters, numbers, underscores only).';
        } elseif ($this->userModel->findByUsername($username)) {
            $errors['username'] = 'Username is already taken.';
        }

        // Validate email *after* sanitizing
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
             $errors['email'] = 'A valid Email is required.';
        } elseif ($this->userModel->findByEmail($email)) {
             $errors['email'] = 'Email address is already registered.';
        }

        if (empty($password)) {
            $errors['password'] = 'Password is required.';
        } elseif (strlen($password) < 8) {
             // You might want more complex password rules (uppercase, number, symbol)
            $errors['password'] = 'Password must be at least 8 characters.';
        }
        if ($password !== $passwordConfirm) {
            $errors['password_confirmation'] = 'Passwords do not match.';
        }

        // --- Role-specific validation ---
        $businessData = []; // To store data for BusinessModel
        if ($role === 'supplier') {
            if (!$this->businessModel) {
                // If BusinessModel failed to load, prevent supplier registration
                 $errors['general'] = 'Supplier registration is currently unavailable. Please contact support.';
            } else {
                 $businessData['business_name'] = trim($input['business_name'] ?? '');
                 if (empty($businessData['business_name'])) $errors['business_name'] = 'Business Name is required for suppliers.';

                 // Collect other optional business data
                 $businessData['registration_number'] = trim($input['registration_number'] ?? '') ?: null; // Store null if empty
                 $businessData['start_date'] = trim($input['start_date'] ?? '') ?: null;
                 if ($businessData['start_date'] && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $businessData['start_date'])) {
                     $errors['start_date'] = 'Invalid start date format. Use YYYY-MM-DD.';
                 }
                 $businessData['business_description'] = trim($input['business_description'] ?? '') ?: null;
                 $businessData['physical_address'] = trim($input['physical_address'] ?? '') ?: null;
                 $businessData['operating_hours'] = trim($input['operating_hours'] ?? '') ?: null;
                 $businessData['contact_phone_1'] = trim($input['contact_phone_1'] ?? '') ?: null;
                 $businessData['contact_phone_2'] = trim($input['contact_phone_2'] ?? '') ?: null;
                 $businessData['business_categories'] = isset($input['business_categories']) && is_array($input['business_categories']) ? $input['business_categories'] : []; // Ensure it's an array

                 // Terms agreement for supplier
                 if (empty($input['terms_supplier'])) $errors['terms_supplier'] = 'You must agree to the Seller Terms and Conditions.';
             }

        } elseif ($role === 'stylist') {
            if (empty($input['terms_stylist'])) $errors['terms_stylist'] = 'You must agree to the Platform Terms and Conditions.';
        } else { // 'user' role
            if (empty($input['terms_user'])) $errors['terms_user'] = 'You must agree to the Platform Terms and Conditions.';
        }

        // --- Process Registration if No Errors ---
        if (empty($errors)) {
            $userId = $this->userModel->createUser($username, $email, $password, $fullName, $role);

            if ($userId) {
                $businessCreationSuccess = true; // Assume success for non-suppliers or if BusinessModel isn't needed/used
                if ($role === 'supplier' && $this->businessModel) {
                    // Add default lat/lon for pinpoint_location if not collected
                    $businessData['longitude'] = $businessData['longitude'] ?? '28.2293'; // Example: Pretoria
                    $businessData['latitude'] = $businessData['latitude'] ?? '-25.7479';  // Example: Pretoria
                    $businessData['status'] = 'pending'; // Default status for new suppliers should likely be 'pending' or 'under_review'

                    $businessId = $this->businessModel->createBusiness($userId, $businessData);
                    if (!$businessId) {
                        $businessCreationSuccess = false;
                        error_log("AuthController::handleRegister - CRITICAL: Failed to create business profile for new supplier user ID: {$userId}. User was created.");
                        // Handle this critical state: maybe delete the user, flag for admin, or inform user clearly.
                        $_SESSION['register_errors']['general'] = 'User account created, but business profile setup failed. Please contact support.';
                        $_SESSION['register_old_input'] = $input;
                        redirect(APP_URL . '/register'); // Redirect back with error
                        exit;
                    } else {
                        error_log("AuthController::handleRegister - Successfully created business ID {$businessId} for supplier user ID {$userId}.");
                    }
                } elseif ($role === 'supplier' && !$this->businessModel) {
                    // This case should ideally be caught earlier by validation if businessModel is required
                    $businessCreationSuccess = false;
                     error_log("AuthController::handleRegister - BusinessModel not available. Cannot create business profile for supplier user ID: {$userId}.");
                     $_SESSION['register_errors']['general'] = 'User account created, but business profile setup is currently unavailable. Please contact support.';
                     $_SESSION['register_old_input'] = $input;
                     redirect(APP_URL . '/register');
                     exit;
                }

                // Only proceed if everything succeeded (user and potentially business profile)
                if ($businessCreationSuccess) {
                    // Generate a new session ID after registration before logging in
                    session_regenerate_id(true);

                    // Log the user in immediately
                    $_SESSION['user_id'] = $userId;
                    $_SESSION['username'] = $username;
                    $_SESSION['user_role'] = $role;
                    // Generate a new CSRF token for the new session
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                    // Set default profile pic URL
                    $_SESSION['user_profile_pic_url'] = rtrim(APP_URL, '/') . '/assets/images/default_avatar.png'; // Ensure APP_URL is defined

                    $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'Registration successful! You are now logged in.'];

                    // Redirect based on role
                    $redirectUrl = APP_URL . '/profile/' . urlencode($username); // Default redirect
                    if ($role === 'supplier') {
                        $redirectUrl = APP_URL . '/supplier/dashboard'; // More appropriate supplier redirect
                    } elseif ($role === 'stylist') {
                         $redirectUrl = APP_URL . '/stylist/dashboard'; // Example stylist redirect
                    }
                    redirect($redirectUrl);
                    exit;
                }
                // If we reach here, business creation failed, but error was already set in session, so loop will redirect below.

            } else {
                // Database error during user creation
                $errors['general'] = 'Registration failed due to a server error. Please try again.';
                error_log("AuthController::handleRegister - Failed to create user account. UserModel::createUser returned false.");
            }
        }

        // If errors occurred at any point, store them and redirect back
        $_SESSION['register_errors'] = $errors;
        $_SESSION['register_old_input'] = $input;
        redirect(APP_URL . '/register');
        exit;
    }

    /**
     * Displays the login form.
     * Generates CSRF token if needed.
     */
    public function showLogin() {
        // --- Generate CSRF token ---
        // Ensure a token exists in the session for the form
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            error_log("AuthController::showLogin - Generated new CSRF token."); // Optional log
        }
        // --- End CSRF token generation ---

        $pageTitle = "Sign In - Private Closet";
        // Retrieve errors/old input passed back via session from handleLogin failure
        $errors = $_SESSION['login_errors'] ?? [];
        $oldInput = $_SESSION['login_old_input'] ?? [];
        unset($_SESSION['login_errors'], $_SESSION['login_old_input']); // Important: Clear flash data

        // Prepare view data (loadView will add CSRF token automatically)
        $data = [
            'errors' => $errors,
            'oldInput' => $oldInput
        ];

        $this->loadView('layouts/_header', ['pageTitle' => $pageTitle]);
        $this->loadView('auth/login_content', $data); // loadView adds CSRF token
        $this->loadView('layouts/_footer');
    }

    /**
     * Handles login form submission.
     * Includes CSRF validation.
     */
    public function handleLogin() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(APP_URL . '/login');
            exit;
        }

        // --- CSRF Check ---
        if (empty($_POST['csrf_token']) || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            error_log("CSRF token validation failed during login."); // Log the failure
            $_SESSION['login_errors']['general'] = 'Invalid security token. Please try logging in again.';
            // Don't repopulate password field on CSRF failure
            $_SESSION['login_old_input'] = ['login_identifier' => $_POST['login_identifier'] ?? ''];
            // Invalidate the used token
            // unset($_SESSION['csrf_token']); // Or generate a new one
            redirect(APP_URL . '/login');
            exit;
        }
        // --- End CSRF Check ---

        $errors = [];
        $input = $_POST;
        $identifier = trim($input['login_identifier'] ?? '');
        $password = $input['password'] ?? '';
        $rememberMe = isset($input['remember_me']) && $input['remember_me'] == '1'; // Check remember me

        if (empty($identifier)) $errors['login_identifier'] = 'Username or Email is required.';
        if (empty($password)) $errors['password'] = 'Password is required.';

        if (empty($errors)) {
            $user = $this->userModel->findByUsernameOrEmail($identifier);

            // Verify user exists, is active, and password matches
            if ($user && ($user['is_active'] ?? 0) == 1 && $this->userModel->verifyPassword($password, $user['password_hash'])) {
                // --- Login successful ---
                // Regenerate session ID *before* setting session variables for the user
                session_regenerate_id(true);

                // Set core session variables
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['user_role'] = $user['role'];
                // Generate a new CSRF token for the now authenticated session
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

                // Set profile picture URL in session
                $app_url_base = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
                if (!empty($user['profile_picture_url'])) {
                    // Prepend base URL if the stored path is relative
                    if (strpos($user['profile_picture_url'], 'http') !== 0 && strpos($user['profile_picture_url'], '/') !== 0) {
                         $_SESSION['user_profile_pic_url'] = $app_url_base . '/assets/images/users/' . ltrim($user['profile_picture_url'], '/'); // Example path structure
                    } else {
                         $_SESSION['user_profile_pic_url'] = $user['profile_picture_url']; // Assume it's absolute or correctly relative already
                    }
                } else {
                    $_SESSION['user_profile_pic_url'] = $app_url_base . '/assets/images/default_avatar.png'; // Default
                }

                // Handle "Remember Me" - TODO: Implement token-based remember me logic
                if ($rememberMe) {
                    // Placeholder: Real implementation requires generating a persistent login token,
                    // storing its hash in DB linked to user ID, and setting a cookie with the token.
                    error_log("Remember Me feature selected for user ID: {$user['id']} (Not Implemented)");
                }

                // --- Redirect after login ---
                // Use intended redirect URL if set, otherwise default based on role
                $redirectTo = $_SESSION['redirect_to'] ?? null;
                unset($_SESSION['redirect_to']); // Clear intended destination

                if (!$redirectTo) { // If no specific destination, use role-based default
                    switch ($user['role']) {
                        case 'supplier':
                            $redirectTo = APP_URL . '/supplier/dashboard';
                            break;
                        case 'stylist':
                             $redirectTo = APP_URL . '/stylist/dashboard';
                             break;
                        case 'admin': // Example admin role
                             $redirectTo = APP_URL . '/admin/dashboard';
                             break;
                        case 'user':
                        default:
                             $redirectTo = APP_URL . '/showroom'; // Default for regular users
                             break;
                    }
                }

                redirect($redirectTo);
                exit;

            } elseif ($user && ($user['is_active'] ?? 0) != 1) {
                // User found but inactive
                $errors['general'] = 'Your account is currently inactive. Please contact support.';
                error_log("Login attempt failed: Account inactive for identifier '{$identifier}'.");
            } else {
                // User not found or password mismatch
                $errors['general'] = 'Invalid username/email or password.';
                error_log("Login attempt failed: Invalid credentials for identifier '{$identifier}'.");
            }
        }

        // --- Login failed ---
        $_SESSION['login_errors'] = $errors;
        // Only repopulate the identifier field on failure, never the password.
        $_SESSION['login_old_input'] = ['login_identifier' => $identifier];
        redirect(APP_URL . '/login');
        exit;
    }

    /**
     * Handles user logout.
     */
    public function logout() {
        // Unset all session variables specific to the user
        unset(
            $_SESSION['user_id'],
            $_SESSION['username'],
            $_SESSION['user_role'],
            $_SESSION['csrf_token'], // Also clear CSRF token on logout
            $_SESSION['user_profile_pic_url']
            // Add any other user-specific session keys here
        );

        // Standard session destruction
        // Optional: Clear the entire $_SESSION array if desired: $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();

        // Redirect to login page with a message (optional)
        // session_start(); // Start a new session briefly to store a flash message
        // $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'You have been logged out.'];
        redirect(APP_URL . '/login');
        exit;
    }

    /**
     * Helper function to load view files and extract data.
     * Automatically adds common variables like app_url, isLoggedIn, userRole, csrf_token.
     */
    private function loadView(string $viewName, array $data = []) {
        // Construct the full path to the view file
        $filePath = rtrim($this->viewPath, '/\\') . DIRECTORY_SEPARATOR . ltrim($viewName, '/\\') . '.php';
        // Normalize directory separators for cross-platform compatibility
        $filePath = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $filePath);

        if (file_exists($filePath)) {
            // --- Automatically add common data to be available in all views ---
            $data['app_url'] = $data['app_url'] ?? (defined('APP_URL') ? APP_URL : '');
            $data['isLoggedIn'] = $data['isLoggedIn'] ?? isset($_SESSION['user_id']);
            $data['userRole'] = $data['userRole'] ?? ($_SESSION['user_role'] ?? null);
            // Ensure CSRF token is always available if the session has one
            $data['csrf_token'] = $data['csrf_token'] ?? ($_SESSION['csrf_token'] ?? '');
            // Add other common variables if needed (e.g., site name, current user object)
            // $data['currentUser'] = isset($_SESSION['user_id']) ? $this->userModel->findById($_SESSION['user_id']) : null;
            // --- End common data ---

            // Make data array keys available as variables in the view file's scope
            extract($data);

            // Include the view file
            require $filePath;

        } else {
            // Handle view file not found error
            error_log("AuthController::loadView - CRITICAL: View file not found at path: " . $filePath);
            // Display a user-friendly error page in production
            // In development, more detailed info might be shown
            http_response_code(500); // Internal Server Error
            echo "<h1>Application Error</h1><p>Sorry, something went wrong.</p>";
            // Optional: Provide more detail if a DEBUG constant is set
            if(defined('DEBUG_MODE') && DEBUG_MODE === true){
                 echo "<p>Error details: A required view file ('" . htmlspecialchars($viewName) .".php') was not found.</p>";
                 echo "<p>Attempted path: ".htmlspecialchars($filePath)."</p>";
            }
            exit; // Stop execution
        }
    }

    // --- THIS IS THE METHOD THE ROUTER IS LOOKING FOR ---
    public function showForgotPasswordForm() {
        $data = [
            'pageTitle' => 'Forgot Password',
            // csrf_token and flashMessage will be handled by loadView if set in session
        ];
        // Flash message should be set before calling loadView if not passed directly
        // $data['flashMessage'] = $_SESSION['flash_message'] ?? null;
        // if (isset($_SESSION['flash_message'])) unset($_SESSION['flash_message']);

        $this->loadView('layouts/_header', $data);
        $this->loadView('auth/forgot_password_content', $data); // Your new view file
        $this->loadView('layouts/_footer', $data);
    }
    // --- END OF showForgotPasswordForm ---

     public function handleForgotPassword() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect($this->app_url . '/forgot-password'); // Use $this->app_url
            exit;
        }

        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid security token. Please try again.'];
            redirect($this->app_url . '/forgot-password'); // Use $this->app_url
            exit;
        }

        $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);

        if (!$email) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid email address provided.'];
            redirect($this->app_url . '/forgot-password'); // Use $this->app_url
            exit;
        }

        $user = $this->userModel->findByEmail($email);

        // Always set this generic message for security (prevents email enumeration)
        $_SESSION['flash_message'] = ['type' => 'success', 'text' => 'If an account with that email exists, a password reset link has been sent. Please check your inbox (and spam folder). (Dev: Check PHP error log for link).'];

        if ($user) {
            $tokenForUrl = bin2hex(random_bytes(32));
            $hashedTokenForDb = password_hash($tokenForUrl, PASSWORD_DEFAULT);

            // Ensure PasswordResetModel is instantiated
            if (!$this->passwordResetModel) {
                 error_log("AuthController FATAL: passwordResetModel not initialized!");
                 $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Server error processing request. Please try again later.'];
                 redirect($this->app_url . '/forgot-password');
                 exit;
            }

            if ($this->passwordResetModel->storeToken($email, $tokenForUrl, $hashedTokenForDb)) {
                $resetLink = $this->app_url . '/reset-password?token=' . urlencode($tokenForUrl) . '&email=' . urlencode($email); // Use $this->app_url
                
                $subject = "Password Reset Request - Private Closet";
                $body = "Hello " . htmlspecialchars($user['username'] ?? 'User') . ",\n\n";
                $body .= "You requested a password reset. Click the link below to reset your password:\n";
                $body .= $resetLink . "\n\n";
                $body .= "This link will expire in approximately 1 hour.\n\n";
                $body .= "If you did not request this, please ignore this email.\n\n";
                $body .= "Thanks,\nThe Private Closet Team";
                // $headers = "From: no-reply@" . ($_SERVER['HTTP_HOST'] ?? 'yourdomain.com'); // For actual mail()

                // Log email content instead of sending
                $emailLogMessage = "--- PASSWORD RESET EMAIL (SIMULATED SEND) ---\n";
                $emailLogMessage .= "To: " . $email . "\n";
                $emailLogMessage .= "Subject: " . $subject . "\n";
                // $emailLogMessage .= "Headers: " . $headers . "\n";
                $emailLogMessage .= "Body:\n" . $body . "\n";
                $emailLogMessage .= "--- END OF SIMULATED EMAIL ---\n";
                error_log($emailLogMessage);
                error_log("Password reset link for {$email} (Dev access): {$resetLink}");

            } else {
                error_log("Could not store password reset token for email: {$email}");
                // User still sees the generic success message
            }
        } else {
            error_log("Password reset attempt for non-existent email: {$email}");
            // User still sees the generic success message
        }

        redirect($this->app_url . '/forgot-password'); // Use $this->app_url
        exit;
    }
      
}
?>