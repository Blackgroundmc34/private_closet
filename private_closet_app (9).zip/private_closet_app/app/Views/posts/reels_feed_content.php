<?php
// File: app/Views/posts/reels_feed_content.php
$reels = $reels ?? [];
$currentPage = $currentPage ?? 1;
$totalPages = $totalPages ?? 1;
$loggedInUserId = $loggedInUserId ?? null;
$isLoggedIn = $isLoggedIn ?? false;
$app_url = $app_url ?? '';
$default_avatar_path = $default_avatar_path ?? 'assets/images/default_avatar.png';
$default_avatar_full_url = $app_url . '/' . ltrim(htmlspecialchars($default_avatar_path), '/');
$csrf_token = $_SESSION['csrf_token'] ?? '';

if (!function_exists('escape_html_reels')) {
    function escape_html_reels($string) { return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
if (!function_exists('time_ago_reels_view')) {
    function time_ago_reels_view($datetime) { // Simplified for display
        try {
            $now = new DateTime(); $ago = new DateTime($datetime); $diff = $now->diff($ago);
            if ($diff->y) return $diff->y . 'y'; if ($diff->m) return $diff->m . 'm';
            $w = floor($diff->d / 7); if ($w) return $w . 'w';
            if ($diff->d) return $diff->d . 'd'; if ($diff->h) return $diff->h . 'h';
            if ($diff->i) return $diff->i . 'm'; return 'now';
        } catch (Exception $e) { return '...'; }
    }
}
?>

<div class="reels-feed-container mx-auto max-w-md relative">
    <?php if (isset($flashMessage) && $flashMessage && isset($flashMessage['text'])): ?>
        <div id="reels-flash-message" class="fixed top-16 left-1/2 transform -translate-x-1/2 z-50 p-3 rounded-md shadow-lg <?php echo ($flashMessage['type'] ?? 'info') === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'; ?>" role="alert">
            <?php echo escape_html_reels($flashMessage['text']); ?>
        </div>
    <?php endif; ?>

    <?php if (empty($reels)): ?>
        <div class="text-center py-20 flex flex-col items-center justify-center h-full">
            <i class="fas fa-film text-6xl text-gray-400 mb-4"></i>
            <p class="text-xl text-gray-500">No Reels to explore yet.</p>
             <?php if ($isLoggedIn): ?>
                 <a href="<?php echo $app_url; ?>/upload" class="mt-4 inline-block bg-indigo-600 text-white font-semibold py-2 px-5 rounded-full hover:bg-indigo-700 transition duration-150">
                    <i class="fas fa-plus-circle mr-2"></i>Create Your First Reel
                </a>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <?php foreach ($reels as $index => $reel): ?>
            <?php
                $reel_id = (int)($reel['id'] ?? 0);
                $author_username = escape_html_reels($reel['author_username'] ?? 'User');
                // CRITICAL: Use the correctly prepared full URL from the model
                $author_profile_pic_full_url = escape_html_reels($reel['author_profile_pic_full_url'] ?? $default_avatar_full_url);
                $media_full_url = escape_html_reels($reel['media_full_url'] ?? '');
                $description = escape_html_reels($reel['description'] ?? '');
                $like_count = (int)($reel['like_count'] ?? 0);
                $comment_count = (int)($reel['comment_count'] ?? 0);
                $is_liked_by_user = (bool)($reel['is_liked_by_user'] ?? false);
                $is_saved_by_user = (bool)($reel['is_saved_by_user'] ?? false);
                $created_at_ago = time_ago_reels_view($reel['created_at'] ?? '');
                $post_url = $app_url . '/post/' . $reel_id;
            ?>
            <div class="reel-item bg-black shadow-xl rounded-lg overflow-hidden snap-start relative flex items-center justify-center"
                 style="height: calc(100vh - 60px); min-height: 450px; max-height: 800px;" 
                 id="reel-<?php echo $reel_id; ?>"
                 data-reel-id="<?php echo $reel_id; ?>"
                 data-post-url="<?php echo $post_url; ?>">

                <video class="reel-video max-w-full max-h-full object-contain"
                       src="<?php echo $media_full_url; ?>"
                       playsinline autoplay loop muted
                       preload="metadata"
                       id="video-<?php echo $reel_id; ?>"
                       poster="<?php echo $app_url . '/assets/images/video_poster_placeholder.png'; // Optional poster ?>">
                    Your browser does not support the video tag.
                </video>

                <div class="absolute top-4 left-4 z-20">
                    <button class="volume-toggle-btn text-white bg-black/50 rounded-full p-2.5 focus:outline-none hover:bg-black/70" data-video-id="video-<?php echo $reel_id; ?>" title="Toggle Mute">
                        <i class="fas fa-volume-mute fa-lg current-volume-icon"></i>
                    </button>
                </div>

                <div class="absolute bottom-0 left-0 right-0 p-4 pb-20 md:pb-6 bg-gradient-to-t from-black/80 via-black/40 to-transparent text-white z-10">
                    <div class="flex items-center mb-2">
                        <a href="<?php echo $app_url . '/profile/' . $author_username; ?>">
                            <img src="<?php echo $author_profile_pic_full_url; ?>" alt="<?php echo $author_username; ?>" class="w-10 h-10 rounded-full border-2 border-white/80 mr-3 object-cover">
                        </a>
                        <div>
                            <a href="<?php echo $app_url . '/profile/' . $author_username; ?>" class="font-semibold hover:underline text-shadow"><?php echo $author_username; ?></a>
                            <p class="text-xs text-gray-200 text-shadow-sm"><?php echo $created_at_ago; ?></p>
                        </div>
                    </div>
                    <p class="text-sm reel-description leading-tight max-h-16 overflow-y-auto text-shadow-sm whitespace-pre-line"><?php echo nl2br($description); ?></p>
                </div>

                <div class="absolute bottom-20 right-3 md:bottom-6 flex flex-col items-center space-y-5 z-10 p-2 text-white">
                    <button class="like-btn reel-action-btn" data-post-id="<?php echo $reel_id; ?>" aria-pressed="<?php echo $is_liked_by_user ? 'true' : 'false'; ?>" title="Like">
                        <i class="<?php echo $is_liked_by_user ? 'fas text-red-500' : 'far'; ?> fa-heart fa-2x"></i>
                        <span class="block text-xs like-count mt-1 text-shadow-md"><?php echo $like_count; ?></span>
                    </button>
                    
                    <button class="comment-modal-trigger reel-action-btn" data-post-id="<?php echo $reel_id; ?>" title="Comments">
                        <i class="far fa-comment-dots fa-2x"></i>
                        <span class="block text-xs comment-count mt-1 text-shadow-md"><?php echo $comment_count; ?></span>
                    </button>

                    <button class="share-btn-reels reel-action-btn" data-share-url="<?php echo $post_url; ?>" data-share-title="<?php echo escape_html_reels($description ? mb_substr($description, 0, 50) . '...' : 'Check out this reel by ' . $author_username); ?>" title="Share">
                        <i class="fas fa-share-square fa-2x"></i>
                        <span class="block text-xs text-shadow-md">Share</span>
                    </button>

                    <button class="save-btn reel-action-btn" data-post-id="<?php echo $reel_id; ?>" aria-pressed="<?php echo $is_saved_by_user ? 'true' : 'false'; ?>" title="Save">
                        <i class="<?php echo $is_saved_by_user ? 'fas' : 'far'; ?> fa-bookmark fa-2x"></i>
                        <span class="block text-xs text-shadow-md">Save</span>
                    </button>
                </div>
                <div class="share-status-toast" id="share-status-reel-<?php echo $reel_id; ?>" style="display: none;">Link copied!</div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<div id="commentsModal" class="fixed inset-0 bg-black bg-opacity-75 flex items-end justify-center z-[1001]" style="display: none; padding-bottom: env(safe-area-inset-bottom, 0);">
    <div id="commentsModalContent" class="bg-gray-900 text-white w-full max-w-md h-[75vh] max-h-[600px] rounded-t-2xl shadow-xl flex flex-col transform transition-transform duration-300 ease-out translate-y-full">
        <div class="p-4 border-b border-gray-700 flex justify-between items-center sticky top-0 bg-gray-900 rounded-t-2xl z-10">
            <h3 id="commentsModalTitle" class="text-lg font-semibold">Comments</h3>
            <button id="closeCommentsModalBtn" class="text-gray-400 hover:text-white text-2xl focus:outline-none">&times;</button>
        </div>
        <div id="commentsListContainer" class="flex-grow overflow-y-auto p-4 space-y-3">
            <div class="text-center py-5 text-gray-400">Loading comments...</div>
        </div>
        <?php if ($isLoggedIn): ?>
        <div class="p-3 border-t border-gray-700 sticky bottom-0 bg-gray-900">
            <form id="reelCommentForm" class="flex gap-2 items-center">
                <input type="hidden" name="post_id_comment_modal" id="post_id_comment_modal" value="">
                <textarea name="comment_text_modal" id="comment_text_modal" rows="1" placeholder="Add a comment..." required class="flex-grow p-2.5 bg-gray-800 border border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 resize-none text-sm placeholder-gray-500"></textarea>
                <button type="submit" id="reelCommentSubmitBtn" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 px-4 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 focus:ring-offset-gray-900">
                    <i class="fas fa-paper-plane"></i>
                </button>
            </form>
            <p class="reel-comment-error-message text-red-400 text-xs mt-1 hidden"></p>
        </div>
        <?php else: ?>
        <div class="p-4 text-center text-sm text-gray-400 border-t border-gray-700">
            <a href="<?php echo $app_url . '/login'; ?>" class="text-indigo-400 hover:underline">Log in</a> to comment.
        </div>
        <?php endif; ?>
    </div>
</div>


<script>
// JavaScript from previous response (with IntersectionObserver, Like, Share, Save, Comments Modal)
// Ensure this script block is complete and correct as provided in the previous detailed explanation.
// Key parts to re-verify and include:
// - showToast function
// - escapeHtmlJs function
// - timeAgoJsSimple function
// - Video Player Logic (IntersectionObserver, Click to Play/Pause, Volume Toggle)
// - Like Button AJAX
// - Save Button AJAX
// - Share Button (Web Share API + Fallback)
// - Comments Modal Logic (Open, Close, Fetch Comments, Render Comments, Post New Comment)

document.addEventListener('DOMContentLoaded', function() {
    const csrfToken = '<?php echo $csrf_token; ?>';
    const appUrl = '<?php echo $app_url; ?>';
    const loggedInUserId = <?php echo $loggedInUserId ? $loggedInUserId : 'null'; ?>;
    const defaultAvatarFullUrl = '<?php echo $default_avatar_full_url; ?>';
    const isLoggedIn = <?php echo $isLoggedIn ? 'true' : 'false'; ?>;

    const reelsFlashMessage = document.getElementById('reels-flash-message');
    if(reelsFlashMessage) {
        setTimeout(() => {
            reelsFlashMessage.style.transition = 'opacity 0.5s ease';
            reelsFlashMessage.style.opacity = '0';
            setTimeout(() => reelsFlashMessage.remove(), 500);
        }, 3000);
    }


    function showToast(message, type = 'success', targetElement = null) {
        let toastDiv;
        if (targetElement && targetElement.querySelector('.share-status-toast')) {
            toastDiv = targetElement.querySelector('.share-status-toast');
        } else {
            toastDiv = document.createElement('div');
            toastDiv.className = 'fixed top-16 left-1/2 transform -translate-x-1/2 p-3 text-white text-sm rounded-md shadow-lg z-[1002]';
            document.body.appendChild(toastDiv);
        }
        
        toastDiv.textContent = message;
        toastDiv.style.backgroundColor = type === 'success' ? '#10B981' : (type === 'error' ? '#EF4444' : '#3B82F6'); // Tailwind green-500, red-500, blue-500
        toastDiv.style.display = 'block';
        toastDiv.style.opacity = '1';
        toastDiv.style.transition = 'opacity 0.3s ease-in-out';

        setTimeout(() => {
            toastDiv.style.opacity = '0';
            setTimeout(() => {
                toastDiv.style.display = 'none';
                 if (toastDiv.parentElement === document.body && (!targetElement || !targetElement.contains(toastDiv))) {
                    toastDiv.remove();
                }
            }, 300);
        }, 2500);
    }

    function escapeHtmlJs(unsafe) {
        if (typeof unsafe !== 'string') return '';
        return unsafe.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }

    function timeAgoJsSimple(datetimeStr) {
        if (!datetimeStr) return "N/A";
        try {
            const date = new Date(datetimeStr.replace(' ', 'T') + (datetimeStr.endsWith('Z') || datetimeStr.includes('+') || datetimeStr.includes('-') ? '' : 'Z'));
            const now = new Date();
            const seconds = Math.round((now - date) / 1000);
            if (seconds < 5) return 'now'; if (seconds < 60) return seconds + 's';
            const minutes = Math.round(seconds / 60); if (minutes < 60) return minutes + 'm';
            const hours = Math.round(minutes / 60); if (hours < 24) return hours + 'h';
            const days = Math.round(hours / 24); if (days < 7) return days + 'd';
            const weeks = Math.round(days / 7); if (weeks < 52) return weeks + 'w';
            const years = Math.round(days/365); return years + 'y';
        } catch (e) { console.error("timeAgoJsSimple error:", e, "Input:", datetimeStr); return '...'; }
    }

    // Video Player Logic
    const videos = document.querySelectorAll('video.reel-video');
    const videoObservers = new Map();
    videos.forEach(video => {
        const reelItem = video.closest('.reel-item');
        const volumeButton = reelItem.querySelector(`.volume-toggle-btn[data-video-id="${video.id}"]`);
        const volumeIcon = volumeButton ? volumeButton.querySelector('i.current-volume-icon') : null;

        function updateVolumeIconDisplay() {
            if (volumeIcon) {
                volumeIcon.classList.toggle('fa-volume-up', !video.muted);
                volumeIcon.classList.toggle('fa-volume-mute', video.muted);
            }
        }
        updateVolumeIconDisplay();

        if (volumeButton) {
            volumeButton.addEventListener('click', (e) => {
                e.stopPropagation(); video.muted = !video.muted; updateVolumeIconDisplay();
            });
        }
        
        video.addEventListener('click', function(event) {
            if (event.target.closest('.reel-action-btn') || event.target.closest('.volume-toggle-btn')) return;
            if (video.paused) { video.play().catch(e => {}); } else { video.pause(); }
        });

        video.addEventListener('play', () => {
            videos.forEach(otherVideo => { if (otherVideo !== video && !otherVideo.paused) otherVideo.pause(); });
            updateVolumeIconDisplay();
        });
        
        const observerOptions = { root: null, rootMargin: '0px', threshold: 0.75 }; // Play when 75% visible
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // entry.target.muted = true; // Ensure muted for autoplay policies
                    entry.target.play().catch(e => console.warn("Autoplay for reel " + entry.target.id + " prevented: ", e.message));
                } else {
                    entry.target.pause();
                }
            });
        }, observerOptions);
        observer.observe(video);
        videoObservers.set(video.id, observer);
    });

    // Like, Save Button AJAX (Generic handler)
    function handlePostInteraction(buttonClass, endpointPath, stateField, iconSelector, activeClass, inactiveClass, activeTextClass, inactiveTextClass) {
        document.querySelectorAll(buttonClass).forEach(button => {
            button.addEventListener('click', function(e) {
                e.stopPropagation();
                if (!isLoggedIn) { window.location.href = appUrl + '/login?redirect_to=' + encodeURIComponent(window.location.href); return; }
                
                const postId = this.dataset.postId;
                const icon = this.querySelector(iconSelector);
                const countSpan = this.querySelector('.' + stateField + '-count'); // e.g., .like-count
                this.disabled = true;

                fetch(`${appUrl}/post/${postId}/${endpointPath}`, {
                    method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken }, body: JSON.stringify({})
                })
                .then(response => {
                    if (!response.ok) { return response.json().then(err => { throw new Error(err.message || `HTTP error ${response.status}`); }); }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        const isActive = data[stateField.replace('-count', '')]; // e.g. data.liked or data.saved
                        if (icon) {
                            icon.classList.toggle(activeClass, isActive);
                            icon.classList.toggle(inactiveClass, !isActive);
                        }
                        if (countSpan && data[stateField] !== undefined) { // Check if count is returned for likes
                            countSpan.textContent = data[stateField];
                        }
                        this.setAttribute('aria-pressed', isActive);
                        if (data.message) showToast(data.message, 'success', this.closest('.reel-item'));
                    } else { showToast(data.message || 'Action failed.', 'error', this.closest('.reel-item')); }
                })
                .catch(error => { console.error(`${stateField} error:`, error); showToast(`${stateField.charAt(0).toUpperCase() + stateField.slice(1)} action failed.`, 'error', this.closest('.reel-item')); })
                .finally(() => { this.disabled = false; });
            });
        });
    }

    handlePostInteraction('.like-btn', 'toggle-like', 'like-count', 'i', 'fas', 'far', 'text-red-500', '');
    handlePostInteraction('.save-btn', 'toggle-save', 'save', 'i', 'fas', 'far', '', '');


    // Share Button
    document.querySelectorAll('.share-btn-reels').forEach(button => {
        button.addEventListener('click', async function(e) {
            e.stopPropagation();
            const url = this.dataset.shareUrl;
            const title = this.dataset.shareTitle;
            const reelItem = this.closest('.reel-item');

            if (navigator.share) {
                try { await navigator.share({ title: title, url: url }); } 
                catch (err) { if (err.name !== 'AbortError') copyToClipboard(url, reelItem); }
            } else { copyToClipboard(url, reelItem); }
        });
    });
    function copyToClipboard(text, reelItem) {
        navigator.clipboard.writeText(text).then(() => {
            showToast('Link copied!', 'success', reelItem);
        }).catch(err => {
            showToast('Copy failed!', 'error', reelItem);
        });
    }

    // Comments Modal Logic
    const commentsModal = document.getElementById('commentsModal');
    const commentsModalContent = document.getElementById('commentsModalContent');
    const closeCommentsModalBtn = document.getElementById('closeCommentsModalBtn');
    const commentsListContainer = document.getElementById('commentsListContainer');
    const reelCommentForm = document.getElementById('reelCommentForm');
    const commentPostIdInput = document.getElementById('post_id_comment_modal');
    const commentTextInput = document.getElementById('comment_text_modal');
    const commentErrorMsgP = document.querySelector('.reel-comment-error-message');
    const commentsModalTitle = document.getElementById('commentsModalTitle');


    function openCommentsModal(postId) {
        commentPostIdInput.value = postId;
        commentsListContainer.innerHTML = '<div class="text-center py-5 text-gray-400"><i class="fas fa-spinner fa-spin mr-2"></i>Loading comments...</div>';
        commentsModal.style.display = 'flex';
        setTimeout(() => { commentsModalContent.style.transform = 'translateY(0)'; }, 10);
        document.body.style.overflow = 'hidden'; // Prevent background scroll

        fetch(`${appUrl}/post/${postId}/comments`, { headers: {'X-Requested-With': 'XMLHttpRequest'} })
            .then(response => response.json())
            .then(data => {
                if (data.success && Array.isArray(data.comments)) {
                    renderComments(data.comments, postId);
                    commentsModalTitle.textContent = `Comments (${data.comments.length})`;
                } else {
                    commentsListContainer.innerHTML = '<div class="text-center py-5 text-gray-400">Could not load comments.</div>';
                     commentsModalTitle.textContent = `Comments (0)`;
                }
            })
            .catch(err => {
                console.error("Error fetching comments:", err);
                commentsListContainer.innerHTML = '<div class="text-center py-5 text-red-400">Error loading comments. Please try again.</div>';
                commentsModalTitle.textContent = `Comments`;
            });
    }

    function closeCommentsModal() {
        commentsModalContent.style.transform = 'translateY(100%)';
        setTimeout(() => { commentsModal.style.display = 'none'; }, 300);
        document.body.style.overflow = ''; // Restore background scroll
        if(commentTextInput) commentTextInput.value = '';
        if(commentErrorMsgP) {commentErrorMsgP.classList.add('hidden'); commentErrorMsgP.textContent = '';}
    }

    function renderComments(commentsData, postId) {
        if (!commentsListContainer) return;
        if (commentsData.length === 0) {
            commentsListContainer.innerHTML = '<div class="text-center py-5 text-gray-400">No comments yet. Be the first!</div>';
            return;
        }
        commentsListContainer.innerHTML = commentsData.map(comment => `
            <div class="flex items-start space-x-2.5 py-2.5 border-b border-gray-700 last:border-b-0">
                <a href="${appUrl}/profile/${escapeHtmlJs(comment.commenter_username || 'user')}">
                    <img class="h-8 w-8 rounded-full object-cover" src="${escapeHtmlJs(comment.commenter_profile_pic_full_url || defaultAvatarFullUrl)}" alt="${escapeHtmlJs(comment.commenter_username || 'User')}">
                </a>
                <div class="flex-1">
                    <div class="flex items-baseline justify-between">
                        <a href="${appUrl}/profile/${escapeHtmlJs(comment.commenter_username || 'user')}" class="text-xs font-semibold text-indigo-400 hover:underline">
                            ${escapeHtmlJs(comment.commenter_username || 'User')}
                        </a>
                        <p class="text-xs text-gray-500">${timeAgoJsSimple(comment.created_at)}</p>
                    </div>
                    <p class="text-sm text-gray-200 mt-0.5 whitespace-pre-line">${escapeHtmlJs(comment.comment_text).replace(/\n/g, '<br>')}</p>
                </div>
            </div>
        `).join('');
    }

    document.querySelectorAll('.comment-modal-trigger').forEach(button => {
        button.addEventListener('click', function(e) {
            e.stopPropagation();
            const postId = this.dataset.postId;
            openCommentsModal(postId);
        });
    });

    if (closeCommentsModalBtn) closeCommentsModalBtn.addEventListener('click', closeCommentsModal);
    if (commentsModal) commentsModal.addEventListener('click', (e) => { if (e.target === commentsModal) closeCommentsModal(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && commentsModal && commentsModal.style.display === 'flex') closeCommentsModal(); });

    if (reelCommentForm && isLoggedIn) {
        reelCommentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const postId = commentPostIdInput.value;
            const commentText = commentTextInput.value.trim();
            const submitBtn = this.querySelector('button[type="submit"]');

            if (!commentText) { if(commentErrorMsgP) { commentErrorMsgP.textContent = 'Comment cannot be empty.'; commentErrorMsgP.classList.remove('hidden'); } return; }
            if (commentText.length > 1000) { if(commentErrorMsgP) { commentErrorMsgP.textContent = 'Comment too long.'; commentErrorMsgP.classList.remove('hidden'); } return; }

            submitBtn.disabled = true; submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            if(commentErrorMsgP) commentErrorMsgP.classList.add('hidden');

            fetch(`${appUrl}/post/${postId}/add-comment`, {
                method: 'POST',
                headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken, 'X-Requested-With': 'XMLHttpRequest'},
                body: JSON.stringify({ comment_text: commentText })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success && data.comment) {
                    commentTextInput.value = '';
                    const newCommentHtml = `
                        <div class="flex items-start space-x-2.5 py-2.5 border-b border-gray-700 last:border-b-0 animate-fade-in">
                            <a href="${appUrl}/profile/${escapeHtmlJs(data.comment.commenter_username || 'user')}">
                                <img class="h-8 w-8 rounded-full object-cover" src="${escapeHtmlJs(data.comment.commenter_profile_pic_full_url || defaultAvatarFullUrl)}" alt="${escapeHtmlJs(data.comment.commenter_username || 'User')}">
                            </a>
                            <div class="flex-1">
                                <div class="flex items-baseline justify-between">
                                    <a href="${appUrl}/profile/${escapeHtmlJs(data.comment.commenter_username || 'user')}" class="text-xs font-semibold text-indigo-400 hover:underline">${escapeHtmlJs(data.comment.commenter_username || 'User')}</a>
                                    <p class="text-xs text-gray-500">${timeAgoJsSimple(data.comment.created_at)}</p>
                                </div>
                                <p class="text-sm text-gray-200 mt-0.5 whitespace-pre-line">${escapeHtmlJs(data.comment.comment_text).replace(/\n/g, '<br>')}</p>
                            </div>
                        </div>`;
                    const noCommentsMsg = commentsListContainer.querySelector('.text-center.py-5.text-gray-400');
                    if (noCommentsMsg && noCommentsMsg.textContent.includes("No comments yet")) {
                        commentsListContainer.innerHTML = '';
                    }
                    commentsListContainer.insertAdjacentHTML('afterbegin', newCommentHtml); // Prepend
                    
                    const reelCommentCountSpan = document.querySelector(`#reel-${postId} .comment-count`);
                    const currentCount = parseInt(reelCommentCountSpan.textContent || 0) + 1;
                    if (reelCommentCountSpan) reelCommentCountSpan.textContent = currentCount;
                    commentsModalTitle.textContent = `Comments (${currentCount})`;


                } else {
                    if(commentErrorMsgP) { commentErrorMsgP.textContent = data.message || 'Failed to post comment.'; commentErrorMsgP.classList.remove('hidden'); }
                }
            })
            .catch(err => {
                console.error("Error posting comment:", err);
                if(commentErrorMsgP) { commentErrorMsgP.textContent = 'An error occurred.'; commentErrorMsgP.classList.remove('hidden'); }
            })
            .finally(() => {
                submitBtn.disabled = false; submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i>';
            });
        });
    }
});
</script>
<style>
.reels-feed-container {
    scroll-snap-type: y mandatory;
    overflow-y: scroll;
    /* Consider device height minus any fixed headers/footers */
    height: calc(100vh - var(--header-height, 60px) - var(--footer-height, 50px)); /* Adjust CSS variables as needed */
    scrollbar-width: none; /* Firefox */
    -ms-overflow-style: none;  /* IE 10+ */
}
.reels-feed-container::-webkit-scrollbar {display: none;} /* WebKit */
.reel-item { 
    scroll-snap-align: start; 
    height: 100%; /* Make reel item take full height of container */
}
.text-shadow { text-shadow: 0 1px 3px rgba(0,0,0,0.6); }
.text-shadow-sm { text-shadow: 0 1px 2px rgba(0,0,0,0.5); }
.text-shadow-md { text-shadow: 0 2px 4px rgba(0,0,0,0.6); }

.reel-action-btn i { transition: transform 0.2s ease-in-out, color 0.2s ease; }
.reel-action-btn:hover i { transform: scale(1.15); }
.like-btn.liked i { color: #EF4444; /* red-500 */ } /* Example for liked state color */
.save-btn.saved i { color: #F59E0B; /* amber-500 */ } /* Example for saved state color */


.animate-fade-in { animation: fadeIn 0.5s ease-out; }
@keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

#commentsModalContent { transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1); }

.share-status-toast {
    position: absolute; /* Position relative to the reel-item if nested, or fixed/absolute globally */
    top: 1rem; left: 50%; transform: translateX(-50%);
    padding: 0.5rem 1rem; background-color: #10B981; /* Default success */
    color: white; font-size: 0.875rem; border-radius: 0.375rem;
    box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06);
    z-index: 20; display: none; /* Controlled by JS */
    transition: opacity 0.3s ease-in-out;
}
</style>