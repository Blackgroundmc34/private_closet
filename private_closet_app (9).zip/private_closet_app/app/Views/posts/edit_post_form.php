<?php
// File: app/Views/posts/edit_post_form.php
// Purpose: Displays the form for editing an existing post.
// Expected variables: $post (array of current post data), $errors (array), $oldInput (array)

$app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
$post = $post ?? null;
$errors = $errors ?? [];
$oldInput = $oldInput ?? []; // Submitted data on failed validation

if (!$post) {
    echo "<div class='container mx-auto px-4 py-8'><p class='text-red-500'>Post data not available for editing.</p></div>";
    return; 
}

// Helper to get field value: check old input first, then current post data
function get_edit_post_value(string $fieldName, array $submittedData, array $currentPostData, $default = '') {
    if (!empty($submittedData[$fieldName])) {
        return htmlspecialchars($submittedData[$fieldName]);
    }
    return isset($currentPostData[$fieldName]) ? htmlspecialchars($currentPostData[$fieldName]) : htmlspecialchars($default);
}

$description = get_edit_post_value('description', $oldInput, $post);
$visibility = get_edit_post_value('visibility', $oldInput, $post, 'public');
$location = get_edit_post_value('location', $oldInput, $post);
// For checkbox, check if it was submitted or use current post data
$allow_comments_current = isset($post['allow_comments']) ? (bool)$post['allow_comments'] : true;
$allow_comments = isset($oldInput['allow_comments_submitted']) // Check if form was submitted
    ? (isset($oldInput['allow_comments']) && $oldInput['allow_comments'] == '1')
    : $allow_comments_current;

?>

<div class="container mx-auto px-4 py-8 max-w-xl">
    <h1 class="text-2xl font-bold mb-6 text-gray-800">Edit Post</h1>

    <?php if (!empty($errors['general'])): ?>
        <div class="mb-4 p-3 rounded-md bg-red-100 text-red-700">
            <?php echo htmlspecialchars($errors['general']); ?>
        </div>
    <?php endif; ?>

    <form action="<?php echo $app_url . '/post/' . (int)$post['id'] . '/edit'; ?>" method="POST" class="bg-white p-6 rounded-lg shadow-md">
        <?php if (!empty($post['media_url'])): ?>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">Current Media:</label>
                <?php if ($post['media_type'] === 'image'): ?>
                    <img src="<?php echo $app_url . '/' . htmlspecialchars($post['media_url']); ?>" alt="Current post media" class="max-w-xs max-h-48 rounded border">
                <?php elseif ($post['media_type'] === 'video'): ?>
                    <video controls src="<?php echo $app_url . '/' . htmlspecialchars($post['media_url']); ?>" class="max-w-xs max-h-48 rounded border">Your browser does not support the video tag.</video>
                <?php endif; ?>
                <p class="text-xs text-gray-500 mt-1">Media file cannot be changed via this form.</p>
            </div>
        <?php endif; ?>

        <div class="mb-4">
            <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Description/Caption:</label>
            <textarea name="description" id="description" rows="6"
                      class="w-full px-3 py-2 border <?php echo isset($errors['description']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                      placeholder="Tell us about your item..."><?php echo $description; ?></textarea>
            <?php if (isset($errors['description'])) echo '<p class="text-red-500 text-xs mt-1">' . htmlspecialchars($errors['description']) . '</p>'; ?>
        </div>

        <div class="mb-4">
            <label for="location" class="block text-sm font-medium text-gray-700 mb-1">Location (Optional):</label>
            <input type="text" name="location" id="location" value="<?php echo $location; ?>"
                   class="w-full px-3 py-2 border <?php echo isset($errors['location']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                   placeholder="e.g., New York, NY">
            <?php if (isset($errors['location'])) echo '<p class="text-red-500 text-xs mt-1">' . htmlspecialchars($errors['location']) . '</p>'; ?>
        </div>

        <div class="mb-4">
            <label for="visibility" class="block text-sm font-medium text-gray-700 mb-1">Visibility:</label>
            <select name="visibility" id="visibility" class="w-full px-3 py-2 border <?php echo isset($errors['visibility']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                <option value="public" <?php echo ($visibility === 'public') ? 'selected' : ''; ?>>Public</option>
                <option value="followers" <?php echo ($visibility === 'followers') ? 'selected' : ''; ?>>Followers Only</option>
                <option value="private" <?php echo ($visibility === 'private') ? 'selected' : ''; ?>>Private (Only Me)</option>
            </select>
            <?php if (isset($errors['visibility'])) echo '<p class="text-red-500 text-xs mt-1">' . htmlspecialchars($errors['visibility']) . '</p>'; ?>
        </div>
        
        <div class="mb-6">
            <label class="flex items-center">
                <input type="checkbox" name="allow_comments" value="1" class="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
                    <?php echo $allow_comments ? 'checked' : ''; ?>>
                <input type="hidden" name="allow_comments_submitted" value="1"> <span class="ml-2 text-sm text-gray-700">Allow comments on this post</span>
            </label>
        </div>


        <div class="flex items-center justify-between">
            <a href="<?php echo $app_url . '/post/' . (int)$post['id']; ?>" class="text-sm text-gray-600 hover:text-indigo-600">Cancel</a>
            <button type="submit"
                    class="px-6 py-2 bg-indigo-600 text-white font-medium rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                Save Changes
            </button>
        </div>
    </form>
</div>
