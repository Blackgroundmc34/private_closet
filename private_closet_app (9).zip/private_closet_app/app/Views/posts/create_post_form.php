<?php
// File: app/Views/posts/create_post_form.php
// Purpose: Provides the HTML form for creating a new post.

// These variables are expected to be passed from PostController::showUploadForm()
// $flashMessage (array|null) - For displaying success/error messages from previous actions
// $app_url (string) - The base URL of the application, essential for form action
// $loggedInUserId (int|null) - ID of the logged-in user (passed for consistency, though not directly used in this basic form view)
// $isLoggedIn (bool) - Boolean indicating if a user is logged in (passed for consistency)

// Ensure escape_html is available (should be loaded via bootstrap.php -> utilities.php)
if (!function_exists('escape_html')) {
    // Basic fallback if utilities.php didn't load or define it, though it should.
    function escape_html($value) { 
        return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8'); 
    }
}

// Construct the URL for the form submission
// This should point to the route handled by PostController::handleUpload()
$form_action_url = ($app_url ?? '') . '/upload'; 

?>

<div class="container mx-auto px-4 py-8 max-w-2xl">
    <div class="bg-white p-6 sm:p-8 rounded-lg shadow-xl border border-gray-200">
        <h1 class="text-2xl sm:text-3xl font-semibold text-gray-800 mb-6 pb-4 border-b border-gray-200 text-center">
            Create New Post
        </h1>

        <?php if (isset($flashMessage) && $flashMessage && is_array($flashMessage) && isset($flashMessage['text'])): ?>
            <div class="mb-6 p-3 rounded-md text-sm <?php
                // Determine background and text color based on flash message type
                $messageTypeClass = 'bg-blue-100 text-blue-700'; // Default for 'info' or other types
                if ($flashMessage['type'] === 'success') {
                    $messageTypeClass = 'bg-green-100 text-green-700';
                } elseif ($flashMessage['type'] === 'error') {
                    $messageTypeClass = 'bg-red-100 text-red-700';
                }
                echo $messageTypeClass;
                ?>">
                <?php echo escape_html($flashMessage['text']); ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo escape_html($form_action_url); ?>" method="POST" enctype="multipart/form-data">
            <?php /* if (function_exists('generate_csrf_token')): // Example CSRF token generation
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token('create_post_form'); ?>">
            <?php endif; */ ?>

            <div class="mb-6">
                <label for="post_description" class="block text-gray-700 text-sm font-bold mb-2">
                    Description <span class="text-red-500">*</span>
                </label>
                <textarea id="post_description" name="description" rows="5" required
                          class="shadow-sm appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                          placeholder="Share something interesting... (max 1000 characters)"></textarea>
                <p class="text-xs text-gray-500 mt-1">What's on your mind? Max 1000 characters.</p>
            </div>

            <div class="mb-6">
                <label for="post_media" class="block text-gray-700 text-sm font-bold mb-2">
                    Upload Image or Video (Optional)
                </label>
                <input type="file" id="post_media" name="media_file" accept="image/jpeg,image/png,image/gif,video/mp4,video/quicktime"
                       class="block w-full text-sm text-gray-500
                              file:mr-4 file:py-2 file:px-4
                              file:rounded-full file:border-0
                              file:text-sm file:font-semibold
                              file:bg-indigo-50 file:text-indigo-700
                              hover:file:bg-indigo-100
                              focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"/>
                <p class="text-xs text-gray-500 mt-1">Allowed: JPG, PNG, GIF, MP4, MOV. Max size: 10MB (server-side validation needed).</p>
            </div>
            
            <div class="mb-6">
                <label for="post_location" class="block text-gray-700 text-sm font-bold mb-2">
                    Location (Optional)
                </label>
                <input type="text" id="post_location" name="location"
                       class="shadow-sm appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                       placeholder="e.g., Paris, France">
            </div>

            <div class="mb-6">
                <label for="allow_comments" class="inline-flex items-center cursor-pointer">
                    <input type="checkbox" id="allow_comments" name="allow_comments" value="1" checked
                           class="rounded h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300">
                    <span class="ml-2 text-sm text-gray-700">Allow comments on this post</span>
                </label>
            </div>
            
            <div class="flex items-center justify-end pt-4 border-t border-gray-200 mt-6">
                <a href="<?php echo escape_html($app_url . '/showroom'); // Or user's profile/closet page ?>" 
                   class="text-gray-600 hover:text-gray-800 text-sm font-medium mr-4 px-4 py-2 rounded-md hover:bg-gray-100 transition-colors duration-150">
                    Cancel
                </a>
                <button type="submit"
                        class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-150">
                    Create Post
                </button>
            </div>
        </form>
    </div>
</div>
