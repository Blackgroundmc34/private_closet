<?php
// File: app/Views/posts/show_content.php

// Ensure essential variables from controller are available and default them
$app_url = $app_url ?? (defined('APP_URL') ? rtrim(APP_URL, '/') : '');
$post = $post ?? null; // This will be an array with post details
$comments = $comments ?? []; // This will be an array of comment arrays
$loggedInUserId = $loggedInUserId ?? null; // Integer or null
$isLoggedIn = (bool)$loggedInUserId;

// Default avatar logic (assuming $default_avatar_path is relative to public, e.g., 'assets/images/default_avatar.png')
$default_avatar_path = $default_avatar_path ?? (defined('DEFAULT_AVATAR_PATH') ? DEFAULT_AVATAR_PATH : 'assets/images/default_avatar.png');
$default_avatar_full_url = $app_url . '/' . ltrim(htmlspecialchars($default_avatar_path), '/');

$flashMessage = $flashMessage ?? null; // Passed from controller

// time_ago_post_show function - ensure it's either here or loaded globally
if (!function_exists('time_ago_post_show')) {
    function time_ago_post_show($datetime, $full = false) {
        if (!$datetime) return "N/A";
        try {
            $appTimeZone = new DateTimeZone(date_default_timezone_get()); // Use app's timezone
            $now = new DateTime('now', $appTimeZone);
            $ago = new DateTime($datetime, $appTimeZone);
            $diff = $now->diff($ago);

            if ($diff->y > 0) return $diff->y . ' year' . ($diff->y > 1 ? 's' : '') . ' ago';
            if ($diff->m > 0) return $diff->m . ' month' . ($diff->m > 1 ? 's' : '') . ' ago';
            if ($diff->d >= 7) { $w = floor($diff->d / 7); return $w . ' week' . ($w > 1 ? 's' : '') . ' ago'; }
            if ($diff->d > 0) return $diff->d . ' day' . ($diff->d > 1 ? 's' : '') . ' ago';
            if ($diff->h > 0) return $diff->h . ' hour' . ($diff->h > 1 ? 's' : '') . ' ago';
            if ($diff->i > 0) return $diff->i . ' minute' . ($diff->i > 1 ? 's' : '') . ' ago';
            if ($diff->s > 30) return $diff->s . ' second' . ($diff->s > 1 ? 's' : '') . ' ago';
            return 'just now';
        } catch (Exception $e) {
            error_log("Error in time_ago_post_show (View): " . $e->getMessage() . " for datetime: " . $datetime);
            return $datetime; // Fallback
        }
    }
}


if (!$post || !isset($post['id'])) {
    echo "<div class='container mx-auto px-4 py-8'><p class='text-center text-red-500'>Post not found or could not be loaded.</p></div>";
    return; // Stop further rendering of this view part
}

// Prepare post variables safely from the $post array
$post_id = (int)$post['id'];
$author_username = escape_html($post['author_username'] ?? 'Unknown User');
$author_profile_pic_path = $post['author_profile_pic'] ?? null;
$author_profile_pic_full_url = $author_profile_pic_path ? ($app_url . '/' . ltrim(escape_html($author_profile_pic_path), '/')) : $default_avatar_full_url;

$post_description_raw = $post['description'] ?? '';
$post_description_html = nl2br(escape_html($post_description_raw)); // For display
$post_location = escape_html($post['location'] ?? '');
$post_media_url_path = $post['media_url'] ?? '';
$post_media_full_url = $post_media_url_path ? ($app_url . '/' . ltrim(escape_html($post_media_url_path), '/')) : '';
$post_media_type = $post['media_type'] ?? '';
$post_created_at = time_ago_post_show($post['created_at'] ?? '');

$like_count = (int)($post['like_count'] ?? 0);
$comment_count = (int)($post['comment_count'] ?? 0);
$isPostAuthor = ($loggedInUserId && isset($post['user_id']) && $loggedInUserId === (int)$post['user_id']);
$isLikedByUser = isset($post['is_liked_by_user']) ? (bool)$post['is_liked_by_user'] : false; // This should come from controller
$allow_comments_on_post = isset($post['allow_comments']) ? (bool)$post['allow_comments'] : true;

$post_url = $app_url . '/post/' . $post_id; // For sharing
$share_title = "Check out this post by " . $author_username;
$share_text_raw = strip_tags($post_description_raw);
$share_text = escape_html(substr($share_text_raw, 0, 150)) . (strlen($share_text_raw) > 150 ? '...' : '');

?>
<div class="container mx-auto px-4 py-8 max-w-2xl">

    <div id="dynamic-flash-message-container" class="mb-4">
        <?php if ($flashMessage && is_array($flashMessage) && isset($flashMessage['text'])): ?>
            <div class="p-3 rounded-md <?php echo ($flashMessage['type'] === 'success' ? 'bg-green-100 text-green-700' : ($flashMessage['type'] === 'error' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700')); ?>">
                <?php echo escape_html($flashMessage['text']); ?>
            </div>
        <?php endif; ?>
    </div>


    <article class="bg-white shadow-xl rounded-lg overflow-hidden">
        <div class="p-4 border-b border-gray-200">
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <a href="<?php echo escape_html($app_url . '/profile/' . $author_username); ?>">
                        <img class="h-12 w-12 rounded-full object-cover mr-4 border border-gray-300"
                             src="<?php echo escape_html($author_profile_pic_full_url); ?>"
                             alt="<?php echo $author_username; ?>'s profile picture"
                             onerror="this.onerror=null; this.src='<?php echo escape_html($default_avatar_full_url); ?>';">
                    </a>
                    <div>
                        <a href="<?php echo escape_html($app_url . '/profile/' . $author_username); ?>" class="font-semibold text-lg text-gray-800 hover:underline">
                            <?php echo $author_username; ?>
                        </a>
                        <p class="text-sm text-gray-500">
                            Posted <?php echo $post_created_at; ?>
                            <?php if ($post_location): ?>
                                <span class="text-gray-400 mx-1">&bull;</span>
                                <i class="fas fa-map-marker-alt text-xs"></i> <?php echo $post_location; ?>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
                <?php if ($isPostAuthor): ?>
                <div class="relative" x-data="{ open: false }"> <button @click="open = !open" class="text-gray-500 hover:text-gray-700 focus:outline-none p-2">
                        <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <div x-show="open" @click.away="open = false"
                         x-transition:enter="transition ease-out duration-100" x-transition:enter-start="transform opacity-0 scale-95" x-transition:enter-end="transform opacity-100 scale-100"
                         x-transition:leave="transition ease-in duration-75" x-transition:leave-start="transform opacity-100 scale-100" x-transition:leave-end="transform opacity-0 scale-95"
                         class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-20 origin-top-right" style="display: none;">
                        <a href="<?php echo escape_html($app_url . '/post/' . $post_id . '/edit'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"><i class="fas fa-edit mr-2 w-4"></i>Edit Post</a>
                        <form action="<?php echo escape_html($app_url . '/post/' . $post_id . '/delete'); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this post? This cannot be undone.');">
                             <button type="submit" class="w-full text-left block px-4 py-2 text-sm text-red-600 hover:bg-red-50 hover:text-red-700"><i class="fas fa-trash-alt mr-2 w-4"></i>Delete Post</button>
                        </form>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($post_media_full_url): ?>
            <div class="bg-gray-100">
                <?php if ($post_media_type === 'image'): ?>
                    <img class="w-full object-contain max-h-[70vh]" src="<?php echo escape_html($post_media_full_url); ?>" alt="Post content by <?php echo $author_username; ?>" onerror="this.style.display='none'; this.parentElement.innerHTML = '<div class=\'text-center p-4 text-red-500\'>Image failed to load.</div>';">
                <?php elseif ($post_media_type === 'video'): ?>
                    <video controls class="w-full max-h-[70vh] bg-black">
                        <source src="<?php echo escape_html($post_media_full_url); ?>" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if ($post_description_raw): ?>
            <div class="p-4 md:p-6">
                <p class="text-gray-700 text-base leading-relaxed whitespace-pre-wrap"><?php echo $post_description_html; ?></p>
            </div>
        <?php endif; ?>

        <div class="p-4 border-t border-gray-200">
            <div class="flex items-center space-x-4 sm:space-x-6 text-gray-600">
                <button type="button" title="<?php echo $isLikedByUser ? 'Unlike' : 'Like'; ?>"
                        data-post-id="<?php echo $post_id; ?>"
                        id="likeButton-<?php echo $post_id; ?>"
                        class="like-button flex items-center focus:outline-none text-sm p-1 rounded-md <?php echo $isLikedByUser ? 'text-red-500' : 'text-gray-600 hover:text-red-500'; ?> hover:bg-gray-100">
                    <i class="<?php echo $isLikedByUser ? 'fas' : 'far'; ?> fa-heart mr-1 text-lg"></i>
                    <span class="like-count" id="likeCount-<?php echo $post_id; ?>"><?php echo $like_count; ?></span>
                    <span class="ml-1 hidden sm:inline">Likes</span>
                </button>

                <a href="#commentsSection-<?php echo $post_id; ?>" class="flex items-center hover:text-indigo-600 text-sm p-1 rounded-md hover:bg-gray-100">
                    <i class="far fa-comment mr-1 text-lg"></i>
                    <span class="comment-count" id="commentCountDisplay-<?php echo $post_id; ?>"><?php echo $comment_count; ?></span>
                    <span class="ml-1 hidden sm:inline">Comments</span>
                </a>

                <button id="shareButton" data-url="<?php echo escape_html($post_url); ?>" data-title="<?php echo escape_html($share_title); ?>" data-text="<?php echo escape_html($share_text); ?>"
                        class="flex items-center hover:text-blue-500 focus:outline-none text-sm p-1 rounded-md hover:bg-gray-100">
                    <i class="fas fa-share-alt mr-1 text-lg"></i>
                    <span class="hidden sm:inline">Share</span>
                </button>
            </div>
        </div>

        <div id="commentsSection-<?php echo $post_id; ?>" class="p-4 md:p-6 border-t border-gray-200">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Comments (<span class="comment-count" id="commentCountHeader-<?php echo $post_id; ?>"><?php echo $comment_count; ?></span>)</h3>

            <?php if ($allow_comments_on_post): ?>
                <?php if ($isLoggedIn): ?>
                    <form id="commentForm-<?php echo $post_id; ?>" class="mb-6 comment-form">
                        <input type="hidden" name="post_id" value="<?php echo $post_id; ?>">
                        <textarea name="comment_text" rows="3" required
                                  class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 placeholder-gray-400"
                                  placeholder="Write a comment..."></textarea>
                        <div class="mt-2 text-right">
                            <button type="submit"
                                    class="comment-submit-button px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                Post Comment
                            </button>
                        </div>
                        <p class="comment-error-message text-red-500 text-sm mt-2 hidden"></p>
                    </form>
                <?php else: ?>
                    <p class="mb-6 text-sm text-gray-600">
                        Please <a href="<?php echo escape_html($app_url . '/login?redirect_to=' . urlencode($post_url . '#commentsSection-' . $post_id)); ?>" class="text-indigo-600 hover:underline font-semibold">log in</a>
                        or <a href="<?php echo escape_html($app_url . '/register'); ?>" class="text-indigo-600 hover:underline font-semibold">register</a> to comment.
                    </p>
                <?php endif; ?>
            <?php else: ?>
                <p class="mb-6 text-sm text-gray-500">Comments are currently disabled for this post.</p>
            <?php endif; ?>

            <div class="space-y-4 comments-list" id="commentsList-<?php echo $post_id; ?>">
                <?php if (empty($comments)): ?>
                    <?php if ($allow_comments_on_post): ?>
                        <p class="no-comments-yet text-gray-500 text-sm">No comments yet. Be the first to comment!</p>
                    <?php endif; ?>
                <?php else: ?>
                    <?php foreach ($comments as $comment):
                        $comment_id = (int)($comment['comment_id'] ?? $comment['id'] ?? 0); // Adapt to your comment data structure
                        $commenter_username = escape_html($comment['commenter_username'] ?? $comment['username'] ?? 'User');
                        $commenter_profile_pic_rel = $comment['commenter_profile_pic'] ?? $comment['profile_picture_url'] ?? null;
                        $commenter_pic_url = $commenter_profile_pic_rel ? ($app_url . '/' . ltrim(escape_html($commenter_profile_pic_rel), '/')) : $default_avatar_full_url;
                        $comment_text = nl2br(escape_html($comment['comment_text'] ?? $comment['text'] ?? ''));
                        $comment_created = time_ago_post_show($comment['created_at'] ?? '');
                        $commenter_url = escape_html($app_url . '/profile/' . $commenter_username);
                    ?>
                        <div class="flex items-start space-x-3 comment-item py-2 border-b border-gray-100 last:border-b-0" id="comment-<?php echo $comment_id; ?>" data-comment-id="<?php echo $comment_id; ?>">
                            <a href="<?php echo $commenter_url; ?>">
                                <img class="h-10 w-10 rounded-full object-cover" src="<?php echo escape_html($commenter_pic_url); ?>" alt="<?php echo $commenter_username; ?>" onerror="this.onerror=null; this.src='<?php echo escape_html($default_avatar_full_url); ?>';">
                            </a>
                            <div class="flex-1">
                                <div class="bg-gray-50 p-3 rounded-lg rounded-tl-none">
                                    <div class="flex items-center justify-between">
                                        <a href="<?php echo $commenter_url; ?>" class="text-sm font-semibold text-gray-900 hover:underline">
                                            <?php echo $commenter_username; ?>
                                        </a>
                                        <p class="text-xs text-gray-500"><?php echo $comment_created; ?></p>
                                    </div>
                                    <p class="text-sm text-gray-700 mt-1"><?php echo $comment_text; ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </article>

    <div id="fallbackShareModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center" style="display: none; z-index: 50;">
        <div class="bg-white p-5 rounded-lg shadow-xl w-11/12 md:max-w-md mx-auto">
            <div class="flex justify-between items-center mb-4">
                <h4 class="text-lg font-semibold">Share this post</h4>
                <button id="closeShareModal" class="text-gray-700 hover:text-red-500 text-2xl">&times;</button>
            </div>
            <p class="mb-2 text-sm">Copy the link below to share:</p>
            <input type="text" id="shareLinkInput" value="<?php echo escape_html($post_url); ?>" readonly class="w-full p-2 border border-gray-300 rounded-md bg-gray-50 mb-3">
            <button id="copyLinkButton" class="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-md">Copy Link</button>
            <p id="copyStatus" class="text-sm text-green-600 mt-2 text-center"></p>
        </div>
    </div>
</div>

<script type="text/javascript">
document.addEventListener('DOMContentLoaded', function() {
    const appUrl = <?php echo json_encode($app_url); ?>;
    const currentPostId = <?php echo json_encode($post_id); ?>;
    const loggedInUserId = <?php echo json_encode($loggedInUserId); ?>; // Used to check if user can interact
    const defaultAvatarUrl = <?php echo json_encode($default_avatar_full_url); ?>;

    console.log('Post Show JS Initialized. Post ID:', currentPostId, 'App URL:', appUrl, 'User ID:', loggedInUserId);

    function escapeHtmlJS(unsafe) {
        if (unsafe === null || typeof unsafe === 'undefined') return '';
        return String(unsafe).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }

    function timeAgoJS(datetimeStr) { // Simplified JS version of time_ago
        if (!datetimeStr) return "N/A";
        try {
            const date = new Date(datetimeStr.replace(' ', 'T')+'Z'); // Assume UTC if no TZ specified
            const now = new Date();
            const seconds = Math.round((now - date) / 1000);

            if (seconds < 30) return 'just now';
            const minutes = Math.round(seconds / 60);
            if (minutes < 60) return minutes + ' minute' + (minutes > 1 ? 's' : '') + ' ago';
            const hours = Math.round(minutes / 60);
            if (hours < 24) return hours + ' hour' + (hours > 1 ? 's' : '') + ' ago';
            const days = Math.round(hours / 24);
            if (days < 7) return days + ' day' + (days > 1 ? 's' : '') + ' ago';
            const weeks = Math.round(days / 7);
            return weeks + ' week' + (weeks > 1 ? 's' : '') + ' ago'; // Simplified further
        } catch (e) { return datetimeStr; }
    }


    // --- Flash Message Handling ---
    const dynamicFlashMessageContainer = document.getElementById('dynamic-flash-message-container');
    function showDynamicFlashMessage(message, type = 'info') {
        if (!dynamicFlashMessageContainer) return;
        let bgColor = 'bg-blue-100 text-blue-700';
        if (type === 'success') bgColor = 'bg-green-100 text-green-700';
        if (type === 'error') bgColor = 'bg-red-100 text-red-700';

        const messageDiv = document.createElement('div');
        messageDiv.className = `p-3 rounded-md mb-2 ${bgColor}`;
        messageDiv.textContent = escapeHtmlJS(message);
        dynamicFlashMessageContainer.prepend(messageDiv); // Add new messages at the top

        setTimeout(() => {
            messageDiv.style.transition = 'opacity 0.5s ease';
            messageDiv.style.opacity = '0';
            setTimeout(() => messageDiv.remove(), 500);
        }, 5000);
    }
    // Auto-hide initial PHP flash message
    const initialFlash = dynamicFlashMessageContainer.querySelector('div[class*="bg-"]');
    if (initialFlash) {
        setTimeout(() => {
            initialFlash.style.transition = 'opacity 0.5s ease';
            initialFlash.style.opacity = '0';
            setTimeout(() => initialFlash.remove(), 500);
        }, 5000);
    }


    // --- Share Button Logic (from your existing script) ---
    const shareButton = document.getElementById('shareButton');
    const fallbackModal = document.getElementById('fallbackShareModal');
    const closeButton = document.getElementById('closeShareModal');
    const shareLinkInput = document.getElementById('shareLinkInput');
    const copyLinkButton = document.getElementById('copyLinkButton');
    const copyStatus = document.getElementById('copyStatus');

    if (shareButton) {
        shareButton.addEventListener('click', async () => { /* ... your existing share logic ... */ });
    }
    // ... rest of your existing share modal event listeners ...


    // --- AJAX for Like Button ---
    const likeButton = document.getElementById(`likeButton-${currentPostId}`);
    if (likeButton) {
        likeButton.addEventListener('click', async (e) => {
            e.preventDefault();
            if (!loggedInUserId) {
                showDynamicFlashMessage('Please log in to like posts.', 'error');
                // Optionally redirect to login: window.location.href = `${appUrl}/login?redirect_to=${encodeURIComponent(window.location.href)}`;
                return;
            }

            likeButton.disabled = true;
            likeButton.classList.add('opacity-50');

            const heartIcon = likeButton.querySelector('i');
            const likeCountSpan = likeButton.querySelector('.like-count');

            try {
                // Note: The route defined in your index.php was /post/{id}/toggle-like
                // The JS in the original file had /toggle-like-ajax. Let's align with index.php if it's simpler.
                // For now, assuming you'll add '-ajax' to the route or remove it from here.
                // Using /post/{id}/toggle-like as per your index.php
                const response = await fetch(`${appUrl}/post/${currentPostId}/toggle-like`, { // Ensure this route is POST in index.php
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json', // Server should expect JSON if you send it
                        'X-Requested-With': 'XMLHttpRequest' // Common practice for AJAX
                        // Add CSRF token header if needed
                    },
                    // body: JSON.stringify({}) // Send empty JSON body if backend expects JSON, or remove if not needed
                });

                if (!response.ok) {
                    const errorData = await response.json().catch(() => ({ message: `HTTP error ${response.status}` }));
                    throw new Error(errorData.message || `HTTP error ${response.status}`);
                }
                const data = await response.json();

                if (data.success) {
                    likeCountSpan.textContent = data.like_count;
                    if (data.liked) {
                        heartIcon.classList.remove('far'); // from Font Awesome Free (empty heart)
                        heartIcon.classList.add('fas');   // to Font Awesome Solid (filled heart)
                        likeButton.classList.add('text-red-500');
                        likeButton.classList.remove('text-gray-600', 'hover:text-red-500');
                    } else {
                        heartIcon.classList.remove('fas');
                        heartIcon.classList.add('far');
                        likeButton.classList.remove('text-red-500');
                        likeButton.classList.add('text-gray-600', 'hover:text-red-500');
                    }
                    // showDynamicFlashMessage(data.message || (data.liked ? 'Post liked!' : 'Post unliked!'), 'success');
                } else {
                    showDynamicFlashMessage(data.message || 'Failed to update like status.', 'error');
                }
            } catch (error) {
                console.error('Error toggling like:', error);
                showDynamicFlashMessage(`Error: ${error.message || 'Could not update like.'}`, 'error');
            } finally {
                likeButton.disabled = false;
                likeButton.classList.remove('opacity-50');
            }
        });
    }


    // --- AJAX for Comment Form ---
    const commentForm = document.getElementById(`commentForm-${currentPostId}`);
    if (commentForm && loggedInUserId) { // Only attach if form exists and user is logged in
        const textarea = commentForm.querySelector('textarea[name="comment_text"]');
        const submitButton = commentForm.querySelector('.comment-submit-button');
        const errorMessageP = commentForm.querySelector('.comment-error-message');
        const commentsListDiv = document.getElementById(`commentsList-${currentPostId}`);
        const commentCountSpans = document.querySelectorAll(`.comment-count`); // Select all elements that show comment count

        commentForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const commentText = textarea.value.trim();

            if (!commentText) {
                errorMessageP.textContent = 'Comment cannot be empty.';
                errorMessageP.classList.remove('hidden');
                return;
            }
             if (commentText.length > 1000) { // Example max length
                errorMessageP.textContent = 'Comment is too long (max 1000 characters).';
                errorMessageP.classList.remove('hidden');
                return;
            }

            submitButton.disabled = true;
            submitButton.textContent = 'Posting...';
            errorMessageP.classList.add('hidden');
            errorMessageP.textContent = '';


            try {
                // Note: Your index.php has /post/{id}/add-comment.
                // The original JS had /add-comment-ajax. We'll use the one from index.php.
                const response = await fetch(`${appUrl}/post/${currentPostId}/add-comment`, { // Ensure this route is POST in index.php
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                        // Add CSRF token header if needed
                    },
                    body: JSON.stringify({ comment_text: commentText }) // Send comment text as JSON
                });

                if (!response.ok) {
                    const errorData = await response.json().catch(() => ({ message: `HTTP error ${response.status}` }));
                    throw new Error(errorData.message || `HTTP error ${response.status}`);
                }
                const data = await response.json();

                if (data.success && data.comment) {
                    const comment = data.comment; // Server should return new comment data

                    // Remove "No comments yet" placeholder if it exists
                    const noCommentsYet = commentsListDiv.querySelector('.no-comments-yet');
                    if (noCommentsYet) noCommentsYet.remove();

                    // Create new comment HTML
                    const newCommentHtml = `
                        <div class="flex items-start space-x-3 comment-item py-2 border-b border-gray-100 last:border-b-0" id="comment-${comment.comment_id}" data-comment-id="${comment.comment_id}">
                            <a href="${escapeHtmlJS(appUrl)}/profile/${escapeHtmlJS(comment.commenter_username || 'user')}">
                                <img class="h-10 w-10 rounded-full object-cover"
                                     src="${escapeHtmlJS(comment.commenter_profile_pic || defaultAvatarUrl)}"
                                     alt="${escapeHtmlJS(comment.commenter_username || 'User')}"
                                     onerror="this.onerror=null; this.src='${escapeHtmlJS(defaultAvatarUrl)}';">
                            </a>
                            <div class="flex-1">
                                <div class="bg-gray-50 p-3 rounded-lg rounded-tl-none">
                                    <div class="flex items-center justify-between">
                                        <a href="${escapeHtmlJS(appUrl)}/profile/${escapeHtmlJS(comment.commenter_username || 'user')}" class="text-sm font-semibold text-gray-900 hover:underline">
                                            ${escapeHtmlJS(comment.commenter_username || 'User')}
                                        </a>
                                        <p class="text-xs text-gray-500">${timeAgoJS(comment.created_at)}</p>
                                    </div>
                                    <p class="text-sm text-gray-700 mt-1">${comment.comment_text.replace(/\n/g, '<br>')}</p>
                                </div>
                            </div>
                        </div>`;
                    commentsListDiv.insertAdjacentHTML('beforeend', newCommentHtml); // Add to end of list
                    textarea.value = ''; // Clear textarea

                    // Update all comment count displays
                    commentCountSpans.forEach(span => {
                        span.textContent = parseInt(span.textContent || 0) + 1;
                    });
                    // showDynamicFlashMessage('Comment posted!', 'success'); // Optional direct feedback
                } else {
                    errorMessageP.textContent = data.message || 'Failed to add comment. Please try again.';
                    errorMessageP.classList.remove('hidden');
                }
            } catch (error) {
                console.error('Error adding comment:', error);
                errorMessageP.textContent = `Error: ${error.message || 'Could not post comment.'}`;
                errorMessageP.classList.remove('hidden');
            } finally {
                submitButton.disabled = false;
                submitButton.textContent = 'Post Comment';
            }
        });
    }

});
</script>
