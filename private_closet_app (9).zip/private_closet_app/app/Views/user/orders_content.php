<?php
// File: app/Views/user/orders_content.php

$profileUser = $profileUser ?? ['username' => 'User', 'id' => null];
$orders = $orders ?? [];
$app_url = $app_url ?? (defined('APP_URL') ? APP_URL : '');
$pageTitle = $pageTitle ?? 'My Orders';
$csrf_token = $csrf_token ?? ($_SESSION['csrf_token'] ?? '');

if (!function_exists('escape_html')) {
    function escape_html($string) { return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
if (!function_exists('format_price')) {
    function format_price($price, string $currencySymbol = 'R'): string {
        if (!is_numeric($price)) $price = 0.00;
        return $currencySymbol . number_format((float)$price, 2, '.', ',');
    }
}
if (!function_exists('format_order_date')) {
    function format_order_date($datetimeStr) {
        if (!$datetimeStr) return 'N/A';
        try {
            $date = new DateTime($datetimeStr);
            return $date->format('M j, Y - g:i A');
        } catch (Exception $e) {
            error_log("Error formatting date in orders_content.php: {$datetimeStr} - " . $e->getMessage());
            return 'Invalid Date';
        }
    }
}

$flashMessage = $_SESSION['flash_message'] ?? null;
if (isset($_SESSION['flash_message'])) unset($_SESSION['flash_message']);
?>

<div class="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div class="flex flex-col sm:flex-row justify-between items-center mb-6 pb-4 border-b border-gray-200">
        <h1 class="text-2xl md:text-3xl font-bold text-gray-800">
            <i class="fas fa-receipt mr-2 text-indigo-600"></i>My Orders
        </h1>
        <a href="<?php echo htmlspecialchars($app_url . '/profile/' . urlencode($profileUser['username'])); ?>" class="text-sm text-indigo-600 hover:text-indigo-800 hover:underline mt-2 sm:mt-0">
            <i class="fas fa-arrow-left mr-1"></i> Back to Profile
        </a>
    </div>

    <?php if ($flashMessage && is_array($flashMessage) && isset($flashMessage['text'])): ?>
        <div class="mb-6 p-4 rounded-md text-sm
            <?php echo ($flashMessage['type'] === 'success' ? 'bg-green-100 text-green-700 border border-green-300' :
                        ($flashMessage['type'] === 'error' ? 'bg-red-100 text-red-700 border border-red-300' :
                                                            'bg-blue-100 text-blue-700 border border-blue-300')); ?>">
            <strong class="font-semibold"><?php echo ucfirst(escape_html($flashMessage['type'])); ?>!</strong>
            <?php echo escape_html($flashMessage['text']); ?>
        </div>
    <?php endif; ?>

    <?php if (empty($orders)): ?>
        <div class="bg-white p-8 rounded-lg shadow-md text-center">
            <i class="fas fa-box-open fa-4x text-gray-300 mb-4"></i>
            <p class="text-gray-600 text-xl mb-2">No Orders Yet!</p>
            <p class="text-gray-500 mb-6">You haven't placed any orders. When you do, they'll appear here.</p>
            <a href="<?php echo htmlspecialchars($app_url); ?>/showroom" class="inline-block px-6 py-3 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-150">
                <i class="fas fa-shopping-bag mr-2"></i>Start Shopping
            </a>
        </div>
    <?php else: ?>
        <div class="bg-white shadow-xl rounded-lg overflow-hidden">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-100">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Order ID</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date Placed</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Amount</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden sm:table-cell">Items</th>
                            <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($orders as $order): ?>
                            <?php
                                // Use $order['id'] for the actual ID value from the database
                                $actual_order_id = $order['id'] ?? 0; // Get the actual ID for links
                                $order_id_display = '#' . escape_html($actual_order_id); // Displayed ID
                                $order_date = format_order_date($order['created_at'] ?? '');
                                $order_total = format_price($order['total_amount'] ?? 0);
                                $order_status_raw = strtolower($order['status'] ?? 'unknown');
                                $order_status_display = escape_html(ucfirst(str_replace('_', ' ', $order_status_raw)));
                                $item_summary_text = !empty($order['product_summary']) ? escape_html($order['product_summary']) : (isset($order['item_count']) ? (int)$order['item_count'] . ' items' : '0 items');
                                
                                $statusClass = 'bg-gray-200 text-gray-800'; // Default
                                switch ($order_status_raw) {
                                    case 'processing': $statusClass = 'bg-blue-100 text-blue-800'; break;
                                    case 'awaiting_payment': case 'on-hold': case 'pending_payment': $statusClass = 'bg-yellow-100 text-yellow-800'; break;
                                    case 'completed': case 'delivered': $statusClass = 'bg-green-100 text-green-800'; break;
                                    case 'shipped': $statusClass = 'bg-purple-100 text-purple-800'; break;
                                    case 'cancelled': case 'refunded': $statusClass = 'bg-red-100 text-red-800'; break;
                                }
                            ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-indigo-600">
                                    <a href="<?php echo htmlspecialchars($app_url . '/order/detail/' . $actual_order_id); ?>" class="hover:underline" title="View Order Details #<?php echo $actual_order_id; ?>">
                                        <?php echo $order_id_display; ?>
                                    </a>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo $order_date; ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-semibold"><?php echo $order_total; ?></td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2.5 py-1 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $statusClass; ?>">
                                        <?php echo $order_status_display; ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 truncate max-w-xs hidden sm:table-cell" title="<?php echo escape_html($order['product_summary'] ?? ''); ?>">
                                    <?php echo $item_summary_text; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-center text-sm font-medium">
                                    <a href="<?php echo htmlspecialchars($app_url . '/order/detail/' . $actual_order_id); ?>" class="text-indigo-600 hover:text-indigo-800 mr-3" title="View Order Details #<?php echo $actual_order_id; ?>">
                                        <i class="fas fa-eye"></i> <span class="hidden sm:inline">View</span>
                                    </a>
                                    <?php if (in_array($order_status_raw, ['awaiting_payment', 'pending_payment'])): ?>
                                        <a href="<?php echo htmlspecialchars($app_url . '/order/pay/' . $actual_order_id); ?>" class="text-green-600 hover:text-green-800 mr-3" title="Make Payment for Order #<?php echo $actual_order_id; ?>">
                                            <i class="fas fa-credit-card"></i> <span class="hidden sm:inline">Pay</span>
                                        </a>
                                    <?php endif; ?>
                                    <?php if (in_array($order_status_raw, ['shipped', 'processing', 'delivered'])): ?>
                                         <a href="<?php echo htmlspecialchars($app_url . '/order/track/' . $actual_order_id); ?>" class="text-blue-600 hover:text-blue-800" title="Track Order #<?php echo $actual_order_id; ?>">
                                            <i class="fas fa-truck"></i> <span class="hidden sm:inline">Track</span>
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php // Add pagination if you implement it in OrderModel and UserController for orders ?>
        <?php if (isset($totalPages) && $totalPages > 1 && isset($currentPage)): ?>
        <div class="mt-6 flex justify-center">
            <nav aria-label="Page navigation">
              <ul class="inline-flex items-center -space-x-px">
                <li>
                  <a href="<?php echo ($currentPage <= 1) ? 'javascript:void(0);' : htmlspecialchars($app_url . '/profile/' . urlencode($profileUser['username']) . '/orders?page=' . ($currentPage - 1)); ?>"
                     class="py-2 px-3 ml-0 leading-tight text-gray-500 bg-white rounded-l-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 <?php echo ($currentPage <= 1) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                     <i class="fas fa-chevron-left mr-1 text-xs"></i> Previous
                  </a>
                </li>
                <?php
                    $startPage = max(1, $currentPage - 2);
                    $endPage = min($totalPages, $currentPage + 2);
                    // Adjust window if near start/end
                    if ($currentPage <= 3) $endPage = min($totalPages, 5);
                    if ($currentPage > $totalPages - 3) $startPage = max(1, $totalPages - 4);

                    if ($startPage > 1) {
                        echo '<li><a href="' . htmlspecialchars($app_url . '/profile/' . urlencode($profileUser['username']) . '/orders?page=1') . '" class="py-2 px-3 leading-tight border border-gray-300 text-gray-500 bg-white hover:bg-gray-100 hover:text-gray-700">1</a></li>';
                        if ($startPage > 2) echo '<li><span class="py-2 px-3 leading-tight border border-gray-300 text-gray-500 bg-white">...</span></li>';
                    }

                    for ($i = $startPage; $i <= $endPage; $i++):
                ?>
                    <li>
                      <a href="<?php echo htmlspecialchars($app_url . '/profile/' . urlencode($profileUser['username']) . '/orders?page=' . $i); ?>"
                         class="py-2 px-3 leading-tight border border-gray-300 <?php echo ($i == $currentPage) ? 'text-indigo-600 bg-indigo-50 hover:bg-indigo-100 hover:text-indigo-700 z-10 ring-1 ring-indigo-500' : 'text-gray-500 bg-white hover:bg-gray-100 hover:text-gray-700'; ?>">
                         <?php echo $i; ?>
                      </a>
                    </li>
                <?php endfor;

                    if ($endPage < $totalPages) {
                        if ($endPage < $totalPages - 1) echo '<li><span class="py-2 px-3 leading-tight border border-gray-300 text-gray-500 bg-white">...</span></li>';
                        echo '<li><a href="' . htmlspecialchars($app_url . '/profile/' . urlencode($profileUser['username']) . '/orders?page=' . $totalPages) . '" class="py-2 px-3 leading-tight border border-gray-300 text-gray-500 bg-white hover:bg-gray-100 hover:text-gray-700">' . $totalPages . '</a></li>';
                    }
                ?>
                <li>
                  <a href="<?php echo ($currentPage >= $totalPages) ? 'javascript:void(0);' : htmlspecialchars($app_url . '/profile/' . urlencode($profileUser['username']) . '/orders?page=' . ($currentPage + 1)); ?>"
                     class="py-2 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 <?php echo ($currentPage >= $totalPages) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                     Next <i class="fas fa-chevron-right ml-1 text-xs"></i>
                  </a>
                </li>
              </ul>
            </nav>
        </div>
        <?php endif; ?>

    <?php endif; ?>
</div>