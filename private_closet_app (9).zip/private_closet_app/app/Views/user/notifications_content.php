<?php
// File: app/Views/user/notifications_content.php
// Purpose: Displays user notifications.
// Expected variables: $notifications (array), $loggedInUserId (int), $app_url (string)

$app_url = $app_url ?? (defined('APP_URL') ? APP_URL : ''); // Ensure $app_url is defined
$notifications = $notifications ?? []; // Ensure $notifications is always an array
$csrf_token = $csrf_token ?? ($_SESSION['csrf_token'] ?? ''); // Ensure CSRF token is available

// Helper function to display time in a user-friendly format
if (!function_exists('time_ago_format_notifications')) { // Renamed to avoid potential global conflicts
    function time_ago_format_notifications($datetime, $full = false) {
        if (!$datetime) return "N/A";
        try {
            // Ensure the datetime string is parsed correctly, assuming UTC if no timezone is specified by DB
            // Or use the application's default timezone
            $appTimeZone = new DateTimeZone(date_default_timezone_get()); // Get current PHP timezone
            $ago = new DateTime($datetime, $appTimeZone); // Assume datetime from DB is in app's timezone
            $now = new DateTime('now', $appTimeZone);
            $diff = $now->diff($ago);

            // Calculate weeks separately, do not assign to $diff->w
            $weeks = 0;
            if ($diff->days !== false && $diff->days >= 7) { // Check if days is available (can be false)
                $weeks = floor($diff->days / 7);
            }
            // Calculate remaining days after full weeks are accounted for
            $days = ($diff->days !== false) ? $diff->days % 7 : 0;


            $stringUnits = [
                'y' => 'year', 'm' => 'month', 'w' => 'week', 'd' => 'day',
                'h' => 'hour', 'i' => 'minute', 's' => 'second',
            ];
            
            $parts = [];
            if ($diff->y) $parts[] = $diff->y . ' ' . $stringUnits['y'] . ($diff->y > 1 ? 's' : '');
            if ($diff->m) $parts[] = $diff->m . ' ' . $stringUnits['m'] . ($diff->m > 1 ? 's' : '');
            
            // Use the calculated $weeks variable
            if ($weeks) $parts[] = $weeks . ' ' . $stringUnits['w'] . ($weeks > 1 ? 's' : '');
            
            // Use the calculated remaining $days
            if ($days && ($full || $weeks == 0)) { // Show days if full view or no weeks shown yet
                 $parts[] = $days . ' ' . $stringUnits['d'] . ($days > 1 ? 's' : '');
            }


            // Only add time components if it's very recent or $full is true
            if ($full || empty($parts) || ($diff->y == 0 && $diff->m == 0 && $weeks == 0 && $days < 1) ) {
                if ($diff->h) $parts[] = $diff->h . ' ' . $stringUnits['h'] . ($diff->h > 1 ? 's' : '');
                if ($diff->i) $parts[] = $diff->i . ' ' . $stringUnits['i'] . ($diff->i > 1 ? 's' : '');
                if ($diff->s && count($parts) < 2) { // Show seconds only if it's very recent
                     $parts[] = $diff->s . ' ' . $stringUnits['s'] . ($diff->s > 1 ? 's' : '');
                }
            }
            
            if (!$full && count($parts) > 1) $parts = array_slice($parts, 0, 1); // Show only the largest unit if not $full & multiple parts exist
            
            return $parts ? implode(', ', $parts) . ' ago' : 'just now';

        } catch (Exception $e) {
            error_log("Error in time_ago_format_notifications (View): " . $e->getMessage() . " for datetime: " . $datetime);
            // Fallback if DateTime parsing fails
            return $datetime; 
        }
    }
}
?>
<div class="container mx-auto px-4 py-8 max-w-3xl">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Notifications</h1>
        <?php if (!empty($notifications)): ?>
            <form action="<?php echo htmlspecialchars($app_url . '/settings/notifications/mark-all-read'); ?>" method="POST" onsubmit="return confirm('Mark all notifications as read?');">
                 <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                 <button type="submit" class="text-sm text-indigo-600 hover:text-indigo-800 focus:outline-none">Mark all as read</button>
            </form>
        <?php endif; ?>
    </div>

    <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="mb-4 p-3 rounded-md <?php echo htmlspecialchars($_SESSION['flash_message']['type'] === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'); ?>">
            <?php echo htmlspecialchars($_SESSION['flash_message']['text']); ?>
        </div>
        <?php unset($_SESSION['flash_message']); ?>
    <?php endif; ?>

    <div class="bg-white shadow-md rounded-lg">
        <?php if (empty($notifications)): ?>
            <p class="p-6 text-center text-gray-500">You have no new notifications.</p>
        <?php else: ?>
            <ul class="divide-y divide-gray-200">
                <?php foreach ($notifications as $notification): ?>
                    <?php
                        // Ensure notification ID is properly escaped for HTML attributes
                        $notification_id_escaped = htmlspecialchars($notification['id'] ?? '');
                    ?>
                    <li class="p-4 <?php echo empty($notification['is_read']) ? 'bg-indigo-50 hover:bg-indigo-100' : 'hover:bg-gray-50'; ?>">
                        <div class="flex items-start space-x-3">
                            <div class="flex-shrink-0 pt-1">
                                <?php 
                                $icon_html = '<i class="fas fa-bell text-gray-400"></i>'; // Default
                                switch ($notification['type'] ?? '') {
                                    case 'new_follower':
                                        $icon_html = '<i class="fas fa-user-plus text-blue-500"></i>';
                                        break;
                                    case 'post_like':
                                        $icon_html = '<i class="fas fa-heart text-red-500"></i>';
                                        break;
                                    case 'new_comment':
                                        $icon_html = '<i class="fas fa-comment text-green-500"></i>';
                                        break;
                                    // Add more specific notification types and their icons
                                    // case 'order_shipped':
                                    //    $icon_html = '<i class="fas fa-truck text-purple-500"></i>';
                                    //    break;
                                }
                                ?>
                                <span class="text-xl"><?php echo $icon_html; ?></span>
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="text-sm text-gray-800 <?php echo empty($notification['is_read']) ? 'font-semibold' : ''; ?>">
                                    <?php echo htmlspecialchars($notification['message'] ?? 'Notification message missing.'); ?>
                                </p>
                                <p class="text-xs text-gray-500 mt-1">
                                    <?php echo time_ago_format_notifications($notification['created_at'] ?? ''); ?>
                                </p>
                                 
<?php if (!empty($notification['related_entity_type']) && !empty($notification['related_entity_id'])): ?>
    <?php
        $related_link = null;
        $link_text = 'View details';
        // CRITICAL: $related_entity_id_escaped IS THE USERNAME (or post ID, order ID etc.)
        $related_entity_id_escaped = htmlspecialchars($notification['related_entity_id']); 

        switch ($notification['related_entity_type']) {
            case 'user':
                // This line already assumes $related_entity_id_escaped is the username
                $related_link = $app_url . '/profile/' . $related_entity_id_escaped;
                $link_text = 'View Profile'; // More specific link text
                break;
            case 'post':
                $related_link = $app_url . '/post/' . $related_entity_id_escaped;
                $link_text = 'View Post'; // More specific link text
                break;
            case 'order':
                // Ensure your order links are correct, e.g., /order/detail/ID
                $related_link = $app_url . '/order/detail/' . $related_entity_id_escaped; 
                $link_text = 'View Order';
                break;
            // Add more entity types as needed
        }
    ?>
    <?php if ($related_link): ?>
    <div class="mt-1">
        <a href="<?php echo htmlspecialchars($related_link); ?>" class="text-xs text-indigo-600 hover:underline"><?php echo htmlspecialchars($link_text); ?> &rarr;</a>
    </div>
    <?php endif; ?>
<?php endif; ?>

                            </div>
                            <?php if (empty($notification['is_read'])): ?>
                                <div class="flex-shrink-0 self-center">
                                    <form action="<?php echo htmlspecialchars($app_url . '/settings/notifications/mark-read'); ?>" method="POST">
                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                        <input type="hidden" name="notification_id" value="<?php echo $notification_id_escaped; ?>">
                                        <button type="submit" title="Mark as read" class="text-xs text-indigo-500 hover:text-indigo-700 focus:outline-none p-1 rounded hover:bg-indigo-100">
                                            <i class="fas fa-check-circle mr-1"></i>Mark read
                                        </button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
    
    <?php if (!empty($notifications) && count($notifications) >= 20): // Basic pagination hint for fetching more ?>
        <div class="mt-6 text-center">
            <a href="<?php echo htmlspecialchars($app_url . '/settings/notifications?page=2'); // Implement proper pagination in controller ?>" 
               class="text-indigo-600 hover:text-indigo-800">
                View older notifications
            </a>
        </div>
    <?php endif; ?>
</div>
