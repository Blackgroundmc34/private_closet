<?php
// File: app/Views/user/settings_profile_content.php
// Purpose: Displays the form for editing user profile settings.
// Expected variables: $currentUser (array), $errors (array), $oldInput (array)

$app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
$currentUser = $currentUser ?? null;
$errors = $errors ?? [];
$oldInput = $oldInput ?? [];

// Function to get old input or current user data for a field
function get_field_value_settings(string $fieldName, array $oldData, ?array $currentUserData) {
    if (!empty($oldData[$fieldName])) {
        return htmlspecialchars($oldData[$fieldName]);
    }
    if ($currentUserData && isset($currentUserData[$fieldName])) {
        return htmlspecialchars($currentUserData[$fieldName]);
    }
    return '';
}

// Default avatar logic
$default_avatar_relative_path = defined('DEFAULT_AVATAR_PATH') ? DEFAULT_AVATAR_PATH : 'assets/images/default_avatar.png';
$default_avatar_full_url = $app_url . '/' . ltrim($default_avatar_relative_path, '/');

$current_profile_pic_url = $default_avatar_full_url;
if ($currentUser && !empty($currentUser['profile_picture_url'])) {
    $current_profile_pic_url = $app_url . '/' . ltrim(htmlspecialchars($currentUser['profile_picture_url']), '/');
}

// For displaying initial if no image
$username_initial = ($currentUser && !empty($currentUser['username'])) ? strtoupper(substr($currentUser['username'], 0, 1)) : '?';

?>
<div class="container mx-auto px-4 py-8 max-w-2xl">
    <h1 class="text-2xl font-bold mb-6 text-gray-800">Edit Profile</h1>

    <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="mb-4 p-3 rounded-md <?php echo $_SESSION['flash_message']['type'] === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
            <?php echo htmlspecialchars($_SESSION['flash_message']['text']); ?>
        </div>
        <?php unset($_SESSION['flash_message']); ?>
    <?php endif; ?>

    <?php if (!empty($errors['general'])): ?>
        <div class="mb-4 p-3 rounded-md bg-red-100 text-red-700">
            <?php echo htmlspecialchars($errors['general']); ?>
        </div>
    <?php endif; ?>

    <form action="<?php echo $app_url . '/settings/profile'; ?>" method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded-lg shadow-md">
        <div class="mb-6">
            <label class="block text-sm font-medium text-gray-700 mb-2">Profile Picture:</label>
            <div class="flex items-center">
                <?php if ($currentUser && !empty($currentUser['profile_picture_url'])): ?>
                    <img id="avatarPreview" class="h-20 w-20 rounded-full object-cover mr-4 border" src="<?php echo htmlspecialchars($current_profile_pic_url); ?>" alt="Current Avatar">
                <?php else: ?>
                    <div id="avatarPreview" class="h-20 w-20 rounded-full bg-indigo-500 text-white flex items-center justify-center text-3xl font-semibold mr-4 border">
                        <?php echo htmlspecialchars($username_initial); ?>
                    </div>
                <?php endif; ?>
                <input type="file" name="profile_picture" id="profile_picture" class="block w-full text-sm text-gray-500
                    file:mr-4 file:py-2 file:px-4
                    file:rounded-full file:border-0
                    file:text-sm file:font-semibold
                    file:bg-indigo-50 file:text-indigo-700
                    hover:file:bg-indigo-100"
                    onchange="previewAvatar(event)">
            </div>
            <?php if (isset($errors['profile_picture'])) echo '<p class="text-red-500 text-xs mt-1">' . htmlspecialchars($errors['profile_picture']) . '</p>'; ?>
        </div>


        <div class="mb-4">
            <label for="full_name" class="block text-sm font-medium text-gray-700 mb-1">Full Name:</label>
            <input type="text" name="full_name" id="full_name" 
                   value="<?php echo get_field_value_settings('full_name', $oldInput, $currentUser); ?>" required
                   class="w-full px-3 py-2 border <?php echo isset($errors['full_name']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
            <?php if (isset($errors['full_name'])) echo '<p class="text-red-500 text-xs mt-1">' . htmlspecialchars($errors['full_name']) . '</p>'; ?>
        </div>

        <div class="mb-4">
            <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email Address:</label>
            <input type="email" name="email" id="email"
                   value="<?php echo get_field_value_settings('email', $oldInput, $currentUser); ?>" required
                   class="w-full px-3 py-2 border <?php echo isset($errors['email']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
            <?php if (isset($errors['email'])) echo '<p class="text-red-500 text-xs mt-1">' . htmlspecialchars($errors['email']) . '</p>'; ?>
        </div>
        
        <div class="mb-4">
            <label for="username" class="block text-sm font-medium text-gray-700 mb-1">Username (cannot be changed):</label>
            <input type="text" name="username" id="username"
                   value="<?php echo get_field_value_settings('username', $oldInput, $currentUser); ?>" readonly
                   class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm bg-gray-100 text-gray-500">
        </div>


        <div class="mb-6">
            <label for="profile_bio" class="block text-sm font-medium text-gray-700 mb-1">Profile Bio:</label>
            <textarea name="profile_bio" id="profile_bio" rows="4"
                      class="w-full px-3 py-2 border <?php echo isset($errors['profile_bio']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                      placeholder="Tell us a bit about yourself..."><?php echo get_field_value_settings('profile_bio', $oldInput, $currentUser); ?></textarea>
            <?php if (isset($errors['profile_bio'])) echo '<p class="text-red-500 text-xs mt-1">' . htmlspecialchars($errors['profile_bio']) . '</p>'; ?>
        </div>

        <div>
            <button type="submit"
                    class="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 ease-in-out">
                Save Changes
            </button>
        </div>
    </form>
</div>
<script>
function previewAvatar(event) {
    const reader = new FileReader();
    reader.onload = function(){
        const output = document.getElementById('avatarPreview');
        if (output.tagName === 'IMG') {
            output.src = reader.result;
        } else { // It's the div for initial
            // Replace div with an img tag
            const img = document.createElement('img');
            img.id = 'avatarPreview';
            img.className = 'h-20 w-20 rounded-full object-cover mr-4 border';
            img.src = reader.result;
            img.alt = 'Avatar Preview';
            output.parentNode.replaceChild(img, output);
        }
    };
    if (event.target.files[0]) {
        reader.readAsDataURL(event.target.files[0]);
    }
}
</script>
