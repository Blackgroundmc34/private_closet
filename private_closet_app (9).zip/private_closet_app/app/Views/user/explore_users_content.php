<?php
// File: app/Views/user/explore_users_content.php
// Purpose: Displays a page to explore and find new users to follow.

// Expected variables from UserController::showExploreUsersPage():
// $usersToExplore (array) - List of user arrays to display. Each should have id, username, full_name, profile_picture_full_url, and a new 'is_followed_by_viewer' boolean.
// $currentPage (int) - Current page number for pagination.
// $totalPages (int) - Total pages for pagination.
// $app_url (string) - Base application URL.
// $csrf_token (string) - CSRF token for follow/unfollow forms.
// $loggedInUserId (int) - ID of the currently logged-in user.
// $default_avatar_full_url (string) - Default avatar URL.
// $flashMessage (array|null) - Flash messages.

$usersToExplore = $usersToExplore ?? [];
$currentPage = $currentPage ?? 1;
$totalPages = $totalPages ?? 1;
$app_url = $app_url ?? (defined('APP_URL') ? rtrim(APP_URL, '/') : '');
$csrf_token = $csrf_token ?? '';
$loggedInUserId = $loggedInUserId ?? null;
$default_avatar_full_url = $default_avatar_full_url ?? ($app_url . '/' . ltrim(defined('DEFAULT_AVATAR_PATH') ? DEFAULT_AVATAR_PATH : 'assets/images/default_avatar.png', '/'));
$flashMessage = $flashMessage ?? null;

if (!function_exists('escape_html')) {
    function escape_html($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
?>

<div class="container mx-auto px-4 py-8 max-w-4xl">
    <h1 class="text-2xl md:text-3xl font-bold text-gray-800 mb-6">
        <i class="fas fa-users mr-2 text-indigo-600"></i>Explore People
    </h1>

    <?php if ($flashMessage && isset($flashMessage['text'])): ?>
        <div class="mb-6 p-3 rounded-md <?php echo ($flashMessage['type'] ?? 'info') === 'success' ? 'bg-green-100 text-green-700' : (($flashMessage['type'] ?? 'info') === 'error' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'); ?>">
            <?php echo escape_html($flashMessage['text']); ?>
        </div>
    <?php endif; ?>

    <?php if (empty($usersToExplore)): ?>
        <div class="text-center py-10 bg-white p-6 rounded-lg shadow">
            <i class="fas fa-user-friends text-4xl text-gray-400 mb-4"></i>
            <p class="text-gray-600">No new users to explore at the moment, or you're following everyone!</p>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            <?php foreach ($usersToExplore as $user): ?>
                <?php
                    $userUsername = escape_html($user['username'] ?? 'user');
                    $userFullName = escape_html($user['full_name'] ?? '');
                    $userProfilePicFullUrl = escape_html($user['profile_picture_full_url'] ?? $default_avatar_full_url);
                    $isFollowedByViewer = (bool)($user['is_followed_by_viewer'] ?? false);
                ?>
                <div class="bg-white p-4 rounded-lg shadow-md text-center transition-transform duration-200 hover:scale-105">
                    <a href="<?php echo $app_url . '/profile/' . $userUsername; ?>">
                        <img class="h-24 w-24 rounded-full object-cover mb-3 mx-auto border-2 border-gray-200 hover:border-indigo-400"
                             src="<?php echo $userProfilePicFullUrl; ?>"
                             alt="<?php echo $userUsername; ?>'s profile picture"
                             onerror="this.onerror=null; this.src='<?php echo $default_avatar_full_url; ?>';">
                    </a>
                    <a href="<?php echo $app_url . '/profile/' . $userUsername; ?>" class="block text-lg font-semibold text-gray-800 hover:text-indigo-600 truncate" title="<?php echo $userUsername; ?>">
                        <?php echo $userUsername; ?>
                    </a>
                    <?php if ($userFullName): ?>
                        <p class="text-sm text-gray-500 truncate" title="<?php echo $userFullName; ?>"><?php echo $userFullName; ?></p>
                    <?php endif; ?>
                    
                    <div class="mt-4">
                        <?php if ($loggedInUserId !== (int)$user['id']): // Don't show follow button for self ?>
                            <?php if ($isFollowedByViewer): ?>
                                <form action="<?php echo $app_url . '/user/' . $userUsername . '/unfollow'; ?>" method="POST">
                                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                    <button type="submit" class="w-full px-4 py-2 bg-gray-200 text-gray-700 text-xs font-medium rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-offset-1 transition-colors">
                                        Following
                                    </button>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo $app_url . '/user/' . $userUsername . '/follow'; ?>" method="POST">
                                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                    <button type="submit" class="w-full px-4 py-2 bg-indigo-500 text-white text-xs font-medium rounded-md hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-1 transition-colors">
                                        Follow
                                    </button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if ($totalPages > 1): ?>
            <nav class="mt-10 flex justify-center" aria-label="User Pagination">
                <ul class="inline-flex items-center -space-x-px">
                    <li>
                        <a href="<?php echo $app_url . '/explore/users?page=' . max(1, $currentPage - 1); ?>"
                           class="py-2 px-3 ml-0 leading-tight text-gray-500 bg-white rounded-l-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 <?php echo ($currentPage <= 1) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                            Previous
                        </a>
                    </li>
                    <?php 
                        $startPage = max(1, $currentPage - 2);
                        $endPage = min($totalPages, $currentPage + 2);
                        if ($currentPage <= 3) $endPage = min($totalPages, 5);
                        if ($currentPage > $totalPages - 3) $startPage = max(1, $totalPages - 4);

                        if ($startPage > 1) {
                            echo '<li><a href="' . $app_url . '/explore/users?page=1" class="py-2 px-3 leading-tight border border-gray-300 text-gray-500 bg-white hover:bg-gray-100 hover:text-gray-700">1</a></li>';
                            if ($startPage > 2) echo '<li><span class="py-2 px-3 leading-tight border border-gray-300 text-gray-500 bg-white">...</span></li>';
                        }

                        for ($i = $startPage; $i <= $endPage; $i++): 
                    ?>
                        <li>
                            <a href="<?php echo $app_url . '/explore/users?page=' . $i; ?>"
                               class="py-2 px-3 leading-tight border border-gray-300 <?php echo ($i == $currentPage) ? 'text-indigo-600 bg-indigo-50 hover:bg-indigo-100 hover:text-indigo-700 z-10 ring-1 ring-indigo-500' : 'text-gray-500 bg-white hover:bg-gray-100 hover:text-gray-700'; ?>">
                                <?php echo $i; ?>
                            </a>
                        </li>
                    <?php endfor; 
                    
                        if ($endPage < $totalPages) {
                            if ($endPage < $totalPages - 1) echo '<li><span class="py-2 px-3 leading-tight border border-gray-300 text-gray-500 bg-white">...</span></li>';
                            echo '<li><a href="' . $app_url . '/explore/users?page=' . $totalPages . '" class="py-2 px-3 leading-tight border border-gray-300 text-gray-500 bg-white hover:bg-gray-100 hover:text-gray-700">' . $totalPages . '</a></li>';
                        }
                    ?>
                    <li>
                        <a href="<?php echo $app_url . '/explore/users?page=' . min($totalPages, $currentPage + 1); ?>"
                           class="py-2 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 <?php echo ($currentPage >= $totalPages) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                            Next
                        </a>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</div>