<?php
// File: app/Views/user/settings_account_content.php
// Purpose: Displays the form for changing account settings (e.g., password).
// Expected variables: $errors (array of error messages)
// APP_URL should be available globally or passed in.

$app_url = defined('APP_URL') ? APP_URL : ''; // Fallback
$errors = $errors ?? []; // Ensure $errors is always an array

// Helper to display errors for a specific field
function display_error($field, $errors_array) {
    if (isset($errors_array[$field])) {
        echo '<p class="text-red-500 text-xs mt-1">' . htmlspecialchars($errors_array[$field]) . '</p>';
    }
}
?>

<div class="container mx-auto px-4 py-8 max-w-2xl">
    <h1 class="text-2xl font-bold mb-6 text-gray-800">Account Settings</h1>

    <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="mb-4 p-3 rounded-md <?php echo $_SESSION['flash_message']['type'] === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
            <?php echo htmlspecialchars($_SESSION['flash_message']['text']); ?>
        </div>
        <?php unset($_SESSION['flash_message']); ?>
    <?php endif; ?>

    <?php if (!empty($errors['general'])): ?>
        <div class="mb-4 p-3 rounded-md bg-red-100 text-red-700">
            <?php echo htmlspecialchars($errors['general']); ?>
        </div>
    <?php endif; ?>

    <div class="bg-white p-6 rounded-lg shadow-md">
        <h2 class="text-xl font-semibold mb-4 text-gray-700">Change Password</h2>
        <form action="<?php echo $app_url . '/settings/account'; ?>" method="POST">
            <div class="mb-4">
                <label for="current_password" class="block text-sm font-medium text-gray-700 mb-1">Current Password:</label>
                <input type="password" name="current_password" id="current_password" required
                       class="w-full px-3 py-2 border <?php echo isset($errors['current_password']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                <?php display_error('current_password', $errors); ?>
            </div>

            <div class="mb-4">
                <label for="new_password" class="block text-sm font-medium text-gray-700 mb-1">New Password:</label>
                <input type="password" name="new_password" id="new_password" required
                       class="w-full px-3 py-2 border <?php echo isset($errors['new_password']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                <?php display_error('new_password', $errors); ?>
                <p class="text-xs text-gray-500 mt-1">Must be at least 8 characters long.</p>
            </div>

            <div class="mb-6">
                <label for="confirm_password" class="block text-sm font-medium text-gray-700 mb-1">Confirm New Password:</label>
                <input type="password" name="confirm_password" id="confirm_password" required
                       class="w-full px-3 py-2 border <?php echo isset($errors['confirm_password']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                <?php display_error('confirm_password', $errors); ?>
            </div>

            <div>
                <button type="submit"
                        class="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 ease-in-out">
                    Change Password
                </button>
            </div>
        </form>
    </div>
</div>
