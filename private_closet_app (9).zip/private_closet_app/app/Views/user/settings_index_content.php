<?php
// File: app/Views/user/settings_index_content.php
// Purpose: Displays the main settings navigation page.

// Ensure helper functions like escape_html() are available if needed (though not directly used here)
// Ensure APP_URL constant is available for links
if (!function_exists('escape_html')) {
    // Attempt to load helpers if not already loaded by controller/bootstrap
    $helperPath = __DIR__ . '/../../Helpers/utilities.php';
    if (file_exists($helperPath)) {
        require_once $helperPath;
    }
}
$appUrl = defined('APP_URL') ? APP_URL : ''; // Get base URL

?>

<div class="container mx-auto px-4 py-8 max-w-lg">
    <h1 class="text-2xl md:text-3xl font-bold text-gray-900 mb-6 text-center">Settings</h1>

    <div class="bg-white p-6 rounded-lg shadow-lg">
        <ul class="space-y-3">
            <li>
                <a href="<?php echo $appUrl; ?>/settings/profile" class="flex items-center justify-between p-3 rounded-md hover:bg-gray-100 transition duration-150">
                    <span class="flex items-center">
                        <i class="fas fa-user-edit w-5 h-5 mr-3 text-indigo-600"></i>
                        <span class="text-gray-800 font-medium">Edit Profile</span>
                    </span>
                    <i class="fas fa-chevron-right text-gray-400"></i>
                </a>
            </li>
            <li>
                <a href="<?php echo $appUrl; ?>/settings/account" class="flex items-center justify-between p-3 rounded-md hover:bg-gray-100 transition duration-150">
                     <span class="flex items-center">
                        <i class="fas fa-key w-5 h-5 mr-3 text-indigo-600"></i>
                        <span class="text-gray-800 font-medium">Change Password</span>
                     </span>
                    <i class="fas fa-chevron-right text-gray-400"></i>
                </a>
            </li>
            <li>
                <a href="<?php echo $appUrl; ?>/settings/notifications" class="flex items-center justify-between p-3 rounded-md hover:bg-gray-100 transition duration-150">
                     <span class="flex items-center">
                        <i class="fas fa-bell w-5 h-5 mr-3 text-indigo-600"></i>
                        <span class="text-gray-800 font-medium">Notification Settings</span>
                     </span>
                    <i class="fas fa-chevron-right text-gray-400"></i>
                </a>
            </li>
             <hr class="my-3">
             <li>
                <a href="<?php echo $appUrl; ?>/logout" class="flex items-center p-3 rounded-md hover:bg-red-50 text-red-600 transition duration-150">
                     <span class="flex items-center">
                        <i class="fas fa-sign-out-alt w-5 h-5 mr-3"></i>
                        <span class="font-medium">Log Out</span>
                     </span>
                </a>
            </li>
        </ul>
    </div>
</div>
