<?php
// File: app/Views/user/profile_content.php
// Purpose: Displays a user's profile information and their posts.
// Expected variables:
// $user (array: profile user's data)
// $posts (array: posts by the profile user)
// $isOwnProfile (bool: true if logged-in user is viewing their own profile)
// $isViewerFollowing (bool: true if logged-in user is following this profile user)
// $loggedInUserId (int|null: ID of the logged-in user)
// $followerCount (int)
// $followingCount (int)
// $currentPage, $totalPages (for post pagination)

$app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : ''; // Ensure no trailing slash
$user = $user ?? null; 
$posts = $posts ?? [];
$isOwnProfile = $isOwnProfile ?? false;
$isViewerFollowing = $isViewerFollowing ?? false;
$loggedInUserId = $loggedInUserId ?? null;
$followerCount = $followerCount ?? 0;
$followingCount = $followingCount ?? 0;
$currentPage = $currentPage ?? 1;
$totalPages = $totalPages ?? 1;


// Default avatar: Path relative to the public directory
$default_avatar_relative_path = defined('DEFAULT_AVATAR_PATH') ? DEFAULT_AVATAR_PATH : 'assets/images/default_avatar.png';
// Construct full URL for default avatar
$default_avatar_full_url = $app_url . '/' . ltrim($default_avatar_relative_path, '/');


if (!function_exists('time_ago_profile')) { // Check if function already exists
    function time_ago_profile($datetime, $full = false) {
        if (!$datetime) return "N/A";
        try {
            $now = new DateTime;
            $ago = new DateTime($datetime);
            $diff = $now->diff($ago);

            $parts = [];
            if ($diff->y) $parts[] = $diff->y . ' year' . ($diff->y > 1 ? 's' : '');
            if ($diff->m) $parts[] = $diff->m . ' month' . ($diff->m > 1 ? 's' : '');
            
            $remaining_days_for_weeks = $diff->d;
            if (($diff->y == 0 && $diff->m == 0) || $full) {
                $weeks = floor($remaining_days_for_weeks / 7);
                if ($weeks) {
                    $parts[] = $weeks . ' week' . ($weeks > 1 ? 's' : '');
                    $remaining_days_for_weeks %= 7; 
                }
            }

            if ($remaining_days_for_weeks) $parts[] = $remaining_days_for_weeks . ' day' . ($remaining_days_for_weeks > 1 ? 's' : '');
            
            if ($full || empty($parts) || ($diff->y == 0 && $diff->m == 0 && !isset($weeks) && $diff->d < 1) ) {
                if ($diff->h) $parts[] = $diff->h . ' hour' . ($diff->h > 1 ? 's' : '');
                if ($diff->i) $parts[] = $diff->i . ' minute' . ($diff->i > 1 ? 's' : '');
                if ($diff->s && count($parts) < 2) {
                     $parts[] = $diff->s . ' second' . ($diff->s > 1 ? 's' : '');
                }
            }

            if (!$full) $parts = array_slice($parts, 0, 1);
            
            return $parts ? implode(', ', $parts) . ' ago' : 'just now';
        } catch (Exception $e) { 
            error_log("Error in time_ago_profile (View): " . $e->getMessage() . " for datetime: " . $datetime);
            return $datetime;
        }
    }
}

if (!$user) {
    echo "<div class='container mx-auto px-4 py-8'><p class='text-red-500'>User data not available.</p></div>";
    return; 
}

// Construct full URL for author profile picture
$user_profile_pic_relative_path = $user['profile_picture_url'] ?? null;
$user_profile_pic_full_url = $user_profile_pic_relative_path 
    ? ($app_url . '/' . ltrim(htmlspecialchars($user_profile_pic_relative_path), '/')) 
    : $default_avatar_full_url;

?>
<div class="container mx-auto px-4 py-8 max-w-4xl">
    
    <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="mb-6 p-4 rounded-md <?php echo $_SESSION['flash_message']['type'] === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
            <?php echo htmlspecialchars($_SESSION['flash_message']['text']); ?>
        </div>
        <?php unset($_SESSION['flash_message']); ?>
    <?php endif; ?>

    <div class="bg-white shadow-lg rounded-lg p-6 mb-8">
        <div class="flex flex-col sm:flex-row items-center">
            <img class="h-24 w-24 sm:h-32 sm:w-32 rounded-full object-cover mr-0 sm:mr-6 mb-4 sm:mb-0 border-2 border-indigo-500"
                 src="<?php echo htmlspecialchars($user_profile_pic_full_url); ?>"
                 alt="<?php echo htmlspecialchars($user['username']); ?>'s profile picture"
                 onerror="this.onerror=null; this.src='<?php echo htmlspecialchars($default_avatar_full_url); ?>'; console.error('Failed to load profile avatar: <?php echo htmlspecialchars($user_profile_pic_full_url); ?>');">
            
            <div class="flex-1 text-center sm:text-left">
                <h1 class="text-3xl font-bold text-gray-800"><?php echo htmlspecialchars($user['full_name'] ?: $user['username']); ?></h1>
                <p class="text-md text-gray-600">@<?php echo htmlspecialchars($user['username']); ?></p>
                
                <?php if (!empty($user['profile_bio'])): ?>
                    <p class="text-sm text-gray-500 mt-2"><?php echo nl2br(htmlspecialchars($user['profile_bio'])); ?></p>
                <?php endif; ?>

                <div class="mt-4 flex justify-center sm:justify-start space-x-4 text-sm text-gray-600">
                    <div><span class="font-semibold"><?php echo $user['post_count'] ?? count($posts); // Use dedicated count if available ?></span> Posts</div>
                    <div><span class="font-semibold"><?php echo htmlspecialchars($followerCount); ?></span> Followers</div>
                    <div><span class="font-semibold"><?php echo htmlspecialchars($followingCount); ?></span> Following</div>
                </div>
            </div>

            <div class="mt-4 sm:mt-0 sm:ml-auto">
                <?php if ($loggedInUserId): ?>
                                        <?php if ($isOwnProfile): ?>
                        <a href="<?php echo $app_url . '/settings/profile'; ?>"
                           class="inline-block px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 mb-2 sm:mb-0 sm:mr-2">
                            Edit Profile
                        </a>
                        <a href="<?php echo $app_url . '/settings'; // Main settings page or /settings/account directly ?>"
                           title="Account Settings"
                           class="inline-block px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                            <i class="fas fa-cog"></i> <span class="hidden sm:inline ml-1">Settings</span>
                        </a>
                    <?php else: ?>
                        <?php if ($isViewerFollowing): ?>
                            <form action="<?php echo $app_url . '/user/' . htmlspecialchars($user['username']) . '/unfollow'; ?>" method="POST" class="inline-block">
                                <button type="submit"
                                        class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                    Unfollow
                                </button>
                            </form>
                        <?php else: ?>
                            <form action="<?php echo $app_url . '/user/' . htmlspecialchars($user['username']) . '/follow'; ?>" method="POST" class="inline-block">
                                <button type="submit"
                                        class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                    Follow
                                </button>
                            </form>
                        <?php endif; ?>
                        <a href="<?php echo $app_url . '/boardroom?start_with_user=' . (int)$user['id']; ?>"
                           class="ml-2 px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                            Message
                        </a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <h2 class="text-xl font-semibold text-gray-700 mb-4">Posts by <?php echo htmlspecialchars($user['username']); ?></h2>
    <?php if (empty($posts)): ?>
        <p class="text-gray-500 text-center py-6">
            <?php echo $isOwnProfile ? "You haven't made any posts yet." : htmlspecialchars($user['username']) . " hasn't made any posts yet."; ?>
            <?php if ($isOwnProfile): ?>
                <a href="<?php echo $app_url . '/upload'; ?>" class="text-indigo-600 hover:underline ml-1">Create a new post?</a>
            <?php endif; ?>
        </p>
    <?php else: ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            <?php foreach ($posts as $post_item): // Renamed to avoid conflict with global $post
                $post_item_author_username = $post_item['post_username'] ?? $user['username']; // Fallback to profile user's name
                $post_item_media_url_path = $post_item['media_url'] ?? '';
                $post_item_media_full_url = $post_item_media_url_path ? ($app_url . '/' . ltrim(htmlspecialchars($post_item_media_url_path), '/')) : '';
            ?>
                <article class="bg-white shadow-md rounded-lg overflow-hidden">
                    <?php if ($post_item_media_full_url): ?>
                        <a href="<?php echo $app_url . '/post/' . (int)$post_item['id']; ?>">
                        <?php if ($post_item['media_type'] === 'image'): ?>
                            <img class="w-full h-48 object-cover" 
                                 src="<?php echo htmlspecialchars($post_item_media_full_url); ?>" 
                                 alt="Post image by <?php echo htmlspecialchars($post_item_author_username); ?>"
                                 onerror="this.onerror=null; this.src='https://placehold.co/400x300/cccccc/ffffff?text=Image+Error';">
                        <?php elseif ($post_item['media_type'] === 'video'): ?>
                            <div class="w-full h-48 bg-black flex items-center justify-center">
                                <video controls class="max-w-full max-h-full">
                                    <source src="<?php echo htmlspecialchars($post_item_media_full_url); ?>" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                            </div>
                        <?php endif; ?>
                        </a>
                    <?php endif; ?>
                    <div class="p-4">
                        <?php if (!empty($post_item['description'])): ?>
                            <p class="text-gray-600 text-sm mb-2 truncate"><?php echo htmlspecialchars(substr($post_item['description'], 0, 100)) . (strlen($post_item['description']) > 100 ? '...' : ''); ?></p>
                        <?php endif; ?>
                        <div class="text-xs text-gray-400 mb-2">
                            Posted <?php echo time_ago_profile($post_item['created_at']); ?>
                        </div>
                        <div class="flex items-center justify-between text-xs text-gray-500">
                            <span><i class="far fa-heart"></i> <?php echo (int)($post_item['like_count'] ?? 0); ?></span>
                            <span><i class="far fa-comment"></i> <?php echo (int)($post_item['comment_count'] ?? 0); ?></span>
                        </div>
                         <a href="<?php echo $app_url . '/post/' . (int)$post_item['id']; ?>" class="mt-2 inline-block text-sm text-indigo-600 hover:text-indigo-800">View Post &rarr;</a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        <?php if ($totalPages > 1): ?>
            <nav class="mt-8 flex justify-center" aria-label="Post Pagination">
                <ul class="inline-flex items-center -space-x-px">
                    <li>
                        <a href="<?php echo $app_url . '/profile/' . htmlspecialchars($user['username']) . '?page=' . max(1, $currentPage - 1); ?>"
                           class="py-2 px-3 ml-0 leading-tight text-gray-500 bg-white rounded-l-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 <?php echo ($currentPage <= 1) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                            Previous
                        </a>
                    </li>
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li>
                            <a href="<?php echo $app_url . '/profile/' . htmlspecialchars($user['username']) . '?page=' . $i; ?>"
                               class="py-2 px-3 leading-tight border border-gray-300 <?php echo ($i == $currentPage) ? 'text-indigo-600 bg-indigo-50 hover:bg-indigo-100 hover:text-indigo-700' : 'text-gray-500 bg-white hover:bg-gray-100 hover:text-gray-700'; ?>">
                                <?php echo $i; ?>
                            </a>
                        </li>
                    <?php endfor; ?>
                    <li>
                        <a href="<?php echo $app_url . '/profile/' . htmlspecialchars($user['username']) . '?page=' . min($totalPages, $currentPage + 1); ?>"
                           class="py-2 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 <?php echo ($currentPage >= $totalPages) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                            Next
                        </a>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</div>
