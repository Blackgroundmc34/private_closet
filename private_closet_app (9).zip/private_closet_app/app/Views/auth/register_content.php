<?php
// File: app/Views/auth/register_content.php
// Purpose: Contains the HTML form specific to the registration page.

// These variables are expected to be passed from AuthController::showRegister()
// $errors (array) - Validation errors
// $oldInput (array) - Previously submitted form data
// $app_url (string) - Base application URL
// $csrf_token (string) - CSRF token for form security

// Ensure variables are initialized to prevent undefined variable notices
$errors = $errors ?? [];
$oldInput = $oldInput ?? [];
$app_url = $app_url ?? (defined('APP_URL') ? APP_URL : '');
// $csrf_token is expected to be passed in $data by AuthController's loadView method.
// If not, it will fall back to the session token directly.
$csrf_token = $csrf_token ?? ($_SESSION['csrf_token'] ?? '');

// Helper function to display error for a specific field
if (!function_exists('display_form_error_register')) { // Renamed to avoid global conflicts
    function display_form_error_register(string $field, array $error_list): void {
        if (isset($error_list[$field])) {
            echo '<p class="text-red-500 text-xs mt-1">' . htmlspecialchars($error_list[$field]) . '</p>';
        }
    }
}
if (!function_exists('escape_html')) { // Basic escape_html if not globally available
    function escape_html($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

?>

<div class="max-w-2xl mx-auto my-8 md:my-12"> 
    <h1 class="text-3xl font-bold mb-8 text-center text-gray-800">Create Your Account</h1>

    <?php if (!empty($errors['general'])): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
            <strong class="font-bold">Error!</strong>
            <span class="block sm:inline"><?php echo escape_html($errors['general']); ?></span>
        </div>
    <?php endif; ?>

    <form action="<?php echo htmlspecialchars($app_url . '/register'); ?>" method="POST" class="bg-white p-6 sm:p-8 rounded-lg shadow-xl border border-gray-200 space-y-6">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">

        <div>
            <label for="role" class="block text-sm font-medium text-gray-700 mb-1">I want to register as a:</label>
            <select id="role" name="role" required 
                    class="w-full px-3 py-2 border <?php echo !empty($errors['role']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                <option value="user" <?php echo (($oldInput['role'] ?? 'user') === 'user') ? 'selected' : ''; ?>>User (Shop & Socialize)</option>
                <option value="supplier" <?php echo (($oldInput['role'] ?? '') === 'supplier') ? 'selected' : ''; ?>>Supplier / Brand Owner (Sell Products)</option>
                <option value="stylist" <?php echo (($oldInput['role'] ?? '') === 'stylist') ? 'selected' : ''; ?>>Stylist (Offer Services)</option>
            </select>
            <?php display_form_error_register('role', $errors); ?>
        </div>

        <hr class="my-4">

        <div class="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
            <div>
                <label for="full_name" class="block text-sm font-medium text-gray-700 mb-1">Full Name <span class="text-red-500">*</span></label>
                <input type="text" id="full_name" name="full_name" required value="<?php echo escape_html($oldInput['full_name'] ?? ''); ?>" 
                       class="w-full px-3 py-2 border <?php echo !empty($errors['full_name']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                <?php display_form_error_register('full_name', $errors); ?>
            </div>
            <div>
                <label for="username" class="block text-sm font-medium text-gray-700 mb-1">Username <span class="text-red-500">*</span></label>
                <input type="text" id="username" name="username" required pattern="^[a-zA-Z0-9_]{3,20}$" title="3-20 characters using letters, numbers, and underscores only." value="<?php echo escape_html($oldInput['username'] ?? ''); ?>" 
                       class="w-full px-3 py-2 border <?php echo !empty($errors['username']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                <?php display_form_error_register('username', $errors); ?>
            </div>
        </div>
        <div>
            <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email Address <span class="text-red-500">*</span></label>
            <input type="email" id="email" name="email" required value="<?php echo escape_html($oldInput['email'] ?? ''); ?>" 
                   class="w-full px-3 py-2 border <?php echo !empty($errors['email']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
            <?php display_form_error_register('email', $errors); ?>
        </div>
         <div class="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
            <div>
                <label for="password" class="block text-sm font-medium text-gray-700 mb-1">Password <span class="text-red-500">*</span></label>
                <input type="password" id="password" name="password" required minlength="8" 
                       class="w-full px-3 py-2 border <?php echo !empty($errors['password']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                <p class="text-xs text-gray-500 mt-1">Minimum 8 characters.</p>
                <?php display_form_error_register('password', $errors); ?>
            </div>
             <div>
                <label for="password_confirmation" class="block text-sm font-medium text-gray-700 mb-1">Confirm Password <span class="text-red-500">*</span></label>
                <input type="password" id="password_confirmation" name="password_confirmation" required 
                       class="w-full px-3 py-2 border <?php echo !empty($errors['password_confirmation']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                <?php display_form_error_register('password_confirmation', $errors); ?>
            </div>
        </div>

        <div id="supplier-fields" class="role-fields space-y-6 border-t border-gray-200 pt-6 mt-6">
            <h3 class="text-xl font-semibold text-gray-800 mb-3">Business Details (for Suppliers)</h3>
             <div>
                <label for="business_name" class="block text-sm font-medium text-gray-700 mb-1">Business Name <span class="text-red-500">*</span></label>
                <input type="text" id="business_name" name="business_name" value="<?php echo escape_html($oldInput['business_name'] ?? ''); ?>" 
                       class="w-full px-3 py-2 border <?php echo !empty($errors['business_name']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                <?php display_form_error_register('business_name', $errors); ?>
            </div>
             <div>
                <label for="registration_number" class="block text-sm font-medium text-gray-700 mb-1">Company Registration Number (Optional)</label>
                <input type="text" id="registration_number" name="registration_number" value="<?php echo escape_html($oldInput['registration_number'] ?? ''); ?>" 
                       class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                <?php display_form_error_register('registration_number', $errors); ?>
            </div>
             <div>
                <label for="start_date" class="block text-sm font-medium text-gray-700 mb-1">Business Start Date (if not registered, Optional)</label>
                <input type="date" id="start_date" name="start_date" value="<?php echo escape_html($oldInput['start_date'] ?? ''); ?>" 
                       class="w-full px-3 py-2 border <?php echo !empty($errors['start_date']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                <?php display_form_error_register('start_date', $errors); ?>
            </div>
             <div>
                <label for="business_description" class="block text-sm font-medium text-gray-700 mb-1">Short Description of Business & Services <span class="text-red-500">*</span></label>
                <textarea id="business_description" name="business_description" rows="3" 
                          class="w-full px-3 py-2 border <?php echo !empty($errors['business_description']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"><?php echo escape_html($oldInput['business_description'] ?? ''); ?></textarea>
                <?php display_form_error_register('business_description', $errors); ?>
            </div>
             <div>
                <label for="physical_address" class="block text-sm font-medium text-gray-700 mb-1">Physical Address (Business or Personal) <span class="text-red-500">*</span></label>
                <textarea id="physical_address" name="physical_address" rows="3" 
                          class="w-full px-3 py-2 border <?php echo !empty($errors['physical_address']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"><?php echo escape_html($oldInput['physical_address'] ?? ''); ?></textarea>
                <?php display_form_error_register('physical_address', $errors); ?>
             </div>
             <div>
                <label for="operating_hours" class="block text-sm font-medium text-gray-700 mb-1">Operating Hours (e.g., Mon-Fri 9am-5pm, Optional)</label>
                <input type="text" id="operating_hours" name="operating_hours" value="<?php echo escape_html($oldInput['operating_hours'] ?? ''); ?>" 
                       class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                <?php display_form_error_register('operating_hours', $errors); ?>
            </div>
             <div class="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                 <div>
                    <label for="contact_phone_1" class="block text-sm font-medium text-gray-700 mb-1">Contact Phone 1 <span class="text-red-500">*</span></label>
                    <input type="tel" id="contact_phone_1" name="contact_phone_1" value="<?php echo escape_html($oldInput['contact_phone_1'] ?? ''); ?>" 
                           class="w-full px-3 py-2 border <?php echo !empty($errors['contact_phone_1']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                    <?php display_form_error_register('contact_phone_1', $errors); ?>
                </div>
                 <div>
                    <label for="contact_phone_2" class="block text-sm font-medium text-gray-700 mb-1">Contact Phone 2 (Optional)</label>
                    <input type="tel" id="contact_phone_2" name="contact_phone_2" value="<?php echo escape_html($oldInput['contact_phone_2'] ?? ''); ?>" 
                           class="w-full px-3 py-2 border <?php echo !empty($errors['contact_phone_2']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                    <?php display_form_error_register('contact_phone_2', $errors); ?>
                </div>
             </div>
             <div>
                 <label class="block text-sm font-medium text-gray-700 mb-1">Type of Fashion / Accessories / Goods (Select all that apply, Optional)</label>
                 <div class="space-y-1 mt-1 max-h-40 overflow-y-auto border border-gray-200 rounded-md p-3 bg-gray-50">
                     <?php
                        // These should ideally come from CategoryModel if dynamic
                        $exampleCategories = [ /* Kept your example categories */
                            1 => 'Street wear', 2 => 'Casual', 3 => 'Sportswear', 4 => 'Formal',
                            5 => 'Minimalist', 6 => 'Denim', 7 => 'Boho-chic', 8 => 'Haute couture',
                            9 => 'Pre-owned', 10 => 'Shoes', 11 => 'Socks', 12 => 'Ties',
                            13 => 'Belts', 14 => 'Handbags', 15 => 'Hats', 16 => 'Sunglasses',
                            17 => 'Watches', 18 => 'Jewellery', 19 => 'Colognes', 20 => 'Cosmetics',
                            21 => 'Underwear'
                        ];
                        $selectedBusinessCategories = $oldInput['business_categories'] ?? [];
                     ?>
                     <?php foreach ($exampleCategories as $id => $name): ?>
                         <label for="bus_cat_<?php echo $id; ?>" class="flex items-center cursor-pointer hover:bg-gray-100 p-1 rounded">
                             <input id="bus_cat_<?php echo $id; ?>" name="business_categories[]" type="checkbox" value="<?php echo $id; ?>"
                                    <?php echo in_array($id, $selectedBusinessCategories) ? 'checked' : ''; ?>
                                    class="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500">
                             <span class="ml-2 text-sm text-gray-700"><?php echo escape_html($name); ?></span>
                         </label>
                     <?php endforeach; ?>
                 </div>
                  <?php display_form_error_register('business_categories', $errors); ?>
             </div>
             <div class="flex items-start mt-4">
                <div class="flex items-center h-5">
                    <input id="terms_supplier" name="terms_supplier" type="checkbox" value="1" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
                </div>
                <div class="ml-3 text-sm">
                    <label for="terms_supplier" class="font-medium text-gray-700">I have read and agree to the <a href="<?php echo $app_url; ?>/terms#seller" class="text-indigo-600 hover:underline">Seller Terms and Conditions</a> <span class="text-red-500">*</span>.</label>
                </div>
             </div>
            <?php display_form_error_register('terms_supplier', $errors); ?>
        </div>

        <div id="stylist-fields" class="role-fields space-y-4 border-t border-gray-200 pt-6 mt-6">
             <h3 class="text-xl font-semibold text-gray-800 mb-3">Stylist Details</h3>
             <p class="text-sm text-gray-600 mb-4">Your profile will be set up. You can add more details like portfolio and services later. Stylists can earn tips!</p>
             <div class="flex items-start">
                <div class="flex items-center h-5">
                    <input id="terms_stylist" name="terms_stylist" type="checkbox" value="1" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
                </div>
                <div class="ml-3 text-sm">
                    <label for="terms_stylist" class="font-medium text-gray-700">I agree to the <a href="<?php echo $app_url; ?>/terms#platform" class="text-indigo-600 hover:underline">Platform Terms and Conditions</a> <span class="text-red-500">*</span>.</label>
                </div>
             </div>
            <?php display_form_error_register('terms_stylist', $errors); ?>
        </div>

        <div id="user-fields" class="role-fields active space-y-4 border-t border-gray-200 pt-6 mt-6">
             <h3 class="text-xl font-semibold text-gray-800 mb-3">User Agreement</h3>
             <p class="text-sm text-gray-600 mb-4">You're joining as a user. You can buy items, post to your closet, follow others, and interact!</p>
             <div class="flex items-start">
                <div class="flex items-center h-5">
                    <input id="terms_user" name="terms_user" type="checkbox" value="1" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
                </div>
                <div class="ml-3 text-sm">
                    <label for="terms_user" class="font-medium text-gray-700">I agree to the <a href="<?php echo $app_url; ?>/terms#platform" class="text-indigo-600 hover:underline">Platform Terms and Conditions</a> <span class="text-red-500">*</span>.</label>
                </div>
             </div>
            <?php display_form_error_register('terms_user', $errors); ?>
         </div>


        <div class="pt-4">
            <button type="submit" class="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 ease-in-out">
                Create Account
            </button>
        </div>

        <div class="text-center text-sm text-gray-600 pt-4">
            Already have an account? <a href="<?php echo htmlspecialchars($app_url . '/login'); ?>" class="font-medium text-indigo-600 hover:underline">Sign In</a>
        </div>

    </form>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const roleSelect = document.getElementById('role');
        const supplierFieldsDiv = document.getElementById('supplier-fields');
        const stylistFieldsDiv = document.getElementById('stylist-fields');
        const userFieldsDiv = document.getElementById('user-fields');

        // Get all relevant input elements within supplier fields for toggling 'required'
        const supplierRequiredInputs = [
            supplierFieldsDiv.querySelector('#business_name'),
            supplierFieldsDiv.querySelector('#business_description'),
            supplierFieldsDiv.querySelector('#physical_address'),
            supplierFieldsDiv.querySelector('#contact_phone_1'),
            supplierFieldsDiv.querySelector('#terms_supplier')
        ];
        // Optional supplier inputs (don't toggle required, but are part of the section)
        // const supplierOptionalInputs = [...] 

        const userTermsCheckbox = userFieldsDiv.querySelector('#terms_user');
        const stylistTermsCheckbox = stylistFieldsDiv.querySelector('#terms_stylist');

        function toggleFields() {
            const selectedRole = roleSelect.value;

            // Hide all role-specific sections
            supplierFieldsDiv.style.display = 'none';
            stylistFieldsDiv.style.display = 'none';
            userFieldsDiv.style.display = 'none';

            // Remove 'required' from all potentially role-specific inputs first
            supplierRequiredInputs.forEach(input => { if(input) input.required = false; });
            if(userTermsCheckbox) userTermsCheckbox.required = false;
            if(stylistTermsCheckbox) stylistTermsCheckbox.required = false;

            // Show the relevant section and set 'required' for its specific inputs
            if (selectedRole === 'supplier') {
                supplierFieldsDiv.style.display = 'block';
                supplierRequiredInputs.forEach(input => { if(input) input.required = true; });
            } else if (selectedRole === 'stylist') {
                stylistFieldsDiv.style.display = 'block';
                if(stylistTermsCheckbox) stylistTermsCheckbox.required = true;
            } else { // Default to 'user'
                userFieldsDiv.style.display = 'block';
                if(userTermsCheckbox) userTermsCheckbox.required = true;
            }
        }

        if (roleSelect) {
            roleSelect.addEventListener('change', toggleFields);
            // Initial call to set the correct fields on page load (e.g., if there's old input)
            toggleFields();
        }
    });
</script>
