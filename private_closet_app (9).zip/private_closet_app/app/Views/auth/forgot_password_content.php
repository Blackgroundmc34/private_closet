<?php
// File: app/Views/auth/forgot_password_content.php
// Variables available: $pageTitle, $csrf_token, $app_url, $flashMessage

$email = $oldInput['email'] ?? '';
$emailError = $errors['email'] ?? ''; // Assuming errors might be passed this way

$flashMessage = $flashMessage ?? $_SESSION['flash_message'] ?? null;
if (isset($_SESSION['flash_message'])) {
    unset($_SESSION['flash_message']);
}

?>

<div class="container mx-auto max-w-md px-4 py-12">
    <div class="bg-white p-6 md:p-8 rounded-xl shadow-xl">
        <h1 class="text-2xl sm:text-3xl font-bold text-center text-gray-800 mb-6">Forgot Your Password?</h1>
        <p class="text-center text-gray-600 text-sm mb-6">
            No problem! Just enter the email address you used to sign up and we'll send you a link to reset your password.
        </p>

        <?php if (isset($flashMessage)): ?>
            <div class="mb-4 p-3 rounded-md text-sm 
                <?php 
                    $messageTypeClass = 'bg-blue-100 text-blue-700 border border-blue-300'; // Default info
                    if (($flashMessage['type'] ?? 'info') === 'success') { $messageTypeClass = 'bg-green-100 text-green-700 border border-green-300'; }
                    elseif (($flashMessage['type'] ?? 'info') === 'error') { $messageTypeClass = 'bg-red-100 text-red-700 border border-red-300'; }
                    elseif (($flashMessage['type'] ?? 'info') === 'warning') { $messageTypeClass = 'bg-yellow-100 text-yellow-700 border border-yellow-300'; }
                    echo $messageTypeClass;
                ?>">
                <?php if(!empty($flashMessage['type'])): ?>
                    <strong class="font-semibold"><?php echo ucfirst(htmlspecialchars($flashMessage['type'])); ?>!</strong> 
                <?php endif; ?>
                <?php echo htmlspecialchars($flashMessage['text']); ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo htmlspecialchars($app_url); ?>/forgot-password" method="POST" class="space-y-6">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token ?? ''); ?>">
            
            <div>
                <label for="email" class="block text-sm font-medium text-gray-700 sr-only">Email address</label>
                <input type="email" name="email" id="email" required 
                       class="appearance-none block w-full px-4 py-3 border <?php echo !empty($emailError) ? 'border-red-500' : 'border-gray-300'; ?> rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 <?php echo !empty($emailError) ? 'focus:ring-red-500' : 'focus:ring-indigo-500'; ?> focus:border-transparent sm:text-sm"
                       placeholder="Enter your email address"
                       value="<?php echo htmlspecialchars($email); ?>">
                <?php if (!empty($emailError)): ?>
                    <p class="mt-2 text-xs text-red-600"><?php echo htmlspecialchars($emailError); ?></p>
                <?php endif; ?>
            </div>

            <div>
                <button type="submit" class="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 ease-in-out">
                    Send Password Reset Link
                </button>
            </div>
        </form>

        <div class="mt-6 text-center">
            <p class="text-sm">
                Remember your password? 
                <a href="<?php echo htmlspecialchars($app_url); ?>/login" class="font-medium text-indigo-600 hover:text-indigo-500">
                    Log in
                </a>
            </p>
        </div>
    </div>
</div>