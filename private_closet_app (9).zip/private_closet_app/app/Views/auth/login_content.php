<?php
// File: app/Views/auth/login_content.php
// Purpose: Contains the HTML form specific to the login page.

// Assumes $errors, $oldInput, and $csrf_token are made available by the controller/loadView method.
// Example initialization (usually done by extract($data) in loadView):
// $errors = $errors ?? [];
// $oldInput = $oldInput ?? [];
// $csrf_token = $csrf_token ?? ''; // Provided by loadView from $_SESSION['csrf_token']

// Define escape_html if not available globally
if (!function_exists('escape_html')) {
    function escape_html($value) {
        return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
    }
}

// Determine APP_URL safely
$appUrl = defined('APP_URL') ? APP_URL : '';

?>

<div class="max-w-md mx-auto mt-8 px-4 md:mt-16"> <h1 class="text-2xl font-semibold mb-6 text-center text-gray-800">Sign In</h1>

    <?php /* Display general login errors (like invalid credentials or CSRF failure) */ ?>
    <?php if (!empty($errors['general'])): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <strong class="font-bold">Login Failed!</strong>
            <span class="block sm:inline"><?php echo escape_html($errors['general']); ?></span>
        </div>
    <?php endif; ?>

    <?php /* Display flash messages (e.g., successful registration, logged out) */ ?>
    <?php // You might need logic here to display $_SESSION['flash_message'] if passed separately ?>
    <?php /* Example:
    <?php if (!empty($flash_message)): ?>
        <div class="bg-<?php echo $flash_message['type'] === 'success' ? 'green' : 'red'; ?>-100 border border-<?php echo $flash_message['type'] === 'success' ? 'green' : 'red'; ?>-400 text-<?php echo $flash_message['type'] === 'success' ? 'green' : 'red'; ?>-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo escape_html($flash_message['text']); ?></span>
        </div>
    <?php endif; ?>
    */?>


    <form action="<?php echo $appUrl; ?>/login" method="POST" class="bg-white p-6 rounded-lg shadow-md space-y-4">

        <input type="hidden" name="csrf_token" value="<?php echo escape_html($csrf_token ?? ''); ?>">
        <div>
            <label for="login_identifier" class="block text-sm font-medium text-gray-700 mb-1">Email or Username:</label>
            <input type="text" id="login_identifier" name="login_identifier" required autofocus
                   value="<?php echo escape_html($oldInput['login_identifier'] ?? ''); ?>"
                   aria-describedby="login_identifier_error"
                   class="w-full px-3 py-2 border <?php echo !empty($errors['login_identifier']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
            <?php if (!empty($errors['login_identifier'])): ?>
                <p id="login_identifier_error" class="mt-1 text-xs text-red-600"><?php echo escape_html($errors['login_identifier']); ?></p>
            <?php endif; ?>
        </div>

        <div>
            <div class="flex justify-between items-baseline">
                <label for="password" class="block text-sm font-medium text-gray-700 mb-1">Password:</label>
                <a href="<?php echo $appUrl; ?>/forgot-password" class="text-sm text-indigo-600 hover:underline">Forgot Password?</a>
            </div>
            <input type="password" id="password" name="password" required
                   aria-describedby="password_error"
                   class="w-full px-3 py-2 border <?php echo !empty($errors['password']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
             <?php if (!empty($errors['password'])): ?>
                <p id="password_error" class="mt-1 text-xs text-red-600"><?php echo escape_html($errors['password']); ?></p>
            <?php endif; ?>
        </div>

        <div class="flex items-center">
            <input id="remember_me" name="remember_me" type="checkbox" value="1" class="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500">
            <label for="remember_me" class="ml-2 block text-sm text-gray-900">Remember me</label>
        </div>


        <div>
            <button type="submit" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                Sign In
            </button>
        </div>

        <div class="text-center text-sm text-gray-600 pt-2"> Don't have an account? <a href="<?php echo $appUrl; ?>/register" class="font-medium text-indigo-600 hover:underline">Register Now</a>
        </div>

    </form>
</div>

<?php
// Optional: Add any specific JavaScript for this page if needed
?>