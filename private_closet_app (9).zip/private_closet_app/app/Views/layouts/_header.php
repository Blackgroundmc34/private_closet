<?php
// File: app/Views/layouts/_header.php
// Purpose: Defines the common header and top navigation for the application.

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Generate CSRF token if not already set
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Helper function for HTML escaping
if (!function_exists('escape_html')) {
    function escape_html($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

// Application base URL (ensure it's defined in your config and points to your public folder, e.g., http://localhost/private_closet_app/public)
$app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : '';

// User session details
$is_logged_in = isset($_SESSION['user_id']);
$user_role = $_SESSION['user_role'] ?? null;
$username = $_SESSION['username'] ?? null;

// This session variable is expected to hold either:
// 1. The FULL CORRECT URL to the user's avatar (e.g., http://localhost/private_closet_app/public/uploads/avatars/filename.jpg)
// 2. OR a path relative to the public directory (e.g., uploads/avatars/filename.jpg)
$user_avatar_path_info = $_SESSION['user_profile_pic_url'] ?? null;

// --- DEBUGGING: Uncomment the line below to see what avatar path/URL is in the session ---
// if ($is_logged_in) { error_log("HEADER AVATAR DEBUG: Session 'user_profile_pic_url' = '{$user_avatar_path_info}' for user '{$username}'"); }
// ---

$avatar_content = '';
$default_avatar_url = $app_url . '/assets/images/default_avatar.png'; // Generic default avatar

if ($is_logged_in) {
    $final_avatar_src = '';

    if (!empty($user_avatar_path_info)) {
        // Check if it looks like a full URL already
        if (strpos($user_avatar_path_info, 'http://') === 0 || strpos($user_avatar_path_info, 'https://') === 0) {
            if (filter_var($user_avatar_path_info, FILTER_VALIDATE_URL)) {
                // It's a full URL, use it directly.
                // CRITICAL: This URL must be the correct one, pointing to .../public/uploads/avatars/
                $final_avatar_src = $user_avatar_path_info;
            }
        } else {
            // Assume it's a path relative to $app_url (which points to the public directory)
            // e.g., if session stores "uploads/avatars/file.jpg"
            // This will construct: http://localhost/private_closet_app/public/uploads/avatars/file.jpg
            $final_avatar_src = $app_url . '/' . ltrim($user_avatar_path_info, '/');
        }
        
        // If we resolved a source, create the image tag
        if (!empty($final_avatar_src)) {
             // Add a distinct console log for the attempted source
            $js_escaped_final_src = escape_html(json_encode($final_avatar_src)); // For JS console.error
            $js_escaped_default_src = escape_html(json_encode($default_avatar_url));

            $avatar_content = '<img class="h-8 w-8 rounded-full object-cover" src="' . escape_html($final_avatar_src) . '" alt="' . escape_html($username ?? 'User') . ' Profile Picture" onerror="this.onerror=null; this.src=' . $js_escaped_default_src . '; console.error(\'Avatar Load Error: Failed to load user avatar from ' . $js_escaped_final_src . '. Switched to default.\');">';
        }
    }

    // Fallback to initials if no valid picture URL was resolved
    if (empty($final_avatar_src) && !empty($username)) {
        $initial = strtoupper(substr($username, 0, 1));
        $avatar_content = '<span class="h-8 w-8 rounded-full bg-indigo-500 text-white flex items-center justify-center text-sm font-semibold">' . escape_html($initial) . '</span>';
    }
    // Absolute fallback to default avatar image if no username or other methods failed
    elseif (empty($avatar_content)) {
        $avatar_content = '<img class="h-8 w-8 rounded-full object-cover" src="' . escape_html($default_avatar_url) . '" alt="Default User Avatar">';
    }
}

// Fetch unread notification count
$unread_notification_count = 0;
if ($is_logged_in && isset($pdo)) { // Ensure $pdo is available in this scope (from bootstrap.php)
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = :user_id AND is_read = 0");
        $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
        $stmt->execute();
        $unread_notification_count = (int) $stmt->fetchColumn();
    } catch (PDOException $e) {
        error_log("Error fetching unread notification count in header: " . $e->getMessage());
    }
}

// Cart item count
$cart_item_count = $_SESSION['cart_total_items'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo escape_html($_SESSION['csrf_token']); ?>">
    <title><?php echo isset($pageTitle) ? escape_html($pageTitle) : 'Private Closet'; ?></title>
    <script src="https://cdn.tailwindcss.com"></script> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
        integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet"> <style>
        body {
            font-family: 'Inter', sans-serif;
            /* background-color is set by Tailwind class 'bg-gray-100' on body */
        }

        /* Styles for bottom navigation active state, if needed beyond Tailwind classes */
        .bottom-nav a.active {
            color: #4f46e5; /* Tailwind's indigo-600 or your chosen active color */
            /* border-top: 2px solid #4f46e5; */ /* Example active indicator */
        }

        .role-fields { display: none; }
        .role-fields.active { display: block; }

        .notification-badge {
            position: absolute;
            top: -5px;    /* Adjust for precise positioning */
            right: -5px;  /* Adjust for precise positioning */
            min-width: 1rem; /* 16px */
            height: 1rem;    /* 16px */
            padding: 0 0.25rem; /* 4px horizontal padding */
            font-size: 0.625rem; /* 10px */
            line-height: 1rem;   /* 16px, to vertically center text */
            display: inline-flex; /* Helps with alignment if count makes it wider */
            align-items: center;
            justify-content: center;
        }
        /* Any other global styles or minor overrides can go here 
   .text-sm {
    font-size: 0.875rem;
    line-height: 1.25rem;
    color: black !important;
}
.space-x-4 > :not([hidden]) ~ :not([hidden]) {
    --tw-space-x-reverse: 0;
    margin-right: calc(1rem * var(--tw-space-x-reverse));
    margin-left: calc(1rem * calc(1 - var(--tw-space-x-reverse)));
    color: white !important;
}
.bg-white {
    --tw-bg-opacity: 1;
    background-color: black !important;
}
.fa-receipt:before {
    content: "\f543";
    color: white !important;
}

.bg-gray-100 {
    --tw-bg-opacity: 1;
    background-color:rgba(0, 0, 0, 0.75) !important;
}
.bg-indigo-600 {
    --tw-bg-opacity: 1;
    background-color: gold  !important;
}
.text-indigo-600 {
    --tw-text-opacity: 1;
    color: gold !important;
}
.text-gray-800 {
    --tw-text-opacity: 1;
    color: rgb(31 41 55 / var(--tw-text-opacity, 1)) !important;
}
.text-gray-700 {
    --tw-text-opacity: 1;
    color: #fff !important;
}
a {
    color: inherit;
    text-decoration: inherit;
    color: gold !important;
}
.text-gray-900 {
    --tw-text-opacity: 1;
    color: #fff !important;
}
.fa-circle-user:before, .fa-user-circle:before {
    content: "\f2bd";
    color: white !important;
}
.text-xs {
    padding: 8px;
    color: white !important;
}
.text-white {
    --tw-text-opacity: 1;
    color: rgb(255 255 255 / var(--tw-text-opacity, 1));
    color: white !important;
}
.fa-comments:before {
    content: "\f086";
    color: blue !important;
}
.fa-store:before {
    content: "\f54e";
    color: white !important;
}
.text-gray-800 {
    --tw-text-opacity: 1;
    color: #fff !important;
}
 
*/
    </style>
</head>
<body class="bg-gray-100 text-gray-800 antialiased"> <nav class="bg-white shadow-md sticky top-0 z-50 px-4 py-3" x-data="{ mobileMenuOpen: false }">
        <div class="container mx-auto flex justify-between items-center">
            <a href="<?php echo $app_url; ?>/showroom" class="text-xl font-bold text-indigo-600">Private Closet</a>

            <div class="hidden md:flex items-center space-x-3 lg:space-x-4">
                <a href="<?php echo $app_url; ?>/showroom" class="text-gray-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium">Showroom</a>
                <?php if ($is_logged_in): ?>
                    <a href="<?php echo $app_url; ?>/closets" class="text-gray-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium">Closets</a>
                    <a href="<?php echo $app_url; ?>/boardroom" class="text-gray-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium">Boardroom</a>
                    <a href="<?php echo htmlspecialchars($app_url . '/profile/' . urlencode($username ?? '') . '/orders'); ?>" class="dropdown-item" role="menuitem">Orders</a>
                    <?php if ($user_role === 'supplier'): ?>
                        <a href="<?php echo $app_url; ?>/supplier/dashboard" class="text-gray-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium">Dashboard</a>
                    <?php endif; ?>
                <?php endif; ?>

                <a href="<?php echo $app_url; ?>/search" aria-label="Search" class="text-gray-600 hover:text-indigo-600 p-2">
                    <i class="fas fa-search fa-lg"></i>
                </a>
                <a href="<?php echo $app_url; ?>/reels" aria-label="Reels" class="text-gray-600 hover:text-indigo-600 p-2">
                    <i class="fas fa-film fa-lg"></i>
                </a>
                <a href="<?php echo $app_url; ?>/settings/notifications" aria-label="Notifications" class="text-gray-600 hover:text-indigo-600 p-2 relative">
                    <i class="fas fa-bell fa-lg"></i>
                    <?php if ($is_logged_in && $unread_notification_count > 0): ?>
                        <span class="notification-badge rounded-full bg-red-500 text-white">
                            <?php echo $unread_notification_count; ?>
                        </span>
                    <?php endif; ?>
                </a>
<a href="<?php echo htmlspecialchars($app_url); ?>/cart" aria-label="Shopping Cart" class="nav-link relative">
    <i class="fas fa-shopping-cart"></i>
    <span id="header-cart-item-count"
          class="absolute -top-1 -right-1 bg-red-600 text-white text-xs font-bold rounded-full h-4 w-4 flex items-center justify-center <?php echo ($cart_item_count > 0) ? '' : 'hidden'; ?>">
        <?php echo htmlspecialchars($cart_item_count); ?>
    </span>
</a>

                <?php if ($is_logged_in): ?>
                    <div x-data="{ dropdownOpen: false }" class="relative">
                        <button @click="dropdownOpen = !dropdownOpen" class="flex items-center text-sm rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500" aria-label="Open user menu" aria-haspopup="true" :aria-expanded="dropdownOpen.toString()">
                            <?php echo $avatar_content; // This will output the <img> or <span> for the avatar ?>
                            <?php if ($username): ?>
                                <span class="hidden lg:inline ml-2 text-gray-600 hover:text-indigo-600"><?php echo escape_html($username); ?></span>
                                <i class="fas fa-chevron-down fa-xs ml-1 text-gray-600 hidden lg:inline"></i>
                            <?php endif; ?>
                        </button>
                        <div x-show="dropdownOpen" @click.away="dropdownOpen = false"
                             x-transition:enter="transition ease-out duration-100"
                             x-transition:enter-start="transform opacity-0 scale-95"
                             x-transition:enter-end="transform opacity-100 scale-100"
                             x-transition:leave="transition ease-in duration-75"
                             x-transition:leave-start="transform opacity-100 scale-100"
                             x-transition:leave-end="transform opacity-0 scale-95"
                             class="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none z-20"
                             role="menu" aria-orientation="vertical" aria-labelledby="user-menu-button" style="display: none;">
                            <?php if ($username): ?>
                                <a href="<?php echo $app_url . '/profile/' . escape_html($username); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">Your Profile</a>
                            <?php endif; ?>
                            <a href="<?php echo $app_url; ?>/settings" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">Settings</a>
                            <a href="<?php echo $app_url; ?>/logout" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">Sign out</a>
                        </div>
                    </div>
                <?php else: // Not logged in ?>
                    <a href="<?php echo $app_url; ?>/login" class="text-gray-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium">Login</a>
                    <a href="<?php echo $app_url; ?>/register" class="ml-2 inline-flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700">Sign Up</a>
                <?php endif; ?>
            </div>

            <div class="md:hidden flex items-center">
<a href="<?php echo htmlspecialchars($app_url); ?>/cart" aria-label="Shopping Cart" class="text-gray-600 hover:text-indigo-600 p-2 mr-2 relative">
    <i class="fas fa-shopping-cart fa-lg"></i>
    <span id="mobile-header-cart-item-count"
          class="absolute -top-1 -right-1 bg-red-600 text-white text-xs font-bold rounded-full h-4 w-4 flex items-center justify-center <?php echo ($cart_item_count > 0) ? '' : 'hidden'; ?>">
        <?php echo htmlspecialchars($cart_item_count); ?>
    </span>
</a>
                <button @click="mobileMenuOpen = !mobileMenuOpen" type="button" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500" aria-controls="mobile-menu" :aria-expanded="mobileMenuOpen.toString()">
                    <span class="sr-only">Open main menu</span>
                    <i class="fas fa-bars fa-lg" x-show="!mobileMenuOpen"></i>
                    <i class="fas fa-times fa-lg" x-show="mobileMenuOpen" style="display: none;"></i>
                </button>
            </div>
        </div>

        <div class="md:hidden" id="mobile-menu" x-show="mobileMenuOpen" @click.away="mobileMenuOpen = false"
             style="display: none;"
             x-transition:enter="transition ease-out duration-200"
             x-transition:enter-start="opacity-0 -translate-y-1"
             x-transition:enter-end="opacity-100 translate-y-0"
             x-transition:leave="transition ease-in duration-150"
             x-transition:leave-start="opacity-100 translate-y-0"
             x-transition:leave-end="opacity-0 -translate-y-1">
            <div class="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                <a href="<?php echo $app_url; ?>/showroom" class="text-gray-700 hover:bg-indigo-50 hover:text-indigo-700 block px-3 py-2 rounded-md text-base font-medium">Showroom</a>
                <?php if ($is_logged_in): ?>
                    <a href="<?php echo $app_url; ?>/closets" class="text-gray-700 hover:bg-indigo-50 hover:text-indigo-700 block px-3 py-2 rounded-md text-base font-medium">Closets</a>
                    <a href="<?php echo $app_url; ?>/boardroom" class="text-gray-700 hover:bg-indigo-50 hover:text-indigo-700 block px-3 py-2 rounded-md text-base font-medium">Boardroom</a>
                    <?php if ($user_role === 'supplier'): ?>
                        <a href="<?php echo $app_url; ?>/supplier/dashboard" class="text-gray-700 hover:bg-indigo-50 hover:text-indigo-700 block px-3 py-2 rounded-md text-base font-medium">Dashboard</a>
                    <?php endif; ?>
                    <hr class="my-2 border-gray-200">
                    <?php if ($username): ?>
                        <a href="<?php echo $app_url . '/profile/' . escape_html($username); ?>" class="text-gray-700 hover:bg-indigo-50 hover:text-indigo-700 block px-3 py-2 rounded-md text-base font-medium">Dashboard</a>
                    <?php endif; ?>
                    <a href="<?php echo $app_url; ?>/settings" class="text-gray-700 hover:bg-indigo-50 hover:text-indigo-700 block px-3 py-2 rounded-md text-base font-medium">Settings</a>
                    <a href="<?php echo $app_url; ?>/settings/notifications" class="text-gray-700 hover:bg-indigo-50 hover:text-indigo-700 block px-3 py-2 rounded-md text-base font-medium relative">
                        Notifications
                        <?php if ($is_logged_in && $unread_notification_count > 0): ?>
                            <span class="ml-2 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-red-100 bg-red-600 rounded-full"><?php echo $unread_notification_count; ?></span>
                        <?php endif; ?>
                    </a>
                    <a href="<?php echo $app_url; ?>/logout" class="text-gray-700 hover:bg-indigo-50 hover:text-indigo-700 block px-3 py-2 rounded-md text-base font-medium">Sign out</a>
                <?php else: // Not logged in (for mobile menu) ?>
                    <a href="<?php echo $app_url; ?>/login" class="text-gray-700 hover:bg-indigo-50 hover:text-indigo-700 block px-3 py-2 rounded-md text-base font-medium">Login</a>
                    <a href="<?php echo $app_url; ?>/register" class="text-gray-700 hover:bg-indigo-50 hover:text-indigo-700 block px-3 py-2 rounded-md text-base font-medium">Sign Up</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <main class="container mx-auto p-4 pb-24">
    