<?php
// File: app/Views/layouts/_footer.php
// Purpose: Defines the common footer and bottom navigation for the application.

// Determine active page for navigation highlighting (example)
// Ensure APP_URL is defined, otherwise default to '#' to prevent errors in href
$appUrlBase = defined('APP_URL') ? APP_URL : '#';

// Simplified route detection for active class - adjust if your routing is more complex
$requestPathForNav = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '/', '/');
$baseDirForNav = trim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');

$currentRoute = $requestPathForNav;
if (!empty($baseDirForNav) && strpos($requestPathForNav, $baseDirForNav) === 0) {
    $currentRoute = trim(substr($requestPathForNav, strlen($baseDirForNav)), '/');
}
$currentRouteParts = explode('/', $currentRoute);
$currentRouteBaseForNav = $currentRouteParts[0] ?: 'showroom'; // Default to showroom if empty

?>
    </main> <nav class="bottom-nav fixed bottom-0 left-0 right-0 h-[60px] bg-white shadow-lg flex justify-around items-center border-t border-gray-200 z-50">
        <a href="<?php echo $appUrlBase; ?>/showroom" class="flex flex-col items-center text-gray-600 hover:text-indigo-600 pt-1 <?php echo ($currentRouteBaseForNav === 'showroom') ? 'active text-indigo-600 font-semibold' : ''; ?>">
            <i class="fas fa-store fa-lg mb-1"></i>
            <span class="text-xs">Showroom</span>
        </a>
        <a href="<?php echo $appUrlBase; ?>/closets" class="flex flex-col items-center text-gray-600 hover:text-indigo-600 pt-1 <?php echo ($currentRouteBaseForNav === 'closets') ? 'active text-indigo-600 font-semibold' : ''; ?>">
            <i class="fas fa-user-tag fa-lg mb-1"></i>
            <span class="text-xs">Closets</span>
        </a>
        <a href="<?php echo $appUrlBase; ?>/upload" class="flex flex-col items-center text-gray-600 hover:text-indigo-600 pt-1 <?php echo ($currentRouteBaseForNav === 'upload') ? 'active text-indigo-600 font-semibold' : ''; ?>">
            <i class="fas fa-plus-square fa-lg mb-1"></i>
            <span class="text-xs">Upload</span>
        </a>
        <a href="<?php echo $appUrlBase; ?>/boardroom" class="flex flex-col items-center text-gray-600 hover:text-indigo-600 pt-1 <?php echo ($currentRouteBaseForNav === 'boardroom') ? 'active text-indigo-600 font-semibold' : ''; ?>">
            <i class="fas fa-comments fa-lg mb-1"></i>
            <span class="text-xs">Boardroom</span>
        </a>
        <a href="<?php echo $appUrlBase; ?>/profile" class="flex flex-col items-center text-gray-600 hover:text-indigo-600 pt-1 <?php echo ($currentRouteBaseForNav === 'profile') ? 'active text-indigo-600 font-semibold' : ''; ?>">
            <i class="fas fa-user-circle fa-lg mb-1"></i>
            <span class="text-xs">Profile</span>
        </a>
    </nav>
    <style>
    main {
    padding-bottom: 80px !important; /* Increased value and added !important for testing */
}
        .text-xs {
            font-size: 0.75rem; /* 12px */
            /* line-height: 2rem !important; /* This was 32px, quite large for 12px text. Consider adjusting if needed */
            line-height: 1rem; /* Adjusted for better proportion, or remove if icons dictate height */
        }
        /* Style for active navigation item */
        .bottom-nav a.active {
            /* color: #4f46e5; /* Indigo-600 if Tailwind isn't processing it for 'active' text color */
            /* font-weight: 600; */
        }
        /* Ensure icons and text are vertically aligned nicely if line-height of text-xs is changed */
        .bottom-nav a > i {
            /* margin-bottom: 0.125rem; /* Adjust if text line-height changes */
        }

        .text-xs {
    padding: 8px;
}
    </style>
    </body>
</html>