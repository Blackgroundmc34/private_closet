<?php
// File: app/Views/search/search_results_content.php
// Expected variables:
// $searchQuery (string) - The current search query.
// $products (array) - Array of product results.
// $totalProducts (int) - Total number of products found.
// $currentPage (int) - Current page number for pagination.
// $totalPages (int) - Total number of pages for pagination.
// $app_url (string) - Base application URL.

$searchQuery = $searchQuery ?? '';
$products = $products ?? [];
$totalProducts = $totalProducts ?? 0;
$currentPage = $currentPage ?? 1;
$totalPages = $totalPages ?? 1;

if (!function_exists('escape_html')) {
    function escape_html($string) { return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
if (!function_exists('format_price')) {
     function format_price(float $price, string $currencySymbol = 'R'): string { return $currencySymbol . number_format($price, 2, '.', ','); }
}

?>
<div class="container mx-auto px-4 py-8">
    <div class="mb-8 p-4 bg-white rounded-lg shadow-md">
        <form action="<?php echo htmlspecialchars($app_url . '/search'); ?>" method="GET" class="flex flex-col sm:flex-row gap-2">
            <label for="search-input" class="sr-only">Search Products</label>
            <input type="search" name="q" id="search-input" value="<?php echo escape_html($searchQuery); ?>" 
                   placeholder="Search for products, brands..."
                   class="flex-grow px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-gray-700" 
                   required>
            <button type="submit" 
                    class="px-6 py-2 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 ease-in-out">
                <i class="fas fa-search mr-2"></i>Search
            </button>
        </form>
    </div>

    <?php if (!empty($searchQuery)): ?>
        <div class="mb-6">
            <h1 class="text-2xl font-semibold text-gray-800">
                Search Results for "<?php echo escape_html($searchQuery); ?>"
            </h1>
            <p class="text-sm text-gray-600"><?php echo (int)$totalProducts; ?> product(s) found.</p>
        </div>

        <?php if (empty($products)): ?>
            <div class="text-center py-10 bg-white rounded-lg shadow-md">
                <i class="fas fa-search-minus fa-3x text-gray-400 mb-4"></i>
                <p class="text-gray-600 text-lg">No products found matching your search criteria.</p>
                <p class="text-sm text-gray-500 mt-2">Try different keywords or check your spelling.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                <?php foreach ($products as $product): ?>
                    <div class="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:scale-105 flex flex-col">
                        <a href="<?php echo htmlspecialchars($app_url . '/product/' . ($product['slug'] ?? $product['id'])); ?>" class="block">
                            <img src="<?php echo escape_html($product['image_url_full'] ?? ($app_url . '/assets/images/default_product_image.png')); ?>" 
                                 alt="<?php echo escape_html($product['name']); ?>" 
                                 class="w-full h-48 object-cover"
                                 onerror="this.onerror=null; this.src='<?php echo $app_url . '/assets/images/default_product_image.png'; ?>';">
                        </a>
                        <div class="p-4 flex flex-col flex-grow">
                            <h3 class="font-semibold text-md mb-1 truncate text-gray-800">
                                <a href="<?php echo htmlspecialchars($app_url . '/product/' . ($product['slug'] ?? $product['id'])); ?>" class="hover:text-indigo-600">
                                    <?php echo escape_html($product['name']); ?>
                                </a>
                            </h3>
                            <?php if (!empty($product['business_name'])): ?>
                                <p class="text-xs text-gray-500 mb-2">By <?php echo escape_html($product['business_name']); ?></p>
                            <?php endif; ?>
                            <p class="text-lg font-bold text-gray-900 mb-3 flex-grow"><?php echo format_price($product['price']); ?></p>
                            <div class="mt-auto">
                                <a href="<?php echo htmlspecialchars($app_url . '/product/' . ($product['slug'] ?? $product['id'])); ?>" class="w-full text-center block text-sm bg-indigo-500 text-white py-2 px-3 rounded hover:bg-indigo-600 transition duration-200">
                                    View Details
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php if ($totalPages > 1): ?>
                <nav class="mt-8 flex justify-center" aria-label="Page navigation">
                  <ul class="inline-flex items-center -space-x-px">
                    <li>
                      <a href="<?php echo htmlspecialchars($app_url . '/search?q=' . urlencode($searchQuery) . '&page=' . max(1, $currentPage - 1)); ?>"
                         class="py-2 px-3 ml-0 leading-tight text-gray-500 bg-white rounded-l-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 <?php echo ($currentPage <= 1) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                         Previous
                      </a>
                    </li>
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <?php
                            // Logic for displaying a limited number of page links with ellipses
                            $showPageLink = false;
                            if ($totalPages <= 7) { // Show all pages if 7 or less
                                $showPageLink = true;
                            } else {
                                // Always show first, last, current, and pages around current
                                if ($i == 1 || $i == $totalPages || ($i >= $currentPage - 1 && $i <= $currentPage + 1)) {
                                    $showPageLink = true;
                                } elseif (($i == $currentPage - 2 && $currentPage > 3) || ($i == $currentPage + 2 && $currentPage < $totalPages - 2)) {
                                    echo '<li><span class="py-2 px-3 leading-tight text-gray-500 bg-white border border-gray-300">...</span></li>';
                                }
                            }
                        ?>
                        <?php if ($showPageLink): ?>
                        <li>
                          <a href="<?php echo htmlspecialchars($app_url . '/search?q=' . urlencode($searchQuery) . '&page=' . $i); ?>"
                             class="py-2 px-3 leading-tight border border-gray-300 <?php echo ($i == $currentPage) ? 'text-indigo-600 bg-indigo-50 hover:bg-indigo-100 hover:text-indigo-700' : 'text-gray-500 bg-white hover:bg-gray-100 hover:text-gray-700'; ?>">
                             <?php echo $i; ?>
                          </a>
                        </li>
                        <?php endif; ?>
                    <?php endfor; ?>
                    <li>
                      <a href="<?php echo htmlspecialchars($app_url . '/search?q=' . urlencode($searchQuery) . '&page=' . min($totalPages, $currentPage + 1)); ?>"
                         class="py-2 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 <?php echo ($currentPage >= $totalPages) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                         Next
                      </a>
                    </li>
                  </ul>
                </nav>
            <?php endif; ?>

        <?php endif; ?>
    <?php else: ?>
        <div class="text-center py-10">
            <i class="fas fa-search fa-3x text-gray-400 mb-4"></i>
            <p class="text-gray-600 text-lg">Enter a search term above to find products.</p>
        </div>
    <?php endif; ?>
</div>
