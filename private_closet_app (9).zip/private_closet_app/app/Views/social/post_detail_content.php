<?php
// File: app/Views/social/post_detail_content.php
// Purpose: Displays a single post with details and comments.
// Expects $post, $comments, $isLoggedIn variables.

$post = $post ?? null; // Default to null if not passed
$comments = $comments ?? [];
$isLoggedIn = $isLoggedIn ?? false;

if (!$post) {
    echo "<p class='text-center text-red-500'>Error: Post data is missing.</p>";
    return; // Stop if no post data
}

?>

<div class="container mx-auto px-4 py-8 max-w-4xl">
    <div class="bg-white rounded-lg shadow-lg overflow-hidden md:flex">

        <div class="md:w-1/2 lg:w-3/5 flex-shrink-0 bg-black flex items-center justify-center">
            <?php if ($post['media_type'] === 'image'): ?>
                <img src="<?php echo escape_html($post['media_url'] ?? 'https://placehold.co/600x800/cccccc/ffffff?text=No+Media'); ?>"
                     alt="Post by <?php echo escape_html($post['username']); ?>"
                     class="max-h-[80vh] w-auto h-auto object-contain">
            <?php elseif ($post['media_type'] === 'video'): ?>
                <video controls class="max-h-[80vh] w-full h-auto">
                     <source src="<?php echo escape_html($post['media_url'] ?? ''); ?>" type="video/mp4">
                     Your browser does not support the video tag.
                 </video>
            <?php else: ?>
                 <div class="text-white p-10">Media type not supported or missing.</div>
            <?php endif; ?>
        </div>

        <div class="md:w-1/2 lg:w-2/5 flex flex-col">
            <div class="p-4 border-b border-gray-200 flex items-center justify-between">
                <a href="<?php echo defined('APP_URL') ? APP_URL : ''; ?>/profile/<?php echo escape_html($post['username']); ?>" class="flex items-center">
                    <img src="<?php echo escape_html($post['profile_picture_url'] ?? 'https://placehold.co/40x40/cccccc/ffffff?text=??'); ?>"
                         alt="<?php echo escape_html($post['username']); ?>'s profile picture"
                         class="w-8 h-8 rounded-full mr-3 object-cover border">
                    <span class="font-semibold text-sm text-gray-800 hover:underline"><?php echo escape_html($post['username']); ?></span>
                </a>
                <button class="text-gray-500 hover:text-gray-700">
                    <i class="fas fa-ellipsis-h"></i>
                </button>
            </div>

            <div class="flex-grow overflow-y-auto p-4 space-y-4 max-h-[calc(80vh-200px)] md:max-h-full">
                <div class="flex items-start space-x-3 mb-4">
                     <a href="<?php echo defined('APP_URL') ? APP_URL : ''; ?>/profile/<?php echo escape_html($post['username']); ?>">
                        <img src="<?php echo escape_html($post['profile_picture_url'] ?? 'https://placehold.co/40x40/cccccc/ffffff?text=??'); ?>"
                             alt="<?php echo escape_html($post['username']); ?>'s profile picture"
                             class="w-8 h-8 rounded-full object-cover border flex-shrink-0">
                    </a>
                    <div>
                        <p class="text-sm">
                            <a href="<?php echo defined('APP_URL') ? APP_URL : ''; ?>/profile/<?php echo escape_html($post['username']); ?>" class="font-semibold text-gray-800 hover:underline"><?php echo escape_html($post['username']); ?></a>
                            <?php echo nl2br(escape_html($post['description'] ?? '')); ?>
                        </p>
                         <p class="text-xs text-gray-500 mt-1" title="<?php echo escape_html($post['created_at']); ?>">
                             <?php // echo time_ago($post['created_at']); // Use a helper function for relative time ?>
                             <?php echo date('M j, Y', strtotime($post['created_at'])); ?>
                             <?php if (!empty($post['location'])): ?>
                                 <span> • <?php echo escape_html($post['location']); ?></span>
                             <?php endif; ?>
                         </p>
                    </div>
                </div>

                <hr class="my-3">

                <?php if (empty($comments)): ?>
                    <p class="text-sm text-gray-500 text-center py-4">No comments yet.</p>
                <?php else: ?>
                    <?php foreach ($comments as $comment): ?>
                    <div class="flex items-start space-x-3">
                        <a href="<?php echo defined('APP_URL') ? APP_URL : ''; ?>/profile/<?php echo escape_html($comment['username']); ?>" class="flex-shrink-0">
                            <img src="<?php echo escape_html($comment['profile_picture_url'] ?? 'https://placehold.co/40x40/cccccc/ffffff?text=??'); ?>"
                                 alt="<?php echo escape_html($comment['username']); ?>'s profile picture"
                                 class="w-8 h-8 rounded-full object-cover border">
                        </a>
                        <div>
                            <p class="text-sm">
                                <a href="<?php echo defined('APP_URL') ? APP_URL : ''; ?>/profile/<?php echo escape_html($comment['username']); ?>" class="font-semibold text-gray-800 hover:underline"><?php echo escape_html($comment['username']); ?></a>
                                <?php echo nl2br(escape_html($comment['comment_text'] ?? '')); ?>
                            </p>
                            <p class="text-xs text-gray-500 mt-1" title="<?php echo escape_html($comment['created_at']); ?>">
                                <?php // echo time_ago($comment['created_at']); ?>
                                <?php echo date('M j', strtotime($comment['created_at'])); ?>
                                </p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <div class="p-4 border-t border-gray-200">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex space-x-4">
                        <form action="<?php echo defined('APP_URL') ? APP_URL : ''; ?>/post/toggle-like" method="POST" class="inline">
                             <input type="hidden" name="post_id" value="<?php echo (int)$post['id']; ?>">
                             <button type="submit" class="text-gray-700 hover:text-red-500 disabled:opacity-50 disabled:hover:text-gray-700" <?php echo !$isLoggedIn ? 'disabled' : ''; ?>>
                                 <?php if($post['is_liked_by_user'] ?? false): ?>
                                     <i class="fas fa-heart text-red-500 text-xl"></i>
                                 <?php else: ?>
                                     <i class="far fa-heart text-xl"></i>
                                 <?php endif; ?>
                             </button>
                        </form>
                        <button onclick="document.getElementById('comment_text_input')?.focus()" class="text-gray-700 hover:text-gray-900 disabled:opacity-50" <?php echo !$isLoggedIn ? 'disabled' : ''; ?>>
                             <i class="far fa-comment text-xl"></i>
                        </button>
                        <button class="text-gray-700 hover:text-gray-900">
                             <i class="far fa-paper-plane text-xl"></i>
                         </button>
                    </div>
                    </div>
                <p class="text-sm font-semibold text-gray-800 mb-1"><?php echo (int)($post['like_count'] ?? 0); ?> likes</p>
                <p class="text-xs text-gray-500 uppercase" title="<?php echo escape_html($post['created_at']); ?>">
                     <?php // echo time_ago($post['created_at']); ?>
                     <?php echo date('F j, Y', strtotime($post['created_at'])); ?>
                </p>
            </div>

            <?php if ($isLoggedIn): ?>
            <div class="p-4 border-t border-gray-200">
                <form action="<?php echo defined('APP_URL') ? APP_URL : ''; ?>/post/add-comment" method="POST" class="flex items-center gap-2">
                    <input type="hidden" name="post_id" value="<?php echo (int)$post['id']; ?>">
                    <input type="text" id="comment_text_input" name="comment_text" placeholder="Add a comment..." required autocomplete="off"
                           class="flex-grow px-4 py-2 border-none focus:outline-none focus:ring-0 text-sm bg-transparent">
                    <button type="submit" class="text-indigo-600 hover:text-indigo-800 font-semibold text-sm disabled:opacity-50" disabled>Post</button>
                </form>
                 <script>
                    // Enable post button only when text is entered
                    const commentInput = document.getElementById('comment_text_input');
                    const commentSubmitBtn = commentInput.nextElementSibling;
                    commentInput.addEventListener('input', () => {
                        commentSubmitBtn.disabled = commentInput.value.trim() === '';
                    });
                 </script>
            </div>
            <?php endif; ?>

        </div>
    </div>
</div>
