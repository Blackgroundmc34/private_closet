<?php
// File: app/Views/social/upload_content.php
// Purpose: Contains the HTML form for uploading a new post.
// Assumes $pageTitle is set before including the header.
// Assumes helper functions like escape_html() are available.

// PHP: You would typically pass validation errors and old input data to this view
// $errors = $errors ?? [];
// $oldInput = $oldInput ?? [];

?>

<div class="container mx-auto px-4 py-8 max-w-2xl">
    <h1 class="text-2xl md:text-3xl font-bold text-gray-900 mb-6 text-center">Create New Post</h1>

    <div class="bg-white p-6 rounded-lg shadow-lg">
        <?php if (!empty($errors['general'])): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                <strong class="font-bold">Error!</strong>
                <span class="block sm:inline"><?php echo escape_html($errors['general']); ?></span>
            </div>
        <?php endif; ?>

        <form action="<?php echo defined('APP_URL') ? APP_URL : ''; ?>/post/create" method="POST" enctype="multipart/form-data" class="space-y-4">
            <div>
                <label for="media_file" class="block text-sm font-medium text-gray-700 mb-1">Select Image or Video:</label>
                <input type="file" id="media_file" name="media_file" required accept="image/*,video/mp4,video/quicktime"
                       class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 <?php echo !empty($errors['media_file']) ? 'border border-red-500 rounded-lg p-1' : ''; ?>">
                <p class="mt-1 text-xs text-gray-500">Max file size: 50MB. Supported formats: JPG, PNG, GIF, MP4, MOV.</p>
                <?php if (!empty($errors['media_file'])): ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo escape_html($errors['media_file']); ?></p>
                <?php endif; ?>
                <div id="media-preview" class="mt-4 border rounded-lg overflow-hidden max-w-sm mx-auto hidden">
                     <img id="image-preview" src="#" alt="Image Preview" class="max-w-full h-auto hidden">
                     <video id="video-preview" controls class="max-w-full h-auto hidden">
                         <source src="#" type="video/mp4"> Your browser does not support the video tag.
                     </video>
                 </div>
            </div>

            <div>
                <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Caption:</label>
                <textarea id="description" name="description" rows="4" placeholder="Write a caption..."
                          class="w-full px-3 py-2 border <?php echo !empty($errors['description']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"><?php echo escape_html($oldInput['description'] ?? ''); ?></textarea>
                 <?php if (!empty($errors['description'])): ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo escape_html($errors['description']); ?></p>
                <?php endif; ?>
            </div>

            <div>
                <label for="tag_products" class="block text-sm font-medium text-gray-700 mb-1">Tag Products (Optional):</label>
                <input type="text" id="tag_products" name="tag_products_search" placeholder="Search products purchased..."
                       class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                <div id="selected_products"></div>
            </div>

             <div>
                <label for="tag_users" class="block text-sm font-medium text-gray-700 mb-1">Tag People (Optional):</label>
                <input type="text" id="tag_users" name="tag_users_search" placeholder="Search users..."
                       class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                <div id="selected_users"></div>
            </div>

             <div>
                <label for="location" class="block text-sm font-medium text-gray-700 mb-1">Add Location (Optional):</label>
                <input type="text" id="location" name="location" placeholder="e.g., Sandton City"
                       value="<?php echo escape_html($oldInput['location'] ?? ''); ?>"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
            </div>

            <div>
                <label for="visibility" class="block text-sm font-medium text-gray-700 mb-1">Visibility:</label>
                <select id="visibility" name="visibility" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                    <option value="public" <?php echo (($oldInput['visibility'] ?? 'public') === 'public') ? 'selected' : ''; ?>>Public Closet</option>
                    <option value="followers" <?php echo (($oldInput['visibility'] ?? '') === 'followers') ? 'selected' : ''; ?>>Followers Only</option>
                    <option value="private" <?php echo (($oldInput['visibility'] ?? '') === 'private') ? 'selected' : ''; ?>>Private (Only You)</option>
                </select>
            </div>


            <div class="pt-4">
                <button type="submit" class="w-full inline-flex justify-center items-center px-6 py-3 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                    Share Post
                </button>
            </div>
        </form>
    </div>
    <script>
        // Basic image/video preview
        const mediaInput = document.getElementById('media_file');
        const previewContainer = document.getElementById('media-preview');
        const imagePreview = document.getElementById('image-preview');
        const videoPreview = document.getElementById('video-preview');
        const videoSource = videoPreview.querySelector('source');

        mediaInput.addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    if (file.type.startsWith('image/')) {
                        imagePreview.src = e.target.result;
                        imagePreview.classList.remove('hidden');
                        videoPreview.classList.add('hidden');
                        previewContainer.classList.remove('hidden');
                    } else if (file.type.startsWith('video/')) {
                        videoSource.src = e.target.result;
                        videoPreview.load(); // Important to load the new source
                        videoPreview.classList.remove('hidden');
                        imagePreview.classList.add('hidden');
                        previewContainer.classList.remove('hidden');
                    } else {
                         previewContainer.classList.add('hidden'); // Hide if not image/video
                    }
                }
                reader.readAsDataURL(file);
            } else {
                 previewContainer.classList.add('hidden');
            }
        });
    </script>
</div>
