<?php
// File: app/Views/social/closets_feed_content.php
// Purpose: Displays the feed of posts from followed users and a sidebar for friend suggestions.
// Expected variables:
// $posts (array) - Posts for the feed
// $loggedInUserId (int|null) - ID of the logged-in user
// $currentPage (int) - For post pagination
// $totalPages (int) - For post pagination
// $feedType (string) - Type of feed (though not explicitly used in this version's layout)
// NEW Expected variables for sidebar:
// $suggestedFriends (array) - List of users to suggest
// $csrf_token (string) - CSRF token for follow forms
// $default_avatar_full_url (string) - Full URL to the default avatar image

$app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
$posts = $posts ?? [];
$currentPage = $currentPage ?? 1;
$totalPages = $totalPages ?? 1;
$loggedInUserId = $loggedInUserId ?? null; // From UserController
$isLoggedIn = (bool)$loggedInUserId; // For JS, already in your original script

// Variables for the new sidebar
$suggestedFriends = $suggestedFriends ?? [];
$csrf_token = $csrf_token ?? ''; // Ensure this is passed from UserController
$default_avatar_path = $default_avatar_path ?? (defined('DEFAULT_AVATAR_PATH') ? DEFAULT_AVATAR_PATH : 'assets/images/default_avatar.png');
$default_avatar_full_url = $default_avatar_full_url ?? ($app_url . '/' . ltrim($default_avatar_path, '/'));


if (!function_exists('escape_html')) {
    function escape_html($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

// Using your existing time_ago_feed function definition
if (!function_exists('time_ago_feed')) {
    function time_ago_feed($datetime, $full = false) {
        if (!$datetime) return "N/A";
        try {
            $now = new DateTime;
            $ago = new DateTime($datetime);
            $diff = $now->diff($ago);
            $weeks = floor($diff->d / 7);
            $days = $diff->d % 7;
            $string = ['y' => 'year', 'm' => 'month', 'w' => 'week', 'd' => 'day', 'h' => 'hour', 'i' => 'minute', 's' => 'second'];
            $parts = [];
            if ($diff->y) $parts['y'] = $diff->y . ' ' . $string['y'] . ($diff->y > 1 ? 's' : '');
            if ($diff->m) $parts['m'] = $diff->m . ' ' . $string['m'] . ($diff->m > 1 ? 's' : '');
            if ($weeks)   $parts['w'] = $weeks . ' ' . $string['w'] . ($weeks > 1 ? 's' : '');
            if ($days)    $parts['d'] = $days . ' ' . $string['d'] . ($days > 1 ? 's' : '');
            if ($full || empty($parts) || ($diff->y == 0 && $diff->m == 0 && $weeks == 0 && $days == 0)) {
                if ($diff->h) $parts['h'] = $diff->h . ' ' . $string['h'] . ($diff->h > 1 ? 's' : '');
                if ($diff->i) $parts['i'] = $diff->i . ' ' . $string['i'] . ($diff->i > 1 ? 's' : '');
                if ($diff->s && count($parts) < 2) { $parts['s'] = $diff->s . ' ' . $string['s'] . ($diff->s > 1 ? 's' : ''); }
            }
            if (!$full) $parts = array_slice($parts, 0, 1);
            return $parts ? implode(', ', $parts) . ' ago' : 'just now';
        } catch (Exception $e) {
            error_log("Error in time_ago_feed: " . $e->getMessage() . " for datetime " . $datetime);
            return $datetime;
        }
    }
}
?>

<div class="container mx-auto px-4 py-8 lg:flex lg:gap-x-8 max-w-5xl">

    <main class="lg:w-2/3 space-y-6">
        <h1 class="text-2xl font-bold text-gray-800">Your Closets Feed</h1>

        <?php if (isset($_SESSION['flash_message'])): ?>
            <div class="mb-4 p-3 rounded-md <?php echo $_SESSION['flash_message']['type'] === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
                <?php echo escape_html($_SESSION['flash_message']['text']); ?>
            </div>
            <?php unset($_SESSION['flash_message']); ?>
        <?php endif; ?>

        <?php if (empty($posts)): ?>
            <div class="text-center py-10 bg-white p-6 rounded-lg shadow-md">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                    <path vector-effect="non-scaling-stroke" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.342 3.942A6.001 6.001 0 006 6H3a1 1 0 00-1 1v11a1 1 0 001 1h3m3.342-15.058A6.001 6.001 0 0112 2.25c1.503 0 2.888.562 3.942 1.492m-7.884 15.058A6.001 6.001 0 0012 21.75c1.503 0 2.888-.562 3.942-1.492m0 0H15a1 1 0 001-1V7a1 1 0 00-1-1h-3m-3.342 1.492A6.001 6.001 0 009 6m0 12v3m0 0a1 1 0 001 1h3a1 1 0 001-1v-3m0 0V9" />
                </svg>
                <h3 class="mt-2 text-sm font-medium text-gray-900">No posts in your feed yet.</h3>
                <p class="mt-1 text-sm text-gray-500">Follow some users to see their latest posts here.</p>
                </div>
        <?php else: ?>
            <?php foreach ($posts as $post): ?>
                <article class="bg-white shadow-md rounded-lg overflow-hidden">
                    <div class="p-4">
                        <div class="flex items-center mb-3">
                            <a href="<?php echo $app_url . '/profile/' . escape_html($post['author_username']); ?>">
                                <img class="h-10 w-10 rounded-full object-cover mr-3"
                                     src="<?php echo escape_html($post['author_profile_pic_full_url'] ?: $default_avatar_full_url); ?>"
                                     alt="<?php echo escape_html($post['author_username']); ?>'s profile picture"
                                     onerror="this.onerror=null; this.src='<?php echo $default_avatar_full_url; ?>';">
                            </a>
                            <div>
                                <a href="<?php echo $app_url . '/profile/' . escape_html($post['author_username']); ?>" class="font-semibold text-sm text-gray-800 hover:underline">
                                    <?php echo escape_html($post['author_username']); ?>
                                </a>
                                <a href="<?php echo $app_url . '/post/' . (int)$post['id']; ?>" class="block text-xs text-gray-500 hover:underline">
                                    <?php echo time_ago_feed($post['created_at']); ?>
                                </a>
                            </div>
                        </div>
                        <?php if (!empty($post['description'])): ?>
                            <p class="text-gray-700 text-sm mb-3"><?php echo nl2br(escape_html($post['description'])); ?></p>
                        <?php endif; ?>
                    </div>

                    <?php if (!empty($post['media_full_url'])): ?>
                        <a href="<?php echo $app_url . '/post/' . (int)$post['id']; ?>">
                            <?php if ($post['media_type'] === 'image'): ?>
                                <img class="w-full object-cover"
                                     src="<?php echo escape_html($post['media_full_url']); ?>"
                                     alt="Post image by <?php echo escape_html($post['author_username']); ?>"
                                     onerror="this.onerror=null; this.src='https://placehold.co/600x400/cccccc/ffffff?text=Image+Not+Found';">
                            <?php elseif ($post['media_type'] === 'video'): ?>
                                <video controls class="w-full bg-black max-h-[500px]">
                                    <source src="<?php echo escape_html($post['media_full_url']); ?>" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                            <?php endif; ?>
                        </a>
                    <?php endif; ?>

                    <div class="p-4 border-t border-gray-200">
                        <div class="flex items-center space-x-4 text-sm text-gray-500">
                             <button data-post-id="<?php echo (int)$post['id']; ?>"
                                    class="like-button flex items-center hover:text-red-500 focus:outline-none <?php echo ($post['is_liked_by_user'] ?? false) ? 'text-red-500' : ''; ?>">
                                <i class="<?php echo ($post['is_liked_by_user'] ?? false) ? 'fas' : 'far'; ?> fa-heart mr-1"></i>
                                <span class="like-count"><?php echo (int)($post['like_count'] ?? 0); ?></span> Likes
                            </button>
                            <a href="<?php echo $app_url . '/post/' . (int)$post['id'] . '#commentsSection-' . (int)$post['id']; ?>" class="flex items-center hover:text-indigo-500">
                                <i class="far fa-comment mr-1"></i>
                                <?php echo (int)($post['comment_count'] ?? 0); ?> Comments
                            </a>
                             <button class="share-button flex items-center hover:text-blue-500 focus:outline-none"
                                    data-url="<?php echo $app_url . '/post/' . (int)$post['id']; ?>"
                                    data-title="Check out this post by <?php echo escape_html($post['author_username']); ?>"
                                    data-text="<?php echo escape_html(substr(strip_tags($post['description'] ?? ''), 0, 100) . '...'); ?>">
                                <i class="fas fa-share-alt mr-1"></i> Share
                            </button>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>

            <?php if ($totalPages > 1): ?>
            <nav class="mt-8 flex justify-center" aria-label="Pagination">
                <ul class="inline-flex items-center -space-x-px">
                    <li>
                        <a href="<?php echo $app_url . '/closets?page=' . max(1, $currentPage - 1); ?>"
                           class="py-2 px-3 ml-0 leading-tight text-gray-500 bg-white rounded-l-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 <?php echo ($currentPage <= 1) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                            Previous
                        </a>
                    </li>
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li>
                            <a href="<?php echo $app_url . '/closets?page=' . $i; ?>"
                               class="py-2 px-3 leading-tight border border-gray-300 <?php echo ($i == $currentPage) ? 'text-indigo-600 bg-indigo-50 hover:bg-indigo-100 hover:text-indigo-700' : 'text-gray-500 bg-white hover:bg-gray-100 hover:text-gray-700'; ?>">
                                <?php echo $i; ?>
                            </a>
                        </li>
                    <?php endfor; ?>
                    <li>
                        <a href="<?php echo $app_url . '/closets?page=' . min($totalPages, $currentPage + 1); ?>"
                           class="py-2 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 <?php echo ($currentPage >= $totalPages) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                            Next
                        </a>
                    </li>
                </ul>
            </nav>
            <?php endif; ?>
        <?php endif; ?>
    </main>

    <aside class="lg:w-1/3 mt-8 lg:mt-0 lg:sticky lg:top-20 self-start"> 
        <div class="bg-white p-4 rounded-lg shadow-md">
            <h2 class="text-lg font-semibold text-gray-700 mb-3 pb-2 border-b">People You May Know</h2>
            <?php if (!empty($suggestedFriends)): ?>
                <div class="space-y-4">
                    <?php foreach ($suggestedFriends as $sFriend): ?>
                        <?php
                            $sFriendUsername = escape_html($sFriend['username'] ?? 'user');
                            $sFriendFullName = escape_html($sFriend['full_name'] ?? '');
                            $sFriendProfilePicPath = $sFriend['profile_picture_url'] ?? null;
                            $sFriendProfilePicFullUrl = $sFriendProfilePicPath
                                ? ($app_url . '/' . ltrim(escape_html($sFriendProfilePicPath), '/'))
                                : $default_avatar_full_url;
                        ?>
                        <div class="flex items-center justify-between">
                            <a href="<?php echo $app_url . '/profile/' . $sFriendUsername; ?>" class="flex items-center space-x-3 group">
                                <img class="h-10 w-10 rounded-full object-cover border border-gray-200 group-hover:border-indigo-400"
                                     src="<?php echo $sFriendProfilePicFullUrl; ?>"
                                     alt="<?php echo $sFriendUsername; ?>'s profile picture"
                                     onerror="this.onerror=null; this.src='<?php echo $default_avatar_full_url; ?>';">
                                <div>
                                    <p class="text-sm font-semibold text-gray-800 group-hover:text-indigo-600"><?php echo $sFriendUsername; ?></p>
                                    <?php if ($sFriendFullName): ?>
                                        <p class="text-xs text-gray-500"><?php echo $sFriendFullName; ?></p>
                                    <?php endif; ?>
                                </div>
                            </a>
                            <form action="<?php echo $app_url . '/user/' . $sFriendUsername . '/follow'; ?>" method="POST">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                <button type="submit" class="px-3 py-1.5 bg-indigo-500 text-white text-xs font-medium rounded-md hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-1 transition-colors">
                                    Follow
                                </button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="mt-5 pt-3 border-t text-center">
                    <a href="<?php echo $app_url . '/explore/users'; // Link to a dedicated user discovery page ?>"
                       class="text-sm text-indigo-600 hover:text-indigo-800 font-semibold">
                        Find More People <i class="fas fa-arrow-right ml-1"></i>
                    </a>
                </div>
            <?php else: ?>
                <p class="text-sm text-gray-500">No suggestions at the moment.</p>
                 <div class="mt-4 text-center">
                    <a href="<?php echo $app_url . '/explore/users'; ?>"
                       class="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500">
                        <i class="fas fa-search mr-2"></i>Explore Users
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </aside>

</div>

<script>
// Your existing JavaScript for like and share buttons (should remain the same)
document.addEventListener('DOMContentLoaded', function() {
    const appUrl = <?php echo json_encode($app_url ?? ''); ?>;
    const loggedInUserId = <?php echo json_encode($loggedInUserId ?? null); ?>;
    const csrfToken = <?php echo json_encode($csrf_token ?? ''); ?>; // Make CSRF available to JS

    document.querySelectorAll('.like-button').forEach(button => {
        button.addEventListener('click', function() {
            if (!loggedInUserId) {
                window.location.href = `${appUrl}/login?redirect_to=${encodeURIComponent(window.location.href)}`;
                return;
            }
            const postId = this.dataset.postId;
            fetch(`${appUrl}/post/${postId}/toggle-like`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken },
                // body: JSON.stringify({}) // If needed
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    const likeCountSpan = this.querySelector('.like-count');
                    const heartIcon = this.querySelector('i');
                    likeCountSpan.textContent = data.like_count;
                    if(data.liked) {
                        heartIcon.classList.remove('far'); heartIcon.classList.add('fas');
                        this.classList.add('text-red-500');
                    } else {
                        heartIcon.classList.remove('fas'); heartIcon.classList.add('far');
                        this.classList.remove('text-red-500');
                    }
                } else { console.warn("Like toggle failed:", data.message); }
            })
            .catch(error => console.error('Error liking post:', error));
        });
    });

    document.querySelectorAll('.share-button').forEach(button => {
        button.addEventListener('click', function() {
            const url = this.dataset.url;
            const title = this.dataset.title;
            const text = this.dataset.text;
            if (navigator.share) {
                navigator.share({ title: title, text: text, url: url })
                    .then(() => console.log('Successful share'))
                    .catch((error) => console.log('Error sharing', error));
            } else {
                prompt("Copy this link to share:", url);
            }
        });
    });
});
</script>