<?php
// File: app/Views/social/boardroom_content.php
// Assumes the following variables are passed from the controller/page script:
// $loggedInUserId (int)
// $conversations (array)
// $selectedConversationId (int|null)
// $messages (array)
// $recipient (array|null)
// $appUrl (string) - CRITICAL FOR JS
// $flashMessage (array|null)
// $initialLastMessageTimestamp (int) - CRITICAL FOR JS
// NEW Expected: $default_avatar_full_url (string) for search results modal

$appUrl = $appUrl ?? (defined('APP_URL') ? rtrim(APP_URL, '/') : '');
$loggedInUserId = $loggedInUserId ?? null;
$conversations = $conversations ?? [];
$selectedConversationId = $selectedConversationId ?? null;
$messages = $messages ?? [];
$recipient = $recipient ?? null;
$flashMessage = $flashMessage ?? null;
$initialLastMessageTimestamp = $initialLastMessageTimestamp ?? 0;

// For user search modal results - ensure this is passed from your controller or defined globally
$default_avatar_path = $default_avatar_path ?? (defined('DEFAULT_AVATAR_PATH') ? DEFAULT_AVATAR_PATH : 'assets/images/default_avatar.png');
$default_avatar_full_url = $default_avatar_full_url ?? ($appUrl . '/' . ltrim($default_avatar_path, '/'));


// Ensure escape_html() is globally available
if (!function_exists('escape_html')) {
    function escape_html($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
?>

<div class="container mx-auto h-[calc(100vh-120px)] flex" id="boardroomApp">
    <div class="w-1/3 lg:w-1/4 h-full bg-white border-r border-gray-200 flex flex-col">
        <div class="p-4 border-b border-gray-200 flex justify-between items-center">
            <h2 class="text-lg font-semibold text-gray-800">Boardroom Chats</h2>
            <button id="openStartConversationModalButton" title="Start New Conversation" class="p-2 text-gray-600 hover:text-indigo-600">
                <i class="fas fa-edit"></i>
            </button>
        </div>

        <div class="flex-grow overflow-y-auto" id="conversationList">
            <?php if (empty($conversations)): ?>
                <p class="text-center text-gray-500 p-4">No conversations yet. Click the <i class="fas fa-edit"></i> icon to start one!</p>
            <?php else: ?>
                <?php foreach ($conversations as $convo): ?>
                    <a href="<?php echo escape_html($appUrl . '/boardroom?conversation_id=' . $convo['conversation_id']); ?>"
                       class="conversation-item flex items-center p-3 hover:bg-gray-100 cursor-pointer border-b border-gray-100 last:border-b-0 <?php echo ($convo['conversation_id'] == $selectedConversationId) ? 'bg-indigo-50 selected' : ''; ?>"
                       data-conversation-id="<?php echo (int)$convo['conversation_id']; ?>">
                        <img src="<?php echo escape_html($convo['recipient_profile_pic'] ?: $default_avatar_full_url); // Use default avatar if pic is missing ?>"
                             alt="<?php echo escape_html($convo['recipient_username'] ?? 'User'); ?>" class="w-10 h-10 rounded-full mr-3 object-cover">
                        <div class="flex-grow overflow-hidden">
                            <div class="flex justify-between items-center">
                                <span class="font-semibold text-sm text-gray-800 truncate recipient-username"><?php echo escape_html($convo['recipient_username'] ?? 'Unknown User'); ?></span>
                                <span class="text-xs text-gray-500 flex-shrink-0 ml-2 last-message-time">
                                    <?php
                                    if (!empty($convo['last_message_at'])) {
                                        try {
                                            $date = new DateTime($convo['last_message_at']);
                                            if ($date->format('Y-m-d') == date('Y-m-d')) { echo $date->format('h:i A'); }
                                            elseif ($date->format('Y-m-d') == date('Y-m-d', strtotime('-1 day'))) { echo 'Yesterday'; }
                                            else { echo $date->format('M d'); }
                                        } catch (Exception $e) { /* Gracefully handle */ }
                                    }
                                    ?>
                                </span>
                            </div>
                            <div class="flex justify-between items-center">
                                <p class="text-sm text-gray-600 truncate last-message-preview"><?php echo escape_html($convo['last_message_text'] ?? 'No messages yet.'); ?></p>
                                <?php if (($convo['unread_count'] ?? 0) > 0): ?>
                                    <span class="unread-count-badge ml-2 bg-red-500 text-white text-xs font-bold rounded-full px-1.5 py-0.5 flex-shrink-0"><?php echo (int)$convo['unread_count']; ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="w-2/3 lg:w-3/4 h-full bg-gray-50 flex flex-col">
        <?php if (!$selectedConversationId || !$recipient): ?>
            <div id="messagePanelPlaceholder" class="flex-grow flex flex-col items-center justify-center text-gray-500 p-6">
                <i class="far fa-comments fa-4x mb-4 text-gray-300"></i>
                <h3 class="text-xl font-semibold mb-2">Boardroom</h3>
                <p class="text-center">Select a conversation from the list to view messages,<br>or click the <i class="fas fa-edit"></i> icon to start a new chat.</p>
                <?php if ($flashMessage && is_array($flashMessage) && isset($flashMessage['text'])): ?>
                <p class="mt-4 p-3 rounded-md <?php echo ($flashMessage['type'] === 'error' ? 'bg-red-100 text-red-700' : ($flashMessage['type'] === 'success' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700')); ?>">
                    <?php echo escape_html($flashMessage['text']); ?>
                </p>
                <?php endif; ?>
            </div>
            <div id="messagePanelActive" class="h-full flex-col hidden"> </div>
        <?php endif; ?>

        <?php if ($selectedConversationId && $recipient): ?>
            <div id="messagePanelActiveContent" class="h-full flex flex-col">
                <div class="p-4 border-b border-gray-200 bg-white flex items-center shadow-sm">
                     <img src="<?php echo escape_html($recipient['profile_picture_url'] ?: $default_avatar_full_url); // Use default avatar ?>"
                          alt="<?php echo escape_html($recipient['username'] ?? 'User'); ?>" class="w-8 h-8 rounded-full mr-3 object-cover">
                     <h3 class="font-semibold text-gray-800" id="chatRecipientName"><?php echo escape_html($recipient['username'] ?? 'Select Chat'); ?></h3>
                </div>

                <div class="flex-grow overflow-y-auto p-4 space-y-4" id="messagesArea">
                    <?php if (empty($messages)): ?>
                        <div class="text-center text-gray-400 py-8 no-messages-placeholder">No messages in this conversation yet. Send one!</div>
                    <?php else: ?>
                        <?php foreach ($messages as $message): ?>
                            <?php $isOwnMessage = (isset($message['sender_user_id']) && $message['sender_user_id'] == $loggedInUserId); ?>
                            <div class="flex <?php echo $isOwnMessage ? 'justify-end' : 'justify-start'; ?>" data-message-id="<?php echo (int)($message['message_id'] ?? 0); ?>">
                                <div class="message-bubble max-w-xs lg:max-w-md px-4 py-2 rounded-lg <?php echo $isOwnMessage ? 'bg-indigo-500 text-white' : 'bg-white text-gray-800 shadow-sm'; ?>">
                                    <p><?php echo nl2br(escape_html($message['message_text'] ?? '')); ?></p>
                                    <span class="text-xs opacity-75 block <?php echo $isOwnMessage ? 'text-indigo-200' : 'text-gray-500';?> text-right mt-1">
                                        <?php
                                        if (!empty($message['created_at'])) {
                                            try { $msgDate = new DateTime($message['created_at']); echo $msgDate->format('h:i A'); }
                                            catch (Exception $e) { /* Handle error */ }
                                        }
                                        ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <div class="p-4 border-t border-gray-200 bg-white">
                    <form id="sendMessageForm" class="flex items-center gap-2">
                         <input type="hidden" name="conversation_id" id="formConversationId" value="<?php echo (int)($selectedConversationId ?? 0); ?>">
                         <button type="button" class="p-2 text-gray-500 hover:text-indigo-600" title="Attach File (Not Implemented)">
                             <i class="fas fa-paperclip"></i>
                         </button>
                         <input type="text" name="message_text" id="messageInput" placeholder="Type your message..." required autocomplete="off"
                                class="flex-grow px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 text-sm">
                         <button type="submit" id="sendMessageButton" class="px-4 py-2 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-indigo-500">
                             <i class="fas fa-paper-plane"></i>
                         </button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<div id="startConversationModal" class="fixed inset-0 bg-gray-800 bg-opacity-75 flex items-center justify-center z-[1000]" style="display: none;">
    <div class="bg-white p-5 sm:p-6 rounded-lg shadow-xl w-11/12 md:max-w-md mx-auto transform transition-all duration-300 ease-out scale-95 opacity-0" id="startConversationModalContent">
        <div class="flex justify-between items-center mb-4 pb-3 border-b">
            <h3 class="text-xl font-semibold text-gray-800">Start New Conversation</h3>
            <button id="closeStartConversationModalButton" class="text-gray-400 hover:text-gray-600 text-2xl focus:outline-none">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div>
            <label for="searchUserInput" class="block text-sm font-medium text-gray-700 mb-1">Search by username:</label>
            <div class="relative">
                <input type="text" id="searchUserInput" name="search_username" placeholder="Enter username..."
                       class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">
                <i class="fas fa-spinner fa-spin absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hidden" id="searchUserSpinner"></i>
            </div>
            <div id="searchResultsContainer" class="mt-3 max-h-60 overflow-y-auto border rounded-md divide-y">
                <p class="p-3 text-sm text-gray-400 text-center hidden" id="searchNoResults">No users found.</p>
                <p class="p-3 text-sm text-gray-400 text-center" id="searchInitialMessage">Start typing to find users.</p>
            </div>
        </div>
        <div class="mt-5 text-right">
            <button id="cancelStartConversationModalButton" type="button" class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-indigo-500">
                Cancel
            </button>
        </div>
    </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', function () {
    const appUrl = <?php echo json_encode($appUrl ?? ''); ?>;
    const loggedInUserId = <?php echo json_encode($loggedInUserId ?? null); ?>;
    const defaultAvatarFullUrl = <?php echo json_encode($default_avatar_full_url ?? ''); ?>;
    let selectedConversationId = <?php echo json_encode($selectedConversationId ?? null); ?>;
    let lastMessageTimestamp = selectedConversationId ? <?php echo json_encode($initialLastMessageTimestamp ?? 0); ?> : 0;

    const messagesArea = document.getElementById('messagesArea');
    const messageInput = document.getElementById('messageInput');
    const sendMessageForm = document.getElementById('sendMessageForm');
    const conversationListEl = document.getElementById('conversationList');
    // const newMessageButton = document.getElementById('newMessageButton'); // Old button ID
    const messagePanelPlaceholder = document.getElementById('messagePanelPlaceholder');
    const messagePanelActiveContent = document.getElementById('messagePanelActiveContent');

    // --- New Conversation Modal Elements ---
    const openStartConversationModalButton = document.getElementById('openStartConversationModalButton'); // Updated ID
    const startConversationModal = document.getElementById('startConversationModal');
    const startConversationModalContent = document.getElementById('startConversationModalContent');
    const closeStartConversationModalButton = document.getElementById('closeStartConversationModalButton');
    const cancelStartConversationModalButton = document.getElementById('cancelStartConversationModalButton');
    const searchUserInput = document.getElementById('searchUserInput');
    const searchResultsContainer = document.getElementById('searchResultsContainer');
    const searchUserSpinner = document.getElementById('searchUserSpinner');
    const searchNoResults = document.getElementById('searchNoResults');
    const searchInitialMessage = document.getElementById('searchInitialMessage');
    let searchTimeout = null;

    console.log('Boardroom JS Initialized. APP_URL:', appUrl, 'SelectedConvoID:', selectedConversationId, 'UserID:', loggedInUserId, 'InitialLastTS:', lastMessageTimestamp);

    if (!appUrl || !loggedInUserId) {
        console.error("Boardroom JS critical error: appUrl or loggedInUserId is not set.", {appUrl, loggedInUserId});
        if(messagePanelPlaceholder) messagePanelPlaceholder.innerHTML = "<p class='text-red-500 p-4'>Critical error: Application configuration missing. Cannot initialize chat.</p>";
        if(messagePanelActiveContent) messagePanelActiveContent.classList.add('hidden');
        return; 
    }

    function escapeHtmlJS(unsafe) {
        if (unsafe === null || typeof unsafe === 'undefined') return '';
        return String(unsafe).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }

    function scrollToBottom() {
        if (messagesArea) { messagesArea.scrollTop = messagesArea.scrollHeight; }
    }

    if (selectedConversationId && messagePanelActiveContent) {
        messagePanelActiveContent.classList.remove('hidden');
        if (messagePanelPlaceholder) messagePanelPlaceholder.classList.add('hidden');
        scrollToBottom();
    } else if (messagePanelPlaceholder) {
        messagePanelPlaceholder.classList.remove('hidden');
        if (messagePanelActiveContent) messagePanelActiveContent.classList.add('hidden');
    }

    // --- Modal Logic ---
    function openModal(modalElement, modalContentElement) {
        if (!modalElement || !modalContentElement) return;
        modalElement.style.display = 'flex';
        setTimeout(() => { 
            modalContentElement.style.opacity = '1';
            modalContentElement.style.transform = 'scale(1)';
        }, 10);
    }

    function closeModal(modalElement, modalContentElement) {
        if (!modalElement || !modalContentElement) return;
        modalContentElement.style.opacity = '0';
        modalContentElement.style.transform = 'scale(0.95)';
        setTimeout(() => {
            modalElement.style.display = 'none';
        }, 300); 
    }

    if (openStartConversationModalButton && startConversationModal && startConversationModalContent) {
        openStartConversationModalButton.addEventListener('click', function() {
            searchUserInput.value = '';
            searchResultsContainer.innerHTML = ''; 
            searchInitialMessage.classList.remove('hidden');
            searchNoResults.classList.add('hidden');
            openModal(startConversationModal, startConversationModalContent);
            searchUserInput.focus();
        });
    }
    if (closeStartConversationModalButton) {
        closeStartConversationModalButton.addEventListener('click', () => closeModal(startConversationModal, startConversationModalContent));
    }
    if (cancelStartConversationModalButton) {
        cancelStartConversationModalButton.addEventListener('click', () => closeModal(startConversationModal, startConversationModalContent));
    }
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape' && startConversationModal && startConversationModal.style.display === 'flex') {
            closeModal(startConversationModal, startConversationModalContent);
        }
    });
    if (startConversationModal) {
        startConversationModal.addEventListener('click', function(event) {
            if (event.target === startConversationModal) {
                closeModal(startConversationModal, startConversationModalContent);
            }
        });
    }

    // --- User Search in Modal ---
    if (searchUserInput) {
        searchUserInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            const searchTerm = this.value.trim();

            searchInitialMessage.classList.add('hidden');
            searchNoResults.classList.add('hidden');
            searchResultsContainer.innerHTML = ''; 

            if (searchTerm.length < 1) { // Start searching from 1 character
                if(searchTerm.length === 0) searchInitialMessage.classList.remove('hidden');
                searchUserSpinner.classList.add('hidden');
                return;
            }

            searchUserSpinner.classList.remove('hidden');

            searchTimeout = setTimeout(() => {
                fetch(`${appUrl}/users/search?username=${encodeURIComponent(searchTerm)}`) // Ensure this endpoint exists
                    .then(response => {
                        searchUserSpinner.classList.add('hidden');
                        if (!response.ok) {
                            throw new Error('Network response was not ok while searching users.');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success && Array.isArray(data.users)) {
                            renderSearchResults(data.users);
                        } else {
                            renderSearchResults([]); // Show no results message if data is not as expected
                            console.warn("User search did not return success or users array:", data);
                        }
                    })
                    .catch(error => {
                        console.error('Error searching users:', error);
                        searchResultsContainer.innerHTML = '<p class="p-3 text-sm text-red-500 text-center">Error searching users. Please try again.</p>';
                    });
            }, 300); // Debounce time: 300ms
        });
    }

    function renderSearchResults(users) {
        searchResultsContainer.innerHTML = ''; 
        if (users.length === 0) {
            searchNoResults.classList.remove('hidden');
            return;
        }
        searchNoResults.classList.add('hidden');

        users.forEach(user => {
            if (user.id == loggedInUserId) return; 

            // User profile_picture_full_url should be provided by the backend directly
            const userProfilePic = user.profile_picture_full_url || defaultAvatarFullUrl; 
            const userElement = document.createElement('div');
            userElement.className = 'p-3 hover:bg-gray-100 cursor-pointer flex items-center space-x-3';
            userElement.innerHTML = `
                <img src="${escapeHtmlJS(userProfilePic)}" alt="${escapeHtmlJS(user.username)}" class="w-10 h-10 rounded-full object-cover">
                <div>
                    <p class="text-sm font-semibold text-gray-700">${escapeHtmlJS(user.username)}</p>
                    ${user.full_name ? `<p class="text-xs text-gray-500">${escapeHtmlJS(user.full_name)}</p>` : ''}
                </div>
            `;
            userElement.addEventListener('click', function() {
                window.location.href = `${appUrl}/boardroom?start_with_user=${user.id}`;
                closeModal(startConversationModal, startConversationModalContent); 
            });
            searchResultsContainer.appendChild(userElement);
        });
    }
    
    // The old prompt-based newMessageButton logic should be removed.
    // The `openStartConversationModalButton` now handles opening the modal.

    // --- Existing message sending and polling logic ---
    if (sendMessageForm) {
        sendMessageForm.addEventListener('submit', function (e) {
            e.preventDefault();
            if (!selectedConversationId) { alert("Please select a conversation."); return; }
            const currentConvoIdInput = document.getElementById('formConversationId');
            if (currentConvoIdInput.value != selectedConversationId) {
                alert("Conversation ID mismatch. Please refresh."); return;
            }
            const messageText = messageInput.value.trim();
            if (!messageText) return;
            const formData = new FormData();
            formData.append('message_text', messageText);
            formData.append('conversation_id', selectedConversationId);
            const sendButton = document.getElementById('sendMessageButton');
            if(sendButton) sendButton.disabled = true;

            fetch(`${appUrl}/boardroom/send`, { method: 'POST', body: formData })
            .then(response => {
                if (!response.ok) {
                    return response.text().then(text => { throw new Error(`Server responded with ${response.status} ${response.statusText}. Response: ${text.substring(0,500)}`); });
                }
                return response.json();
            })
            .then(data => {
                if (data.success && data.data) {
                    appendMessage(data.data);
                    messageInput.value = '';
                    if (data.data.message_timestamp > lastMessageTimestamp) {
                        lastMessageTimestamp = data.data.message_timestamp;
                    }
                    updateConversationListPreview(selectedConversationId, data.data.message_text, data.data.message_timestamp, true);
                } else {
                    alert('Error: ' + (data.message || 'Could not send message.'));
                }
            })
            .catch(error => {
                console.error('Fetch error during send:', error);
                alert(`Failed to send message. ${error.message}.`);
            })
            .finally(() => {
                if(sendButton) sendButton.disabled = false;
                if(messageInput) messageInput.focus();
            });
        });
    }

    function appendMessage(message) {
        if (!messagesArea || !loggedInUserId) return;
        const placeholder = messagesArea.querySelector('.no-messages-placeholder');
        if (placeholder) placeholder.remove();
        const isOwnMessage = (message.sender_user_id == loggedInUserId);
        const messageId = message.message_id || ('temp-' + Date.now());
        if(document.querySelector(`.flex[data-message-id="${messageId}"]`)) return;

        const outerDiv = document.createElement('div');
        outerDiv.classList.add('flex', isOwnMessage ? 'justify-end' : 'justify-start');
        outerDiv.dataset.messageId = messageId;
        const bubbleDiv = document.createElement('div');
        bubbleDiv.classList.add('message-bubble', 'max-w-xs', 'lg:max-w-md', 'px-4', 'py-2', 'rounded-lg');
        bubbleDiv.classList.toggle('bg-indigo-500', isOwnMessage);
        bubbleDiv.classList.toggle('text-white', isOwnMessage);
        bubbleDiv.classList.toggle('bg-white', !isOwnMessage);
        bubbleDiv.classList.toggle('text-gray-800', !isOwnMessage);
        bubbleDiv.classList.toggle('shadow-sm', !isOwnMessage);
        const textP = document.createElement('p');
        textP.innerHTML = escapeHtmlJS(message.message_text || '').replace(/\n/g, '<br>');
        const timeSpan = document.createElement('span');
        timeSpan.classList.add('text-xs', 'opacity-75', 'block', 'text-right', 'mt-1');
        timeSpan.classList.toggle('text-indigo-200', isOwnMessage);
        timeSpan.classList.toggle('text-gray-500', !isOwnMessage);
        let msgDate;
        if (message.created_at && typeof message.created_at === 'string') {
            msgDate = new Date(message.created_at.replace(' ', 'T')+'Z');
        } else if (message.message_timestamp) {
            msgDate = new Date(message.message_timestamp * 1000);
        } else { msgDate = new Date(); }
        timeSpan.textContent = msgDate.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true });
        bubbleDiv.appendChild(textP);
        bubbleDiv.appendChild(timeSpan);
        outerDiv.appendChild(bubbleDiv);
        messagesArea.appendChild(outerDiv);
        scrollToBottom();
    }

    function fetchNewMessages() {
        if (!selectedConversationId || document.hidden || !appUrl) return;
        fetch(`${appUrl}/boardroom/ajax/messages?conversation_id=${selectedConversationId}&last_timestamp=${lastMessageTimestamp}`)
        .then(response => {
            if (!response.ok) { return response.text().then(text => { throw new Error(`Server responded with ${response.status} ${response.statusText} to ajax/messages. Response: ${text.substring(0,300)}`); }); }
            return response.json();
        })
        .then(data => {
            if (data.success && data.data && data.data.length > 0) {
                data.data.forEach(msg => {
                    appendMessage(msg);
                    if (msg.message_timestamp > lastMessageTimestamp) { lastMessageTimestamp = msg.message_timestamp; }
                });
            }
        })
        .catch(error => console.error('Error fetching new messages:', error.message));
    }

    let messagePollingInterval;
    function startMessagePolling() {
        if (messagePollingInterval) clearInterval(messagePollingInterval);
        if (selectedConversationId) {
            fetchNewMessages();
            messagePollingInterval = setInterval(fetchNewMessages, 7000);
        }
    }
    if (selectedConversationId) { startMessagePolling(); }

    function updateConversationListPreview(conversationId, messageText, messageTimestamp, isOwnMessage) {
        if (!conversationListEl) return;
        const convoItem = conversationListEl.querySelector(`.conversation-item[data-conversation-id="${conversationId}"]`);
        if (convoItem) {
            const previewEl = convoItem.querySelector('.last-message-preview');
            const timeEl = convoItem.querySelector('.last-message-time');
            const unreadBadge = convoItem.querySelector('.unread-count-badge');
            if (previewEl) previewEl.textContent = (isOwnMessage ? "You: " : "") + escapeHtmlJS(messageText).substring(0, 25) + (messageText.length > 25 ? "..." : "");
            if (timeEl) {
                const date = new Date(messageTimestamp * 1000);
                const today = new Date(); const yesterday = new Date(today); yesterday.setDate(yesterday.getDate() - 1);
                if (date.toDateString() === today.toDateString()) { timeEl.textContent = date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true }); }
                else if (date.toDateString() === yesterday.toDateString()) { timeEl.textContent = 'Yesterday'; }
                else { timeEl.textContent = date.toLocaleDateString([], { month: 'short', day: 'numeric' });}
            }
            if (isOwnMessage && unreadBadge) { unreadBadge.style.display = 'none'; }
            if (conversationListEl.firstChild !== convoItem) { conversationListEl.insertBefore(convoItem, conversationListEl.firstChild); }
        }
    }

    function fetchConversationUpdates() {
        if (document.hidden || !appUrl) return;
        fetch(`${appUrl}/boardroom/ajax/conversations`)
        .then(response => {
            if (!response.ok) { return response.text().then(text => { throw new Error(`Server responded with ${response.status} ${response.statusText} to ajax/conversations. Response: ${text.substring(0,300)}`); });}
            return response.json();
        })
        .then(data => {
            if (data.success && Array.isArray(data.data)) { renderConversationList(data.data); }
            else { console.warn("Received non-array or unsuccessful response for conversations list: ", data); }
        })
        .catch(error => console.error('Error fetching conversations list:', error.message));
    }

    function renderConversationList(convosData) {
        if (!conversationListEl) return;
        let html = '';
        if (!convosData || convosData.length === 0) {
            html = `<p class="text-center text-gray-500 p-4">No conversations yet. Click the <i class="fas fa-edit"></i> icon to start one!</p>`;
        } else {
            convosData.forEach(convo => {
                let lastMessageTimeFormatted = '';
                if (convo.last_message_at) {
                    try {
                        const date = new Date(convo.last_message_at.replace(' ', 'T')+'Z');
                        const today = new Date(); const yesterday = new Date(today); yesterday.setDate(yesterday.getDate() - 1);
                        if (date.toDateString() === today.toDateString()) { lastMessageTimeFormatted = date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true }); }
                        else if (date.toDateString() === yesterday.toDateString()) { lastMessageTimeFormatted = 'Yesterday'; }
                        else { lastMessageTimeFormatted = date.toLocaleDateString([], { month: 'short', day: 'numeric' });}
                    } catch (e) { lastMessageTimeFormatted = 'Invalid date'; }
                }
                const unreadCount = parseInt(convo.unread_count || 0);
                html += `
                    <a href="${escapeHtmlJS(appUrl)}/boardroom?conversation_id=${convo.conversation_id}"
                       class="conversation-item flex items-center p-3 hover:bg-gray-100 cursor-pointer border-b border-gray-100 last:border-b-0 ${convo.conversation_id == selectedConversationId ? 'bg-indigo-50 selected' : ''}"
                       data-conversation-id="${convo.conversation_id}">
                        <img src="${escapeHtmlJS(convo.recipient_profile_pic || defaultAvatarFullUrl)}"
                             alt="${escapeHtmlJS(convo.recipient_username || 'User')}" class="w-10 h-10 rounded-full mr-3 object-cover">
                        <div class="flex-grow overflow-hidden">
                            <div class="flex justify-between items-center">
                                <span class="font-semibold text-sm text-gray-800 truncate recipient-username">${escapeHtmlJS(convo.recipient_username || 'Unknown User')}</span>
                                <span class="text-xs text-gray-500 flex-shrink-0 ml-2 last-message-time">${escapeHtmlJS(lastMessageTimeFormatted)}</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <p class="text-sm text-gray-600 truncate last-message-preview">${escapeHtmlJS(convo.last_message_text || 'No messages yet.')}</p>
                                ${ unreadCount > 0 ? `<span class="unread-count-badge ml-2 bg-red-500 text-white text-xs font-bold rounded-full px-1.5 py-0.5 flex-shrink-0">${unreadCount}</span>` : '' }
                            </div>
                        </div>
                    </a>`;
            });
        }
        conversationListEl.innerHTML = html;
    }
    let conversationPollingInterval;
    function startConversationPolling() {
        if(conversationPollingInterval) clearInterval(conversationPollingInterval);
        fetchConversationUpdates();
        conversationPollingInterval = setInterval(fetchConversationUpdates, 15000);
    }
    startConversationPolling();

    document.addEventListener("visibilitychange", function() {
        if (document.hidden) {
            if (messagePollingInterval) clearInterval(messagePollingInterval);
            if (conversationPollingInterval) clearInterval(conversationPollingInterval);
            console.log("Polling paused (tab hidden)");
        } else {
            console.log("Polling resumed (tab visible)");
            startMessagePolling();
            startConversationPolling();
        }
    });
});
</script>