<?php
// File: app/Views/supplier/order_list_content.php
// Lists orders for the supplier to manage.

$orders = $orders ?? [];
$currentPage = $currentPage ?? 1;
$totalPages = $totalPages ?? 1;
$filters = $filters ?? []; 
$app_url = $app_url ?? (defined('APP_URL') ? rtrim(APP_URL, '/') : '');
$flashMessage = $flashMessage ?? null; 

if (!function_exists('escape_html')) {
    function escape_html($string) { return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
if (!function_exists('format_price_sup_order_list')) {
    function format_price_sup_order_list($price, string $currencySymbol = 'R'): string {
        if (!is_numeric($price)) $price = 0.00;
        return $currencySymbol . number_format((float)$price, 2, '.', ',');
    }
}
if (!function_exists('format_datetime_sup_order_list')) {
    function format_datetime_sup_order_list($datetimeStr) {
        if (!$datetimeStr) return 'N/A';
        try { $date = new DateTime($datetimeStr); return $date->format('M d, Y, g:i A'); } 
        catch (Exception $e) { return 'Invalid Date'; }
    }
}

$currentStatusFilter = $filters['status'] ?? '';
$allStatuses = ['pending_payment', 'awaiting_payment', 'processing', 'shipped', 'delivered', 'completed', 'cancelled', 'on-hold'];
?>

<div class="container mx-auto px-4 py-8">
    <div class="flex flex-col sm:flex-row justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">My Business Orders</h1>
    </div>

    <?php if ($flashMessage && isset($flashMessage['text'])): ?>
        <div class="mb-4 p-3 rounded-md <?php echo ($flashMessage['type'] ?? 'info') === 'success' ? 'bg-green-100 text-green-700' : (($flashMessage['type'] ?? 'info') === 'error' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'); ?>">
            <?php echo escape_html($flashMessage['text']); ?>
        </div>
    <?php endif; ?>

    <form method="GET" action="<?php echo $app_url; ?>/supplier/orders" class="mb-6 bg-white p-4 rounded-lg shadow">
        <div class="flex flex-wrap gap-4 items-end">
            <div>
                <label for="status_filter" class="block text-sm font-medium text-gray-700">Filter by Status:</label>
                <select name="status_filter" id="status_filter" class="mt-1 block w-full sm:w-auto pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                    <option value="">All Statuses</option>
                    <?php foreach ($allStatuses as $status): ?>
                    <option value="<?php echo escape_html($status); ?>" <?php echo ($currentStatusFilter === $status) ? 'selected' : ''; ?>>
                        <?php echo escape_html(ucfirst(str_replace('_', ' ', $status))); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <button type="submit" class="px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-indigo-500">
                    Filter Orders
                </button>
            </div>
        </div>
    </form>

    <?php if (empty($orders)): ?>
        <div class="text-center py-10 bg-white p-6 rounded-lg shadow">
            <i class="fas fa-inbox text-4xl text-gray-400 mb-4"></i>
            <p class="text-gray-600">No orders found<?php echo !empty($currentStatusFilter) ? ' matching this status' : ''; ?>.</p>
        </div>
    <?php else: ?>
        <div class="bg-white shadow-xl rounded-lg overflow-hidden">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Order ID</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Items (Yours/Total)</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Order Total</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-indigo-600 hover:underline">
                                    <a href="<?php echo $app_url . '/supplier/orders/view/' . (int)$order['order_id']; ?>">
                                        #<?php echo escape_html($order['order_id']); ?>
                                    </a>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo format_datetime_sup_order_list($order['created_at']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo escape_html($order['customer_username'] ?? ($order['customer_full_name'] ?? 'N/A')); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    <?php echo (int)($order['supplier_item_count'] ?? 0); ?> / <?php echo (int)($order['total_item_count_in_order'] ?? 0); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-semibold"><?php echo format_price_sup_order_list($order['total_amount']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2.5 py-1 inline-flex text-xs leading-5 font-semibold rounded-full 
                                        <?php 
                                            $status_raw = strtolower($order['status'] ?? 'unknown');
                                            switch ($status_raw) {
                                                case 'processing': echo 'bg-blue-100 text-blue-800'; break;
                                                case 'awaiting_payment': case 'pending_payment': case 'on-hold': echo 'bg-yellow-100 text-yellow-800'; break;
                                                case 'shipped': echo 'bg-purple-100 text-purple-800'; break;
                                                case 'delivered': case 'completed': echo 'bg-green-100 text-green-800'; break;
                                                case 'cancelled': case 'refunded': echo 'bg-red-100 text-red-800'; break;
                                                default: echo 'bg-gray-100 text-gray-700'; break;
                                            }
                                        ?>">
                                        <?php echo escape_html(ucfirst(str_replace('_', ' ', $order['status']))); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-center text-sm font-medium">
                                    <a href="<?php echo $app_url . '/supplier/orders/view/' . (int)$order['order_id']; ?>" class="text-indigo-600 hover:text-indigo-800">
                                        View/Manage
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php if ($totalPages > 1): ?>
            <nav class="mt-6 flex justify-center" aria-label="Order list pagination">
                <ul class="inline-flex items-center -space-x-px">
                    <li>
                        <a href="<?php echo $app_url . '/supplier/orders?page=' . max(1, $currentPage - 1) . '&' . http_build_query($filters); ?>"
                           class="py-2 px-3 ml-0 leading-tight text-gray-500 bg-white rounded-l-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 <?php echo ($currentPage <= 1) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                            Previous
                        </a>
                    </li>
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li>
                            <a href="<?php echo $app_url . '/supplier/orders?page=' . $i . '&' . http_build_query($filters); ?>"
                               class="py-2 px-3 leading-tight border border-gray-300 <?php echo ($i == $currentPage) ? 'text-indigo-600 bg-indigo-50' : 'text-gray-500 bg-white hover:bg-gray-100'; ?>">
                                <?php echo $i; ?>
                            </a>
                        </li>
                    <?php endfor; ?>
                    <li>
                        <a href="<?php echo $app_url . '/supplier/orders?page=' . min($totalPages, $currentPage + 1) . '&' . http_build_query($filters); ?>"
                           class="py-2 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 <?php echo ($currentPage >= $totalPages) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                            Next
                        </a>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</div>