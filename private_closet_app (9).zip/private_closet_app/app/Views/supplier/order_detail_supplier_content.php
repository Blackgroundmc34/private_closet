<?php
// File: app/Views/supplier/order_detail_supplier_content.php
$order = $order ?? null;
$errors = $errors ?? [];
$app_url = $app_url ?? (defined('APP_URL') ? rtrim(APP_URL, '/') : '');
$csrf_token = $csrf_token ?? ($_SESSION['csrf_token'] ?? ''); // Ensure CSRF is available
$flashMessage = $flashMessage ?? null;

if (!function_exists('escape_html')) {
    function escape_html($string) { return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
if (!function_exists('format_price_sup_order_det')) {
    function format_price_sup_order_det($price, string $currencySymbol = 'R'): string {
        if (!is_numeric($price)) $price = 0.00;
        return $currencySymbol . number_format((float)$price, 2, '.', ',');
    }
}
if (!function_exists('format_datetime_sup_order_det')) {
    function format_datetime_sup_order_det($datetimeStr) {
        if (!$datetimeStr) return 'N/A';
        try { $date = new DateTime($datetimeStr); return $date->format('F j, Y, g:i a'); } 
        catch (Exception $e) { return 'Invalid Date'; }
    }
}

$default_product_image_full_url = $app_url . '/assets/images/default_product_image.png';
$allowedOrderStatusesForSupplier = ['processing' => 'Processing', 'shipped' => 'Shipped', 'delivered' => 'Delivered', 'on-hold' => 'On Hold', 'cancelled' => 'Cancelled'];
?>

<div class="container mx-auto px-4 py-8 max-w-3xl">
    <?php if (!$order || !isset($order['id'])): ?>
        <div class="bg-white p-6 rounded-lg shadow text-center">
            <p class="text-red-500">Order details could not be loaded for management.</p>
            <a href="<?php echo $app_url; ?>/supplier/orders" class="mt-4 inline-block text-indigo-600 hover:underline">Back to Orders</a>
        </div>
    <?php else: 
        $orderIdDisplay = escape_html($order['id']);
        $orderStatusRaw = strtolower($order['status'] ?? 'unknown');
    ?>
        <div class="bg-white shadow-xl rounded-lg p-6 sm:p-8">
            <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 pb-4 border-b">
                <div>
                    <h1 class="text-2xl md:text-3xl font-bold text-gray-800">Manage Order #<?php echo $orderIdDisplay; ?></h1>
                    <p class="text-sm text-gray-500">Placed: <?php echo format_datetime_sup_order_det($order['created_at'] ?? ''); ?></p>
                    <p class="text-sm text-gray-500">Customer: <?php echo escape_html($order['customer_username'] ?? 'N/A'); ?> (<?php echo escape_html($order['customer_email'] ?? 'N/A'); ?>)</p>
                </div>
                <span class="mt-2 md:mt-0 px-3 py-1 inline-flex text-sm leading-5 font-semibold rounded-full <?php echo ($orderStatusRaw === 'completed' || $orderStatusRaw === 'delivered') ? 'bg-green-100 text-green-800' : (($orderStatusRaw === 'cancelled' || $orderStatusRaw === 'refunded') ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800'); ?>">
                    Current Status: <?php echo escape_html(ucfirst(str_replace('_', ' ', $orderStatusRaw))); ?>
                </span>
            </div>

            <?php if ($flashMessage && isset($flashMessage['text'])): ?>
            <div class="mb-4 p-3 rounded-md <?php echo ($flashMessage['type'] ?? 'info') === 'success' ? 'bg-green-100 text-green-700' : (($flashMessage['type'] ?? 'info') === 'error' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'); ?>">
                <?php echo escape_html($flashMessage['text']); ?>
            </div>
            <?php endif; ?>
            
            <div id="js-validation-message-area" class="mb-4"></div>

            <?php if (!empty($errors['general'])): ?>
            <div class="mb-4 p-3 rounded-md bg-red-100 text-red-700"><?php echo escape_html($errors['general']); ?></div>
            <?php endif; ?>

            <div class="mb-6">
                <h2 class="text-lg font-semibold text-gray-700 mb-2">Shipping Details</h2>
                <div class="text-sm text-gray-600 bg-gray-50 p-4 rounded-md border">
                    <?php $shipping = $order['shipping_address_details'] ?? []; ?>
                    <p><strong><?php echo escape_html($shipping['full_name'] ?? 'N/A'); ?></strong></p>
                    <p><?php echo escape_html($shipping['address_line_1'] ?? 'N/A'); ?></p>
                    <?php if (!empty($shipping['address_line_2'])): ?><p><?php echo escape_html($shipping['address_line_2']); ?></p><?php endif; ?>
                    <p><?php echo escape_html($shipping['city'] ?? 'N/A'); ?>, <?php echo escape_html($shipping['province'] ?? 'N/A'); ?> <?php echo escape_html($shipping['postal_code'] ?? 'N/A'); ?></p>
                    <p>Phone: <?php echo escape_html($shipping['phone'] ?? 'N/A'); ?></p>
                </div>
            </div>

            <div class="mb-6">
                <h2 class="text-lg font-semibold text-gray-700 mb-3">Items from Your Business in this Order</h2>
                <div class="space-y-3">
                    <?php if (empty($order['items'])): ?>
                        <p class="text-sm text-gray-500">No items from your business found in this order.</p>
                    <?php else: ?>
                        <?php foreach ($order['items'] as $item): ?>
                        <div class="flex items-center gap-3 p-3 border rounded-md bg-white">
                            <img src="<?php echo escape_html($item['product_image_full'] ?? $default_product_image_full_url); ?>" 
                                 alt="<?php echo escape_html($item['product_name'] ?? 'Product'); ?>" 
                                 class="w-16 h-16 object-cover rounded-md border"
                                 onerror="this.onerror=null; this.src='<?php echo $default_product_image_full_url; ?>';">
                            <div class="flex-grow">
                                <p class="font-medium text-gray-800"><?php echo escape_html($item['product_name'] ?? 'Product'); ?></p>
                                <p class="text-xs text-gray-500">SKU: <?php echo escape_html($item['product_sku'] ?? 'N/A'); ?></p>
                                <p class="text-sm text-gray-500">Qty: <?php echo (int)($item['quantity'] ?? 1); ?> @ <?php echo format_price_sup_order_det($item['price_at_time_of_order'] ?? 0); ?></p>
                            </div>
                            <p class="text-md font-semibold text-gray-700">
                                <?php echo format_price_sup_order_det((float)($item['price_at_time_of_order'] ?? 0) * (int)($item['quantity'] ?? 1)); ?>
                            </p>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <hr class="my-6">

            <form id="update-order-form" action="<?php echo $app_url . '/supplier/orders/update/' . $orderIdDisplay; ?>" method="POST" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                <h2 class="text-lg font-semibold text-gray-700 mb-1">Update Order Fulfillment</h2>

                <div>
                    <label for="order_status" class="block text-sm font-medium text-gray-700 mb-1">Order Status <span class="text-red-500">*</span></label>
                    <select id="order_status" name="order_status" required class="mt-1 block w-full md:w-2/3 lg:w-1/2 pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md <?php echo isset($errors['order_status']) ? 'border-red-500' : ''; ?>">
                        <option value="">Select New Status</option>
                        <?php foreach ($allowedOrderStatusesForSupplier as $statusVal => $statusLabel): ?>
                            <option value="<?php echo $statusVal; ?>" <?php echo ($orderStatusRaw === $statusVal) ? 'selected' : ''; ?>>
                                <?php echo $statusLabel; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if (isset($errors['order_status'])): ?>
                        <p class="text-xs text-red-500 mt-1"><?php echo escape_html($errors['order_status']); ?></p>
                    <?php endif; ?>
                </div>

                <div>
                    <label for="shipping_provider" class="block text-sm font-medium text-gray-700 mb-1">Shipping Provider (Required if Shipped)</label>
                    <input type="text" name="shipping_provider" id="shipping_provider" value="<?php echo escape_html($order['shipping_provider'] ?? ''); ?>" placeholder="e.g., Fastway, The Courier Guy"
                           class="mt-1 block w-full md:w-2/3 lg:w-1/2 px-3 py-2 border <?php echo isset($errors['shipping_provider']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    <?php if (isset($errors['shipping_provider'])): ?>
                        <p class="text-xs text-red-500 mt-1"><?php echo escape_html($errors['shipping_provider']); ?></p>
                    <?php endif; ?>
                </div>

                <div>
                    <label for="tracking_number" class="block text-sm font-medium text-gray-700 mb-1">Tracking Number (Required if Shipped)</label>
                    <input type="text" name="tracking_number" id="tracking_number" value="<?php echo escape_html($order['tracking_number'] ?? ''); ?>" placeholder="Enter tracking number"
                           class="mt-1 block w-full md:w-2/3 lg:w-1/2 px-3 py-2 border <?php echo isset($errors['tracking_number']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    <?php if (isset($errors['tracking_number'])): ?>
                        <p class="text-xs text-red-500 mt-1"><?php echo escape_html($errors['tracking_number']); ?></p>
                    <?php endif; ?>
                </div>
                
                <div class="pt-3">
                    <button type="submit" class="px-6 py-2.5 bg-green-600 text-white font-medium text-sm rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                        <i class="fas fa-save mr-2"></i>Update Order
                    </button>
                </div>
            </form>

            <div class="mt-8 pt-6 border-t text-left">
                <a href="<?php echo $app_url; ?>/supplier/orders" class="text-indigo-600 hover:text-indigo-800 text-sm font-medium">
                    <i class="fas fa-arrow-left mr-1"></i>Back to Orders List
                </a>
            </div>
        </div>

        <div id="updateOrderConfirmModal" class="fixed inset-0 bg-gray-800 bg-opacity-75 flex items-center justify-center z-[1000]" style="display: none;">
            <div class="bg-white p-5 sm:p-8 rounded-lg shadow-xl w-11/12 md:max-w-md mx-auto transform transition-all duration-300 ease-out scale-95 opacity-0" id="updateOrderConfirmModalContent">
                <div class="text-center">
                    <div class="mx-auto flex items-center justify-center h-12 w-12 sm:h-16 sm:w-16 rounded-full bg-blue-100 mb-4 sm:mb-5">
                        <i class="fas fa-question-circle fa-2x sm:fa-3x text-blue-500"></i>
                    </div>
                    <h3 class="text-lg sm:text-xl leading-6 font-semibold text-gray-900 mb-2" id="updateOrderModalTitle">Confirm Order Update</h3>
                    <div class="mt-2 px-2 sm:px-4 py-3">
                        <p class="text-sm sm:text-md text-gray-600" id="updateOrderModalMessage">Are you sure you want to update the order status?</p>
                    </div>
                    <div class="mt-5 sm:mt-6 flex flex-col sm:flex-row-reverse gap-3 justify-center">
                        <button id="confirmOrderUpdateBtn" type="button" class="w-full sm:w-auto inline-flex justify-center rounded-md border border-transparent shadow-sm px-5 py-2 bg-green-600 text-base font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 sm:text-sm">
                            <i class="fas fa-check mr-2"></i>Confirm Update
                        </button>
                        <button id="cancelOrderUpdateBtn" type="button" class="w-full sm:w-auto mt-3 sm:mt-0 inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-5 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:text-sm">
                            Cancel
                        </button>
                    </div>
                </div>
            </div>
        </div>


        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const updateForm = document.getElementById('update-order-form');
                const jsValidationMessageArea = document.getElementById('js-validation-message-area');

                const modal = document.getElementById('updateOrderConfirmModal');
                const modalContent = document.getElementById('updateOrderConfirmModalContent');
                const modalMessage = document.getElementById('updateOrderModalMessage');
                const confirmBtn = document.getElementById('confirmOrderUpdateBtn');
                const cancelBtn = document.getElementById('cancelOrderUpdateBtn');

                function showJsValidationError(message) {
                    jsValidationMessageArea.innerHTML = '<div class="p-3 rounded-md bg-red-100 text-red-700 border border-red-300 text-sm">' + escapeHtmlJs(message) + '</div>';
                    jsValidationMessageArea.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
                function clearJsValidationError() {
                    jsValidationMessageArea.innerHTML = '';
                }
                 function escapeHtmlJs(unsafe) {
                    if (typeof unsafe !== 'string') return '';
                    return unsafe
                         .replace(/&/g, "&amp;")
                         .replace(/</g, "&lt;")
                         .replace(/>/g, "&gt;")
                         .replace(/"/g, "&quot;")
                         .replace(/'/g, "&#039;");
                }


                function openModal(message) {
                    modalMessage.innerHTML = escapeHtmlJs(message); // Use innerHTML if message might contain simple formatting or is pre-escaped
                    modal.style.display = 'flex';
                    setTimeout(() => {
                        modalContent.style.opacity = '1';
                        modalContent.style.transform = 'scale(1)';
                    }, 10);
                }

                function closeModal() {
                    modalContent.style.opacity = '0';
                    modalContent.style.transform = 'scale(0.95)';
                    setTimeout(() => {
                        modal.style.display = 'none';
                    }, 300);
                }

                if (updateForm) {
                    updateForm.addEventListener('submit', function(event) {
                        event.preventDefault(); // Always prevent default initially
                        clearJsValidationError();

                        const statusSelect = document.getElementById('order_status');
                        const status = statusSelect.value;
                        const selectedStatusText = statusSelect.options[statusSelect.selectedIndex].text;
                        const shippingProvider = document.getElementById('shipping_provider').value.trim();
                        const trackingNumber = document.getElementById('tracking_number').value.trim();
                        let validationPassed = true;
                        let confirmMessage = 'Are you sure you want to update the order status to "' + selectedStatusText + '"?';

                        if (status === 'shipped') {
                            if (!shippingProvider) {
                                showJsValidationError('Shipping Provider is required when status is "Shipped".');
                                validationPassed = false;
                            }
                            if (!trackingNumber) {
                                showJsValidationError('Tracking Number is required when status is "Shipped".');
                                validationPassed = false;
                            }
                            if (validationPassed) {
                                confirmMessage += '<br><br>Shipping Provider: ' + escapeHtmlJs(shippingProvider) + '<br>Tracking Number: ' + escapeHtmlJs(trackingNumber);
                            }
                        } else if (!status) {
                             showJsValidationError('Please select a new order status.');
                             validationPassed = false;
                        }


                        if (validationPassed) {
                            openModal(confirmMessage);
                        }
                    });
                }

                if (confirmBtn) {
                    confirmBtn.addEventListener('click', function() {
                        if (updateForm) {
                            updateForm.submit(); // Submit the actual form
                        }
                    });
                }
                if (cancelBtn) {
                    cancelBtn.addEventListener('click', closeModal);
                }
                if (modal) {
                    modal.addEventListener('click', function(event) {
                        if (event.target === modal) {
                            closeModal();
                        }
                    });
                }
                document.addEventListener('keydown', function(event) {
                    if (event.key === 'Escape' && modal && modal.style.display === 'flex') {
                        closeModal();
                    }
                });
            });
        </script>
    <?php endif; ?>
</div>