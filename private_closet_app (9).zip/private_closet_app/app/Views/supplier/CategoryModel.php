<?php
// File: app/Models/CategoryModel.php
class CategoryModel {
    private $pdo;
    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function getAll(): array {
        // Assuming your categories table has 'id' and 'name' and perhaps 'parent_category_id'
        // Adjust query if your schema is different
        $sql = "SELECT id, name FROM categories WHERE parent_category_id IS NULL OR parent_category_id = 0 ORDER BY name ASC"; // Example: Top-level categories
        // Or SELECT id, name FROM categories ORDER BY name ASC; for all categories
        try {
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (PDOException $e) {
            error_log("CategoryModel::getAll PDOException: " . $e->getMessage());
            return [];
        }
    }
    // Add findById, etc. as needed
}
?>