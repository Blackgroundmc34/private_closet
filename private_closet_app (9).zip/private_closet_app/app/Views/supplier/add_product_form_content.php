<?php
// File: app/Views/supplier/add_product_form_content.php

// These variables are expected to be passed from SupplierController::showAddProductForm()
// $errors (array) - Validation errors
// $oldInput (array) - Previously submitted form data
// $categories (array) - List of categories for the dropdown
// $app_url (string) - Base URL
// $csrf_token (string) - CSRF token for form security

// Ensure variables are initialized to prevent undefined variable notices in the view itself
$errors = $errors ?? [];
$oldInput = $oldInput ?? [];
$app_url = $app_url ?? (defined('APP_URL') ? APP_URL : '');
$categories = $categories ?? [];
$csrf_token = $csrf_token ?? ($_SESSION['csrf_token'] ?? ''); // Ensure CSRF token is available

// Helper function to display error for a specific field
if (!function_exists('display_form_error')) {
    function display_form_error(string $field, array $error_list): void {
        if (isset($error_list[$field])) {
            echo '<p class="text-red-500 text-xs mt-1">' . htmlspecialchars($error_list[$field]) . '</p>';
        }
    }
}
?>
<div class="container mx-auto px-4 py-8 max-w-2xl">
    <div class="bg-white p-6 sm:p-8 rounded-lg shadow-xl border border-gray-200">
        <h1 class="text-2xl sm:text-3xl font-semibold text-gray-800 mb-6 pb-4 border-b border-gray-200 text-center">
            Add New Product
        </h1>

        <?php if (isset($_SESSION['flash_message'])): ?>
            <div class="mb-4 p-3 rounded-md <?php echo htmlspecialchars($_SESSION['flash_message']['type'] === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'); ?>">
                <?php echo htmlspecialchars($_SESSION['flash_message']['text']); unset($_SESSION['flash_message']); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($errors['general'])): ?>
            <div class="mb-4 p-3 rounded-md bg-red-100 text-red-700">
                <strong>Error:</strong> <?php echo htmlspecialchars($errors['general']); ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo $app_url; ?>/supplier/products/add" method="POST" enctype="multipart/form-data" class="space-y-6">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">

            <div>
                <label for="name" class="block text-sm font-medium text-gray-700 mb-1">Product Name <span class="text-red-500">*</span></label>
                <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($oldInput['name'] ?? ''); ?>" required
                       class="mt-1 block w-full px-3 py-2 border <?php echo isset($errors['name']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                <?php display_form_error('name', $errors); ?>
            </div>

            <div>
                <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Description <span class="text-red-500">*</span></label>
                <textarea name="description" id="description" rows="4" required
                          class="mt-1 block w-full px-3 py-2 border <?php echo isset($errors['description']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"><?php echo htmlspecialchars($oldInput['description'] ?? ''); ?></textarea>
                <?php display_form_error('description', $errors); ?>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="price" class="block text-sm font-medium text-gray-700 mb-1">Price (R) <span class="text-red-500">*</span></label>
                    <input type="number" name="price" id="price" value="<?php echo htmlspecialchars($oldInput['price'] ?? ''); ?>" required step="0.01" min="0.01"
                           class="mt-1 block w-full px-3 py-2 border <?php echo isset($errors['price']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    <?php display_form_error('price', $errors); ?>
                </div>
                <div>
                    <label for="stock_quantity" class="block text-sm font-medium text-gray-700 mb-1">Stock Quantity <span class="text-red-500">*</span></label>
                    <input type="number" name="stock_quantity" id="stock_quantity" value="<?php echo htmlspecialchars($oldInput['stock_quantity'] ?? '0'); ?>" required min="0"
                           class="mt-1 block w-full px-3 py-2 border <?php echo isset($errors['stock_quantity']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    <?php display_form_error('stock_quantity', $errors); ?>
                </div>
            </div>
            
            <div>
                <label for="sku" class="block text-sm font-medium text-gray-700 mb-1">SKU (Optional)</label>
                <input type="text" name="sku" id="sku" value="<?php echo htmlspecialchars($oldInput['sku'] ?? ''); ?>"
                       class="mt-1 block w-full px-3 py-2 border <?php echo isset($errors['sku']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                <?php display_form_error('sku', $errors); ?>
            </div>

            <div>
                <label for="category_id" class="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select name="category_id" id="category_id"
                        class="mt-1 block w-full px-3 py-2 border <?php echo isset($errors['category_id']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    <option value="">Select Category (Optional)</option>
                    <?php if (!empty($categories)): ?>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo (int)$category['id']; ?>" <?php echo (isset($oldInput['category_id']) && $oldInput['category_id'] == $category['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($category['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <option value="" disabled>No categories available. Please add categories first.</option>
                    <?php endif; ?>
                </select>
                <?php display_form_error('category_id', $errors); ?>
            </div>

            <div>
                <label for="primary_image" class="block text-sm font-medium text-gray-700 mb-1">Primary Image</label>
                <input type="file" name="primary_image" id="primary_image" accept="image/jpeg,image/png,image/gif"
                       class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                 <p class="text-xs text-gray-500 mt-1">Recommended: Square or portrait. Max 5MB. JPG, PNG, GIF.</p>
                <?php display_form_error('primary_image', $errors); ?>
            </div>
            
            <?php for ($i = 1; $i <= 3; $i++): ?>
            <div>
                <label for="additional_image_<?php echo $i; ?>" class="block text-sm font-medium text-gray-700 mb-1">Additional Image <?php echo $i; ?> (Optional)</label>
                <input type="file" name="additional_image_<?php echo $i; ?>" id="additional_image_<?php echo $i; ?>" accept="image/jpeg,image/png,image/gif"
                       class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                <?php display_form_error("additional_image_$i", $errors); ?>
            </div>
            <?php endfor; ?>

            <div class="flex items-center justify-end pt-6 border-t border-gray-200 mt-8">
                <a href="<?php echo $app_url; ?>/supplier/products" class="text-gray-600 hover:text-gray-800 text-sm font-medium mr-4 px-4 py-2 rounded-md hover:bg-gray-100">Cancel</a>
                <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                    Add Product
                </button>
            </div>
        </form>
    </div>
</div>
