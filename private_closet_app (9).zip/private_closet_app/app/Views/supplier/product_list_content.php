<?php
// File: app/Views/supplier/product_list_content.php
$products = $products ?? [];
$app_url = $app_url ?? (defined('APP_URL') ? rtrim(APP_URL, '/') : '');
$csrf_token = $csrf_token ?? ($_SESSION['csrf_token'] ?? ''); 
$flashMessage = $flashMessage ?? null; 

if (!function_exists('escape_html_sup_prod_list')) { // Unique function name
    function escape_html_sup_prod_list($string) { return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
if (!function_exists('format_price_sup_prod_list')) { // Unique function name
    function format_price_sup_prod_list($price, string $currencySymbol = 'R'): string {
        if (!is_numeric($price)) $price = 0.00;
        return $currencySymbol . number_format((float)$price, 2, '.', ',');
    }
}
?>
<div class="container mx-auto px-4 py-8">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">My Products</h1>
        <a href="<?php echo $app_url; ?>/supplier/products/add" class="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 text-sm font-medium">
            <i class="fas fa-plus mr-1"></i> Add New Product
        </a>
    </div>

    <?php if ($flashMessage && isset($flashMessage['text'])): ?>
        <div class="mb-4 p-3 rounded-md <?php echo ($flashMessage['type'] ?? 'info') === 'success' ? 'bg-green-100 text-green-700' : (($flashMessage['type'] ?? 'info') === 'error' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'); ?>">
            <?php echo escape_html_sup_prod_list($flashMessage['text']); ?>
        </div>
    <?php endif; ?>

    <?php if (empty($products)): ?>
        <div class="text-center py-10 bg-white p-6 rounded-lg shadow">
            <i class="fas fa-box-open text-4xl text-gray-400 mb-4"></i>
            <p class="text-gray-600">You haven't added any products yet.</p>
            <a href="<?php echo $app_url; ?>/supplier/products/add" class="mt-2 text-indigo-600 hover:underline">Add your first product!</a>
        </div>
    <?php else: ?>
        <div class="bg-white shadow-xl rounded-lg overflow-hidden">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Image</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($products as $product): ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <img src="<?php echo !empty($product['primary_image_url_full']) ? escape_html_sup_prod_list($product['primary_image_url_full']) : 'https://placehold.co/50x50/E2E8F0/CBD5E0?text=N/A'; ?>" 
                                         alt="<?php echo escape_html_sup_prod_list($product['name']); ?>" class="w-12 h-12 object-cover rounded-md border">
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo escape_html_sup_prod_list($product['name']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo format_price_sup_prod_list($product['price']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo (int)$product['stock_quantity']; ?></td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2.5 py-1 inline-flex text-xs leading-5 font-semibold rounded-full 
                                        <?php 
                                            switch (strtolower($product['status'] ?? 'inactive')) {
                                                case 'active': echo 'bg-green-100 text-green-800'; break;
                                                case 'inactive': echo 'bg-red-100 text-red-800'; break;
                                                case 'draft': echo 'bg-yellow-100 text-yellow-800'; break;
                                                case 'out_of_stock': echo 'bg-gray-100 text-gray-800'; break;
                                                default: echo 'bg-gray-100 text-gray-700'; break;
                                            }
                                        ?>">
                                        <?php echo escape_html_sup_prod_list(ucfirst($product['status'])); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-center text-sm font-medium">
                                    <a href="<?php echo $app_url; ?>/supplier/products/edit/<?php echo (int)$product['id']; ?>" class="text-indigo-600 hover:text-indigo-800 mr-3">Edit</a>
                                    
                                    <form id="deleteForm_<?php echo (int)$product['id']; ?>" action="<?php echo $app_url; ?>/supplier/products/delete/<?php echo (int)$product['id']; ?>" method="POST" class="inline">
                                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                        <input type="hidden" name="product_id" value="<?php echo (int)$product['id']; ?>">
                                        <button type="button" 
                                                class="delete-product-btn text-red-600 hover:text-red-800"
                                                data-product-id="<?php echo (int)$product['id']; ?>"
                                                data-product-name="<?php echo escape_html_sup_prod_list($product['name']); ?>">
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>

<div id="deleteConfirmModal" class="fixed inset-0 bg-gray-800 bg-opacity-75 flex items-center justify-center z-[1000]" style="display: none;">
    <div class="bg-white p-5 sm:p-8 rounded-lg shadow-xl w-11/12 md:max-w-md mx-auto transform transition-all duration-300 ease-out scale-95 opacity-0" id="deleteConfirmModalContent">
        <div class="text-center">
            <div class="mx-auto flex items-center justify-center h-12 w-12 sm:h-16 sm:w-16 rounded-full bg-red-100 mb-4 sm:mb-5">
                <i class="fas fa-exclamation-triangle fa-2x sm:fa-3x text-red-500"></i>
            </div>
            <h3 class="text-lg sm:text-xl leading-6 font-semibold text-gray-900 mb-2" id="deleteModalTitle">Delete Product?</h3>
            <div class="mt-2 px-2 sm:px-4 py-3">
                <p class="text-sm sm:text-md text-gray-600" id="deleteModalMessage">Are you sure you want to delete the product "<strong id="deleteModalProductName" class="font-semibold">this product</strong>"? This action cannot be undone.</p>
            </div>
            <div class="mt-5 sm:mt-6 flex flex-col sm:flex-row-reverse gap-3 justify-center">
                <button id="confirmDeleteProductBtn" type="button" class="w-full sm:w-auto inline-flex justify-center rounded-md border border-transparent shadow-sm px-5 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 sm:text-sm">
                    <i class="fas fa-trash-alt mr-2"></i>Confirm Delete
                </button>
                <button id="cancelDeleteProductBtn" type="button" class="w-full sm:w-auto mt-3 sm:mt-0 inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-5 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:text-sm">
                    Cancel
                </button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const deleteModal = document.getElementById('deleteConfirmModal');
    const deleteModalContent = document.getElementById('deleteConfirmModalContent');
    const deleteModalProductName = document.getElementById('deleteModalProductName');
    const confirmDeleteProductBtn = document.getElementById('confirmDeleteProductBtn');
    const cancelDeleteProductBtn = document.getElementById('cancelDeleteProductBtn');
    let formToSubmitForDelete = null;

    document.querySelectorAll('.delete-product-btn').forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            formToSubmitForDelete = this.closest('form');
            const productName = this.dataset.productName;
            if (deleteModalProductName) deleteModalProductName.textContent = productName;
            if (deleteModal && deleteModalContent) {
                deleteModal.style.display = 'flex';
                setTimeout(() => {
                    deleteModalContent.style.opacity = '1';
                    deleteModalContent.style.transform = 'scale(1)';
                }, 10);
            }
        });
    });

    function closeDeleteModal() {
        if (deleteModal && deleteModalContent) {
            deleteModalContent.style.opacity = '0';
            deleteModalContent.style.transform = 'scale(0.95)';
            setTimeout(() => {
                deleteModal.style.display = 'none';
                formToSubmitForDelete = null; 
            }, 300);
        }
    }

    if (confirmDeleteProductBtn) {
        confirmDeleteProductBtn.addEventListener('click', function() {
            if (formToSubmitForDelete) formToSubmitForDelete.submit();
        });
    }
    if (cancelDeleteProductBtn) cancelDeleteProductBtn.addEventListener('click', closeDeleteModal);
    if (deleteModal) {
        deleteModal.addEventListener('click', function(event) { if (event.target === deleteModal) closeDeleteModal(); });
    }
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape' && deleteModal && deleteModal.style.display === 'flex') closeDeleteModal();
    });
});
</script>