<?php
// File: app/Views/supplier/edit_product_form_content.php
$product = $product ?? null; 
$errors = $errors ?? [];
$oldInput = $oldInput ?? []; 
$categories = $categories ?? [];
$app_url = $app_url ?? (defined('APP_URL') ? rtrim(APP_URL, '/') : '');
$csrf_token = $csrf_token ?? ($_SESSION['csrf_token'] ?? '');

if (!$product || !isset($product['id'])) {
    echo "<div class='container mx-auto p-4'><p class='text-red-500 text-center'>Product data not found or invalid for editing.</p></div>";
    return;
}

// Helper to get field value: check old input first, then current product data
if (!function_exists('get_edit_value_supplier_form')) { // Unique function name for this view
    function get_edit_value_supplier_form(string $fieldName, array $submittedData, array $currentProductData, $default = '') {
        if (!empty($submittedData) && isset($submittedData[$fieldName])) {
            return htmlspecialchars($submittedData[$fieldName]);
        }
        return isset($currentProductData[$fieldName]) ? htmlspecialchars($currentProductData[$fieldName]) : htmlspecialchars($default);
    }
}
if (!function_exists('display_form_error_supplier_edit')) { // Unique function name
    function display_form_error_supplier_edit(string $field, array $error_list): void {
        if (isset($error_list[$field])) {
            echo '<p class="text-red-500 text-xs mt-1">' . htmlspecialchars($error_list[$field]) . '</p>';
        }
    }
}

$default_product_image_full_url = $app_url . '/assets/images/default_product_image.png'; // Define default

?>
<div class="container mx-auto px-4 py-8 max-w-3xl">
    <div class="bg-white p-6 sm:p-8 rounded-lg shadow-xl border border-gray-200">
        <h1 class="text-2xl sm:text-3xl font-semibold text-gray-800 mb-6 pb-4 border-b border-gray-200 text-center">
            Edit Product: <?php echo get_edit_value_supplier_form('name', $oldInput, $product); ?>
        </h1>

        <?php if (isset($_SESSION['flash_message'])): ?>
            <div class="mb-4 p-3 rounded-md <?php echo htmlspecialchars($_SESSION['flash_message']['type'] === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'); ?>">
                <?php echo htmlspecialchars($_SESSION['flash_message']['text']); unset($_SESSION['flash_message']); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($errors['general'])): ?>
            <div class="mb-4 p-3 rounded-md bg-red-100 text-red-700">
                <strong>Error:</strong> <?php echo htmlspecialchars($errors['general']); ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo htmlspecialchars($app_url . '/supplier/products/edit/' . (int)$product['id']); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
            <input type="hidden" name="product_id" value="<?php echo (int)$product['id']; ?>">

            <div>
                <label for="name" class="block text-sm font-medium text-gray-700 mb-1">Product Name <span class="text-red-500">*</span></label>
                <input type="text" name="name" id="name" value="<?php echo get_edit_value_supplier_form('name', $oldInput, $product); ?>" required
                       class="mt-1 block w-full px-3 py-2 border <?php echo isset($errors['name']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                <?php display_form_error_supplier_edit('name', $errors); ?>
            </div>

            <div>
                <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Description <span class="text-red-500">*</span></label>
                <textarea name="description" id="description" rows="4" required
                          class="mt-1 block w-full px-3 py-2 border <?php echo isset($errors['description']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"><?php echo get_edit_value_supplier_form('description', $oldInput, $product); ?></textarea>
                <?php display_form_error_supplier_edit('description', $errors); ?>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="price" class="block text-sm font-medium text-gray-700 mb-1">Price (R) <span class="text-red-500">*</span></label>
                    <input type="number" name="price" id="price" value="<?php echo get_edit_value_supplier_form('price', $oldInput, $product); ?>" required step="0.01" min="0.01"
                           class="mt-1 block w-full px-3 py-2 border <?php echo isset($errors['price']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    <?php display_form_error_supplier_edit('price', $errors); ?>
                </div>
                <div>
                    <label for="stock_quantity" class="block text-sm font-medium text-gray-700 mb-1">Stock Quantity <span class="text-red-500">*</span></label>
                    <input type="number" name="stock_quantity" id="stock_quantity" value="<?php echo get_edit_value_supplier_form('stock_quantity', $oldInput, $product, '0'); ?>" required min="0"
                           class="mt-1 block w-full px-3 py-2 border <?php echo isset($errors['stock_quantity']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    <?php display_form_error_supplier_edit('stock_quantity', $errors); ?>
                </div>
            </div>

            <div>
                <label for="sku" class="block text-sm font-medium text-gray-700 mb-1">SKU (Optional)</label>
                <input type="text" name="sku" id="sku" value="<?php echo get_edit_value_supplier_form('sku', $oldInput, $product); ?>"
                       class="mt-1 block w-full px-3 py-2 border <?php echo isset($errors['sku']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                <?php display_form_error_supplier_edit('sku', $errors); ?>
            </div>

            <div>
                <label for="category_id" class="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select name="category_id" id="category_id"
                        class="mt-1 block w-full px-3 py-2 border <?php echo isset($errors['category_id']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    <option value="">Select Category (Optional)</option>
                    <?php if (!empty($categories)): ?>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo (int)$category['id']; ?>" <?php echo (get_edit_value_supplier_form('category_id', $oldInput, $product) == $category['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($category['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
                <?php display_form_error_supplier_edit('category_id', $errors); ?>
            </div>

            <div>
                <label for="status" class="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <select name="status" id="status" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    <option value="active" <?php echo (get_edit_value_supplier_form('status', $oldInput, $product, 'active') == 'active') ? 'selected' : ''; ?>>Active</option>
                    <option value="inactive" <?php echo (get_edit_value_supplier_form('status', $oldInput, $product) == 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                    <option value="draft" <?php echo (get_edit_value_supplier_form('status', $oldInput, $product) == 'draft') ? 'selected' : ''; ?>>Draft</option>
                    <option value="out_of_stock" <?php echo (get_edit_value_supplier_form('status', $oldInput, $product) == 'out_of_stock') ? 'selected' : ''; ?>>Out of Stock</option>
                </select>
                 <?php display_form_error_supplier_edit('status', $errors); ?>
            </div>

            <fieldset class="mt-6 border-t pt-4">
                <legend class="text-base font-medium text-gray-800 mb-3">Manage Product Images</legend>
                
                <div class="mb-6">
                    <h4 class="text-sm font-medium text-gray-700 mb-2">Current Images:</h4>
                    <?php if (!empty($product['images'])): ?>
                        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                            <?php foreach($product['images'] as $image): ?>
                                <div class="relative group border rounded-md p-2 bg-gray-50">
                                    <img src="<?php echo htmlspecialchars($image['image_url_full'] ?? $default_product_image_full_url); ?>" 
                                         alt="<?php echo htmlspecialchars($image['alt_text'] ?? 'Product image'); ?>" 
                                         class="w-full h-24 sm:h-28 object-cover rounded-md mb-2"
                                         onerror="this.onerror=null; this.src='<?php echo $default_product_image_full_url; ?>';">
                                    
                                    <div class="flex items-center justify-between text-xs">
                                        <label for="delete_img_<?php echo (int)$image['id']; ?>" class="flex items-center text-red-600 hover:text-red-800 cursor-pointer">
                                            <input type="checkbox" name="delete_images[]" id="delete_img_<?php echo (int)$image['id']; ?>" value="<?php echo (int)$image['id']; ?>" class="h-4 w-4 text-red-600 border-gray-300 rounded focus:ring-red-500 mr-1 delete-image-checkbox">
                                            Delete
                                        </label>
                                        <label for="set_primary_<?php echo (int)$image['id']; ?>" class="flex items-center text-indigo-600 hover:text-indigo-800 cursor-pointer">
                                            <input type="radio" name="set_primary_image" id="set_primary_<?php echo (int)$image['id']; ?>" value="<?php echo (int)$image['id']; ?>" class="h-4 w-4 text-indigo-600 border-gray-300 focus:ring-indigo-500 mr-1 set-primary-checkbox" <?php echo $image['is_primary'] ? 'checked' : ''; ?>>
                                            Primary
                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                         <p class="text-xs text-gray-500 mt-2">Check "Delete" to remove an image. Select a "Primary" image (only one can be primary).</p>
                    <?php else: ?>
                        <p class="text-sm text-gray-500">No images currently uploaded for this product.</p>
                    <?php endif; ?>
                </div>
                
                <hr class="my-4">
                <h4 class="text-sm font-medium text-gray-700 mb-2">Upload New Images:</h4>

                <div class="mb-3">
                    <label for="primary_image_edit" class="block text-xs font-medium text-gray-600 mb-1">New Primary Image (Optional - if selected, this will become the primary)</label>
                    <input type="file" name="primary_image" id="primary_image_edit" accept="image/jpeg,image/png,image/gif"
                           class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                    <?php display_form_error_supplier_edit('primary_image', $errors); ?>
                </div>
                
                <?php for ($i = 1; $i <= 3; $i++): ?>
                <div class="mb-3">
                    <label for="new_additional_image_<?php echo $i; ?>" class="block text-xs font-medium text-gray-600 mb-1">New Additional Image <?php echo $i; ?> (Optional)</label>
                    <input type="file" name="new_additional_image_<?php echo $i; ?>" id="new_additional_image_<?php echo $i; ?>" accept="image/jpeg,image/png,image/gif"
                           class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                    <?php display_form_error_supplier_edit("new_additional_image_$i", $errors); ?>
                </div>
                <?php endfor; ?>
            </fieldset>

            <div class="flex items-center justify-end pt-6 border-t border-gray-200 mt-8">
                <a href="<?php echo htmlspecialchars($app_url . '/supplier/products'); ?>" class="text-gray-600 hover:text-gray-800 text-sm font-medium mr-4 px-4 py-2 rounded-md hover:bg-gray-100">Cancel</a>
                <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                    Save Changes
                </button>
            </div>
        </form>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Visual feedback for delete checkboxes
    document.querySelectorAll('.delete-image-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const imageContainer = this.closest('.relative.group') || this.closest('div > div'); // Adjust selector if structure changes
            if (imageContainer) {
                imageContainer.classList.toggle('opacity-50', this.checked);
                imageContainer.classList.toggle('border-red-300', this.checked); // Example: add red border
            }
        });
    });

    // Ensure only one radio button for primary can be checked (though HTML radio groups handle this)
    // This script is more for if you wanted custom visual styling beyond default radio buttons.
    const primaryRadios = document.querySelectorAll('.set-primary-checkbox');
    primaryRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            if (this.checked) {
                // Optionally, visually distinguish the selected primary's container
                primaryRadios.forEach(otherRadio => {
                    const otherContainer = otherRadio.closest('.relative.group') || otherRadio.closest('div > div');
                    if (otherContainer) {
                        otherContainer.classList.remove('border-2', 'border-green-500'); // Example: remove highlight
                    }
                });
                const currentContainer = this.closest('.relative.group') || this.closest('div > div');
                if (currentContainer) {
                    currentContainer.classList.add('border-2', 'border-green-500'); // Example: highlight selected
                }
            }
        });
    });
     // Initial highlight for the already checked primary image
    const checkedPrimary = document.querySelector('.set-primary-checkbox:checked');
    if (checkedPrimary) {
        const container = checkedPrimary.closest('.relative.group') || checkedPrimary.closest('div > div');
        if (container) {
            // container.classList.add('border-2', 'border-green-500'); // Apply initial highlight
        }
    }
});
</script>