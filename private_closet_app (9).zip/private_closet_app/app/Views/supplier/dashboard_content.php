<?php
// File: app/Views/supplier/dashboard_content.php
$business = $business ?? null;
$flashMessage = $flashMessage ?? null;
$app_url = $app_url ?? '';

if (!function_exists('escape_html')) {
    function escape_html($string) { return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
?>
<div class="container mx-auto px-4 py-8">
    <h1 class="text-2xl font-bold text-gray-800 mb-6">Supplier Dashboard</h1>

    <?php if ($flashMessage && isset($flashMessage['text'])): ?>
        <div class="mb-6 p-4 rounded-md text-sm 
            <?php 
                $messageTypeClass = 'bg-blue-100 text-blue-700 border border-blue-300';
                if (($flashMessage['type'] ?? 'info') === 'success') { $messageTypeClass = 'bg-green-100 text-green-700 border border-green-300'; }
                elseif (($flashMessage['type'] ?? 'info') === 'error') { $messageTypeClass = 'bg-red-100 text-red-700 border border-red-300'; }
                elseif (($flashMessage['type'] ?? 'info') === 'warning') { $messageTypeClass = 'bg-yellow-100 text-yellow-700 border border-yellow-300'; }
                echo $messageTypeClass;
            ?>">
            <strong class="font-semibold"><?php echo ucfirst(escape_html($flashMessage['type'] ?? 'info')); ?>!</strong> 
            <?php echo escape_html($flashMessage['text']); ?>
        </div>
    <?php endif; ?>

    <?php if (!$business || !isset($business['id']) || $business['status'] !== 'approved'): ?>
        <div class="bg-white p-6 rounded-lg shadow-md">
            <h2 class="text-xl font-semibold text-orange-600 mb-3">Business Profile Incomplete or Pending Approval</h2>
            <p class="text-gray-600 mb-2">
                Your business profile needs to be completed and approved before you can manage products and orders.
            </p>
            <?php if ($business && $business['status'] !== 'approved'): ?>
                <p class="text-gray-600 mb-4">Current status: <strong class="font-mono px-2 py-1 bg-gray-200 rounded"><?php echo escape_html($business['status']); ?></strong>. Please await approval.</p>
            <?php else: ?>
                 <p class="text-gray-600 mb-4">Please ensure your business details are fully submitted.</p>
            <?php endif; ?>
            <p class="text-gray-600">
                If you believe this is an error, or to complete your profile, please 
                <?php // TODO: Add a link to a business profile edit/creation page if available.
                      // Example: <a href="<?php echo $app_url; ?>/supplier/profile/setup" class="text-indigo-600 hover:underline">contact support or complete your business profile</a>.
                ?>
                contact support.
            </p>
        </div>
    <?php else: ?>
        <p class="text-gray-700 mb-4">Welcome back, <?php echo escape_html($_SESSION['username'] ?? 'Supplier'); ?>!</p>
        <p class="text-gray-600">From your dashboard, you can manage your products, view orders, and update your business settings.</p>
        
        <div class="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <a href="<?php echo $app_url; ?>/supplier/products" class="block p-6 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-md transition-all">
                <h2 class="text-xl font-semibold mb-2"><i class="fas fa-boxes mr-2"></i>Manage Products</h2>
                <p class="text-indigo-100 text-sm">View, add, edit, or delete your product listings.</p>
            </a>
            <a href="<?php echo $app_url; ?>/supplier/orders" class="block p-6 bg-green-600 hover:bg-green-700 text-white rounded-lg shadow-md transition-all">
                <h2 class="text-xl font-semibold mb-2"><i class="fas fa-receipt mr-2"></i>Manage Orders</h2>
                <p class="text-green-100 text-sm">Check new orders and manage their fulfillment.</p>
            </a>
            </div>
    <?php endif; ?>
</div>