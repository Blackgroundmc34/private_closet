<?php
// File: app/Views/shop/order_track_content.php
// Displays order tracking information.

$order = $order ?? null;
$app_url = $app_url ?? (defined('APP_URL') ? rtrim(APP_URL, '/') : '');

if (!function_exists('escape_html')) {
    function escape_html($string) { return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}

$orderIdDisplay = $order ? escape_html($order['id']) : 'N/A';
$orderStatusRaw = strtolower($order['status'] ?? 'unknown');
$orderStatusDisplay = escape_html(ucfirst(str_replace('_', ' ', $orderStatusRaw)));
$shippingProvider = escape_html($order['shipping_provider'] ?? 'Not yet specified');
$trackingNumber = escape_html($order['tracking_number'] ?? 'Not yet available');

// Define order statuses and their typical sequence for progress bar
$statusSequence = ['pending_payment', 'awaiting_payment', 'processing', 'shipped', 'delivered', 'completed'];
$currentStatusIndex = array_search($orderStatusRaw, $statusSequence);
if ($currentStatusIndex === false && ($orderStatusRaw === 'on-hold' || $orderStatusRaw === 'pending')) {
    $currentStatusIndex = array_search('awaiting_payment', $statusSequence); // Map 'on-hold' to 'awaiting_payment' for progress
}


$statusLabels = [
    'pending_payment' => 'Pending Payment',
    'awaiting_payment' => 'Awaiting Payment',
    'processing' => 'Processing',
    'shipped' => 'Shipped',
    'delivered' => 'Delivered',
    'completed' => 'Completed',
    'cancelled' => 'Cancelled',
    'refunded' => 'Refunded'
];

?>

<div class="container mx-auto px-4 py-8 max-w-2xl">
    <?php if (!$order || !isset($order['id'])): ?>
        <div class="bg-white p-6 rounded-lg shadow text-center">
            <p class="text-red-500">Order tracking details could not be loaded.</p>
        </div>
    <?php else: ?>
        <div class="bg-white shadow-xl rounded-lg p-6 sm:p-8">
            <div class="mb-6 pb-4 border-b border-gray-200">
                <h1 class="text-2xl md:text-3xl font-bold text-gray-800">Track Order #<?php echo $orderIdDisplay; ?></h1>
                <p class="text-sm text-gray-500">Current Status: <strong class="text-indigo-600"><?php echo $orderStatusDisplay; ?></strong></p>
            </div>

            <?php if ($orderStatusRaw === 'cancelled' || $orderStatusRaw === 'refunded'): ?>
                <div class="text-center py-6">
                    <i class="fas fa-times-circle fa-3x text-red-500 mb-3"></i>
                    <p class="text-lg text-gray-700">This order has been <?php echo strtolower($orderStatusDisplay); ?>.</p>
                    <p class="text-sm text-gray-500 mt-1">If you have questions, please contact support.</p>
                </div>
            <?php else: ?>
                <div class="mb-8">
                    <h2 class="text-lg font-semibold text-gray-700 mb-3">Order Progress</h2>
                    <div class="flex items-center">
                        <?php 
                        $isPastCurrent = true;
                        foreach ($statusSequence as $index => $statusKey): 
                            if ($statusKey === 'pending_payment' && $orderStatusRaw !== 'pending_payment' && $orderStatusRaw !== 'awaiting_payment') continue; // Skip if past this early stage unless it's the current
                            if ($statusKey === 'awaiting_payment' && $orderStatusRaw !== 'awaiting_payment' && $currentStatusIndex > $index) continue;

                            $isCompleted = $currentStatusIndex !== false && $index < $currentStatusIndex;
                            $isCurrent = $currentStatusIndex !== false && $index === $currentStatusIndex;
                            if ($isCurrent) $isPastCurrent = false;
                        ?>
                        <?php if ($index > 0 && array_search($statusSequence[$index-1], $statusSequence) < array_search($statusKey, $statusSequence) ): // Ensure there's a line only if it's not the first visible item ?>
                            <div class="flex-auto border-t-2 transition-colors duration-500 ease-in-out <?php echo ($isCompleted || $isCurrent) ? 'border-indigo-600' : 'border-gray-300'; ?>"></div>
                        <?php endif; ?>
                        <div class="flex items-center relative">
                            <div class="rounded-full transition-colors duration-500 ease-in-out h-8 w-8 md:h-10 md:w-10 flex items-center justify-center text-white <?php echo ($isCompleted || $isCurrent) ? 'bg-indigo-600' : 'bg-gray-300'; ?>">
                                <?php if($isCompleted): ?><i class="fas fa-check"></i><?php elseif($isCurrent): ?><i class="fas fa-spinner fa-spin"></i><?php else: echo $index + 1; endif; ?>
                            </div>
                            <p class="absolute top-0 -ml-10 text-center mt-12 w-32 text-xs font-medium uppercase <?php echo ($isCompleted || $isCurrent) ? 'text-indigo-600' : 'text-gray-500'; ?>">
                                <?php echo $statusLabels[$statusKey] ?? ucfirst(str_replace('_',' ',$statusKey)); ?>
                            </p>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-16">
                    <div>
                        <h3 class="font-semibold text-gray-700 mb-1">Shipping Provider:</h3>
                        <p class="text-gray-600"><?php echo $shippingProvider; ?></p>
                    </div>
                    <div>
                        <h3 class="font-semibold text-gray-700 mb-1">Tracking Number:</h3>
                        <?php if ($trackingNumber !== 'Not yet available' && !empty($trackingNumber)): ?>
                            <p class="text-gray-600 font-mono bg-gray-100 px-2 py-1 rounded inline-block"><?php echo $trackingNumber; ?></p>
                            <?php // You could add a link to a generic tracking site or specific provider if known
                                // Example: if(strtolower($order['shipping_provider']) === 'fastway') link to fastway + tracking number
                            ?>
                        <?php else: ?>
                            <p class="text-gray-600"><?php echo $trackingNumber; ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <?php if ($orderStatusRaw === 'processing'): ?>
                <p class="mt-6 text-sm text-gray-500">Your order is being processed. Tracking information will be available once it's shipped.</p>
                <?php elseif ($orderStatusRaw === 'shipped'): ?>
                <p class="mt-6 text-sm text-gray-500">Your order has been shipped! Use the tracking number above with the shipping provider for updates.</p>
                <?php elseif ($orderStatusRaw === 'delivered' || $orderStatusRaw === 'completed'): ?>
                <p class="mt-6 text-sm text-green-600 font-semibold">Your order has been delivered. Thank you for shopping with us!</p>
                <?php endif; ?>
            <?php endif; // End if not cancelled/refunded ?>

            <div class="mt-8 pt-6 border-t text-center">
                <a href="<?php echo $app_url . '/order/detail/' . $orderIdDisplay; ?>" class="text-indigo-600 hover:text-indigo-800 text-sm font-medium mr-4">
                    <i class="fas fa-info-circle mr-1"></i>View Order Details
                </a>
                <a href="<?php echo $app_url . '/profile/' . ($_SESSION['username'] ?? '') . '/orders'; ?>" class="text-gray-600 hover:text-gray-800 text-sm font-medium">
                    <i class="fas fa-list-alt mr-1"></i>Back to Order History
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>