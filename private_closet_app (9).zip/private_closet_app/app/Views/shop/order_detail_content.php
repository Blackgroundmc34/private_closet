<?php
// File: app/Views/shop/order_detail_content.php
// Displays detailed information about a single order.

$order = $order ?? null; // Expected from ShopController
$app_url = $app_url ?? (defined('APP_URL') ? rtrim(APP_URL, '/') : '');

if (!function_exists('escape_html')) {
    function escape_html($string) { return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
if (!function_exists('format_price')) {
    function format_price($price, string $currencySymbol = 'R'): string {
        if (!is_numeric($price)) $price = 0.00;
        return $currencySymbol . number_format((float)$price, 2, '.', ',');
    }
}
if (!function_exists('format_order_datetime')) { // More specific name
    function format_order_datetime($datetimeStr) {
        if (!$datetimeStr) return 'N/A';
        try {
            $date = new DateTime($datetimeStr);
            return $date->format('F j, Y, g:i a'); // e.g., May 22, 2025, 10:30 pm
        } catch (Exception $e) {
            return 'Invalid Date';
        }
    }
}

$default_product_image_url = $app_url . '/assets/images/default_product_image.png'; // Ensure this path is correct
?>

<div class="container mx-auto px-4 py-8">
    <?php if (!$order || !isset($order['id'])): ?>
        <div class="bg-white p-6 rounded-lg shadow text-center">
            <p class="text-red-500">Order details could not be loaded.</p>
        </div>
    <?php else: ?>
        <?php
            $orderIdDisplay = escape_html($order['id']);
            $orderDate = format_order_datetime($order['created_at'] ?? '');
            $orderStatusRaw = strtolower($order['status'] ?? 'unknown');
            $orderStatusDisplay = escape_html(ucfirst(str_replace('_', ' ', $orderStatusRaw)));
            
            $statusClasses = [
                'pending_payment' => 'bg-yellow-100 text-yellow-800',
                'awaiting_payment' => 'bg-yellow-100 text-yellow-800',
                'on-hold' => 'bg-yellow-100 text-yellow-800',
                'processing' => 'bg-blue-100 text-blue-800',
                'shipped' => 'bg-purple-100 text-purple-800',
                'delivered' => 'bg-green-100 text-green-700',
                'completed' => 'bg-green-100 text-green-700',
                'cancelled' => 'bg-red-100 text-red-700',
                'refunded' => 'bg-gray-100 text-gray-700',
                'default' => 'bg-gray-100 text-gray-700'
            ];
            $statusClass = $statusClasses[$orderStatusRaw] ?? $statusClasses['default'];

            $shippingAddress = $order['shipping_address_details'] ?? [];
            $billingAddress = $order['billing_address_details'] ?? [];
            $orderItems = $order['items'] ?? [];
        ?>
        <div class="bg-white shadow-xl rounded-lg p-6 sm:p-8">
            <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 pb-4 border-b border-gray-200">
                <div>
                    <h1 class="text-2xl md:text-3xl font-bold text-gray-800">Order #<?php echo $orderIdDisplay; ?></h1>
                    <p class="text-sm text-gray-500">Placed on: <?php echo $orderDate; ?></p>
                </div>
                <div class="mt-3 md:mt-0">
                    <span class="px-3 py-1 inline-flex text-sm leading-5 font-semibold rounded-full <?php echo $statusClass; ?>">
                        Status: <?php echo $orderStatusDisplay; ?>
                    </span>
                </div>
            </div>

            <?php if (($order['payment_method'] ?? '') === 'manual_eft' && ($order['status'] ?? '') === 'awaiting_payment'): ?>
                <div class="mb-6 p-4 border border-indigo-200 rounded-md bg-indigo-50 text-left">
                    <h3 class="text-lg font-semibold text-indigo-700 mb-2"><i class="fas fa-university mr-2"></i>Manual EFT / Bank Deposit Instructions</h3>
                    <p class="text-sm text-gray-700 mb-1">Please make payment to the following bank account:</p>
                    <ul class="text-sm text-gray-700 list-disc list-inside mb-3 pl-4">
                        <li><strong>Bank:</strong> FNB (First National Bank)</li>
                        <li><strong>Account Name:</strong> Private Closet (Pty) Ltd</li>
                        <li><strong>Account Number:</strong> 60012345678</li>
                        <li><strong>Branch Code:</strong> 250655</li>
                        <li><strong>Reference:</strong> Order #<?php echo $orderIdDisplay; ?></li>
                    </ul>
                    <p class="text-sm text-gray-700 mb-1"><strong>Amount:</strong> <?php echo format_price($order['total_amount'] ?? 0); ?></p>
                    <p class="text-xs text-gray-500">Use your Order ID as reference. Send proof of payment to payments@privatecloset.co.za.</p>
                </div>
            <?php endif; ?>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                    <h2 class="text-lg font-semibold text-gray-700 mb-2">Shipping Address</h2>
                    <div class="text-sm text-gray-600 bg-gray-50 p-4 rounded-md border">
                        <p><strong><?php echo escape_html($shippingAddress['full_name'] ?? 'N/A'); ?></strong></p>
                        <p><?php echo escape_html($shippingAddress['address_line_1'] ?? 'N/A'); ?></p>
                        <?php if(!empty($shippingAddress['address_line_2'])): ?><p><?php echo escape_html($shippingAddress['address_line_2']); ?></p><?php endif; ?>
                        <p><?php echo escape_html($shippingAddress['city'] ?? 'N/A'); ?>, <?php echo escape_html($shippingAddress['province'] ?? 'N/A'); ?> <?php echo escape_html($shippingAddress['postal_code'] ?? 'N/A'); ?></p>
                        <p>Phone: <?php echo escape_html($shippingAddress['phone'] ?? 'N/A'); ?></p>
                    </div>
                </div>
                <div>
                    <h2 class="text-lg font-semibold text-gray-700 mb-2">Billing Address</h2>
                    <div class="text-sm text-gray-600 bg-gray-50 p-4 rounded-md border">
                        <?php if(json_encode($shippingAddress) === json_encode($billingAddress) || empty($billingAddress['full_name'])): // Heuristic for "same as shipping" ?>
                            <p>Same as shipping address.</p>
                        <?php else: ?>
                            <p><strong><?php echo escape_html($billingAddress['full_name'] ?? 'N/A'); ?></strong></p>
                            <p><?php echo escape_html($billingAddress['address_line_1'] ?? 'N/A'); ?></p>
                            <?php if(!empty($billingAddress['address_line_2'])): ?><p><?php echo escape_html($billingAddress['address_line_2']); ?></p><?php endif; ?>
                            <p><?php echo escape_html($billingAddress['city'] ?? 'N/A'); ?>, <?php echo escape_html($billingAddress['province'] ?? 'N/A'); ?> <?php echo escape_html($billingAddress['postal_code'] ?? 'N/A'); ?></p>
                            <p>Phone: <?php echo escape_html($billingAddress['phone'] ?? 'N/A'); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="mb-6">
                <h2 class="text-lg font-semibold text-gray-700 mb-2">Payment Information</h2>
                <div class="text-sm text-gray-600 bg-gray-50 p-4 rounded-md border">
                    <p><strong>Method:</strong> <?php echo escape_html(ucwords(str_replace('_', ' ', $order['payment_method'] ?? 'N/A'))); ?></p>
                    <p><strong>Status:</strong> <span class="font-medium <?php echo ($order['payment_status'] ?? 'pending') === 'paid' ? 'text-green-600' : 'text-yellow-600'; ?>"><?php echo escape_html(ucfirst($order['payment_status'] ?? 'Pending')); ?></span></p>
                    <?php if(!empty($order['payment_gateway_ref'])): ?>
                        <p><strong>Reference:</strong> <?php echo escape_html($order['payment_gateway_ref']); ?></p>
                    <?php endif; ?>
                </div>
            </div>
            
            <div>
                <h2 class="text-lg font-semibold text-gray-700 mb-3">Order Items (<?php echo count($orderItems); ?>)</h2>
                <div class="space-y-4">
                    <?php foreach ($orderItems as $item): ?>
                        <div class="flex items-center gap-4 p-3 border rounded-md bg-white hover:bg-gray-50">
                            <a href="<?php echo $app_url . '/product/' . escape_html($item['product_slug'] ?? $item['product_id']); ?>" class="flex-shrink-0">
                                <img src="<?php echo escape_html($item['product_image'] ?? $default_product_image_url); ?>" 
                                     alt="<?php echo escape_html($item['product_name'] ?? 'Product'); ?>" 
                                     class="w-20 h-20 object-cover rounded-md border"
                                     onerror="this.onerror=null; this.src='<?php echo $default_product_image_url; ?>';">
                            </a>
                            <div class="flex-grow">
                                <a href="<?php echo $app_url . '/product/' . escape_html($item['product_slug'] ?? $item['product_id']); ?>" class="font-medium text-gray-800 hover:text-indigo-600"><?php echo escape_html($item['product_name'] ?? 'Product'); ?></a>
                                <p class="text-sm text-gray-500">Qty: <?php echo (int)($item['quantity'] ?? 1); ?></p>
                                <p class="text-sm text-gray-500">Price: <?php echo format_price($item['price_at_time_of_order'] ?? 0); ?></p>
                            </div>
                            <p class="text-md font-semibold text-gray-700">
                                <?php echo format_price((float)($item['price_at_time_of_order'] ?? 0) * (int)($item['quantity'] ?? 1)); ?>
                            </p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="mt-6 pt-6 border-t">
                <div class="w-full md:w-1/2 md:ml-auto space-y-2 text-gray-700">
                    <div class="flex justify-between">
                        <span>Subtotal:</span>
                        <span><?php echo format_price(($order['total_amount'] ?? 0) - ($order['shipping_cost'] ?? 0)); // Approximate subtotal ?></span>
                    </div>
                    <div class="flex justify-between">
                        <span>Shipping:</span>
                        <span><?php echo format_price($order['shipping_cost'] ?? 0); ?></span>
                    </div>
                    <div class="flex justify-between text-lg font-bold text-gray-900">
                        <span>Grand Total:</span>
                        <span><?php echo format_price($order['total_amount'] ?? 0); ?></span>
                    </div>
                </div>
            </div>
            
            <div class="mt-8 flex flex-col sm:flex-row justify-end gap-3">
                <?php if(!empty($order['tracking_number']) && $order['status'] === 'shipped'): ?>
                     <a href="<?php echo $app_url . '/order/track/' . $orderIdDisplay; ?>" class="px-5 py-2.5 text-sm font-medium text-center text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 inline-flex items-center justify-center">
                        <i class="fas fa-truck mr-2"></i>Track Your Order
                    </a>
                <?php endif; ?>
                <a href="<?php echo $app_url . '/profile/' . ($_SESSION['username'] ?? '') . '/orders'; ?>" class="px-5 py-2.5 text-sm font-medium text-center text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 border border-gray-300 focus:ring-4 focus:outline-none focus:ring-gray-200 inline-flex items-center justify-center">
                    <i class="fas fa-list-alt mr-2"></i>Back to Order History
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>