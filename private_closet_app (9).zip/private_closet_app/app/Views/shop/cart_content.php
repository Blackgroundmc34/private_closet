<?php
// File: app/Views/shop/cart_content.php
// Purpose: Contains the HTML structure for the shopping cart page.
// Expects $cartItems (array of item details) and $cartTotals (array of totals) from CartController.

// Ensure variables are initialized to prevent errors if not passed from controller
$cartItems = $cartItems ?? [];
$cartTotals = $cartTotals ?? ['subtotal' => 0, 'shipping' => 0, 'total' => 0, 'item_count' => 0];
$app_url = $app_url ?? (defined('APP_URL') ? APP_URL : '');
$csrf_token = $csrf_token ?? ($_SESSION['csrf_token'] ?? ''); // Ensure CSRF token is available

// Helper functions (ensure they are loaded, e.g., via bootstrap.php or defined here)
if (!function_exists('escape_html')) {
    function escape_html($string) { return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
if (!function_exists('format_price')) {
    function format_price($price, string $currencySymbol = 'R'): string {
        if (!is_numeric($price)) $price = 0;
        return $currencySymbol . number_format((float)$price, 2, '.', ',');
    }
}

// Default product image URL
$default_product_image_url = $app_url . '/assets/images/default_product_image.png';

?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-2xl md:text-3xl font-bold text-gray-900 mb-6">Your Shopping Cart</h1>

    <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="mb-4 p-3 rounded-md <?php echo htmlspecialchars($_SESSION['flash_message']['type'] === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'); ?>">
            <?php echo htmlspecialchars($_SESSION['flash_message']['text']); ?>
        </div>
        <?php unset($_SESSION['flash_message']); // Clear the flash message after displaying ?>
    <?php endif; ?>

    <?php if (empty($cartItems)): ?>
        <div class="bg-white p-6 rounded-lg shadow text-center">
            <i class="fas fa-shopping-cart text-4xl text-gray-400 mb-4"></i>
            <p class="text-gray-600">Your cart is currently empty.</p>
            <a href="<?php echo htmlspecialchars($app_url); ?>/showroom" class="mt-4 inline-block px-5 py-2 bg-indigo-600 text-white text-sm font-medium rounded-md hover:bg-indigo-700 transition-colors duration-150">
                Continue Shopping
            </a>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">

            <div class="lg:col-span-2 bg-white p-4 md:p-6 rounded-lg shadow">
                <h2 class="text-xl font-semibold mb-4 text-gray-800">Items (<?php echo (int)($cartTotals['item_count'] ?? 0); ?>)</h2>
                <div class="space-y-6">
                    <?php foreach ($cartItems as $cartItemId => $item): ?>
                        <?php
                            // Prepare item data for display, with fallbacks
                            $product_id = (int)($item['product_id'] ?? 0);
                            $item_name = escape_html($item['name'] ?? 'Unknown Product');
                            $item_slug = escape_html($item['slug'] ?? $product_id);
                            $item_image_url = escape_html($item['image'] ?? $default_product_image_url);
                            $item_business_name = escape_html($item['business_name'] ?? 'N/A');
                            $item_quantity = (int)($item['quantity'] ?? 1);
                            $item_price = (float)($item['price'] ?? 0.00);
                            $line_total = (float)($item['line_total'] ?? ($item_price * $item_quantity));
                            $item_options = $item['options'] ?? [];
                            // Assuming stock_quantity might be passed for validation in input field
                            $stock_quantity = isset($item['stock_quantity']) ? (int)$item['stock_quantity'] : 99; // Default high if not passed
                        ?>
                        <div class="flex flex-col sm:flex-row items-start sm:items-center gap-4 border-b pb-6 last:border-b-0 cart-item-row" data-cart-item-id="<?php echo escape_html($cartItemId); ?>">
                            <a href="<?php echo htmlspecialchars($app_url . '/product/' . $item_slug); ?>" class="flex-shrink-0">
                                <img src="<?php echo $item_image_url; ?>" 
                                     alt="<?php echo $item_name; ?>" 
                                     class="w-24 h-24 object-cover rounded-md border"
                                     onerror="this.onerror=null; this.src='<?php echo $default_product_image_url; ?>';">
                            </a>

                            <div class="flex-grow">
                                <h3 class="font-semibold text-md mb-1">
                                    <a href="<?php echo htmlspecialchars($app_url . '/product/' . $item_slug); ?>" class="hover:text-indigo-600 product-name">
                                        <?php echo $item_name; ?>
                                    </a>
                                </h3>
                                <p class="text-sm text-gray-500 mb-1">Sold by: <?php echo $item_business_name; ?></p>
                                <?php if (!empty($item_options) && is_array($item_options)): ?>
                                    <?php foreach($item_options as $optionName => $optionValue): ?>
                                        <p class="text-sm text-gray-600">
                                            <span class="font-medium"><?php echo escape_html($optionName); ?>:</span> <?php echo escape_html($optionValue); ?>
                                        </p>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>

                            <div class="flex flex-col items-start sm:items-end space-y-2 sm:space-y-0 sm:space-x-4 mt-2 sm:mt-0 w-full sm:w-auto">
                                <form action="<?php echo htmlspecialchars($app_url . '/cart/update'); ?>" method="POST" class="flex items-center update-quantity-form">
                                    <input type="hidden" name="csrf_token" value="<?php echo escape_html($csrf_token); ?>">
                                    <input type="hidden" name="cart_item_id" value="<?php echo escape_html($cartItemId); ?>">
                                    <label for="quantity_<?php echo escape_html($cartItemId); ?>" class="sr-only">Quantity</label>
                                    <input type="number" id="quantity_<?php echo escape_html($cartItemId); ?>" name="quantity" 
                                           value="<?php echo $item_quantity; ?>" min="0" max="<?php echo $stock_quantity; ?>" class="w-16 px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                                           onchange="this.form.submit()">
                                </form>

                                <p class="text-md font-semibold text-gray-900"><?php echo format_price($line_total); ?></p>

                                <form action="<?php echo htmlspecialchars($app_url . '/cart/remove'); ?>" method="POST" class="remove-item-form">
                                    <input type="hidden" name="csrf_token" value="<?php echo escape_html($csrf_token); ?>">
                                    <input type="hidden" name="cart_item_id" value="<?php echo escape_html($cartItemId); ?>">
                                    <button type="button" class="text-red-600 hover:text-red-800 text-sm font-medium remove-item-btn" 
                                            aria-label="Remove <?php echo $item_name; ?>">
                                        <i class="fas fa-trash-alt mr-1"></i>Remove
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="lg:col-span-1">
                <div class="bg-white p-6 rounded-lg shadow sticky top-24"> 
                    <h2 class="text-xl font-semibold mb-4 text-gray-800 border-b pb-2">Order Summary</h2>
                    <div class="space-y-3 text-gray-700">
                        <div class="flex justify-between">
                            <span>Subtotal</span>
                            <span class="font-medium"><?php echo format_price($cartTotals['subtotal']); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span>Estimated Shipping</span>
                            <span class="font-medium"><?php echo format_price($cartTotals['shipping']); ?></span>
                        </div>
                        <div class="flex justify-between border-t pt-3 text-lg font-bold text-gray-900">
                            <span>Total</span>
                            <span><?php echo format_price($cartTotals['total']); ?></span>
                        </div>
                    </div>
                    <div class="mt-6">
                        <a href="<?php echo htmlspecialchars($app_url . '/checkout/shipping'); ?>" 
                           class="w-full inline-flex justify-center items-center px-6 py-3 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-150">
                            Proceed to Checkout
                        </a>
                    </div>
                    <div class="mt-4 text-center">
                        <a href="<?php echo htmlspecialchars($app_url); ?>/showroom" class="text-sm text-indigo-600 hover:underline">
                            or Continue Shopping
                        </a>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<div id="removeConfirmModal" class="fixed inset-0 bg-gray-800 bg-opacity-75 overflow-y-auto h-full w-full flex items-center justify-center z-[1000]" style="display: none;">
    <div class="bg-white p-5 sm:p-8 rounded-lg shadow-xl w-11/12 md:max-w-lg mx-auto transform transition-all duration-300 ease-out scale-95 opacity-0" id="removeConfirmModalContent">
        <div class="text-center">
            <div class="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-red-100 mb-5">
                <i class="fas fa-exclamation-triangle fa-3x text-red-500"></i>
            </div>
            <h3 class="text-xl leading-6 font-semibold text-gray-900 mb-2" id="modalTitle">Remove Item?</h3>
            <div class="mt-2 px-4 py-3">
                <p class="text-md text-gray-600" id="modalMessage">Are you sure you want to remove "<strong id="modalItemName" class="font-semibold">this item</strong>" from your cart?</p>
            </div>
            <div class="mt-6 sm:mt-8 flex flex-col sm:flex-row-reverse gap-3 justify-center">
                <button id="confirmRemoveBtn" type="button" class="w-full sm:w-auto inline-flex justify-center rounded-md border border-transparent shadow-sm px-6 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 sm:text-sm">
                    <i class="fas fa-trash-alt mr-2"></i>Remove
                </button>
                <button id="cancelRemoveBtn" type="button" class="w-full sm:w-auto mt-3 sm:mt-0 inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-6 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:text-sm">
                    Cancel
                </button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('removeConfirmModal');
    const modalContent = document.getElementById('removeConfirmModalContent');
    const modalItemNameSpan = document.getElementById('modalItemName');
    const confirmRemoveBtn = document.getElementById('confirmRemoveBtn');
    const cancelRemoveBtn = document.getElementById('cancelRemoveBtn');
    let formToSubmit = null; // Variable to store the form that needs to be submitted

    document.querySelectorAll('.remove-item-btn').forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault(); // Prevent immediate form submission
            formToSubmit = this.closest('form.remove-item-form'); // Get the parent form
            
            // Try to find the product name from the closest cart item row
            const cartItemRow = this.closest('.cart-item-row');
            let itemName = 'this item'; // Default
            if (cartItemRow) {
                const productNameElement = cartItemRow.querySelector('.product-name');
                if (productNameElement) {
                    itemName = productNameElement.textContent.trim();
                }
            }
            
            modalItemNameSpan.textContent = itemName;
            modal.style.display = 'flex'; // Show the modal overlay
            
            // Trigger CSS transition for modal content
            setTimeout(() => {
                modalContent.style.opacity = '1';
                modalContent.style.transform = 'scale(1)';
            }, 10); 
        });
    });

    function closeModal() {
        modalContent.style.opacity = '0';
        modalContent.style.transform = 'scale(0.95)';
        setTimeout(() => {
            modal.style.display = 'none'; // Hide the modal overlay after transition
            formToSubmit = null; // Reset the form to submit
        }, 300); // Should match the transition duration (e.g., duration-300)
    }

    confirmRemoveBtn.addEventListener('click', function() {
        if (formToSubmit) {
            formToSubmit.submit(); // Submit the stored form
        }
        // No need to call closeModal here if page reloads due to form submission
    });

    cancelRemoveBtn.addEventListener('click', closeModal);

    // Close modal if user clicks on the overlay (outside the modal content)
    modal.addEventListener('click', function(event) {
        if (event.target === modal) {
            closeModal();
        }
    });

    // Close modal with Escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape' && modal.style.display === 'flex') {
            closeModal();
        }
    });
});
</script>
