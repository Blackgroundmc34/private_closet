<?php
// File: app/Views/shop/checkout_review_content.php
// Purpose: Displays the final order review step before placing the order.

// Expected variables from ShopController::showCheckoutReview()
// These should be initialized by the controller before loading this view.
// For safety, provide defaults in case they are not set.
$shippingAddress = $shippingAddress ?? [];
$billingAddressOption = $_SESSION['checkout_billing_option'] ?? 'same'; // Get how billing address was set

// Determine billing address based on the option selected in the previous step
if ($billingAddressOption === 'different' && isset($_SESSION['checkout_billing_address']) && is_array($_SESSION['checkout_billing_address'])) {
    $billingAddress = $_SESSION['checkout_billing_address'];
} else {
    $billingAddress = $shippingAddress; // Default to shipping address if 'same' or if different billing address isn't properly set
}

$paymentMethod = $paymentMethod ?? 'N/A';
$cartItems = $cartItems ?? [];
$orderSummary = $orderSummary ?? ['subtotal' => 0, 'shipping' => 0, 'total' => 0, 'item_count' => 0];

$app_url = $app_url ?? (defined('APP_URL') ? APP_URL : '');
$csrf_token = $csrf_token ?? ($_SESSION['csrf_token'] ?? ''); // Ensure CSRF token is available

// Helper functions (ensure these are loaded, e.g., via bootstrap.php or defined in a global scope)
if (!function_exists('escape_html')) {
    function escape_html($string) { return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
if (!function_exists('format_price')) {
    function format_price($price, string $currencySymbol = 'R'): string {
        if (!is_numeric($price)) $price = 0.00; // Ensure numeric, default to 0.00
        return $currencySymbol . number_format((float)$price, 2, '.', ',');
    }
}
$default_product_image_url = $app_url . '/assets/images/default_product_image.png'; // Ensure this path is correct
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-2xl md:text-3xl font-bold text-gray-900 mb-6">Review Your Order</h1>

    <div class="mb-8">
        <ol class="flex items-center w-full text-sm font-medium text-center text-gray-500 dark:text-gray-400">
            <li class="flex md:w-full items-center text-indigo-600 dark:text-indigo-500 sm:after:content-[''] after:w-full after:h-1 after:border-b after:border-indigo-300 dark:after:border-indigo-700 after:border-1 after:hidden sm:after:inline-block after:mx-6 xl:after:mx-10">
                <span class="flex items-center after:content-['/'] sm:after:hidden after:mx-2 after:text-gray-200 dark:after:text-gray-500">
                    <i class="fas fa-map-marker-alt w-3.5 h-3.5 sm:w-4 sm:h-4 mr-2.5"></i> Shipping
                </span>
            </li>
            <li class="flex md:w-full items-center text-indigo-600 dark:text-indigo-500 sm:after:content-[''] after:w-full after:h-1 after:border-b after:border-indigo-300 dark:after:border-indigo-700 after:border-1 after:hidden sm:after:inline-block after:mx-6 xl:after:mx-10">
                <span class="flex items-center after:content-['/'] sm:after:hidden after:mx-2 after:text-gray-200 dark:after:text-gray-500">
                     <i class="fas fa-credit-card w-3.5 h-3.5 sm:w-4 sm:h-4 mr-2.5"></i> Payment
                </span>
            </li>
            <li class="flex items-center text-indigo-600 dark:text-indigo-500"> 
                 <i class="fas fa-check-circle w-3.5 h-3.5 sm:w-4 sm:h-4 mr-2.5"></i> Review
            </li>
        </ol>
    </div>

    <?php 
    $flashMessage = $_SESSION['flash_message'] ?? null; // Check session for flash messages
    if ($flashMessage && is_array($flashMessage) && isset($flashMessage['text'])): 
        $messageTypeClass = 'bg-blue-100 border-blue-500 text-blue-700'; // Default for info
        if ($flashMessage['type'] === 'success') {
            $messageTypeClass = 'bg-green-100 border-green-300 text-green-700';
        } elseif ($flashMessage['type'] === 'error') {
            $messageTypeClass = 'bg-red-100 border-red-300 text-red-700';
        } elseif ($flashMessage['type'] === 'warning') {
            $messageTypeClass = 'bg-yellow-100 border-yellow-300 text-yellow-700';
        }
    ?>
        <div class="mb-6 p-4 rounded-md border <?php echo $messageTypeClass; ?>" role="alert">
            <strong class="font-bold"><?php echo ucfirst(escape_html($flashMessage['type'])); ?>!</strong>
            <span><?php echo escape_html($flashMessage['text']); ?></span>
        </div>
        <?php unset($_SESSION['flash_message']); // Clear the flash message after displaying ?>
    <?php endif; ?>


    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
        <div class="md:col-span-2 bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-xl font-semibold mb-5 text-gray-800 border-b pb-3">Confirm Your Details</h2>

            <div class="mb-6">
                <div class="flex justify-between items-center mb-2">
                    <h3 class="text-lg font-medium text-gray-700"><i class="fas fa-shipping-fast mr-2 text-gray-400"></i>Shipping Address</h3>
                    <a href="<?php echo htmlspecialchars($app_url . '/checkout/shipping'); ?>" class="text-xs text-indigo-600 hover:underline font-medium">Change</a>
                </div>
                <div class="text-sm text-gray-600 bg-gray-50 p-4 rounded-md border border-gray-200">
                    <p><strong><?php echo escape_html($shippingAddress['full_name'] ?? 'N/A'); ?></strong></p>
                    <p><?php echo escape_html($shippingAddress['address_line_1'] ?? 'N/A'); ?></p>
                    <?php if(!empty($shippingAddress['address_line_2'])): ?>
                        <p><?php echo escape_html($shippingAddress['address_line_2']); ?></p>
                    <?php endif; ?>
                    <p><?php echo escape_html($shippingAddress['city'] ?? 'N/A'); ?>, <?php echo escape_html($shippingAddress['province'] ?? 'N/A'); ?> <?php echo escape_html($shippingAddress['postal_code'] ?? 'N/A'); ?></p>
                    <p>Phone: <?php echo escape_html($shippingAddress['phone'] ?? 'N/A'); ?></p>
                </div>
            </div>

            <div class="mb-6">
                 <div class="flex justify-between items-center mb-2">
                    <h3 class="text-lg font-medium text-gray-700"><i class="fas fa-file-invoice-dollar mr-2 text-gray-400"></i>Billing Address</h3>
                    <a href="<?php echo htmlspecialchars($app_url . '/checkout/payment'); ?>" class="text-xs text-indigo-600 hover:underline font-medium">Change</a>
                </div>
                <div class="text-sm text-gray-600 bg-gray-50 p-4 rounded-md border border-gray-200">
                    <?php if($billingAddressOption === 'same'): ?>
                        <p>Same as shipping address.</p>
                    <?php elseif(!empty($billingAddress)): // Check if billingAddress array is populated ?>
                        <p><strong><?php echo escape_html($billingAddress['full_name'] ?? 'N/A'); ?></strong></p>
                        <p><?php echo escape_html($billingAddress['address_line_1'] ?? 'N/A'); ?></p>
                        <?php if(!empty($billingAddress['address_line_2'])): ?>
                            <p><?php echo escape_html($billingAddress['address_line_2']); ?></p>
                        <?php endif; ?>
                        <p><?php echo escape_html($billingAddress['city'] ?? 'N/A'); ?>, <?php echo escape_html($billingAddress['province'] ?? 'N/A'); ?> <?php echo escape_html($billingAddress['postal_code'] ?? 'N/A'); ?></p>
                        <p>Phone: <?php echo escape_html($billingAddress['phone'] ?? 'N/A'); ?></p>
                    <?php else: ?>
                        <p>Billing address not specified or same as shipping.</p> 
                    <?php endif; ?>
                </div>
            </div>

            <div class="mb-6">
                <div class="flex justify-between items-center mb-2">
                    <h3 class="text-lg font-medium text-gray-700"><i class="fas fa-credit-card mr-2 text-gray-400"></i>Payment Method</h3>
                    <a href="<?php echo htmlspecialchars($app_url . '/checkout/payment'); ?>" class="text-xs text-indigo-600 hover:underline font-medium">Change</a>
                </div>
                <div class="text-sm text-gray-600 bg-gray-50 p-4 rounded-md border border-gray-200">
                    <p class="font-medium">
                        <?php 
                            switch ($paymentMethod) {
                                case 'card': echo '<i class="far fa-credit-card mr-2 text-indigo-600"></i>Credit/Debit Card'; break;
                                case 'eft_secure': echo '<i class="fas fa-university mr-2 text-indigo-600"></i>EFT Secure'; break;
                                case 'manual_eft': echo '<i class="fas fa-money-check-alt mr-2 text-indigo-600"></i>Manual EFT / Bank Deposit'; break;
                                default: echo 'Not specified'; break;
                            }
                        ?>
                    </p>
                </div>
            </div>

            <div>
                <h3 class="text-lg font-medium text-gray-700 mb-3"><i class="fas fa-box-open mr-2 text-gray-400"></i>Items in your order (<?php echo (int)($orderSummary['item_count'] ?? 0); ?>)</h3>
                <div class="space-y-4">
                    <?php if (empty($cartItems)): ?>
                        <p class="text-sm text-gray-500">Your cart is empty. Cannot proceed.</p>
                    <?php else: ?>
                        <?php foreach ($cartItems as $cartItemId => $item): ?>
                            <div class="flex items-center gap-4 border-b border-gray-100 pb-3 last:border-b-0 last:pb-0">
                                <img src="<?php echo escape_html($item['image'] ?? $default_product_image_url); ?>" 
                                     alt="<?php echo escape_html($item['name'] ?? 'Product'); ?>" 
                                     class="w-16 h-16 object-cover rounded-md border"
                                     onerror="this.onerror=null; this.src='<?php echo $default_product_image_url; ?>';">
                                <div class="flex-grow">
                                    <p class="font-medium text-sm text-gray-800"><?php echo escape_html($item['name'] ?? 'Product'); ?></p>
                                    <p class="text-xs text-gray-500">Qty: <?php echo (int)($item['quantity'] ?? 1); ?></p>
                                     <?php if (!empty($item['options']) && is_array($item['options'])): ?>
                                        <?php foreach($item['options'] as $optName => $optVal): ?>
                                            <p class="text-xs text-gray-500"><?php echo escape_html($optName); ?>: <?php echo escape_html($optVal); ?></p>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                                <p class="text-sm font-medium text-gray-700"><?php echo format_price((float)($item['price'] ?? 0) * (int)($item['quantity'] ?? 1)); ?></p>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="md:col-span-1">
            <div class="bg-white p-6 rounded-lg shadow-lg sticky top-24">
                <h2 class="text-xl font-semibold mb-4 text-gray-800 border-b pb-2">Order Summary</h2>
                <div class="space-y-3 text-gray-700 mb-6">
                    <div class="flex justify-between">
                        <span>Subtotal</span>
                        <span class="font-medium"><?php echo format_price($orderSummary['subtotal']); ?></span>
                    </div>
                    <div class="flex justify-between">
                        <span>Shipping</span>
                        <span class="font-medium"><?php echo format_price($orderSummary['shipping']); ?></span>
                    </div>
                    <div class="flex justify-between border-t pt-3 text-lg font-bold text-gray-900">
                        <span>Total</span>
                        <span><?php echo format_price($orderSummary['total']); ?></span>
                    </div>
                </div>

                <form action="<?php echo htmlspecialchars($app_url . '/checkout/place-order'); ?>" method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo escape_html($csrf_token); ?>">
                    <button type="submit" 
                            class="w-full inline-flex justify-center items-center px-6 py-3 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-colors duration-150 <?php echo empty($cartItems) ? 'opacity-50 cursor-not-allowed' : ''; ?>"
                            <?php echo empty($cartItems) ? 'disabled' : ''; ?>>
                        <i class="fas fa-lock mr-2"></i>Place Order Securely
                    </button>
                </form>
                <p class="text-xs text-gray-500 mt-3 text-center">By placing your order, you agree to our <a href="<?php echo htmlspecialchars($app_url . '/terms'); // Link to your terms page ?>" class="underline hover:text-indigo-600">Terms & Conditions</a>.</p>
            </div>
        </div>
    </div>
</div>
