<?php
// File: app/Views/shop/checkout_shipping_content.php

// Expected variables from ShopController:
// $errors (array) - Validation errors, specific and general.
// $oldInput (array) - Previously submitted form data to repopulate fields.
// $csrf_token (string) - CSRF token for form security.
// $app_url (string) - Base application URL.
// $orderSummary (array) - To display cart totals.

// Initialize variables with defaults to prevent errors if not set by the controller.
$errors = $errors ?? [];
$oldInput = $oldInput ?? []; 
$app_url = $app_url ?? (defined('APP_URL') ? APP_URL : '');
$csrf_token = $csrf_token ?? ($_SESSION['csrf_token'] ?? ''); // Ensure CSRF token is available.

// Order summary might be passed from the controller or fetched from session if stored there.
// The ShopController (shop_controller_place_order_fix) now passes $orderSummary.
$orderSummary = $orderSummary ?? ['subtotal' => 0, 'shipping' => 0, 'total' => 0, 'item_count' => 0];

// Helper function to display error for a specific field.
if (!function_exists('display_checkout_form_error')) {
    function display_checkout_form_error(string $field, array $error_list): void {
        if (isset($error_list[$field])) {
            echo '<p class="text-red-600 text-xs mt-1">' . htmlspecialchars($error_list[$field]) . '</p>';
        }
    }
}

// Helper function to get old input value, falling back to default.
if (!function_exists('get_checkout_old_input')) {
    function get_checkout_old_input(string $field, array $input_data, $default = '') {
        return htmlspecialchars($input_data[$field] ?? $default);
    }
}

// Helper function for formatting price (ensure it's available).
if (!function_exists('format_price')) { 
    function format_price($price, string $currencySymbol = 'R'): string {
        if (!is_numeric($price)) $price = 0;
        return $currencySymbol . number_format((float)$price, 2, '.', ',');
    }
}
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-2xl md:text-3xl font-bold text-gray-900 mb-6">Checkout - Shipping Address</h1>

    <div class="mb-8">
        <ol class="flex items-center w-full text-sm font-medium text-center text-gray-500 dark:text-gray-400">
            <li class="flex md:w-full items-center text-indigo-600 dark:text-indigo-500 sm:after:content-[''] after:w-full after:h-1 after:border-b after:border-indigo-100 dark:after:border-indigo-700 after:border-1 after:hidden sm:after:inline-block after:mx-6 xl:after:mx-10">
                <span class="flex items-center after:content-['/'] sm:after:hidden after:mx-2 after:text-gray-200 dark:after:text-gray-500">
                    <i class="fas fa-map-marker-alt w-3.5 h-3.5 sm:w-4 sm:h-4 mr-2.5"></i> Shipping
                </span>
            </li>
            <li class="flex md:w-full items-center after:content-['/'] sm:after:hidden after:mx-2 after:text-gray-200 dark:after:text-gray-500 sm:before:content-[''] before:w-full before:h-1 before:border-b before:border-gray-200 dark:before:border-gray-700 before:border-1 before:hidden sm:before:inline-block before:mr-6 xl:before:mr-10">
                <span class="flex items-center">
                     <i class="fas fa-credit-card w-3.5 h-3.5 sm:w-4 sm:h-4 mr-2.5"></i> Payment
                </span>
            </li>
            <li class="flex items-center">
                 <i class="fas fa-check-circle w-3.5 h-3.5 sm:w-4 sm:h-4 mr-2.5"></i> Review
            </li>
        </ol>
    </div>
    
    <?php if (!empty($errors['general'])): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 px-4 py-3 rounded-md relative mb-6 shadow" role="alert">
            <strong class="font-bold block"><i class="fas fa-exclamation-triangle mr-2"></i>An Error Occurred!</strong>
            <span class="block sm:inline"><?php echo htmlspecialchars($errors['general']); ?></span>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
        <div class="md:col-span-2">
            <div class="bg-white p-6 rounded-lg shadow-lg">
                <h2 class="text-xl font-semibold mb-5 text-gray-800 border-b pb-3">Enter your delivery address</h2>

                <form action="<?php echo htmlspecialchars($app_url . '/checkout/shipping'); ?>" method="POST" class="space-y-5">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">

                    <div>
                        <label for="full_name" class="block text-sm font-medium text-gray-700 mb-1">Full Name <span class="text-red-500">*</span></label>
                        <input type="text" id="full_name" name="full_name" required autocomplete="name"
                               value="<?php echo get_checkout_old_input('full_name', $oldInput); ?>"
                               class="w-full px-3 py-2 border <?php echo isset($errors['full_name']) ? 'border-red-500 ring-1 ring-red-300' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                        <?php display_checkout_form_error('full_name', $errors); ?>
                    </div>

                    <div>
                        <label for="address_line_1" class="block text-sm font-medium text-gray-700 mb-1">Street Address <span class="text-red-500">*</span></label>
                        <input type="text" id="address_line_1" name="address_line_1" required autocomplete="address-line1" placeholder="House number and street name"
                               value="<?php echo get_checkout_old_input('address_line_1', $oldInput); ?>"
                               class="w-full px-3 py-2 border <?php echo isset($errors['address_line_1']) ? 'border-red-500 ring-1 ring-red-300' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                        <?php display_checkout_form_error('address_line_1', $errors); ?>
                    </div>

                    <div>
                        <label for="address_line_2" class="block text-sm font-medium text-gray-700 mb-1">Apartment, suite, etc. (Optional)</label>
                        <input type="text" id="address_line_2" name="address_line_2" autocomplete="address-line2"
                               value="<?php echo get_checkout_old_input('address_line_2', $oldInput); ?>"
                               class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div>
                            <label for="city" class="block text-sm font-medium text-gray-700 mb-1">City <span class="text-red-500">*</span></label>
                            <input type="text" id="city" name="city" required autocomplete="address-level2"
                                   value="<?php echo get_checkout_old_input('city', $oldInput); ?>"
                                   class="w-full px-3 py-2 border <?php echo isset($errors['city']) ? 'border-red-500 ring-1 ring-red-300' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                            <?php display_checkout_form_error('city', $errors); ?>
                        </div>
                        <div>
                            <label for="province" class="block text-sm font-medium text-gray-700 mb-1">Province <span class="text-red-500">*</span></label>
                            <input type="text" id="province" name="province" required autocomplete="address-level1"
                                   value="<?php echo get_checkout_old_input('province', $oldInput); ?>"
                                   class="w-full px-3 py-2 border <?php echo isset($errors['province']) ? 'border-red-500 ring-1 ring-red-300' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                            <?php display_checkout_form_error('province', $errors); ?>
                        </div>
                        <div>
                            <label for="postal_code" class="block text-sm font-medium text-gray-700 mb-1">Postal Code <span class="text-red-500">*</span></label>
                            <input type="text" id="postal_code" name="postal_code" required autocomplete="postal-code"
                                   value="<?php echo get_checkout_old_input('postal_code', $oldInput); ?>"
                                   class="w-full px-3 py-2 border <?php echo isset($errors['postal_code']) ? 'border-red-500 ring-1 ring-red-300' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                             <?php display_checkout_form_error('postal_code', $errors); ?>
                        </div>
                    </div>

                     <div>
                        <label for="phone" class="block text-sm font-medium text-gray-700 mb-1">Phone Number <span class="text-red-500">*</span></label>
                        <input type="tel" id="phone" name="phone" required autocomplete="tel" placeholder="For delivery updates"
                               value="<?php echo get_checkout_old_input('phone', $oldInput); ?>"
                               class="w-full px-3 py-2 border <?php echo isset($errors['phone']) ? 'border-red-500 ring-1 ring-red-300' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                         <?php display_checkout_form_error('phone', $errors); ?>
                    </div>

                    <div class="flex items-center mt-6">
                        <input id="save_address" name="save_address" type="checkbox" value="1" 
                               <?php echo !empty($oldInput['save_address']) ? 'checked' : ''; ?>
                               class="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500">
                        <label for="save_address" class="ml-2 block text-sm text-gray-900">Save this address for next time</label>
                    </div>

                    <div class="pt-6 flex justify-between items-center border-t border-gray-200 mt-6">
                        <a href="<?php echo htmlspecialchars($app_url . '/cart'); ?>" class="text-sm text-indigo-600 hover:underline">
                            <i class="fas fa-arrow-left mr-1"></i> Return to Cart
                        </a>
                        <button type="submit" class="inline-flex justify-center items-center px-6 py-3 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-150">
                            Continue to Billing/Payment <i class="fas fa-arrow-right ml-2"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div class="md:col-span-1">
            <div class="bg-white p-6 rounded-lg shadow-lg sticky top-24"> <h2 class="text-xl font-semibold mb-4 text-gray-800 border-b pb-2">Order Summary</h2>
                 <div class="space-y-2 text-sm text-gray-600">
                     <?php if (!empty($orderSummary['item_count'])): ?>
                        <div class="flex justify-between">
                            <span>Items (<?php echo (int)$orderSummary['item_count']; ?>)</span>
                            <span><?php echo format_price($orderSummary['subtotal']); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span>Shipping</span>
                            <span><?php echo format_price($orderSummary['shipping']); ?></span>
                        </div>
                     <?php else: ?>
                        <p>Your cart appears to be empty.</p>
                     <?php endif; ?>
                 </div>
                 <div class="flex justify-between border-t pt-3 mt-3 text-lg font-bold text-gray-900">
                    <span>Total</span>
                    <span><?php echo format_price($orderSummary['total']); ?></span>
                 </div>
            </div>
        </div>
    </div>
</div>
