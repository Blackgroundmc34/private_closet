<?php
// File: app/Views/shop/order_confirmation_content.php
// Purpose: Displays the order confirmation message and details.

$order = $order ?? null; // Expected from ShopController::showOrderConfirmation()
$app_url = $app_url ?? (defined('APP_URL') ? APP_URL : '');

// Helpers
if (!function_exists('escape_html')) {
    function escape_html($string) { return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
if (!function_exists('format_price')) {
    function format_price($price, string $currencySymbol = 'R'): string {
        if (!is_numeric($price)) $price = 0;
        return $currencySymbol . number_format((float)$price, 2, '.', ',');
    }
}

$flashMessage = $flashMessage ?? ($_SESSION['flash_message'] ?? null);
if (isset($_SESSION['flash_message'])) unset($_SESSION['flash_message']);

?>

<div class="container mx-auto px-4 py-8">
    <?php if ($flashMessage && is_array($flashMessage) && isset($flashMessage['text'])): ?>
        <div class="mb-6 p-4 rounded-md text-sm 
            <?php echo ($flashMessage['type'] === 'success' ? 'bg-green-100 text-green-700 border border-green-300' : 
                       ($flashMessage['type'] === 'error' ? 'bg-red-100 text-red-700 border border-red-300' : 
                                                            'bg-blue-100 text-blue-700 border border-blue-300')); ?>">
            <strong class="font-semibold"><?php echo ucfirst(escape_html($flashMessage['type'])); ?>!</strong> <?php echo escape_html($flashMessage['text']); ?>
        </div>
    <?php endif; ?>

    <?php if ($order && isset($order['id'])): ?>
        <div class="bg-white p-6 sm:p-8 rounded-lg shadow-xl text-center">
            <div class="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-100 mb-5">
                <i class="fas fa-check-circle fa-3x text-green-500"></i>
            </div>
            <h1 class="text-2xl md:text-3xl font-bold text-gray-900 mb-3">Thank You for Your Order!</h1>
            <p class="text-gray-600 mb-1">Your Order ID is: <strong class="text-gray-800">#<?php echo escape_html($order['id']); ?></strong></p>
            <p class="text-gray-600 mb-6">
                Current status: <span class="font-semibold px-2 py-0.5 rounded-full text-sm
                    <?php 
                        switch ($order['status'] ?? 'pending_payment') {
                            case 'processing': echo 'bg-blue-100 text-blue-700'; break;
                            case 'awaiting_payment': case 'on-hold': echo 'bg-yellow-100 text-yellow-700'; break;
                            case 'completed': case 'shipped': case 'delivered': echo 'bg-green-100 text-green-700'; break;
                            case 'cancelled': case 'refunded': echo 'bg-red-100 text-red-700'; break;
                            default: echo 'bg-gray-100 text-gray-700'; break;
                        }
                    ?>">
                    <?php echo ucfirst(str_replace('_', ' ', escape_html($order['status'] ?? 'Pending'))); ?>
                </span>
            </p>

            <?php if (($order['payment_method'] ?? '') === 'manual_eft' && ($order['status'] ?? '') === 'awaiting_payment'): ?>
                <div class="my-6 p-4 border border-indigo-200 rounded-md bg-indigo-50 text-left max-w-lg mx-auto">
                    <h3 class="text-lg font-semibold text-indigo-700 mb-2"><i class="fas fa-university mr-2"></i>Manual EFT / Bank Deposit Instructions</h3>
                    <p class="text-sm text-gray-700 mb-1">Please make payment to the following bank account:</p>
                    <ul class="text-sm text-gray-700 list-disc list-inside mb-3">
                        <li><strong>Bank:</strong> FNB (First National Bank)</li>
                        <li><strong>Account Name:</strong> Private Closet (Pty) Ltd</li>
                        <li><strong>Account Number:</strong> 60012345678</li>
                        <li><strong>Branch Code:</strong> 250655</li>
                        <li><strong>Reference:</strong> Order #<?php echo escape_html($order['id']); ?></li>
                    </ul>
                    <p class="text-sm text-gray-700 mb-1"><strong>Amount:</strong> <?php echo format_price($order['total_amount'] ?? 0); ?></p>
                    <p class="text-xs text-gray-500">Please use your Order ID as the payment reference. Your order will be processed once payment is confirmed. Send proof of payment to payments@privatecloset.co.za to speed up confirmation.</p>
                </div>
            <?php else: ?>
                <p class="text-gray-600 mb-4">You will receive an email confirmation shortly with your order details.</p>
            <?php endif; ?>

            <div class="mt-8">
                <a href="<?php echo htmlspecialchars($app_url); ?>/showroom" class="px-6 py-3 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 transition-colors duration-150">
                    <i class="fas fa-shopping-bag mr-2"></i>Continue Shopping
                </a>
                <?php if(isset($_SESSION['user_id'])): // Link to order history if user is logged in ?>
                <a href="<?php echo htmlspecialchars($app_url); ?>/profile/<?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?>/orders" class="ml-3 px-6 py-3 bg-gray-200 text-gray-700 font-semibold rounded-md hover:bg-gray-300 transition-colors duration-150">
                    View Order History
                </a>
                <?php endif; ?>
            </div>
        </div>
    <?php else: ?>
        <div class="bg-white p-8 rounded-lg shadow-xl text-center">
            <i class="fas fa-exclamation-circle fa-3x text-red-500 mb-4"></i>
            <h1 class="text-2xl font-bold text-gray-800 mb-3">Order Not Found</h1>
            <p class="text-gray-600 mb-6">We could not find the details for this order. It might have been an issue during processing, or the order ID is incorrect.</p>
            <a href="<?php echo htmlspecialchars($app_url); ?>/showroom" class="px-5 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                Back to Shopping
            </a>
        </div>
    <?php endif; ?>
</div>
