<?php
// File: app/Views/shop/checkout_payment_content.php
// Purpose: Contains the HTML structure for the payment method step of checkout.

// Expected variables from ShopController:
// $orderSummary (array) - Totals for display.
// $shippingAddress (array) - Shipping address details.
// $errors (array) - Validation errors.
// $oldInput (array) - Previously submitted form data for repopulation.
// $csrf_token (string) - CSRF token.
// $app_url (string) - Base application URL.

// Initialize variables with defaults
$orderSummary = $orderSummary ?? ['subtotal' => 0, 'shipping' => 0, 'total' => 0, 'item_count' => 0];
$shippingAddress = $shippingAddress ?? [];
$errors = $errors ?? [];
$oldInput = $oldInput ?? [];
$app_url = $app_url ?? (defined('APP_URL') ? APP_URL : '');
$csrf_token = $csrf_token ?? ($_SESSION['csrf_token'] ?? '');

// Helper functions (ensure they are loaded, e.g., via bootstrap.php or defined here)
if (!function_exists('escape_html')) {
    function escape_html($string) { return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
if (!function_exists('format_price')) {
    function format_price($price, string $currencySymbol = 'R'): string {
        if (!is_numeric($price)) $price = 0;
        return $currencySymbol . number_format((float)$price, 2, '.', ',');
    }
}
// Helper function to display error for a specific field.
if (!function_exists('display_checkout_form_error')) { // Re-using from shipping for consistency
    function display_checkout_form_error(string $field, array $error_list): void {
        if (isset($error_list[$field])) {
            echo '<p class="text-red-600 text-xs mt-1">' . htmlspecialchars($error_list[$field]) . '</p>';
        }
    }
}
// Helper function to get old input value, falling back to default.
if (!function_exists('get_checkout_old_input')) { // Re-using from shipping
    function get_checkout_old_input(string $field, array $input_data, $default = '') {
        return htmlspecialchars($input_data[$field] ?? $default);
    }
}
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-2xl md:text-3xl font-bold text-gray-900 mb-6">Checkout - Payment</h1>

    <div class="mb-8">
        <ol class="flex items-center w-full text-sm font-medium text-center text-gray-500 dark:text-gray-400">
            <li class="flex md:w-full items-center text-indigo-600 dark:text-indigo-500 sm:after:content-[''] after:w-full after:h-1 after:border-b after:border-indigo-300 dark:after:border-indigo-700 after:border-1 after:hidden sm:after:inline-block after:mx-6 xl:after:mx-10">
                <span class="flex items-center after:content-['/'] sm:after:hidden after:mx-2 after:text-gray-200 dark:after:text-gray-500">
                    <i class="fas fa-map-marker-alt w-3.5 h-3.5 sm:w-4 sm:h-4 mr-2.5"></i> Shipping
                </span>
            </li>
            <li class="flex md:w-full items-center text-indigo-600 dark:text-indigo-500 sm:after:content-[''] after:w-full after:h-1 after:border-b after:border-indigo-300 dark:after:border-indigo-700 after:border-1 after:hidden sm:after:inline-block after:mx-6 xl:after:mx-10">
                <span class="flex items-center after:content-['/'] sm:after:hidden after:mx-2 after:text-gray-200 dark:after:text-gray-500">
                     <i class="fas fa-credit-card w-3.5 h-3.5 sm:w-4 sm:h-4 mr-2.5"></i> Payment
                </span>
            </li>
            <li class="flex items-center text-gray-500 dark:text-gray-400">
                 <i class="fas fa-check-circle w-3.5 h-3.5 sm:w-4 sm:h-4 mr-2.5"></i> Review
            </li>
        </ol>
    </div>

    <?php if (!empty($errors['general'])): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 px-4 py-3 rounded-md relative mb-6 shadow" role="alert">
            <strong class="font-bold block"><i class="fas fa-exclamation-triangle mr-2"></i>Error!</strong>
            <span class="block sm:inline"><?php echo htmlspecialchars($errors['general']); ?></span>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
        <div class="md:col-span-2">
            <form action="<?php echo htmlspecialchars($app_url . '/checkout/payment'); ?>" method="POST" class="space-y-6">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">

                <div class="bg-white p-4 rounded-lg shadow-md">
                    <div class="flex justify-between items-center mb-2">
                        <h3 class="text-lg font-semibold text-gray-800">Ship To:</h3>
                        <a href="<?php echo htmlspecialchars($app_url . '/checkout/shipping'); ?>" class="text-xs text-indigo-600 hover:underline">Change</a>
                    </div>
                    <div class="text-sm text-gray-600 bg-gray-50 p-3 rounded-md">
                        <p><strong><?php echo escape_html($shippingAddress['full_name'] ?? 'N/A'); ?></strong></p>
                        <p><?php echo escape_html($shippingAddress['address_line_1'] ?? 'N/A'); ?></p>
                        <?php if(!empty($shippingAddress['address_line_2'])): ?>
                            <p><?php echo escape_html($shippingAddress['address_line_2']); ?></p>
                        <?php endif; ?>
                        <p><?php echo escape_html($shippingAddress['city'] ?? 'N/A'); ?>, <?php echo escape_html($shippingAddress['province'] ?? 'N/A'); ?> <?php echo escape_html($shippingAddress['postal_code'] ?? 'N/A'); ?></p>
                        <p>Phone: <?php echo escape_html($shippingAddress['phone'] ?? 'N/A'); ?></p>
                    </div>
                </div>

                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h3 class="text-lg font-semibold mb-3 text-gray-800">Billing Address</h3>
                    <div class="space-y-3">
                        <div class="flex items-center">
                            <input id="billing_same" name="billing_address_option" type="radio" value="same" 
                                   <?php echo (get_checkout_old_input('billing_address_option', $oldInput, 'same') === 'same') ? 'checked' : ''; ?> 
                                   class="h-4 w-4 text-indigo-600 border-gray-300 focus:ring-indigo-500">
                            <label for="billing_same" class="ml-3 block text-sm font-medium text-gray-700">Same as shipping address</label>
                        </div>
                        <div class="flex items-center">
                            <input id="billing_different" name="billing_address_option" type="radio" value="different"
                                   <?php echo (get_checkout_old_input('billing_address_option', $oldInput) === 'different') ? 'checked' : ''; ?>
                                   class="h-4 w-4 text-indigo-600 border-gray-300 focus:ring-indigo-500">
                            <label for="billing_different" class="ml-3 block text-sm font-medium text-gray-700">Use a different billing address</label>
                        </div>
                        <?php display_checkout_form_error('billing_address_option', $errors); ?>
                    </div>
                    
                    <div id="billing-address-fields" class="mt-4 space-y-4 <?php echo (get_checkout_old_input('billing_address_option', $oldInput) === 'different') ? '' : 'hidden'; ?>">
                        <hr class="my-4">
                        <p class="text-sm font-medium text-gray-700">Enter different billing address details:</p>
                        <div>
                            <label for="billing_full_name" class="block text-sm font-medium text-gray-700 mb-1">Full Name <span class="text-red-500">*</span></label>
                            <input type="text" id="billing_full_name" name="billing_full_name" autocomplete="billing name"
                                   value="<?php echo get_checkout_old_input('billing_full_name', $oldInput); ?>"
                                   class="w-full px-3 py-2 border <?php echo isset($errors['billing_full_name']) ? 'border-red-500 ring-1 ring-red-300' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                            <?php display_checkout_form_error('billing_full_name', $errors); ?>
                        </div>
                        <div>
                            <label for="billing_address_line_1" class="block text-sm font-medium text-gray-700 mb-1">Street Address <span class="text-red-500">*</span></label>
                            <input type="text" id="billing_address_line_1" name="billing_address_line_1" autocomplete="billing address-line1"
                                   value="<?php echo get_checkout_old_input('billing_address_line_1', $oldInput); ?>"
                                   class="w-full px-3 py-2 border <?php echo isset($errors['billing_address_line_1']) ? 'border-red-500 ring-1 ring-red-300' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                            <?php display_checkout_form_error('billing_address_line_1', $errors); ?>
                        </div>
                        <div>
                            <label for="billing_city" class="block text-sm font-medium text-gray-700 mb-1">City <span class="text-red-500">*</span></label>
                            <input type="text" id="billing_city" name="billing_city" autocomplete="billing address-level2"
                                   value="<?php echo get_checkout_old_input('billing_city', $oldInput); ?>"
                                   class="w-full px-3 py-2 border <?php echo isset($errors['billing_city']) ? 'border-red-500 ring-1 ring-red-300' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                            <?php display_checkout_form_error('billing_city', $errors); ?>
                        </div>
                        </div>
                </div>

                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h3 class="text-lg font-semibold mb-3 text-gray-800">Payment Method</h3>
                    <?php display_checkout_form_error('payment_method', $errors); ?>
                    <div class="space-y-3">
                        <?php 
                            $payment_methods = [
                                'card' => 'Credit/Debit Card',
                                'eft_secure' => 'EFT Secure',
                                'manual_eft' => 'Manual EFT / Bank Deposit'
                            ];
                            $selected_payment_method = get_checkout_old_input('payment_method', $oldInput);
                        ?>
                        <?php foreach ($payment_methods as $value => $label): ?>
                        <div class="border rounded-md p-3 has-[:checked]:bg-indigo-50 has-[:checked]:border-indigo-400 transition-all duration-150">
                            <input id="payment_<?php echo $value; ?>" name="payment_method" type="radio" value="<?php echo $value; ?>" required 
                                   <?php echo ($selected_payment_method === $value) ? 'checked' : ''; ?>
                                   class="h-4 w-4 text-indigo-600 border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-1 mr-3 align-middle payment-method-radio">
                            <label for="payment_<?php echo $value; ?>" class="text-sm font-medium text-gray-700 align-middle cursor-pointer"><?php echo $label; ?></label>
                            <div id="<?php echo $value; ?>-details" class="mt-2 pl-7 text-xs text-gray-500 <?php echo ($selected_payment_method !== $value) ? 'hidden' : ''; ?> payment-details-content">
                                <?php if ($value === 'card'): ?>
                                    Secure card payment will be processed by our trusted gateway. (Placeholder for gateway integration)
                                <?php elseif ($value === 'eft_secure'): ?>
                                    You will be redirected to complete the payment securely via your bank.
                                <?php elseif ($value === 'manual_eft'): ?>
                                    Banking details and instructions will be provided after you place the order. Payment confirmation will be required.
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="pt-6 flex justify-between items-center border-t border-gray-200 mt-6">
                    <a href="<?php echo htmlspecialchars($app_url . '/checkout/shipping'); ?>" class="text-sm text-indigo-600 hover:underline">
                        <i class="fas fa-arrow-left mr-1"></i> Return to Shipping
                    </a>
                    <button type="submit" class="inline-flex justify-center items-center px-6 py-3 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-150">
                        Continue to Review Order <i class="fas fa-arrow-right ml-2"></i>
                    </button>
                </div>
            </form>
        </div>

        <div class="md:col-span-1">
            <div class="bg-white p-6 rounded-lg shadow-lg sticky top-24">
                 <h2 class="text-xl font-semibold mb-4 text-gray-800 border-b pb-2">Order Summary</h2>
                 <div class="space-y-2 text-sm text-gray-600">
                    <?php if (!empty($orderSummary['item_count'])): ?>
                        <div class="flex justify-between">
                            <span>Items (<?php echo (int)$orderSummary['item_count']; ?>)</span>
                            <span><?php echo format_price($orderSummary['subtotal']); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span>Shipping</span>
                            <span><?php echo format_price($orderSummary['shipping']); ?></span>
                        </div>
                     <?php else: ?>
                        <p>Your cart is empty.</p>
                     <?php endif; ?>
                 </div>
                 <div class="flex justify-between border-t pt-3 mt-3 text-lg font-bold text-gray-900">
                    <span>Total</span>
                    <span><?php echo format_price($orderSummary['total']); ?></span>
                 </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const billingOptionSame = document.getElementById('billing_same');
    const billingOptionDiff = document.getElementById('billing_different');
    const billingFieldsDiv = document.getElementById('billing-address-fields');
    const billingRequiredFields = billingFieldsDiv.querySelectorAll('input[required]'); // Get required fields within this div

    function toggleBillingFields() {
        const isDifferent = billingOptionDiff.checked;
        billingFieldsDiv.classList.toggle('hidden', !isDifferent);
        // Dynamically set/remove 'required' attribute for fields in the different billing address section
        billingRequiredFields.forEach(field => {
            if (isDifferent) {
                field.setAttribute('required', 'required');
            } else {
                field.removeAttribute('required');
            }
        });
    }

    if (billingOptionSame && billingOptionDiff && billingFieldsDiv) {
        billingOptionSame.addEventListener('change', toggleBillingFields);
        billingOptionDiff.addEventListener('change', toggleBillingFields);
        toggleBillingFields(); // Initial call to set state based on pre-selected radio
    }

    const paymentMethodRadios = document.querySelectorAll('.payment-method-radio');
    paymentMethodRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            document.querySelectorAll('.payment-details-content').forEach(div => {
                div.classList.add('hidden');
            });
            if (this.checked) {
                const detailsDiv = document.getElementById(this.value + '-details');
                if (detailsDiv) {
                    detailsDiv.classList.remove('hidden');
                }
            }
        });
    });
});
</script>
