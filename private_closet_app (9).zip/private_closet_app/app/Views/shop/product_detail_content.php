<?php
// File: app/Views/shop/product_detail_content.php
// Purpose: Contains the HTML structure for displaying a single product's details.
// Expects $product, $reviews, $csrf_token variables passed from ShopController.

// --- Variable Setup & Validation ---
$product = $product ?? null; // Ensure $product exists
$reviews = $reviews ?? [];   // Ensure $reviews exists
$csrf_token = $csrf_token ?? ''; // Expected from controller
$loggedInUserId = $loggedInUserId ?? null; // Ensure loggedInUserId is available for review form
$isLoggedIn = (bool)$loggedInUserId; // Check if user is logged in

// Basic check if product data is available
if (!$product || !isset($product['id'], $product['name'], $product['price'], $product['description'])) {
    echo "<p class='text-center text-red-500 p-8'>Error: Essential product data is missing or invalid.</p>";
    error_log("Product Detail View: Missing essential data for product ID (if available): " . ($product['id'] ?? 'N/A'));
    return; // Stop rendering if essential data is missing
}

// --- Helper Functions & Constants ---
if (!function_exists('escape_html')) {
    // Assuming utilities.php is included via bootstrap or a global require
    // If not, define it:
    function escape_html($string) { return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
if (!function_exists('format_price')) {
    function format_price($price, string $currencySymbol = 'R'): string {
        if (!is_numeric($price)) $price = 0;
        if (extension_loaded('intl')) {
            $formatter = new NumberFormatter('en_ZA', NumberFormatter::CURRENCY);
            return $formatter->formatCurrency((float)$price, 'ZAR');
        }
        return $currencySymbol . number_format((float)$price, 2, '.', ',');
    }
}
$appUrl = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
$imageUrlPrefix = $appUrl . '/';
$defaultImageUrl = $appUrl . '/assets/images/placeholder_600x600.png';

// --- Image Processing ---
$mainImage = ['url' => $defaultImageUrl, 'alt' => escape_html($product['name'] ?? 'Product Image') . ' - Image unavailable'];
$thumbnails = [];
$primaryImageUrl = null;

if (!empty($product['images']) && is_array($product['images'])) {
    $processedImages = [];
    foreach ($product['images'] as $img) {
        if (empty($img['image_url']) || !is_string($img['image_url'])) {
            error_log("Product Detail: Skipping image due to missing/invalid 'image_url' for product ID: " . ($product['id'] ?? 'N/A'));
            continue;
        }
        $imageUrl = $img['image_url'];
        $isAbsoluteUrl = strpos($imageUrl, 'http://') === 0 || strpos($imageUrl, 'https://') === 0 || strpos($imageUrl, '//') === 0;
        $fullUrl = $isAbsoluteUrl ? $imageUrl : $imageUrlPrefix . ltrim($imageUrl, '/');
        $processedImage = ['url' => $fullUrl, 'alt' => escape_html($img['alt_text'] ?? $product['name']), 'is_primary' => !empty($img['is_primary'])];
        $processedImages[] = $processedImage;
        if ($processedImage['is_primary'] && $primaryImageUrl === null) {
            $primaryImageUrl = $processedImage['url'];
            $mainImage = $processedImage;
        }
    }
    $thumbnails = $processedImages;
    if ($primaryImageUrl === null && !empty($thumbnails)) {
        $mainImage = $thumbnails[0];
        $primaryImageUrl = $mainImage['url'];
    }
}

// --- Review Calculation (Example) ---
$totalRating = 0;
$reviewCount = count($reviews);
foreach ($reviews as $review) { $totalRating += ($review['rating'] ?? 0); }
$averageRating = $reviewCount > 0 ? round($totalRating / $reviewCount, 1) : 0;

// Prepare product data for JavaScript (used in Add to Cart)
$productNameForJS = escape_html($product['name']);
$productPriceForJS = (float)($product['price'] ?? 0.00);
$productImageForJS = $mainImage['url']; // Use the main display image for cart
$productSlugForJS = escape_html($product['slug'] ?? 'product-' . $product['id']);
$productStockForJS = isset($product['stock_quantity']) ? (int)$product['stock_quantity'] : 0;
$productBusinessNameForJS = escape_html($product['business']['name'] ?? 'Unknown Seller');

// Retrieve review errors and old input from session
$reviewErrors = $_SESSION['review_errors'] ?? [];
$oldReviewInput = $_SESSION['review_old_input'] ?? [];
unset($_SESSION['review_errors'], $_SESSION['review_old_input']);


$isFavorited = $isFavorited ?? false; 
?>

<div class="container mx-auto px-4 py-8">
    <div id="product-detail-notification" class="fixed top-20 right-4 z-[100]" style="display: none;">
        </div>

    <div class="bg-white p-4 sm:p-6 rounded-lg shadow-lg">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">

            <div>
                <div class="mb-4 border rounded-lg overflow-hidden aspect-square bg-gray-100 relative group">
                    <img id="mainProductImage" src="<?php echo $mainImage['url']; ?>"
                         alt="<?php echo $mainImage['alt']; ?>"
                         class="w-full h-full object-cover transition-transform duration-300 ease-in-out group-hover:scale-105"
                         onerror="this.onerror=null; this.src='<?php echo $defaultImageUrl; ?>'; this.alt='Image failed to load';">
                </div>

                <?php if (count($thumbnails) > 1): ?>
                <div class="flex space-x-2 overflow-x-auto pb-2" role="tablist" aria-label="Product image thumbnails">
                    <?php foreach ($thumbnails as $index => $thumb): ?>
                    <button role="tab" aria-selected="<?php echo ($thumb['url'] === $primaryImageUrl) ? 'true' : 'false'; ?>"
                            class="flex-shrink-0 focus:outline-none border-2 <?php echo ($thumb['url'] === $primaryImageUrl) ? 'border-indigo-500 ring-2 ring-indigo-300' : 'border-transparent'; ?> rounded hover:border-indigo-400 thumbnail-button p-0.5"
                            onclick="
                                const mainImg = document.getElementById('mainProductImage');
                                mainImg.src='<?php echo $thumb['url']; ?>';
                                mainImg.alt='<?php echo $thumb['alt']; ?>';
                                document.querySelectorAll('.thumbnail-button').forEach(btn => { btn.classList.remove('border-indigo-500', 'ring-2', 'ring-indigo-300'); btn.setAttribute('aria-selected', 'false'); });
                                this.classList.add('border-indigo-500', 'ring-2', 'ring-indigo-300');
                                this.setAttribute('aria-selected', 'true');
                            "
                            aria-controls="mainProductImage"
                            aria-label="View image <?php echo $index + 1; ?>: <?php echo $thumb['alt']; ?>">
                        <img src="<?php echo $thumb['url']; ?>"
                             alt="Thumbnail: <?php echo $thumb['alt']; ?>"
                             class="w-16 h-16 object-cover rounded"
                             loading="lazy">
                    </button>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <div>
                <h1 class="text-2xl md:text-3xl font-bold text-gray-900 mb-2"><?php echo escape_html($product['name']); ?></h1>

                <?php if (!empty($product['business']['name'])): ?>
                <p class="text-sm text-gray-500 mb-3">
                    Sold by: <a href="<?php echo escape_html($product['business']['profile_url'] ?? '#'); ?>" class="text-indigo-600 hover:underline"><?php echo escape_html($product['business']['name']); ?></a>
                </p>
                <?php endif; ?>

                <?php if ($reviewCount > 0): ?>
                <div class="flex items-center mb-4">
                    <div class="flex text-yellow-400" role="img" aria-label="Rating: <?php echo $averageRating; ?> out of 5 stars">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <?php if ($i <= floor($averageRating)): ?><i class="fas fa-star"></i><?php elseif ($i - 0.5 <= $averageRating): ?><i class="fas fa-star-half-alt"></i><?php else: ?><i class="far fa-star text-gray-300"></i><?php endif; ?>
                        <?php endfor; ?>
                    </div>
                    <a href="#reviews" class="text-gray-600 text-sm ml-2 hover:underline">(<?php echo $reviewCount; ?> review<?php echo $reviewCount !== 1 ? 's' : ''; ?>)</a>
                </div>
                <?php endif; ?>

                <p class="text-3xl font-extrabold text-gray-900 mb-4"><?php echo format_price($product['price']); ?></p>

                <div class="prose prose-sm max-w-none text-gray-700 mb-6">
                    <?php echo nl2br(escape_html($product['description'])); ?>
                </div>

                <form id="add-to-cart-form" class="space-y-4">
                    <input type="hidden" name="product_id" value="<?php echo (int)$product['id']; ?>">
                    <input type="hidden" name="csrf_token" value="<?php echo escape_html($csrf_token); ?>">
                    
                    <input type="hidden" name="product_name" value="<?php echo $productNameForJS; ?>">
                    <input type="hidden" name="product_price" value="<?php echo $productPriceForJS; ?>">
                    <input type="hidden" name="product_image" value="<?php echo $productImageForJS; ?>">
                    <input type="hidden" name="product_slug" value="<?php echo $productSlugForJS; ?>">
                    <input type="hidden" name="stock_quantity" value="<?php echo $productStockForJS; ?>">
                    <input type="hidden" name="business_name" value="<?php echo $productBusinessNameForJS; ?>">


                    <?php if (!empty($product['options']) && is_array($product['options'])): ?>
                        <?php foreach ($product['options'] as $optionName => $optionValues): ?>
                        <div class="mb-4">
                            <label for="option_<?php echo escape_html(strtolower(str_replace(' ', '_', $optionName))); ?>" class="block text-sm font-medium text-gray-700 mb-1"><?php echo escape_html($optionName); ?>:</label>
                            <?php if (!empty($optionValues) && is_array($optionValues)): ?>
                            <select id="option_<?php echo escape_html(strtolower(str_replace(' ', '_', $optionName))); ?>" name="options[<?php echo escape_html($optionName); ?>]" required class="w-full md:w-1/2 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm">
                                <option value="">Select <?php echo escape_html($optionName); ?></option>
                                <?php foreach ($optionValues as $value): ?>
                                <option value="<?php echo escape_html($value); ?>"><?php echo escape_html($value); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <?php else: ?>
                            <p class="text-sm text-gray-500">No options available for <?php echo escape_html($optionName); ?>.</p>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>

                    <?php $stockQuantity = isset($product['stock_quantity']) ? (int)$product['stock_quantity'] : 0; ?>
                    <div class="mb-6">
                        <label for="quantity" class="block text-sm font-medium text-gray-700 mb-1">Quantity:</label>
                        <div class="flex items-center space-x-3">
                            <input type="number" id="quantity" name="quantity" value="1" min="1" max="<?php echo $stockQuantity > 0 ? $stockQuantity : 1; ?>" required
                                   class="w-20 px-3 py-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm disabled:opacity-70 disabled:bg-gray-100"
                                   <?php echo ($stockQuantity <= 0) ? 'disabled' : ''; ?>>
                            <?php if ($stockQuantity > 0): ?>
                                <span class="text-sm text-gray-500">(<?php echo $stockQuantity; ?> in stock)</span>
                            <?php else: ?>
                                <span class="text-sm text-red-600">(Out of stock)</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="flex flex-col sm:flex-row gap-4">
                        <button type="submit" name="add_to_cart" class="add-to-cart-btn flex-1 inline-flex justify-center items-center px-6 py-3 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                                <?php echo ($stockQuantity <= 0) ? 'disabled' : ''; ?>>
                            <i class="fas fa-shopping-cart mr-2 -ml-1 h-5 w-5" aria-hidden="true"></i>
                            <span class="button-text"><?php echo ($stockQuantity > 0) ? 'Add to Cart' : 'Out of Stock'; ?></span>
                            <i class="fas fa-spinner fa-spin ml-2 button-loader" style="display: none;"></i>
                        </button>
<button type="button" id="toggle-favorite-btn"
        data-product-id="<?php echo (int)$product['id']; ?>"
        data-is-favorited="<?php echo $isFavorited ? 'true' : 'false'; ?>"
        aria-label="<?php echo $isFavorited ? 'Remove from favorites' : 'Add to favorites'; ?>"
        title="<?php echo $isFavorited ? 'Remove from favorites' : 'Add to favorites'; ?>"
        class="inline-flex justify-center items-center px-6 py-3 border border-gray-300 rounded-md shadow-sm text-base font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-500">
    <i id="favorite-icon" class="<?php echo $isFavorited ? 'fas text-pink-500' : 'far text-gray-400'; ?> fa-heart mr-2 -ml-1 h-5 w-5" aria-hidden="true"></i>
    <span id="favorite-text"><?php echo $isFavorited ? 'Favorited' : 'Favorite'; ?></span>
</button>
                    </div>
                </form>

            </div> </div> <div id="reviews" class="mt-12 border-t pt-8">
            <h2 class="text-xl font-semibold mb-4 text-gray-800">Customer Reviews</h2>
            <?php if (empty($reviews)): ?>
                <p class="text-gray-600">Be the first to review this product!</p>
            <?php else: ?>
                <div class="space-y-6">
                    <?php foreach ($reviews as $review): ?>
                    <?php
                        $rating = isset($review['rating']) ? (int)$review['rating'] : 0;
                        $reviewUsername = escape_html($review['username'] ?? 'Anonymous');
                        $reviewDate = isset($review['created_at']) ? date('F j, Y', strtotime($review['created_at'])) : 'N/A';
                        $reviewComment = nl2br(escape_html($review['comment_text'] ?? ''));

                        // Use the new prepared URL directly
                        $reviewerProfilePicUrl = escape_html($review['reviewer_profile_pic_full_url'] ?? $default_avatar_full_url); // Fallback to default
                    ?>
                    <div class="border-b pb-4 last:border-b-0">
                        <div class="flex items-center mb-1">
                            <div class="flex text-yellow-400 mr-2" role="img" aria-label="Rating: <?php echo $rating; ?> out of 5 stars">
                                <?php for($s_i = 0; $s_i < 5; $s_i++): ?>
                                    <i class="<?php echo ($s_i < $rating) ? 'fas' : 'far'; ?> fa-star"></i>
                                <?php endfor; ?>
                            </div>
                            <span class="font-medium text-gray-800"><?php echo $reviewUsername; ?></span>
                        </div>
                        <p class="text-sm text-gray-500 mb-2"><?php echo $reviewDate; ?></p>
                        <p class="text-gray-700"><?php echo $reviewComment; ?></p>
                        <div class="flex items-center mt-2">
                            <img class="h-8 w-8 rounded-full object-cover mr-2"
                                 src="<?php echo $reviewerProfilePicUrl; ?>"
                                 alt="<?php echo $reviewUsername; ?>'s profile picture"
                                 onerror="this.onerror=null; this.src='<?php echo $default_avatar_full_url; ?>';">
                            <span class="text-sm text-gray-600">Reviewed by <?php echo $reviewUsername; ?></span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>


            <div class="mt-8 border-t pt-6">
                <h3 class="text-lg font-semibold mb-3">Write a Review</h3>
                <?php if($isLoggedIn): // Check if user is logged in ?>
                    <?php
                    // Check for general errors that might prevent form display/submission
                    if (!empty($reviewErrors['general'])): ?>
                        <div class="mb-4 p-3 rounded-md bg-red-100 text-red-700">
                            <?php echo htmlspecialchars($reviewErrors['general']); ?>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo $appUrl; ?>/product/<?php echo (int)$product['id']; ?>/review" method="POST" class="space-y-4">
                        <input type="hidden" name="csrf_token" value="<?php echo escape_html($csrf_token); ?>">
                        <input type="hidden" name="product_id" value="<?php echo (int)$product['id']; ?>">

                        <div>
                            <label for="rating" class="block text-sm font-medium text-gray-700 mb-1">Your Rating:</label>
                            <div class="flex items-center space-x-1" id="star-rating">
                                <?php
                                $selectedRating = isset($oldReviewInput['rating']) ? (int)$oldReviewInput['rating'] : 0;
                                for ($i = 1; $i <= 5; $i++):
                                ?>
                                    <button type="button" class="text-gray-300 hover:text-yellow-400 text-2xl rating-star" data-rating="<?php echo $i; ?>">
                                        <i class="<?php echo ($i <= $selectedRating) ? 'fas' : 'far'; ?> fa-star"></i>
                                    </button>
                                <?php endfor; ?>
                                <input type="hidden" name="rating" id="rating_input" value="<?php echo $selectedRating; ?>" required>
                            </div>
                            <?php if (isset($reviewErrors['rating'])) echo '<p class="text-red-500 text-xs mt-1">' . htmlspecialchars($reviewErrors['rating']) . '</p>'; ?>
                        </div>

                        <div>
                            <label for="review_text" class="block text-sm font-medium text-gray-700 mb-1">Your Review:</label>
                            <textarea name="review_text" id="review_text" rows="5" required
                                      class="w-full px-3 py-2 border <?php echo isset($reviewErrors['review_text']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                                      placeholder="Write your review here..."><?php echo htmlspecialchars($oldReviewInput['review_text'] ?? ''); ?></textarea>
                            <?php if (isset($reviewErrors['review_text'])) echo '<p class="text-red-500 text-xs mt-1">' . htmlspecialchars($reviewErrors['review_text']) . '</p>'; ?>
                        </div>

                        <div>
                            <button type="submit" class="px-6 py-2 bg-indigo-600 text-white font-medium rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                Submit Review
                            </button>
                        </div>
                    </form>
                <?php else: ?>
                    <p class="text-sm text-gray-600 mb-4">
                        Please <a href="<?php echo $appUrl; ?>/login?redirect_to=<?php echo urlencode($_SERVER['REQUEST_URI'] ?? ''); ?>" class="text-indigo-600 hover:underline">log in</a> to write a review.
                    </p>
                <?php endif; ?>
            </div>
        </div> </div> </div> <script>
document.addEventListener('DOMContentLoaded', function() {
    // Smooth scroll for review links
    document.querySelectorAll('a[href="#reviews"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const reviewsSection = document.getElementById('reviews');
            if(reviewsSection) {
                reviewsSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    // AJAX Add to Cart
    const addToCartForm = document.getElementById('add-to-cart-form');
    if (addToCartForm) {
        addToCartForm.addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent traditional form submission

            const submitButton = this.querySelector('.add-to-cart-btn');
            const buttonText = submitButton.querySelector('.button-text');
            const buttonLoader = submitButton.querySelector('.button-loader');

            buttonText.style.display = 'none';
            buttonLoader.style.display = 'inline-block';
            submitButton.disabled = true;

            const formData = new FormData(this);
            const appUrl = '<?php echo $appUrl; ?>'; // Get APP_URL from PHP

            fetch(appUrl + '/cart/add', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                // Try to parse JSON regardless of response.ok, as server might send error details in JSON
                return response.json().then(data => ({ ok: response.ok, status: response.status, data }));
            })
            .then(({ ok, status, data }) => {
                if (ok && data.success) {
                    showProductDetailNotification(data.message || 'Item added to cart!', 'success');
                    // Optionally, update a cart icon count in the header
                    if (data.cart_item_count !== undefined) {
                        const cartCountElement = document.getElementById('header-cart-item-count'); // Assume header has an element with this ID
                        if (cartCountElement) {
                            cartCountElement.textContent = data.cart_item_count;
                            cartCountElement.classList.remove('hidden'); // If it was hidden when empty
                        }
                    }
                } else {
                    showProductDetailNotification(data.message || 'Could not add item to cart. Status: ' + status, 'error');
                    console.error('Add to cart error:', data);
                }
            })
            .catch(error => {
                console.error('Fetch error:', error);
                showProductDetailNotification('An error occurred. Please try again. ' + error.message, 'error');
            })
            .finally(() => {
                buttonText.style.display = 'inline-block';
                buttonLoader.style.display = 'none';
                if (<?php echo $stockQuantity > 0 ? 'true' : 'false'; ?>) { // Re-enable only if in stock
                    submitButton.disabled = false;
                }
            });
        });
    }

    function showProductDetailNotification(message, type = 'info') {
        const notificationArea = document.getElementById('product-detail-notification');
        if (!notificationArea) return;

        const bgColor = type === 'success' ? 'bg-green-500' : (type === 'error' ? 'bg-red-500' : 'bg-blue-500');
        const icon = type === 'success' ? '<i class="fas fa-check-circle mr-2"></i>' : (type === 'error' ? '<i class="fas fa-exclamation-circle mr-2"></i>' : '<i class="fas fa-info-circle mr-2"></i>');

        const notificationDiv = document.createElement('div');
        notificationDiv.className = `p-4 mb-2 text-white ${bgColor} rounded-md shadow-lg flex items-center`;
        notificationDiv.innerHTML = `${icon} ${escapeHTMLPolicy(message)}`; // Use a robust escape function for message

        notificationArea.appendChild(notificationDiv);
        notificationArea.style.display = 'block';

        setTimeout(() => {
            notificationDiv.style.transition = 'opacity 0.5s ease-out';
            notificationDiv.style.opacity = '0';
            setTimeout(() => {
                notificationDiv.remove();
                if (notificationArea.children.length === 0) {
                    notificationArea.style.display = 'none';
                }
            }, 500);
        }, 5000); // Notification disappears after 5 seconds
    }
    
    // Basic HTML escaping for messages shown in JS, complement PHP's escape_html
    function escapeHTMLPolicy(str) {
        if (typeof str !== 'string') return '';
        return str.replace(/[&<>"']/g, function (match) {
            return {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#39;'
            }[match];
        });
    }

    // --- Star Rating Functionality ---
    const starRatingContainer = document.getElementById('star-rating');
    const ratingInput = document.getElementById('rating_input');

    if (starRatingContainer && ratingInput) {
        const stars = starRatingContainer.querySelectorAll('.rating-star');
        
        function updateStars(rating) {
            stars.forEach(starBtn => {
                const starIcon = starBtn.querySelector('i');
                if (parseInt(starBtn.dataset.rating) <= rating) {
                    starIcon.classList.remove('far');
                    starIcon.classList.add('fas', 'text-yellow-400');
                } else {
                    starIcon.classList.remove('fas', 'text-yellow-400');
                    starIcon.classList.add('far');
                }
            });
        }

        stars.forEach(starBtn => {
            starBtn.addEventListener('click', function() {
                const rating = parseInt(this.dataset.rating);
                ratingInput.value = rating;
                updateStars(rating);
            });

            starBtn.addEventListener('mouseover', function() {
                const hoverRating = parseInt(this.dataset.rating);
                stars.forEach(s => {
                    const icon = s.querySelector('i');
                    if (parseInt(s.dataset.rating) <= hoverRating) {
                        icon.classList.remove('far');
                        icon.classList.add('fas', 'text-yellow-400');
                    } else {
                        icon.classList.remove('fas', 'text-yellow-400');
                        icon.classList.add('far');
                    }
                });
            });

            starBtn.addEventListener('mouseout', function() {
                updateStars(parseInt(ratingInput.value)); // Revert to selected rating
            });
        });

        // Initialize stars based on old input value if available
        updateStars(parseInt(ratingInput.value));
    }
});
// Thumbnail click logic is handled inline in the button onclick attributes.
// Consider moving that to this script block for better separation if it grows more complex.
document.addEventListener('DOMContentLoaded', function() {
    // ... (your existing JS for smooth scroll, add to cart, notifications, star rating) ...

    const toggleFavoriteBtn = document.getElementById('toggle-favorite-btn');
    if (toggleFavoriteBtn) {
        toggleFavoriteBtn.addEventListener('click', function() {
            const isLoggedIn = <?php echo json_encode($isLoggedIn); ?>;
            if (!isLoggedIn) {
                // Redirect to login or show modal
                showProductDetailNotification('Please log in to add favorites.', 'info');
                // Optionally redirect: window.location.href = '<?php echo $appUrl; ?>/login?redirect_to=' + encodeURIComponent(window.location.href);
                return;
            }

            const productId = this.dataset.productId;
            let isCurrentlyFavorited = this.dataset.isFavorited === 'true';
            const csrfToken = '<?php echo escape_html($csrf_token); ?>'; // Get CSRF from PHP
            const appUrl = '<?php echo $appUrl; ?>';
            const icon = document.getElementById('favorite-icon');
            const text = document.getElementById('favorite-text');

            const formData = new FormData();
            formData.append('product_id', productId);
            formData.append('csrf_token', csrfToken);

            fetch(appUrl + '/favorites/toggle', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.dataset.isFavorited = data.isFavorited ? 'true' : 'false';
                    if (data.isFavorited) {
                        icon.classList.remove('far', 'text-gray-400');
                        icon.classList.add('fas', 'text-pink-500');
                        text.textContent = 'Favorited';
                        this.setAttribute('aria-label', 'Remove from favorites');
                        this.setAttribute('title', 'Remove from favorites');
                    } else {
                        icon.classList.remove('fas', 'text-pink-500');
                        icon.classList.add('far', 'text-gray-400');
                        text.textContent = 'Favorite';
                        this.setAttribute('aria-label', 'Add to favorites');
                        this.setAttribute('title', 'Add to favorites');
                    }
                    showProductDetailNotification(data.message, 'success');
                } else {
                    if (data.redirectToLogin) {
                        window.location.href = '<?php echo $appUrl; ?>/login?redirect_to=' + encodeURIComponent(window.location.href);
                    } else {
                        showProductDetailNotification(data.message || 'Could not update favorites.', 'error');
                    }
                }
            })
            .catch(error => {
                console.error('Favorite toggle error:', error);
                showProductDetailNotification('An error occurred. Please try again.', 'error');
            });
        });
    }
});
</script>