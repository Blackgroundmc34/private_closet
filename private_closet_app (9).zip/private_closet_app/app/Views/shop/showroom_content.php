<?php
// File: app/Views/shop/showroom_content.php
// This version expects variables like $products, $categories, $currentPage, $totalPages, $filters, $csrf_token, $loggedInUserId, $app_url to be passed in.

// Ensure variables are set to avoid errors
$products = $products ?? [];
$categories = $categories ?? []; // This was $categoriesForView in showroom.php, should be passed as $categories
$currentPage = $currentPage ?? 1;
$totalPages = $totalPages ?? 1;
$filters = $filters ?? [];
$csrf_token = $csrf_token ?? ''; // Crucial for AJAX POST requests
$loggedInUserId = $loggedInUserId ?? null;
$isLoggedIn = (bool)$loggedInUserId;
$app_url = $app_url ?? (defined('APP_URL') ? APP_URL : ''); // Ensure $app_url is correctly defined and passed

// Helper function for escaping HTML (if not globally available)
if (!function_exists('escape_html')) {
    function escape_html($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
// Helper function for formatting price (if not globally available)
if (!function_exists('format_price')) {
    function format_price($price, $currency = 'R') {
        if (!is_numeric($price)) $price = 0;
        // Using number_format for simplicity, intl extension is more robust if available
        return $currency . number_format((float)$price, 2, '.', ',');
    }
}
$defaultProductImage = $app_url . '/assets/images/default_product_image.png'; // Default image

?>

<div class="container mx-auto px-4 py-8">

    <form method="GET" action="<?php echo escape_html($app_url); ?>/showroom">
        <div class="mb-8 p-4 bg-white rounded-lg shadow-md">
            <h2 class="text-xl font-semibold mb-4 text-gray-800 border-b pb-2">Filter & Sort</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label for="category_filter" class="block text-sm font-medium text-gray-700 mb-1">Category:</label>
                    <select id="category_filter" name="category" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm">
                        <option value="">All Categories</option>
                        <?php if (!empty($categories)): ?>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?php echo (int)($category['id'] ?? ''); ?>"
                                    <?php echo (($filters['category'] ?? null) == ($category['id'] ?? null)) ? 'selected' : ''; ?>>
                                    <?php echo escape_html($category['name'] ?? 'Unknown Category'); ?>
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div>
                    <label for="sort_by" class="block text-sm font-medium text-gray-700 mb-1">Sort By:</label>
                    <select id="sort_by" name="sort" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm">
                        <option value="newest" <?php echo (($filters['sort'] ?? 'newest') === 'newest') ? 'selected' : ''; ?>>Newest Arrivals</option>
                        <option value="price_asc" <?php echo (($filters['sort'] ?? '') === 'price_asc') ? 'selected' : ''; ?>>Price: Low to High</option>
                        <option value="price_desc" <?php echo (($filters['sort'] ?? '') === 'price_desc') ? 'selected' : ''; ?>>Price: High to Low</option>
                        <option value="popular" <?php echo (($filters['sort'] ?? '') === 'popular') ? 'selected' : ''; ?>>Popularity</option>
                    </select>
                </div>
                <div>
                    <label for="price_range" class="block text-sm font-medium text-gray-700 mb-1">Price Range:</label>
                    <input type="text" id="price_range" name="price" placeholder="e.g., 100-1000" value="<?php echo escape_html($filters['price'] ?? ''); ?>" class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm">
                </div>
            </div>
            <div class="mt-4 text-right">
                <button type="submit" class="px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                    Apply Filters
                </button>
            </div>
        </div>
    </form>

    <div id="showroom-notification-area" class="fixed top-20 right-4 z-[100] w-full max-w-xs sm:max-w-sm" style="display: none;"></div>

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-8">

        <?php if (empty($products)): ?>
            <p class="col-span-full text-center text-gray-500 py-10 text-lg">No products found matching your criteria.</p>
        <?php else: ?>
            <?php foreach ($products as $product): ?>
                <?php
                    $productId = (int)($product['id'] ?? 0);
                    $productName = escape_html($product['name'] ?? 'N/A Product');
                    $productSlug = escape_html($product['slug'] ?? 'product-' . $productId);
                    $productPriceFormatted = format_price($product['price'] ?? 0.00);
                    $productPriceFloat = (float)($product['price'] ?? 0.00);
                    $businessName = escape_html($product['business_name'] ?? 'Unknown Seller');
                    $isFavorited = (bool)($product['is_favorited'] ?? false); // This should be passed from showroom.php
                    $stockQuantity = (int)($product['stock_quantity'] ?? 0); // Ensure this key exists and is correct

                    // Image: Using 'image_url_full' which should be prepared by your model or showroom.php
                    $imageUrl = $product['image_url_full'] ?? $defaultProductImage;
                    // Fallback logic if 'image_url_full' is not set (copied from your previous version)
                    if ($imageUrl === $defaultProductImage) { // Only if image_url_full was not provided
                        if (!empty($product['images']) && is_array($product['images'])) {
                            $primaryImg = null;
                            foreach($product['images'] as $img) { if(!empty($img['is_primary'])) {$primaryImg = $img; break;} }
                            if (!$primaryImg && !empty($product['images'][0])) $primaryImg = $product['images'][0];

                            if ($primaryImg && !empty($primaryImg['image_url'])) {
                                 $imgRelPath = $primaryImg['image_url'];
                                 $isAbsolute = strpos($imgRelPath, 'http') === 0 || strpos($imgRelPath, '//') === 0;
                                 $imageUrl = $isAbsolute ? $imgRelPath : $app_url . '/' . ltrim($imgRelPath, '/');
                            }
                        } elseif (!empty($product['image_url'])) {
                             $imgRelPath = $product['image_url'];
                             $isAbsolute = strpos($imgRelPath, 'http') === 0 || strpos($imgRelPath, '//') === 0;
                             $imageUrl = $isAbsolute ? $imgRelPath : $app_url . '/' . ltrim($imgRelPath, '/');
                        }
                    }
                ?>
                <div class="group bg-white rounded-lg shadow-md overflow-hidden transition-shadow duration-300 hover:shadow-xl flex flex-col">
                    <a href="<?php echo $app_url; ?>/product/<?php echo $productSlug; ?>" class="block relative w-full aspect-[3/4] overflow-hidden bg-gray-200">
                        <img src="<?php echo escape_html($imageUrl); ?>"
                             alt="Image of <?php echo $productName; ?>"
                             class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                             onerror="this.onerror=null; this.src='<?php echo $defaultProductImage; ?>'; this.alt='Image loading error';">
                    </a>
                    <div class="p-4 flex flex-col flex-grow">
                        <h3 class="text-md font-semibold text-gray-800 mb-1 truncate group-hover:text-indigo-600" title="<?php echo $productName; ?>">
                            <a href="<?php echo $app_url; ?>/product/<?php echo $productSlug; ?>">
                                <?php echo $productName; ?>
                            </a>
                        </h3>
                        <p class="text-xs text-gray-500 mb-2">By <?php echo $businessName; ?></p>
                        <p class="text-lg font-bold text-gray-900 mb-3"><?php echo $productPriceFormatted; ?></p>
                        
                        <div class="mt-auto pt-3 border-t border-gray-200 flex items-center justify-between space-x-2">
                            <button type="button"
                                    class="showroom-add-to-cart-btn flex-grow inline-flex justify-center items-center px-3 py-2 border border-transparent rounded-md shadow-sm text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-60 disabled:cursor-not-allowed"
                                    data-product-id="<?php echo $productId; ?>"
                                    data-product-name="<?php echo $productName; ?>"
                                    data-product-price="<?php echo $productPriceFloat; ?>"
                                    data-product-image="<?php echo escape_html($imageUrl); ?>" 
                                    data-product-slug="<?php echo $productSlug; ?>"
                                    data-stock-quantity="<?php echo $stockQuantity; ?>"
                                    data-business-name="<?php echo $businessName; ?>"
                                    <?php echo ($stockQuantity <= 0) ? 'disabled' : ''; ?>>
                                <i class="fas fa-shopping-cart mr-1.5 text-sm"></i>
                                <span class="button-text text-xs"><?php echo ($stockQuantity > 0) ? 'Add to Cart' : 'Out of Stock'; ?></span>
                                <i class="fas fa-spinner fa-spin ml-1.5 button-loader" style="display: none;"></i>
                            </button>

                            <button type="button"
                                    class="showroom-toggle-favorite-btn p-2 text-gray-400 hover:text-pink-500 rounded-full focus:outline-none focus:ring-2 ring-pink-500 ring-offset-1"
                                    data-product-id="<?php echo $productId; ?>"
                                    data-is-favorited="<?php echo $isFavorited ? 'true' : 'false'; ?>"
                                    title="<?php echo $isFavorited ? 'Remove from Favorites' : 'Add to Favorites'; ?>"
                                    aria-label="<?php echo $isFavorited ? 'Remove from Favorites' : 'Add to Favorites'; ?>">
                                <i class="<?php echo $isFavorited ? 'fas text-pink-500' : 'far'; ?> fa-heart text-lg"></i>
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <?php if ($totalPages > 1): ?>
    <div class="mt-10 flex justify-center">
        <nav aria-label="Page navigation">
          <ul class="inline-flex items-center -space-x-px">
            <li>
              <a href="<?php echo ($currentPage <= 1) ? 'javascript:void(0);' : build_showroom_pagination_url($filters, $currentPage - 1, $app_url); ?>"
                 class="py-2 px-3 ml-0 leading-tight text-gray-500 bg-white rounded-l-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 <?php echo ($currentPage <= 1) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                 <i class="fas fa-chevron-left mr-1 text-xs"></i> Previous
              </a>
            </li>
            <?php
                $startPage = max(1, $currentPage - 2);
                $endPage = min($totalPages, $currentPage + 2);
                if ($currentPage <= 3) $endPage = min($totalPages, 5);
                if ($currentPage > $totalPages - 3) $startPage = max(1, $totalPages - 4);

                if ($startPage > 1) {
                    echo '<li><a href="' . build_showroom_pagination_url($filters, 1, $app_url) . '" class="py-2 px-3 leading-tight border border-gray-300 text-gray-500 bg-white hover:bg-gray-100 hover:text-gray-700">1</a></li>';
                    if ($startPage > 2) echo '<li><span class="py-2 px-3 leading-tight border border-gray-300 text-gray-500 bg-white">...</span></li>';
                }

                for ($i = $startPage; $i <= $endPage; $i++):
            ?>
                <li>
                  <a href="<?php echo build_showroom_pagination_url($filters, $i, $app_url); ?>"
                     class="py-2 px-3 leading-tight border border-gray-300 <?php echo ($i == $currentPage) ? 'text-indigo-600 bg-indigo-50 hover:bg-indigo-100 hover:text-indigo-700 z-10 ring-1 ring-indigo-500' : 'text-gray-500 bg-white hover:bg-gray-100 hover:text-gray-700'; ?>">
                     <?php echo $i; ?>
                  </a>
                </li>
            <?php endfor;

                if ($endPage < $totalPages) {
                    if ($endPage < $totalPages - 1) echo '<li><span class="py-2 px-3 leading-tight border border-gray-300 text-gray-500 bg-white">...</span></li>';
                    echo '<li><a href="' . build_showroom_pagination_url($filters, $totalPages, $app_url) . '" class="py-2 px-3 leading-tight border border-gray-300 text-gray-500 bg-white hover:bg-gray-100 hover:text-gray-700">' . $totalPages . '</a></li>';
                }
            ?>
            <li>
              <a href="<?php echo ($currentPage >= $totalPages) ? 'javascript:void(0);' : build_showroom_pagination_url($filters, $currentPage + 1, $app_url); ?>"
                 class="py-2 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 <?php echo ($currentPage >= $totalPages) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                 Next <i class="fas fa-chevron-right ml-1 text-xs"></i>
              </a>
            </li>
          </ul>
        </nav>
    </div>
    <?php endif; ?>
</div>

<?php
// Helper function for pagination URLs specific to showroom.php
if (!function_exists('build_showroom_pagination_url')) {
    function build_showroom_pagination_url(array $currentFilters, int $pageNumber, string $baseUrl): string {
        $queryParams = $currentFilters;
        $queryParams['page'] = $pageNumber;
        $queryParams = array_filter($queryParams, fn($value) => $value !== null && $value !== ''); // Clean empty filters
        return rtrim($baseUrl, '/') . '/showroom?' . http_build_query($queryParams);
    }
}
?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const csrfToken = '<?php echo escape_html($csrf_token); ?>';
    const appUrl = '<?php echo escape_html($app_url); ?>';
    const isLoggedIn = <?php echo json_encode($isLoggedIn); ?>;

    function showShowroomNotification(message, type = 'info', duration = 3000) {
        const notificationArea = document.getElementById('showroom-notification-area');
        if (!notificationArea) { console.error("Notification area #showroom-notification-area not found"); return; }

        const bgColor = type === 'success' ? 'bg-green-500' : (type === 'error' ? 'bg-red-500' : 'bg-blue-500');
        const iconHtml = type === 'success' ? '<i class="fas fa-check-circle mr-2"></i>' :
                         (type === 'error' ? '<i class="fas fa-exclamation-circle mr-2"></i>' : '<i class="fas fa-info-circle mr-2"></i>');

        const notificationDiv = document.createElement('div');
        notificationDiv.className = `p-3 mb-2 text-sm text-white ${bgColor} rounded-md shadow-lg flex items-center transition-all duration-300 ease-in-out transform opacity-0 translate-x-full`;
        notificationDiv.innerHTML = `${iconHtml} ${escapeHTMLPolicy(message)}`;

        notificationArea.appendChild(notificationDiv);
        notificationArea.style.display = 'block';

        requestAnimationFrame(() => {
            notificationDiv.classList.remove('opacity-0', 'translate-x-full');
            notificationDiv.classList.add('opacity-100', 'translate-x-0');
        });

        setTimeout(() => {
            notificationDiv.classList.remove('opacity-100', 'translate-x-0');
            notificationDiv.classList.add('opacity-0', 'translate-x-full');
            setTimeout(() => {
                notificationDiv.remove();
                if (notificationArea.children.length === 0) {
                    notificationArea.style.display = 'none';
                }
            }, 300);
        }, duration);
    }

    function escapeHTMLPolicy(str) {
        if (typeof str !== 'string') return '';
        return str.replace(/[&<>"']/g, match => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'})[match]);
    }

    // Add to Cart functionality
    document.querySelectorAll('.showroom-add-to-cart-btn').forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            const submitButton = this;
            const buttonTextSpan = submitButton.querySelector('.button-text');
            const buttonLoader = submitButton.querySelector('.button-loader');
            const stock = parseInt(submitButton.dataset.stockQuantity);

            if (submitButton.disabled || stock <= 0) { // Double check disabled and stock
                showShowroomNotification('This item is out of stock.', 'error');
                return;
            }

            if (buttonTextSpan) buttonTextSpan.style.display = 'none';
            if (buttonLoader) buttonLoader.style.display = 'inline-block';
            submitButton.disabled = true;

            const formData = new FormData();
            formData.append('product_id', this.dataset.productId);
            formData.append('quantity', 1);
            formData.append('csrf_token', csrfToken);
            formData.append('product_name', this.dataset.productName);
            formData.append('product_price', this.dataset.productPrice);
            formData.append('product_image', this.dataset.productImage);
            formData.append('product_slug', this.dataset.productSlug);
            formData.append('business_name', this.dataset.businessName);

            fetch(appUrl + '/cart/add', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json().then(data => ({ ok: response.ok, status: response.status, data })))
            .then(({ ok, status, data }) => {
                if (ok && data.success) {
                    showShowroomNotification(data.message || 'Item added to cart!', 'success');
                    const cartCountElement = document.getElementById('header-cart-item-count');
                    if (cartCountElement && data.cart_item_count !== undefined) {
                        cartCountElement.textContent = data.cart_item_count;
                        cartCountElement.classList.remove('hidden');
                    }
                } else {
                    showShowroomNotification(data.message || 'Could not add item. Status: ' + status, 'error');
                }
            })
            .catch(error => {
                showShowroomNotification('Error adding to cart. ' + error.message, 'error');
            })
            .finally(() => {
                if (buttonTextSpan) buttonTextSpan.style.display = 'inline-block';
                if (buttonLoader) buttonLoader.style.display = 'none';
                // Re-enable based on original stock data attribute,
                // as actual stock might have changed on server but we don't have updated info here without another fetch.
                if (parseInt(submitButton.dataset.stockQuantity) > 0) {
                    submitButton.disabled = false;
                } else {
                    if (buttonTextSpan) buttonTextSpan.textContent = 'Out of Stock'; // Ensure it shows OOS
                    submitButton.disabled = true; // Explicitly disable
                }
            });
        });
    });

    // Toggle Favorite functionality
    document.querySelectorAll('.showroom-toggle-favorite-btn').forEach(button => {
        button.addEventListener('click', function() {
            if (!isLoggedIn) {
                showShowroomNotification('Please log in to manage favorites.', 'info');
                return;
            }

            const productId = this.dataset.productId;
            const icon = this.querySelector('i');
            let isCurrentlyFavorited = this.dataset.isFavorited === 'true';

            const formData = new FormData();
            formData.append('product_id', productId);
            formData.append('csrf_token', csrfToken);

            // Optimistic UI update (changes icon immediately)
            this.dataset.isFavorited = !isCurrentlyFavorited ? 'true' : 'false';
            if (!isCurrentlyFavorited) { // Action: Favorite
                icon.classList.remove('far');
                icon.classList.add('fas', 'text-pink-500');
                this.setAttribute('title', 'Remove from Favorites');
                this.setAttribute('aria-label', 'Remove from Favorites');
            } else { // Action: Unfavorite
                icon.classList.remove('fas', 'text-pink-500');
                icon.classList.add('far');
                this.setAttribute('title', 'Add to Favorites');
                this.setAttribute('aria-label', 'Add to Favorites');
            }

            fetch(appUrl + '/favorites/toggle', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Confirm UI state with server response (it should match the optimistic update)
                    this.dataset.isFavorited = data.isFavorited ? 'true' : 'false';
                    if (data.isFavorited) {
                        icon.classList.remove('far');
                        icon.classList.add('fas', 'text-pink-500');
                        this.setAttribute('title', 'Remove from Favorites');
                        this.setAttribute('aria-label', 'Remove from Favorites');
                    } else {
                        icon.classList.remove('fas', 'text-pink-500');
                        icon.classList.add('far');
                        this.setAttribute('title', 'Add to Favorites');
                        this.setAttribute('aria-label', 'Add to Favorites');
                    }
                    showShowroomNotification(data.message, 'success');
                } else {
                    // Revert optimistic UI update on failure
                    this.dataset.isFavorited = isCurrentlyFavorited ? 'true' : 'false'; // Revert to original state
                    if (isCurrentlyFavorited) {
                        icon.classList.remove('far');
                        icon.classList.add('fas', 'text-pink-500');
                        this.setAttribute('title', 'Remove from Favorites');
                        this.setAttribute('aria-label', 'Remove from Favorites');
                    } else {
                        icon.classList.remove('fas', 'text-pink-500');
                        icon.classList.add('far');
                        this.setAttribute('title', 'Add to Favorites');
                        this.setAttribute('aria-label', 'Add to Favorites');
                    }

                    if (data.redirectToLogin) {
                        showShowroomNotification('Please log in to manage favorites.', 'info');
                        // Consider delaying redirect:
                        // setTimeout(() => { window.location.href = appUrl + '/login?redirect_to=' + encodeURIComponent(window.location.href); }, 2000);
                    } else {
                        showShowroomNotification(data.message || 'Could not update favorites.', 'error');
                    }
                }
            })
            .catch(error => {
                // Revert optimistic UI update on network error
                 this.dataset.isFavorited = isCurrentlyFavorited ? 'true' : 'false';
                 if (isCurrentlyFavorited) {
                    icon.classList.remove('far');
                    icon.classList.add('fas', 'text-pink-500');
                    this.setAttribute('title', 'Remove from Favorites');
                    this.setAttribute('aria-label', 'Remove from Favorites');
                } else {
                    icon.classList.remove('fas', 'text-pink-500');
                    icon.classList.add('far');
                    this.setAttribute('title', 'Add to Favorites');
                    this.setAttribute('aria-label', 'Add to Favorites');
                }
                showShowroomNotification('Error updating favorites. Please try again.', 'error');
            });
        });
    });
});
</script>