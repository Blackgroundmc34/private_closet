<?php
// File: app/Views/errors/500_content.php
// Purpose: Basic server error page.
// Expected: $pageTitle, $errorMessage (optional)

$pageTitle = $pageTitle ?? 'Server Error';
$errorMessage = $errorMessage ?? 'An unexpected error occurred on the server. Please try again later.';
$app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : '';

// Note: This view might be called when _header.php or _footer.php also can't be loaded
// or when the full controller context isn't available. So, keep it self-contained or very simple.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?> - Private Closet</title>
    <style>
        body { font-family: sans-serif; margin: 0; background-color: #f4f4f4; color: #333; display: flex; justify-content: center; align-items: center; min-height: 100vh; text-align: center; }
        .container { background-color: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 0 15px rgba(0,0,0,0.1); max-width: 500px; margin: 20px;}
        h1 { color: #d9534f; font-size: 2em; margin-bottom: 0.5em; }
        p { font-size: 1.1em; margin-bottom: 1em;}
        a { color: #5cb85c; text-decoration: none; font-weight: bold; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <h1><?php echo htmlspecialchars($pageTitle); ?></h1>
        <p><?php echo htmlspecialchars($errorMessage); ?></p>
        <?php if ($app_url): ?>
            <p><a href="<?php echo $app_url; ?>">Go Back Home</a></p>
        <?php endif; ?>
    </div>
</body>
</html>
