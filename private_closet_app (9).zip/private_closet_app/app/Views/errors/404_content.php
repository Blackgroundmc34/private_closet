<?php
// File: app/Views/errors/404_content.php
// Purpose: Content for the 404 Not Found page.
// Expects $requestedRoute variable.

$requestedRoute = $requestedRoute ?? ''; // Default if not passed

?>
<div class="container mx-auto px-4 py-16 text-center">
    <h1 class="text-6xl font-bold text-indigo-600 mb-4">404</h1>
    <h2 class="text-3xl font-semibold text-gray-800 mb-3">Page Not Found</h2>
    <p class="text-gray-600 mb-6">
        Sorry, we couldn't find the page you were looking for.
        <?php if (!empty($requestedRoute) && defined('DEBUG_MODE') && DEBUG_MODE): ?>
            <br><code class="text-sm bg-gray-100 p-1 rounded">Requested route: /<?php echo escape_html($requestedRoute); ?></code>
        <?php endif; ?>
    </p>
    <a href="<?php echo defined('APP_URL') ? APP_URL : '/'; ?>" class="inline-block px-6 py-3 bg-indigo-600 text-white font-medium rounded-md hover:bg-indigo-700 transition duration-150">
        Go Back Home
    </a>
</div>