<?php
// File: app/Views/admin/category_add_form_content.php

$allCategories = $allCategories ?? [];
$errors = $errors ?? [];
$oldInput = $oldInput ?? [];
$app_url = $app_url ?? (defined('APP_URL') ? APP_URL : '');
$csrf_token = $csrf_token ?? ($_SESSION['csrf_token'] ?? '');

if (!function_exists('escape_html_admin_cat')) {
    function escape_html_admin_cat($string) { return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
if (!function_exists('display_form_error_admin_cat')) {
    function display_form_error_admin_cat(string $field, array $error_list): void {
        if (isset($error_list[$field])) {
            echo '<p class="text-red-500 text-xs mt-1">' . escape_html_admin_cat($error_list[$field]) . '</p>';
        }
    }
}
?>
<div class="container mx-auto px-4 py-8 max-w-lg">
    <div class="bg-white p-6 sm:p-8 rounded-lg shadow-xl border border-gray-200">
        <h1 class="text-2xl font-semibold text-gray-800 mb-6 pb-3 border-b border-gray-200">Add New Category</h1>

        <?php if (isset($_SESSION['flash_message'])): ?>
            <div class="mb-4 p-3 rounded-md <?php echo escape_html_admin_cat($_SESSION['flash_message']['type'] === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'); ?>">
                <?php echo escape_html_admin_cat($_SESSION['flash_message']['text']); unset($_SESSION['flash_message']); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($errors['general'])): ?>
            <div class="mb-4 p-3 rounded-md bg-red-100 text-red-700">
                <strong>Error:</strong> <?php echo escape_html_admin_cat($errors['general']); ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo escape_html_admin_cat($app_url . '/admin/categories/add'); ?>" method="POST" class="space-y-4">
            <input type="hidden" name="csrf_token" value="<?php echo escape_html_admin_cat($csrf_token); ?>">

            <div>
                <label for="name" class="block text-sm font-medium text-gray-700 mb-1">Category Name <span class="text-red-500">*</span></label>
                <input type="text" name="name" id="name" value="<?php echo escape_html_admin_cat($oldInput['name'] ?? ''); ?>" required
                       class="mt-1 block w-full px-3 py-2 border <?php echo isset($errors['name']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                <?php display_form_error_admin_cat('name', $errors); ?>
            </div>

            <div>
                <label for="type" class="block text-sm font-medium text-gray-700 mb-1">Category Type <span class="text-red-500">*</span></label>
                <select name="type" id="type" required
                        class="mt-1 block w-full px-3 py-2 border <?php echo isset($errors['type']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    <option value="">Select Type</option>
                    <option value="fashion" <?php echo (($oldInput['type'] ?? '') === 'fashion') ? 'selected' : ''; ?>>Fashion</option>
                    <option value="accessories" <?php echo (($oldInput['type'] ?? '') === 'accessories') ? 'selected' : ''; ?>>Accessories</option>
                    <option value="pre_owned" <?php echo (($oldInput['type'] ?? '') === 'pre_owned') ? 'selected' : ''; ?>>Pre-Owned</option>
                </select>
                <?php display_form_error_admin_cat('type', $errors); ?>
            </div>

            <div>
                <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Description (Optional)</label>
                <textarea name="description" id="description" rows="3"
                          class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"><?php echo escape_html_admin_cat($oldInput['description'] ?? ''); ?></textarea>
                <?php display_form_error_admin_cat('description', $errors); ?>
            </div>

            <div>
                <label for="parent_category_id" class="block text-sm font-medium text-gray-700 mb-1">Parent Category (Optional, for subcategories)</label>
                <select name="parent_category_id" id="parent_category_id"
                        class="mt-1 block w-full px-3 py-2 border <?php echo isset($errors['parent_category_id']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    <option value="">None (Top-Level Category)</option>
                    <?php if (!empty($allCategories)): ?>
                        <?php foreach ($allCategories as $category): ?>
                            <option value="<?php echo (int)$category['id']; ?>" <?php echo (isset($oldInput['parent_category_id']) && $oldInput['parent_category_id'] == $category['id']) ? 'selected' : ''; ?>>
                                <?php echo escape_html_admin_cat($category['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
                <?php display_form_error_admin_cat('parent_category_id', $errors); ?>
            </div>

            <div class="pt-5">
                <button type="submit" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                    Add Category
                </button>
            </div>
        </form>
    </div>
</div>
