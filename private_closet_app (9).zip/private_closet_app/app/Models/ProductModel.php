<?php
// File: app/Models/ProductModel.php

class ProductModel {
    private $pdo;
    private $app_url;
    private $default_product_image_url;
    private $default_avatar_full_url; // For consistency if other methods use it

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
        
        $default_image_relative = defined('DEFAULT_PRODUCT_IMAGE_PATH') ? DEFAULT_PRODUCT_IMAGE_PATH : 'assets/images/default_product_image.png';
        $this->default_product_image_url = $this->app_url . '/' . ltrim($default_image_relative, '/');

        // Define default avatar URL, though not directly used by product methods, good for consistency
        $default_avatar_path = defined('DEFAULT_AVATAR_PATH') ? DEFAULT_AVATAR_PATH : 'assets/images/default_avatar.png';
        $this->default_avatar_full_url = $this->app_url . '/' . ltrim($default_avatar_path, '/');
    }

    public function prepareFullUrl(?string $relativePath): string {
        if (empty($relativePath)) {
            return $this->default_product_image_url;
        }
        if (preg_match('/^https?:\/\//i', $relativePath)) {
            return $relativePath;
        }
        return $this->app_url . '/' . ltrim($relativePath, '/');
    }
    
    private function tableExists(string $tableName): bool {
        try {
            $safeTableName = preg_replace('/[^a-zA-Z0-9_]/', '', $tableName);
            if (empty($safeTableName)) return false;
            $sql = "SHOW TABLES LIKE '" . $safeTableName . "'";
            $stmt = $this->pdo->query($sql);
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            error_log("ProductModel::tableExists - Error checking table '{$tableName}': " . $e->getMessage());
            return false;
        }
    }

    private function generateUniqueSlug(string $name, string $tableName = 'products', string $columnName = 'slug', ?int $excludeId = null): string {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name), '-'));
        if (empty($slug)) {
            $slug = 'product-' . bin2hex(random_bytes(4));
        }
        $originalSlug = $slug;
        $counter = 1;
        while ($this->slugExists($slug, $tableName, $columnName, $excludeId)) {
            $slug = $originalSlug . '-' . $counter++;
        }
        return $slug;
    }

    private function slugExists(string $slug, string $tableName, string $columnName, ?int $excludeId = null): bool {
        $sql = "SELECT 1 FROM `" . str_replace('`','``',$tableName) . "` WHERE `" . str_replace('`','``',$columnName) . "` = :slug";
        if ($excludeId !== null) {
            $sql .= " AND id != :exclude_id";
        }
        $sql .= " LIMIT 1";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':slug', $slug);
            if ($excludeId !== null) {
                $stmt->bindParam(':exclude_id', $excludeId, PDO::PARAM_INT);
            }
            $stmt->execute();
            return $stmt->fetchColumn() !== false;
        } catch (PDOException $e) {
            error_log("Error checking slug existence for {$tableName}.{$columnName} = '{$slug}': " . $e->getMessage());
            return true; 
        }
    }
    
    public function isSkuTaken(string $sku, ?int $excludeProductId = null): bool {
        if (empty($sku)) return false;
        $sql = "SELECT 1 FROM products WHERE sku = :sku";
        if ($excludeProductId !== null) $sql .= " AND id != :exclude_product_id";
        $sql .= " LIMIT 1";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':sku', $sku, PDO::PARAM_STR);
            if ($excludeProductId !== null) $stmt->bindParam(':exclude_product_id', $excludeProductId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchColumn() !== false;
        } catch (PDOException $e) {
            error_log("ProductModel::isSkuTaken - Error checking SKU '{$sku}': " . $e->getMessage());
            return true; 
        }
    }

    public function createProduct(
        int $businessId, string $name, string $description, float $price, int $stockQuantity,
        ?int $categoryId, string $status = 'active', array $imagesData = [], ?string $sku = null
    ): int|false {
        $slug = $this->generateUniqueSlug($name);
        $sqlProduct = "INSERT INTO products (business_id, name, slug, description, price, stock_quantity, sku, category_id, status, created_at, updated_at)
                       VALUES (:business_id, :name, :slug, :description, :price, :stock_quantity, :sku, :category_id, :status, NOW(), NOW())";
        try {
            $this->pdo->beginTransaction();
            $stmtProduct = $this->pdo->prepare($sqlProduct);
            $stmtProduct->bindParam(':business_id', $businessId, PDO::PARAM_INT);
            $stmtProduct->bindParam(':name', $name, PDO::PARAM_STR);
            $stmtProduct->bindParam(':slug', $slug, PDO::PARAM_STR);
            $stmtProduct->bindParam(':description', $description, PDO::PARAM_STR);
            $stmtProduct->bindParam(':price', $price);
            $stmtProduct->bindParam(':stock_quantity', $stockQuantity, PDO::PARAM_INT);
            $stmtProduct->bindParam(':sku', $sku, $sku === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
            $stmtProduct->bindParam(':category_id', $categoryId, $categoryId === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
            $stmtProduct->bindParam(':status', $status, PDO::PARAM_STR);

            if (!$stmtProduct->execute()) { $this->pdo->rollBack(); return false; }
            $productId = (int)$this->pdo->lastInsertId();
            if ($productId === 0) { $this->pdo->rollBack(); return false; }

            if ($categoryId !== null && $this->tableExists('product_categories')) {
                $sqlCatLink = "INSERT INTO product_categories (product_id, category_id) VALUES (:product_id, :category_id)";
                $stmtCatLink = $this->pdo->prepare($sqlCatLink);
                $stmtCatLink->bindParam(':product_id', $productId, PDO::PARAM_INT);
                $stmtCatLink->bindParam(':category_id', $categoryId, PDO::PARAM_INT);
                if (!$stmtCatLink->execute()) { $this->pdo->rollBack(); return false;}
            }
            if (!empty($imagesData) && $this->tableExists('product_images')) {
                $sqlImage = "INSERT INTO product_images (product_id, image_url, alt_text, is_primary, display_order)
                             VALUES (:product_id, :image_url, :alt_text, :is_primary, :display_order)";
                $stmtImage = $this->pdo->prepare($sqlImage);
                $order = 0;
                $primaryImageSet = false;
                foreach ($imagesData as $img) {
                    $isPrimary = isset($img['is_primary']) ? (bool)$img['is_primary'] : false;
                    if ($isPrimary) $primaryImageSet = true;
                    $altText = $img['alt_text'] ?? $name . ($isPrimary ? ' main image' : " image " . ($order + 1));
                    $imageUrl = $img['url'] ?? null;
                    if ($imageUrl === null) continue; 

                    $stmtImage->bindParam(':product_id', $productId, PDO::PARAM_INT);
                    $stmtImage->bindParam(':image_url', $imageUrl, PDO::PARAM_STR);
                    $stmtImage->bindParam(':alt_text', $altText, PDO::PARAM_STR);
                    $stmtImage->bindParam(':is_primary', $isPrimary, PDO::PARAM_BOOL);
                    $stmtImage->bindParam(':display_order', $order, PDO::PARAM_INT);
                    if (!$stmtImage->execute()) { $this->pdo->rollBack(); return false; }
                    $order++;
                }
                if (!$primaryImageSet && $order > 0) { // If no primary was explicitly set, make the first one primary
                    $this->ensurePrimaryImageExists($productId);
                }
            }
            $this->pdo->commit();
            return $productId;
        } catch (PDOException $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            error_log("ProductModel::createProduct PDOException: " . $e->getMessage());
            return false;
        }
    }

    public function findProductByIdAndBusinessId(int $productId, int $businessId): array|false {
        // This query assumes a single category_id is stored directly in the products table.
        // If you use a pivot table (product_categories), you'll need to adjust this.
        $sql = "SELECT p.* FROM products p
                WHERE p.id = :product_id AND p.business_id = :business_id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
            $stmt->bindParam(':business_id', $businessId, PDO::PARAM_INT);
            $stmt->execute();
            $product = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($product) {
                // Fetch associated images
                if ($this->tableExists('product_images')) {
                    $sqlImages = "SELECT id, image_url, alt_text, is_primary 
                                  FROM product_images 
                                  WHERE product_id = :product_id 
                                  ORDER BY is_primary DESC, display_order ASC, id ASC"; // Added id ASC for consistent ordering
                    $stmtImages = $this->pdo->prepare($sqlImages);
                    $stmtImages->bindParam(':product_id', $product['id'], PDO::PARAM_INT);
                    $stmtImages->execute();
                    $images = $stmtImages->fetchAll(PDO::FETCH_ASSOC);
                    $product['images'] = [];
                    foreach ($images as $img) {
                        $product['images'][] = [
                            'id' => (int)$img['id'],
                            'image_url_relative' => $img['image_url'], // Keep relative for potential server-side use
                            'image_url_full' => $this->prepareFullUrl($img['image_url']),
                            'alt_text' => $img['alt_text'],
                            'is_primary' => (bool)$img['is_primary']
                        ];
                    }
                } else {
                    $product['images'] = [];
                }
            }
            return $product ?: false;
        } catch (PDOException $e) {
            error_log("ProductModel::findProductByIdAndBusinessId PDOException: " . $e->getMessage());
            return false;
        }
    }

    public function updateProduct(int $productId, int $businessId, array $data, array $imageOps = []): bool {
        $currentProduct = $this->findProductByIdAndBusinessId($productId, $businessId);
        if (!$currentProduct) {
            error_log("ProductModel::updateProduct - Product ID {$productId} not found or doesn't belong to Business ID {$businessId}.");
            return false;
        }

        $slug = $this->generateUniqueSlug($data['name'], 'products', 'slug', $productId);

        $sql = "UPDATE products SET 
                    name = :name, 
                    slug = :slug,
                    description = :description, 
                    price = :price, 
                    stock_quantity = :stock_quantity, 
                    sku = :sku, 
                    category_id = :category_id, 
                    status = :status, 
                    updated_at = NOW() 
                WHERE id = :product_id AND business_id = :business_id";

        try {
            $this->pdo->beginTransaction();

            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':name', $data['name']);
            $stmt->bindParam(':slug', $slug);
            $stmt->bindParam(':description', $data['description']);
            $stmt->bindParam(':price', $data['price']);
            $stmt->bindParam(':stock_quantity', $data['stock_quantity'], PDO::PARAM_INT);
            $stmt->bindParam(':sku', $data['sku'], (empty($data['sku']) ? PDO::PARAM_NULL : PDO::PARAM_STR));
            $stmt->bindParam(':category_id', $data['category_id'], ($data['category_id'] === null ? PDO::PARAM_NULL : PDO::PARAM_INT));
            $stmt->bindParam(':status', $data['status']);
            $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
            $stmt->bindParam(':business_id', $businessId, PDO::PARAM_INT);

            if (!$stmt->execute()) {
                error_log("ProductModel::updateProduct - Product update failed: " . implode(" | ", $stmt->errorInfo()));
                $this->pdo->rollBack();
                return false;
            }

            // Handle Category Link (assuming single category_id in products table)
            // If using a pivot table (product_categories), this logic would need to change:
            // 1. Delete existing links from product_categories for this product.
            // 2. Insert new link if a category_id is provided.
            // For now, assuming category_id is directly in products table.

            // Handle Image Operations
            if ($this->tableExists('product_images')) {
                if (!empty($imageOps['delete_images']) && is_array($imageOps['delete_images'])) {
                    $this->deleteProductImages($productId, $imageOps['delete_images']);
                }

                if (isset($imageOps['set_primary_image_id']) && is_numeric($imageOps['set_primary_image_id'])) {
                    $this->setPrimaryImage($productId, (int)$imageOps['set_primary_image_id']);
                }
                
                if (!empty($imageOps['new_images_data']) && is_array($imageOps['new_images_data'])) {
                    $sqlImage = "INSERT INTO product_images (product_id, image_url, alt_text, is_primary, display_order)
                                 VALUES (:product_id, :image_url, :alt_text, :is_primary, :display_order)";
                    $stmtImage = $this->pdo->prepare($sqlImage);
                    
                    // Get current max display_order for this product to append new images
                    $maxOrderStmt = $this->pdo->prepare("SELECT MAX(display_order) FROM product_images WHERE product_id = ?");
                    $maxOrderStmt->execute([$productId]);
                    $currentMaxOrder = (int)$maxOrderStmt->fetchColumn();
                    $displayOrderStart = $currentMaxOrder + 1;

                    $newPrimaryUploaded = false;
                    foreach ($imageOps['new_images_data'] as $img) {
                        if (isset($img['is_primary']) && $img['is_primary']) {
                            $newPrimaryUploaded = true;
                            break;
                        }
                    }
                     // If a new primary image is being uploaded, unset any existing primary
                    if ($newPrimaryUploaded) {
                        $this->pdo->prepare("UPDATE product_images SET is_primary = 0 WHERE product_id = ?")->execute([$productId]);
                    }

                    foreach ($imageOps['new_images_data'] as $idx => $img) {
                        $isPrimary = (isset($img['is_primary']) && $img['is_primary']);
                        $altText = $img['alt_text'] ?? $data['name'] . ' image';
                        $currentDisplayOrder = $displayOrderStart + $idx;

                        $stmtImage->bindParam(':product_id', $productId, PDO::PARAM_INT);
                        $stmtImage->bindParam(':image_url', $img['url']); // Relative path from upload
                        $stmtImage->bindParam(':alt_text', $altText);
                        $stmtImage->bindParam(':is_primary', $isPrimary, PDO::PARAM_BOOL);
                        $stmtImage->bindParam(':display_order', $currentDisplayOrder, PDO::PARAM_INT);
                        if (!$stmtImage->execute()) {
                            error_log("ProductModel::updateProduct - New image insert failed.");
                        }
                    }
                }
                $this->ensurePrimaryImageExists($productId);
            }

            $this->pdo->commit();
            return true;

        } catch (PDOException $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            error_log("ProductModel::updateProduct PDOException: " . $e->getMessage());
            return false;
        }
    }
    
    private function deleteProductImages(int $productId, array $imageIdsToDelete): void {
        if (empty($imageIdsToDelete) || !$this->tableExists('product_images')) return;

        $placeholders = implode(',', array_fill(0, count($imageIdsToDelete), '?'));
        $sqlSelectUrls = "SELECT image_url FROM product_images WHERE product_id = ? AND id IN ({$placeholders})";
        $stmtSelectUrls = $this->pdo->prepare($sqlSelectUrls);
        $stmtSelectUrls->bindValue(1, $productId, PDO::PARAM_INT);
        foreach($imageIdsToDelete as $k => $imgId){
            $stmtSelectUrls->bindValue($k + 2, (int)$imgId, PDO::PARAM_INT);
        }
        $stmtSelectUrls->execute();
        $imageUrls = $stmtSelectUrls->fetchAll(PDO::FETCH_COLUMN, 0);

        $sqlDelete = "DELETE FROM product_images WHERE product_id = ? AND id IN ({$placeholders})";
        $stmtDelete = $this->pdo->prepare($sqlDelete);
        $stmtDelete->bindValue(1, $productId, PDO::PARAM_INT);
        foreach($imageIdsToDelete as $k => $imgId){
            $stmtDelete->bindValue($k + 2, (int)$imgId, PDO::PARAM_INT);
        }
        $stmtDelete->execute();

        $publicDir = realpath(__DIR__ . '/../../public');
        if ($publicDir) {
            foreach ($imageUrls as $relativeUrl) {
                if (!empty($relativeUrl)) {
                    $filePath = $publicDir . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, ltrim($relativeUrl, '/'));
                    if (file_exists($filePath) && is_file($filePath)) {
                        @unlink($filePath);
                    }
                }
            }
        }
    }

    private function setPrimaryImage(int $productId, int $newPrimaryImageId): void {
        if (!$this->tableExists('product_images')) return;
        $this->pdo->prepare("UPDATE product_images SET is_primary = 0 WHERE product_id = ?")->execute([$productId]);
        $this->pdo->prepare("UPDATE product_images SET is_primary = 1 WHERE product_id = ? AND id = ?")->execute([$productId, $newPrimaryImageId]);
    }
    
    private function ensurePrimaryImageExists(int $productId): void {
        if (!$this->tableExists('product_images')) return;
        $stmtCheck = $this->pdo->prepare("SELECT 1 FROM product_images WHERE product_id = ? AND is_primary = 1 LIMIT 1");
        $stmtCheck->execute([$productId]);
        if (!$stmtCheck->fetchColumn()) { 
            $stmtFirst = $this->pdo->prepare("SELECT id FROM product_images WHERE product_id = ? ORDER BY display_order ASC, id ASC LIMIT 1");
            $stmtFirst->execute([$productId]);
            $firstImageId = $stmtFirst->fetchColumn();
            if ($firstImageId) {
                $this->setPrimaryImage($productId, (int)$firstImageId);
            }
        }
    }

    public function deleteProduct(int $productId, int $businessId): bool {
        $product = $this->findProductByIdAndBusinessId($productId, $businessId);
        if (!$product) {
            error_log("ProductModel::deleteProduct - Product ID {$productId} not found or does not belong to Business ID {$businessId}.");
            return false;
        }

        try {
            $this->pdo->beginTransaction();

            if (!empty($product['images'])) {
                $imageIdsToDelete = array_map(fn($img) => $img['id'], $product['images']);
                $this->deleteProductImages($productId, $imageIdsToDelete);
            }
            
            if ($this->tableExists('product_categories')) {
                $this->pdo->prepare("DELETE FROM product_categories WHERE product_id = ?")->execute([$productId]);
            }
            
            // Consider implications for order_items. Usually, you wouldn't delete products that are part of placed orders.
            // Or, use FK constraints with ON DELETE SET NULL or ON DELETE RESTRICT.
            // For now, directly deleting the product.

            $stmt = $this->pdo->prepare("DELETE FROM products WHERE id = :product_id AND business_id = :business_id");
            $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
            $stmt->bindParam(':business_id', $businessId, PDO::PARAM_INT);
            
            if (!$stmt->execute()) {
                $this->pdo->rollBack();
                return false;
            }

            $this->pdo->commit();
            return true;
        } catch (PDOException $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            error_log("ProductModel::deleteProduct PDOException: " . $e->getMessage());
            return false;
        }
    }

    public function getProductsByBusinessId(int $businessId): array {
        $sql = "SELECT p.id, p.name, p.price, p.slug, p.stock_quantity, p.status,
                       (SELECT pi.image_url FROM product_images pi WHERE pi.product_id = p.id AND pi.is_primary = TRUE LIMIT 1) as primary_image_url
                FROM products p
                WHERE p.business_id = :business_id
                ORDER BY p.created_at DESC";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':business_id', $businessId, PDO::PARAM_INT);
            $stmt->execute();
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($products as &$product) { 
                $product['primary_image_url_full'] = $this->prepareFullUrl($product['primary_image_url'] ?? null);
            }
            unset($product); 
            return $products ?: [];
        } catch (PDOException $e) {
            error_log("ProductModel::getProductsByBusinessId PDOException: " . $e->getMessage());
            return [];
        }
    }

    public function getShowroomProducts(array $filters = [], int $limit = 12, int $offset = 0): array {
        $params = [];
        // ***** FIX: Added p.stock_quantity to the SELECT statement *****
        $sqlBase = "SELECT DISTINCT p.id, p.name, p.price, p.slug, p.business_id, p.stock_quantity, b.business_name,
                       (SELECT image_url FROM product_images pi WHERE pi.product_id = p.id AND pi.is_primary = TRUE LIMIT 1) as image_url
                FROM products p
                JOIN businesses b ON p.business_id = b.id
                LEFT JOIN product_categories pc ON p.id = pc.product_id 
                LEFT JOIN categories cat ON pc.category_id = cat.id";
        
        $whereClauses = ["p.status = 'active'"]; // Only show active products in showroom

        if (!empty($filters['category']) && is_numeric($filters['category'])) {
            $whereClauses[] = "pc.category_id = :category_id";
            $params[':category_id'] = (int)$filters['category'];
        }
        
        if (!empty($filters['price'])) {
            $priceParts = explode('-', $filters['price']);
            if (count($priceParts) == 2 && is_numeric(trim($priceParts[0])) && is_numeric(trim($priceParts[1]))) {
                $minPrice = (float)trim($priceParts[0]);
                $maxPrice = (float)trim($priceParts[1]);
                if ($minPrice >= 0 && $maxPrice >= $minPrice) {
                    $whereClauses[] = "p.price BETWEEN :min_price AND :max_price";
                    $params[':min_price'] = $minPrice;
                    $params[':max_price'] = $maxPrice;
                }
            }
        }

        if (!empty($whereClauses)) {
            $sqlBase .= " WHERE " . implode(" AND ", $whereClauses);
        }

        $sortOrder = match ($filters['sort'] ?? 'newest') {
            'price_asc' => 'p.price ASC, p.id ASC', // Added p.id for consistent secondary sort
            'price_desc' => 'p.price DESC, p.id DESC',
            // 'popular' would require a popularity metric, e.g., sales count or views. Using created_at for now.
            'popular' => 'p.created_at DESC', // Placeholder for popularity
            default => 'p.created_at DESC', // newest
        };
        $sqlBase .= " ORDER BY " . $sortOrder;

        $sqlBase .= " LIMIT :limit OFFSET :offset";
        $params[':limit'] = $limit;
        $params[':offset'] = $offset;
        
        try {
            $stmt = $this->pdo->prepare($sqlBase);
            foreach ($params as $key => $value) {
                $type = PDO::PARAM_STR; // Default type
                if ($key === ':limit' || $key === ':offset' || $key === ':category_id') {
                    $type = PDO::PARAM_INT;
                }
                // For price, PDO usually handles floats correctly as strings or can infer
                $stmt->bindValue($key, $value, $type);
            }

            $stmt->execute();
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($products as &$product) { // Use reference to modify array directly
                $product['image_url_full'] = $this->prepareFullUrl($product['image_url'] ?? null);
                // Ensure stock_quantity is treated as an integer
                $product['stock_quantity'] = isset($product['stock_quantity']) ? (int)$product['stock_quantity'] : 0;
            }
            unset($product); // Break the reference
            return $products ?: [];
        } catch (PDOException $e) {
            error_log("ProductModel::getShowroomProducts PDOException: " . $e->getMessage() . " SQL: " . $sqlBase . " Params: " . print_r($params, true));
            return [];
        }
    }

    public function countShowroomProducts(array $filters = []): int {
        $params = [];
        $sqlBase = "SELECT COUNT(DISTINCT p.id) 
                    FROM products p 
                    JOIN businesses b ON p.business_id = b.id
                    LEFT JOIN product_categories pc ON p.id = pc.product_id
                    LEFT JOIN categories cat ON pc.category_id = cat.id";
        $whereClauses = ["p.status = 'active'"];

        if (!empty($filters['category']) && is_numeric($filters['category'])) {
            $whereClauses[] = "pc.category_id = :category_id";
            $params[':category_id'] = (int)$filters['category'];
        }
        if (!empty($filters['price'])) {
            $priceParts = explode('-', $filters['price']);
            if (count($priceParts) == 2 && is_numeric(trim($priceParts[0])) && is_numeric(trim($priceParts[1]))) {
                $whereClauses[] = "p.price BETWEEN :min_price AND :max_price";
                $params[':min_price'] = (float)trim($priceParts[0]);
                $params[':max_price'] = (float)trim($priceParts[1]);
            }
        }

        if (!empty($whereClauses)) {
            $sqlBase .= " WHERE " . implode(" AND ", $whereClauses);
        }

        try {
            $stmt = $this->pdo->prepare($sqlBase);
            foreach ($params as $key => $value) {
                 if ($key === ':category_id') {
                    $stmt->bindValue($key, $value, PDO::PARAM_INT);
                } elseif ($key === ':min_price' || $key === ':max_price') {
                    $stmt->bindValue($key, $value); 
                } else {
                    $stmt->bindValue($key, $value, PDO::PARAM_STR);
                }
            }
            $stmt->execute();
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log("ProductModel::countShowroomProducts PDOException: " . $e->getMessage());
            return 0;
        }
    }
    
    public function findProductByIdOrSlug(string|int $identifier, ?int $loggedInUserId = null): array|false {
        $field = is_numeric($identifier) ? 'p.id' : 'p.slug';
        
        $sql = "SELECT
                    p.id, p.business_id, p.name, p.slug, p.description, p.price,
                    p.stock_quantity, p.sku, p.status, p.created_at,
                    b.business_name,
                    GROUP_CONCAT(DISTINCT cat.name SEPARATOR ', ') as category_names, -- For display
                    p.category_id -- Assuming single category_id stored in products table for simplicity in forms
                FROM products p
                JOIN businesses b ON p.business_id = b.id
                LEFT JOIN categories cat ON p.category_id = cat.id -- Join based on products.category_id
                WHERE {$field} = :identifier AND p.status = 'active' -- Typically only show active products on detail page
                GROUP BY p.id 
                LIMIT 1";
        try {
            $stmt = $this->pdo->prepare($sql);
            $paramType = is_numeric($identifier) ? PDO::PARAM_INT : PDO::PARAM_STR;
            $stmt->bindParam(':identifier', $identifier, $paramType);
            $stmt->execute();
            $product = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$product) {
                return false;
            }

            if ($this->tableExists('product_images')) {
                $sqlImages = "SELECT id, image_url, alt_text, is_primary
                              FROM product_images
                              WHERE product_id = :product_id
                              ORDER BY is_primary DESC, display_order ASC, id ASC";
                $stmtImages = $this->pdo->prepare($sqlImages);
                $stmtImages->bindParam(':product_id', $product['id'], PDO::PARAM_INT);
                $stmtImages->execute();
                $images = $stmtImages->fetchAll(PDO::FETCH_ASSOC);
                $product['images'] = [];
                foreach($images as $img) {
                    $product['images'][] = [
                        'id' => (int)$img['id'],
                        'image_url' => $this->prepareFullUrl($img['image_url']), 
                        'image_url_relative' => $img['image_url'], 
                        'alt_text' => $img['alt_text'],
                        'is_primary' => (bool)$img['is_primary']
                    ];
                }
            } else {
                $product['images'] = [['image_url' => $this->default_product_image_url, 'alt_text' => $product['name'], 'is_primary' => true]];
            }
            
            $product['options'] = []; // Placeholder

            $product['business'] = [
                'id' => $product['business_id'],
                'name' => $product['business_name'],
                'profile_url' => $this->app_url . '/profile/' . ($this->getBusinessOwnerUsername((int)$product['business_id']) ?: $product['business_id'])
            ];
            return $product;

        } catch (PDOException $e) {
            error_log("ProductModel::findProductByIdOrSlug PDOException for identifier ({$identifier}): " . $e->getMessage());
            return false;
        }
    }

    private function getBusinessOwnerUsername(int $businessId): ?string {
        if ($businessId <= 0) return null;
        $sql = "SELECT u.username FROM users u JOIN businesses b ON u.id = b.user_id WHERE b.id = :business_id LIMIT 1";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':business_id', $businessId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchColumn() ?: null;
        } catch (PDOException $e) {
            error_log("ProductModel::getBusinessOwnerUsername PDOException for business ID {$businessId}: " . $e->getMessage());
            return null;
        }
    }

    public function searchProducts(string $query, int $limit = 10, int $offset = 0): array {
        $searchTerm = '%' . $query . '%';
        $sql = "SELECT DISTINCT
                    p.id, p.name, p.slug, p.price, p.description,
                    b.business_name,
                    (SELECT pi.image_url FROM product_images pi WHERE pi.product_id = p.id AND pi.is_primary = TRUE LIMIT 1) as image_url
                FROM products p
                JOIN businesses b ON p.business_id = b.id
                WHERE p.status = 'active' AND (
                    p.name LIKE :query_name OR 
                    p.description LIKE :query_desc OR
                    p.sku LIKE :query_sku 
                )
                ORDER BY p.created_at DESC
                LIMIT :limit OFFSET :offset";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':query_name', $searchTerm, PDO::PARAM_STR);
            $stmt->bindParam(':query_desc', $searchTerm, PDO::PARAM_STR);
            $stmt->bindParam(':query_sku', $searchTerm, PDO::PARAM_STR);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($products as &$product) {
                $product['image_url_full'] = $this->prepareFullUrl($product['image_url'] ?? null);
            }
            unset($product);
            return $products ?: [];
        } catch (PDOException $e) {
            error_log("ProductModel::searchProducts PDOException: " . $e->getMessage() . " Query: " . $query);
            return [];
        }
    }

    public function countSearchedProducts(string $query): int {
        $searchTerm = '%' . $query . '%';
        $sql = "SELECT COUNT(DISTINCT p.id)
                FROM products p
                JOIN businesses b ON p.business_id = b.id
                WHERE p.status = 'active' AND (
                    p.name LIKE :query_name OR 
                    p.description LIKE :query_desc OR
                    p.sku LIKE :query_sku
                )";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':query_name', $searchTerm, PDO::PARAM_STR);
            $stmt->bindParam(':query_desc', $searchTerm, PDO::PARAM_STR);
            $stmt->bindParam(':query_sku', $searchTerm, PDO::PARAM_STR);
            $stmt->execute();
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log("ProductModel::countSearchedProducts PDOException: " . $e->getMessage() . " Query: " . $query);
            return 0;
        }
    }
}
?>