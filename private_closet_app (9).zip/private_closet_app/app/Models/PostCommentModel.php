<?php
// File: app/Models/PostCommentModel.php

class PostCommentModel {
    private $pdo;
    private $app_url;
    private $default_avatar_full_url;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : '';

        // Define default avatar URL, mirrors logic from your view/controllers
        $default_avatar_path = defined('DEFAULT_AVATAR_PATH') ? DEFAULT_AVATAR_PATH : 'assets/images/default_avatar.png';
        $this->default_avatar_full_url = $this->app_url . '/' . ltrim($default_avatar_path, '/');
    }

    /**
     * Fetches all comments for a given post ID.
     * Orders by oldest first for typical chronological display.
     * Includes commenter's username and constructs the full profile picture URL.
     */
    public function getCommentsByPostId(int $postId): array {
        $sql = "SELECT
                    pc.id AS comment_id,
                    pc.comment_text,
                    pc.created_at,
                    pc.user_id AS commenter_user_id,
                    u.username AS commenter_username,
                    u.profile_picture_url AS commenter_profile_pic_relative_url
                FROM post_comments pc
                JOIN users u ON pc.user_id = u.id
                WHERE pc.post_id = :post_id
                ORDER BY pc.created_at ASC"; // Or DESC if you prefer newest first and adjust JS

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':post_id', $postId, PDO::PARAM_INT);
            $stmt->execute();
            $comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Prepare full profile picture URLs
            foreach ($comments as &$comment) { // Use reference to modify directly
                if (!empty($comment['commenter_profile_pic_relative_url'])) {
                    $isAbsolute = strpos($comment['commenter_profile_pic_relative_url'], 'http') === 0 ||
                                  strpos($comment['commenter_profile_pic_relative_url'], '//') === 0;
                    $comment['commenter_profile_pic_full_url'] = $isAbsolute
                        ? $comment['commenter_profile_pic_relative_url']
                        : $this->app_url . '/' . ltrim($comment['commenter_profile_pic_relative_url'], '/');
                } else {
                    $comment['commenter_profile_pic_full_url'] = $this->default_avatar_full_url;
                }
                // Remove relative URL if you don't need it in the final JSON
                // unset($comment['commenter_profile_pic_relative_url']);
            }
            unset($comment); // Break the reference

            return $comments;

        } catch (PDOException $e) {
            error_log("PostCommentModel::getCommentsByPostId ERROR: " . $e->getMessage());
            return []; // Return empty array on error
        }
    }

    /**
     * Adds a new comment to a post.
     * Returns the newly inserted comment data (or false on failure).
     */
    public function addComment(int $postId, int $userId, string $commentText): array|false {
        $sql = "INSERT INTO post_comments (post_id, user_id, comment_text, created_at, updated_at)
                VALUES (:post_id, :user_id, :comment_text, NOW(), NOW())";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':post_id', $postId, PDO::PARAM_INT);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':comment_text', $commentText, PDO::PARAM_STR);
            
            if ($stmt->execute()) {
                $commentId = $this->pdo->lastInsertId();
                // Fetch the newly inserted comment with user details
                $fetchSql = "SELECT pc.id AS comment_id, pc.comment_text, pc.created_at,
                                    u.username AS commenter_username, u.profile_picture_url AS commenter_profile_pic_relative_url
                             FROM post_comments pc
                             JOIN users u ON pc.user_id = u.id
                             WHERE pc.id = :comment_id";
                $fetchStmt = $this->pdo->prepare($fetchSql);
                $fetchStmt->bindParam(':comment_id', $commentId);
                $fetchStmt->execute();
                $newComment = $fetchStmt->fetch(PDO::FETCH_ASSOC);

                if ($newComment) {
                    if (!empty($newComment['commenter_profile_pic_relative_url'])) {
                        $isAbsolute = strpos($newComment['commenter_profile_pic_relative_url'], 'http') === 0 ||
                                      strpos($newComment['commenter_profile_pic_relative_url'], '//') === 0;
                        $newComment['commenter_profile_pic_full_url'] = $isAbsolute
                            ? $newComment['commenter_profile_pic_relative_url']
                            : $this->app_url . '/' . ltrim($newComment['commenter_profile_pic_relative_url'], '/');
                    } else {
                        $newComment['commenter_profile_pic_full_url'] = $this->default_avatar_full_url;
                    }
                    return $newComment;
                }
            }
            return false;
        } catch (PDOException $e) {
            error_log("PostCommentModel::addComment ERROR: " . $e->getMessage());
            return false;
        }
    }
}