<?php
// File: app/Models/BusinessModel.php

class BusinessModel {
    private $pdo;
    // You might want to add $app_url here if you construct full URLs within this model
    // private $app_url;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        // $this->app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
    }

    /**
     * Fetches business details by the user_id of the supplier.
     * This version fetches the business regardless of status,
     * as the controller might need to know about pending/rejected businesses too.
     * @param int $userId
     * @return array|null
     */
    public function getBusinessByUserId(int $userId): ?array {
        $sql = "SELECT * FROM businesses WHERE user_id = :user_id LIMIT 1";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->execute();
            $business = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$business) {
                error_log("BusinessModel::getBusinessByUserId - No business profile found for user_id {$userId}.");
            }
            return $business ?: null;
        } catch (PDOException $e) {
            error_log("BusinessModel::getBusinessByUserId PDOException for user_id {$userId}: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Creates a business profile.
     * Default status is 'pending_review' unless specified in $businessData.
     * @param int $userId
     * @param array $businessData
     * @return int|null The new business ID or null on failure
     */
    public function createBusiness(int $userId, array $businessData): ?int {
        $sql = "INSERT INTO businesses (
                    user_id, business_name, registration_number, start_date, 
                    description, physical_address, pinpoint_location, operating_hours, 
                    contact_phone_1, contact_phone_2, status, shelf_template_id,
                    allows_appointments, allows_layby, allows_reservations,
                    created_at, updated_at
                ) VALUES (
                    :user_id, :business_name, :registration_number, :start_date, 
                    :description, :physical_address, ST_GeomFromText(:pinpoint_location), :operating_hours, 
                    :contact_phone_1, :contact_phone_2, :status, :shelf_template_id,
                    :allows_appointments, :allows_layby, :allows_reservations,
                    NOW(), NOW()
                )";
        try {
            $stmt = $this->pdo->prepare($sql);

            $longitude = $businessData['longitude'] ?? '28.2293'; 
            $latitude = $businessData['latitude'] ?? '-25.7479';  
            $pinpointWKT = "POINT({$longitude} {$latitude})";

            // IMPORTANT: New businesses should default to 'pending_review'
            $status = $businessData['status'] ?? 'pending_review'; 
            $shelfTemplateId = $businessData['shelf_template_id'] ?? null;
            $allowsAppointments = isset($businessData['allows_appointments']) ? (int)(bool)$businessData['allows_appointments'] : 0;
            $allowsLayby = isset($businessData['allows_layby']) ? (int)(bool)$businessData['allows_layby'] : 0;
            $allowsReservations = isset($businessData['allows_reservations']) ? (int)(bool)$businessData['allows_reservations'] : 0;

            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':business_name', $businessData['business_name']);
            $stmt->bindParam(':pinpoint_location', $pinpointWKT, PDO::PARAM_STR);
            $stmt->bindParam(':status', $status, PDO::PARAM_STR); // Use the determined status
            $stmt->bindParam(':shelf_template_id', $shelfTemplateId, $shelfTemplateId === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
            $stmt->bindParam(':allows_appointments', $allowsAppointments, PDO::PARAM_INT);
            $stmt->bindParam(':allows_layby', $allowsLayby, PDO::PARAM_INT);
            $stmt->bindParam(':allows_reservations', $allowsReservations, PDO::PARAM_INT);

            $optionalFields = [
                'registration_number' => $businessData['registration_number'] ?? null,
                'start_date' => $businessData['start_date'] ?? null,
                'description' => $businessData['business_description'] ?? ($businessData['description'] ?? null),
                'physical_address' => $businessData['physical_address'] ?? null,
                'operating_hours' => $businessData['operating_hours'] ?? null,
                'contact_phone_1' => $businessData['contact_phone_1'] ?? null,
                'contact_phone_2' => $businessData['contact_phone_2'] ?? null,
            ];

            foreach ($optionalFields as $paramKey => $value) {
                $stmt->bindParam(":$paramKey", $optionalFields[$paramKey], ($value === null ? PDO::PARAM_NULL : PDO::PARAM_STR));
            }
            
            if ($stmt->execute()) {
                $businessId = (int)$this->pdo->lastInsertId();
                if ($businessId > 0) {
                    error_log("BusinessModel::createBusiness - Successfully created business ID {$businessId} for user ID {$userId} with status '{$status}'.");
                    if (!empty($businessData['business_categories']) && is_array($businessData['business_categories'])) {
                        $this->linkBusinessToCategories($businessId, $businessData['business_categories']);
                    }
                    return $businessId;
                } else {
                    error_log("BusinessModel::createBusiness - Execute succeeded but lastInsertId was 0 for user ID {$userId}.");
                    return null;
                }
            } else {
                error_log("BusinessModel::createBusiness - SQL Execute failed for user ID {$userId}: " . implode(" | ", $stmt->errorInfo()));
                return null;
            }
        } catch (PDOException $e) {
            error_log("BusinessModel::createBusiness PDOException for user ID {$userId}: " . $e->getMessage());
            return null;
        }
    }
    
    public function linkBusinessToCategories(int $businessId, array $categoryIds): bool {
        // ... (your existing linkBusinessToCategories method) ...
        if (empty($categoryIds)) return true;
        $sql = "INSERT INTO business_categories (business_id, category_id) VALUES (:business_id, :category_id)";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':business_id', $businessId, PDO::PARAM_INT);
            foreach ($categoryIds as $categoryId) {
                if (!is_numeric($categoryId) || $categoryId <= 0) continue;
                $currentCatId = (int)$categoryId; // Ensure it's int for bindParam
                $stmt->bindParam(':category_id', $currentCatId, PDO::PARAM_INT);
                if (!$stmt->execute()) {
                    error_log("BusinessModel::linkBusinessToCategories - Failed to link business {$businessId} to category {$currentCatId}: " . implode(" | ", $stmt->errorInfo()));
                }
            }
            return true; 
        } catch (PDOException $e) {
            error_log("BusinessModel::linkBusinessToCategories PDOException for business ID {$businessId}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Fetches all businesses with their owner's username and email.
     * Can be filtered by status. Includes pagination.
     */
    public function getAllBusinessesWithOwners(string $statusFilter = null, int $limit = 20, int $offset = 0): array {
        $sql = "SELECT b.id, b.user_id, b.business_name, b.status, b.created_at, 
                       u.username as owner_username, u.email as owner_email
                FROM businesses b
                JOIN users u ON b.user_id = u.id";
        $params = [];
        if ($statusFilter && $statusFilter !== '') { // Check if filter is actually provided
            $sql .= " WHERE b.status = :status";
            $params[':status'] = $statusFilter;
        }
        $sql .= " ORDER BY b.created_at DESC LIMIT :limit OFFSET :offset";
        
        try {
            $stmt = $this->pdo->prepare($sql);
            if ($statusFilter && $statusFilter !== '') {
                $stmt->bindParam(':status', $statusFilter, PDO::PARAM_STR);
            }
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("BusinessModel::getAllBusinessesWithOwners Error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Counts all businesses, optionally filtered by status.
     */
    public function countAllBusinesses(string $statusFilter = null): int {
        $sql = "SELECT COUNT(*) FROM businesses b"; // Added alias for clarity
        $params = [];
        if ($statusFilter && $statusFilter !== '') {
            $sql .= " WHERE b.status = :status"; // Used alias
            $params[':status'] = $statusFilter;
        }
        try {
            $stmt = $this->pdo->prepare($sql);
            if ($statusFilter && $statusFilter !== '') {
                $stmt->bindParam(':status', $statusFilter, PDO::PARAM_STR);
            }
            $stmt->execute();
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log("BusinessModel::countAllBusinesses Error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Fetches a single business by its ID, along with owner details.
     */
    public function findBusinessById(int $businessId): array|false {
        $sql = "SELECT b.*, u.username as owner_username, u.email as owner_email 
                FROM businesses b 
                JOIN users u ON b.user_id = u.id 
                WHERE b.id = :business_id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':business_id', $businessId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
             error_log("BusinessModel::findBusinessById Error for ID {$businessId}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Updates the status of a business.
     */
    public function updateBusinessStatus(int $businessId, string $newStatus): bool {
        $allowedStatuses = ['pending_review', 'approved', 'rejected', 'suspended'];
        if (!in_array($newStatus, $allowedStatuses)) {
            error_log("BusinessModel::updateBusinessStatus - Invalid status provided: {$newStatus}");
            return false;
        }

        $sql = "UPDATE businesses SET status = :status, updated_at = NOW() WHERE id = :business_id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':status', $newStatus, PDO::PARAM_STR);
            $stmt->bindParam(':business_id', $businessId, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log("BusinessModel::updateBusinessStatus Error for ID {$businessId}: " . $e->getMessage());
            return false;
        }
    }
}