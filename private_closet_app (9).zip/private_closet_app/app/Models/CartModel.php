<?php
// File: app/Models/CartModel.php

class CartModel {
    private $pdo; 
    private $sessionKey = 'shopping_cart_v2'; 
    private $productModel; 

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        // Ensure ProductModel is available. It should be loaded by the autoloader or required in bootstrap/controller.
        if (!class_exists('ProductModel')) {
            // This is a critical dependency.
            error_log('CartModel FATAL: ProductModel class not found.');
            throw new RuntimeException('ProductModel class not found, cart cannot function.');
        }
        $this->productModel = new ProductModel($pdo); 

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if (!isset($_SESSION[$this->sessionKey]) || !is_array($_SESSION[$this->sessionKey])) {
            $_SESSION[$this->sessionKey] = [];
        }
    }

    private function generateCartItemId(int $productId, array $options = []): string {
        ksort($options); 
        $key = (string)$productId;
        foreach ($options as $optionKey => $optionValue) {
            $safeKey = preg_replace('/[^a-zA-Z0-9_-]/', '-', strtolower((string)$optionKey));
            $safeValue = preg_replace('/[^a-zA-Z0-9_-]/', '-', strtolower((string)$optionValue));
            $key .= '_' . $safeKey . '_' . $safeValue;
        }
        return $key;
    }

    public function addItem(int $productId, int $quantity = 1, array $detailsFromForm = [], array $options = []): bool {
        if ($quantity <= 0) {
            error_log("CartModel::addItem - Invalid quantity {$quantity} for product ID {$productId}.");
            return false;
        }

        $cartItemId = $this->generateCartItemId($productId, $options);
        $productDataFromDb = $this->productModel->findProductByIdOrSlug($productId);

        if (!$productDataFromDb) {
            error_log("CartModel::addItem - Product ID {$productId} not found in database.");
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Product not found and cannot be added to cart.'];
            return false; 
        }

        $currentStock = (int)($productDataFromDb['stock_quantity'] ?? 0);
        $existingQuantityInCart = (int)($_SESSION[$this->sessionKey][$cartItemId]['quantity'] ?? 0);
        
        if (($existingQuantityInCart + $quantity) > $currentStock) {
            error_log("CartModel::addItem - Not enough stock for product ID {$productId}. Requested: {$quantity}, In Cart: {$existingQuantityInCart}, Stock: {$currentStock}");
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Not enough stock for ' . htmlspecialchars($detailsFromForm['name'] ?? $productDataFromDb['name'] ?? 'product') . '. Only ' . $currentStock . ' available.'];
            return false; 
        }

        // Use the accurate name and price from the database
        $nameForCart = $productDataFromDb['name'] ?? $detailsFromForm['name'] ?? 'Unknown Product';
        $priceForCart = (float)($productDataFromDb['price'] ?? $detailsFromForm['price'] ?? 0.00);
        // Determine image: use primary from DB if available, then form, then default
        $imageForCart = $this->productModel->prepareFullUrl(null); // Default
        if (!empty($productDataFromDb['images']) && !empty($productDataFromDb['images'][0]['image_url'])) {
            // ProductModel's findProductByIdOrSlug should already prepare full URLs for images
            $imageForCart = $productDataFromDb['images'][0]['image_url']; 
        } elseif (!empty($detailsFromForm['image'])) {
            $imageForCart = $detailsFromForm['image']; // Assuming this is already a full URL or correctly relative
        }


        if (isset($_SESSION[$this->sessionKey][$cartItemId])) {
            $_SESSION[$this->sessionKey][$cartItemId]['quantity'] += $quantity;
            // Update price if it changed in DB, though typically price at time of adding is kept
            // $_SESSION[$this->sessionKey][$cartItemId]['price'] = $priceForCart; 
        } else {
            $_SESSION[$this->sessionKey][$cartItemId] = [
                'product_id' => $productId,
                'quantity' => $quantity,
                'options' => $options,
                'name' => $nameForCart,
                'price' => $priceForCart,
                'image' => $imageForCart,
                'slug' => $productDataFromDb['slug'] ?? $detailsFromForm['slug'] ?? (string)$productId,
                'business_name' => $productDataFromDb['business_name'] ?? $detailsFromForm['business_name'] ?? 'Unknown Seller',
                // Store stock at time of adding for reference, but always check current stock for updates
                'stock_at_add_time' => $currentStock 
            ];
        }
        $this->updateCartTotalsInSession();
        return true;
    }

    public function updateItem(string $cartItemId, int $quantity): bool {
        if (!isset($_SESSION[$this->sessionKey][$cartItemId])) {
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Item not found in cart for update.'];
            return false; 
        }

        if ($quantity <= 0) { // If quantity is 0, remove the item
            return $this->removeItem($cartItemId);
        }
        
        $productId = $_SESSION[$this->sessionKey][$cartItemId]['product_id'];
        $productDataFromDb = $this->productModel->findProductByIdOrSlug($productId);
        $currentStock = (int)($productDataFromDb['stock_quantity'] ?? 0);

        if ($quantity > $currentStock) {
             $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Cannot update quantity. Only ' . $currentStock . ' in stock for ' . htmlspecialchars($_SESSION[$this->sessionKey][$cartItemId]['name'] ?? 'product') . '.'];
             return false;
        }
        $_SESSION[$this->sessionKey][$cartItemId]['quantity'] = $quantity;
        $this->updateCartTotalsInSession();
        return true;
    }

    public function removeItem(string $cartItemId): bool {
        if (isset($_SESSION[$this->sessionKey][$cartItemId])) {
            unset($_SESSION[$this->sessionKey][$cartItemId]);
            $this->updateCartTotalsInSession();
            return true;
        }
        $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Item not found in cart for removal.'];
        return false;
    }

    public function getItems(): array {
        $cartItemsFromSession = $_SESSION[$this->sessionKey] ?? [];
        $detailedItems = [];

        foreach ($cartItemsFromSession as $cartItemId => $item) {
            // For display, we use the data stored in session at the time of adding.
            // Price is particularly important to be the one at time of adding.
            // You could add a step here to re-fetch product name/image if they might change frequently
            // and you want the cart to always show the *absolute latest* details, but this can add overhead.
            $detailedItems[$cartItemId] = [
                'cart_item_id' => $cartItemId, 
                'product_id' => $item['product_id'],
                'name' => $item['name'] ?? 'N/A',
                'price' => (float)($item['price'] ?? 0.00),
                'quantity' => (int)($item['quantity'] ?? 0),
                'options' => $item['options'] ?? [],
                'image' => $item['image'] ?? $this->productModel->prepareFullUrl(null), 
                'slug' => $item['slug'] ?? (string)$item['product_id'],
                'business_name' => $item['business_name'] ?? 'N/A',
                'line_total' => (float)($item['price'] ?? 0.00) * (int)($item['quantity'] ?? 0)
            ];
        }
        return $detailedItems;
    }

    public function getTotals(): array {
        $subtotal = 0;
        $itemCount = 0;
        $items = $_SESSION[$this->sessionKey] ?? []; // Read directly from session for totals calculation

        foreach ($items as $item) {
            $subtotal += (float)($item['price'] ?? 0.00) * (int)($item['quantity'] ?? 0);
            $itemCount += (int)($item['quantity'] ?? 0);
        }

        $shipping = ($itemCount > 0 && $subtotal > 0) ? 50.00 : 0.00; 
        if ($subtotal > 1000 && $subtotal > 0) { 
            $shipping = 0.00;
        }
        $total = $subtotal + $shipping;

        return [
            'subtotal' => $subtotal,
            'item_count' => $itemCount,
            'shipping' => $shipping,
            'total' => $total,
        ];
    }
    
    private function updateCartTotalsInSession(): void {
        $totals = $this->getTotals();
        $_SESSION['cart_total_items'] = $totals['item_count'];
    }

    public function clear(): void {
        $_SESSION[$this->sessionKey] = [];
        $_SESSION['cart_total_items'] = 0; 
    }
    
    public function isEmpty(): bool {
        return empty($_SESSION[$this->sessionKey]);
    }
}
