<?php
// File: app/Models/CategoryModel.php
class CategoryModel {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    /**
     * Fetches all categories from the database.
     * @return array List of all categories.
     */
    public function getAll(): array {
        // Fetches all categories, useful for dropdowns
        $sql = "SELECT id, name, slug, description, parent_category_id, type FROM categories ORDER BY name ASC";
        try {
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (PDOException $e) {
            error_log("CategoryModel::getAll PDOException: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Fetches a single category by its ID.
     * @param int $id The ID of the category.
     * @return array|null The category data or null if not found.
     */
    public function findById(int $id): ?array {
        if ($id <= 0) { // Basic validation
            error_log("CategoryModel::findById - Invalid ID provided: {$id}");
            return null;
        }
        $sql = "SELECT id, name, slug, description, parent_category_id, type FROM categories WHERE id = :id LIMIT 1";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            $category = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$category) {
                error_log("CategoryModel::findById - No category found for ID {$id}.");
            }
            return $category ?: null;
        } catch (PDOException $e) {
            error_log("CategoryModel::findById PDOException for ID {$id}: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Fetches categories by their type.
     * @param string $type The type of categories to fetch (e.g., 'fashion', 'accessories', 'pre_owned').
     * @return array List of categories of the specified type.
     */
    public function findByType(string $type): array {
        $sql = "SELECT id, name, slug, description, parent_category_id, type FROM categories WHERE type = :type ORDER BY name ASC";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':type', $type, PDO::PARAM_STR);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (PDOException $e) {
            error_log("CategoryModel::findByType PDOException for type {$type}: " . $e->getMessage());
            return [];
        }
    }
    
    private function slugExists(string $slug): bool {
        $sql = "SELECT 1 FROM categories WHERE slug = :slug LIMIT 1";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':slug', $slug, PDO::PARAM_STR);
            $stmt->execute();
            return $stmt->fetchColumn() !== false;
        } catch (PDOException $e) {
            error_log("CategoryModel::slugExists PDOException for slug '{$slug}': " . $e->getMessage());
            return true; 
        }
    }

    public function createCategory(string $name, string $type, ?string $description, ?int $parentCategoryId): ?int {
        $baseSlug = strtolower(trim(preg_replace('/[^a-z0-9]+/', '-', $name), '-'));
        if (empty($baseSlug)) {
            $baseSlug = 'category-' . bin2hex(random_bytes(3));
        }
        
        $slug = $baseSlug;
        $counter = 1;
        while ($this->slugExists($slug)) {
            $slug = $baseSlug . '-' . $counter++;
        }

        $allowedTypes = ['fashion', 'accessories', 'pre_owned'];
        if (!in_array($type, $allowedTypes)) {
            error_log("CategoryModel::createCategory - Invalid category type provided: {$type}. Allowed types: " . implode(', ', $allowedTypes));
            return null;
        }

        $sql = "INSERT INTO categories (name, slug, type, description, parent_category_id, created_at)
                VALUES (:name, :slug, :type, :description, :parent_category_id, NOW())";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':name', $name, PDO::PARAM_STR);
            $stmt->bindParam(':slug', $slug, PDO::PARAM_STR);
            $stmt->bindParam(':type', $type, PDO::PARAM_STR); 
            $stmt->bindParam(':description', $description, $description === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
            $stmt->bindParam(':parent_category_id', $parentCategoryId, $parentCategoryId === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
            
            if ($stmt->execute()) {
                $lastId = (int)$this->pdo->lastInsertId();
                if ($lastId > 0) {
                    error_log("CategoryModel::createCategory - Successfully created category '{$name}' with ID {$lastId}.");
                    return $lastId;
                } else {
                    error_log("CategoryModel::createCategory - Execute succeeded but lastInsertId was 0 for category '{$name}'. Check table auto_increment.");
                    return null;
                }
            } else {
                error_log("CategoryModel::createCategory - SQL Execute failed for category '{$name}': " . implode(" | ", $stmt->errorInfo()));
                return null;
            }
        } catch (PDOException $e) {
            error_log("CategoryModel::createCategory PDOException for category '{$name}': " . $e->getMessage() . " | SQL: " . $sql);
            return null;
        }
    }
}
?>
