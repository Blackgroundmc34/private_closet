<?php
// File: app/Models/UserModel.php

class UserModel {
    private $pdo;
    private $app_url; 
    private $default_avatar_full_url; 

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
        $default_avatar_path = defined('DEFAULT_AVATAR_PATH') ? DEFAULT_AVATAR_PATH : 'assets/images/default_avatar.png';
        $this->default_avatar_full_url = $this->app_url . '/' . ltrim($default_avatar_path, '/');
    }

    public function prepareProfilePicUrl(?string $relativePath): string {
        if (empty($relativePath)) {
            return $this->default_avatar_full_url;
        }
        if (preg_match('/^https?:\/\//i', $relativePath)) {
            return $relativePath;
        }
        return $this->app_url . '/' . ltrim($relativePath, '/');
    }
    
    public function findByUsernameOrEmail(string $identifier) {
        $sql = "SELECT id, username, email, password_hash, role, full_name, profile_picture_url, profile_bio, is_active 
                FROM users 
                WHERE username = :username_identifier OR email = :email_identifier 
                LIMIT 1";
        try {
            $stmt = $this->pdo->prepare($sql);
            if (!$stmt) {
                error_log("PDO Prepare Failed in findByUsernameOrEmail. SQL: " . $sql);
                return false; 
            }
            $executeResult = $stmt->execute([
                ':username_identifier' => $identifier,
                ':email_identifier'    => $identifier
            ]);
            if ($executeResult) {
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($user) {
                    $user['profile_picture_full_url'] = $this->prepareProfilePicUrl($user['profile_picture_url'] ?? null);
                }
                return $user ?: false;
            } else {
                $errorInfo = $stmt->errorInfo();
                error_log("PDO Execute Failed in findByUsernameOrEmail. SQLSTATE: " . $errorInfo[0] . " | Driver Code: " . $errorInfo[1] . " | Message: " . $errorInfo[2]);
                return false;
            }
        } catch (\PDOException $e) {
            error_log("PDOException in findByUsernameOrEmail: " . $e->getMessage());
            return false;
        }
    }

    public function findById(int $userId) {
        $sql = "SELECT id, username, email, password_hash, full_name, profile_bio, profile_picture_url, role, created_at, is_active 
                FROM users 
                WHERE id = :user_id 
                LIMIT 1";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($user) {
                $user['profile_picture_full_url'] = $this->prepareProfilePicUrl($user['profile_picture_url'] ?? null);
            }
            return $user ?: false;
        } catch (\PDOException $e) {
            error_log("Error in findById for user ID {$userId}: " . $e->getMessage());
            return false;
        }
    }

    public function findByUsername(string $username) {
        $sql = "SELECT id, username, email, password_hash, full_name, profile_bio, profile_picture_url, role, created_at 
                FROM users 
                WHERE username = :username 
                LIMIT 1";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([':username' => $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($user) {
                $user['profile_picture_full_url'] = $this->prepareProfilePicUrl($user['profile_picture_url'] ?? null);
            }
            return $user ?: false;
        } catch (\PDOException $e) {
            error_log("Error in findByUsername: " . $e->getMessage());
            return false;
        }
    }

    public function findByEmail(string $email) {
        $sql = "SELECT id, username, email FROM users WHERE email = :email LIMIT 1";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([':email' => $email]);
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: false;
        } catch (\PDOException $e) {
            error_log("Error in findByEmail: " . $e->getMessage());
            return false;
        }
    }

    public function verifyPassword(string $password, string $hashedPassword): bool {
        if (empty($hashedPassword)) { return false; }
        return password_verify($password, $hashedPassword);
    }

    public function createUser(string $username, string $email, string $password, string $fullName, string $role = 'user') {
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        if (!$passwordHash) { error_log("Password hashing failed for user: " . $username); return false; }
        $sql = "INSERT INTO users (username, email, password_hash, full_name, role, is_active, is_verified, created_at, updated_at) 
                VALUES (:username, :email, :password_hash, :full_name, :role, 1, 0, NOW(), NOW())";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([':username' => $username, ':email' => $email, ':password_hash' => $passwordHash, ':full_name' => $fullName, ':role' => $role]);
            return (int)$this->pdo->lastInsertId();
        } catch (\PDOException $e) {
            $errorInfo = isset($stmt) ? $stmt->errorInfo() : $this->pdo->errorInfo();
            error_log("Error in createUser: " . $e->getMessage() . " | SQLSTATE: " . $errorInfo[0] . " | Driver Code: " . $errorInfo[1] . " | Message: " . $errorInfo[2]);
            return false;
        }
    }

    public function updatePassword(int $userId, string $newPassword): bool {
        $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);
        if (!$newPasswordHash) { error_log("Password hashing failed for user ID: " . $userId); return false; }
        $sql = "UPDATE users SET password_hash = :password_hash, updated_at = NOW() WHERE id = :user_id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':password_hash', $newPasswordHash, PDO::PARAM_STR);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (\PDOException $e) {
            error_log("Error updating password for user ID {$userId}: " . $e->getMessage());
            return false;
        }
    }
    
    public function updateUserProfile(int $userId, array $data): bool {
        $allowedFields = ['full_name', 'email', 'profile_bio', 'profile_picture_url'];
        $setClauses = [];
        $params = [':user_id' => $userId];
        foreach ($data as $key => $value) {
            if (in_array($key, $allowedFields)) {
                $setClauses[] = "{$key} = :{$key}";
                $params[":{$key}"] = ($value === '' && $key === 'profile_bio') ? null : $value;
            }
        }
        if (empty($setClauses)) { return false; }
        $setClauses[] = "updated_at = NOW()";
        $sql = "UPDATE users SET " . implode(', ', $setClauses) . " WHERE id = :user_id";
        try {
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute($params);
        } catch (\PDOException $e) {
            error_log("Error updating profile for user ID {$userId}: " . $e->getMessage());
            return false;
        }
    }

    public function getUserPosts(int $userId, int $limit = 10, int $offset = 0): array {
        $sql = "SELECT p.id, p.user_id, u.username as post_username, u.profile_picture_url as post_user_profile_pic, 
                       p.description, p.media_url, p.media_type, p.location, p.visibility, 
                       p.allow_comments, p.created_at, p.updated_at,
                       (SELECT COUNT(*) FROM post_likes pl WHERE pl.post_id = p.id) as like_count,
                       (SELECT COUNT(*) FROM post_comments pc WHERE pc.post_id = p.id) as comment_count
                FROM posts p JOIN users u ON p.user_id = u.id 
                WHERE p.user_id = :user_id ORDER BY p.created_at DESC LIMIT :limit OFFSET :offset";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
            // It's better if PostModel handles its own image URL preparations when posts are fetched.
            // However, if UserModel is solely responsible for data passed to user profile, it can do it here.
            // For now, assuming PostModel (if it has a method like getPostsByUserId called by this one) or this loop handles it.
            foreach($posts as &$post) {
                if(isset($post['post_user_profile_pic'])) {
                    $post['post_user_profile_pic_full_url'] = $this->prepareProfilePicUrl($post['post_user_profile_pic']);
                }
                // Media URL preparation would be similar if PostModel doesn't do it:
                // if(isset($post['media_url'])) {
                //    $post['media_full_url'] = $this->app_url . '/' . ltrim($post['media_url'], '/');
                // }
            }
            unset($post);
            return $posts ?: []; 
        } catch (\PDOException $e) {
            error_log("Error fetching posts for user ID {$userId}: " . $e->getMessage());
            return []; 
        }
    }

    public function countUserPosts(int $userId): int {
        $sql = "SELECT COUNT(*) FROM posts WHERE user_id = :user_id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->execute();
            return (int)$stmt->fetchColumn();
        } catch (\PDOException $e) {
            error_log("Error counting posts for user ID {$userId}: " . $e->getMessage());
            return 0;
        }
    }

    public function getFollowerCount(int $userId): int {
        $sql = "SELECT COUNT(*) FROM follows WHERE following_user_id = :user_id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->execute();
            return (int)$stmt->fetchColumn();
        } catch (\PDOException $e) {
            error_log("Error getting followers for user ID {$userId}: " . $e->getMessage());
            return 0;
        }
    }

    public function getFollowingCount(int $userId): int {
        $sql = "SELECT COUNT(*) FROM follows WHERE follower_user_id = :user_id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->execute();
            return (int)$stmt->fetchColumn();
        } catch (\PDOException $e) {
            error_log("Error getting following count for user ID {$userId}: " . $e->getMessage());
            return 0;
        }
    }
    
    public function getFollowedUserIds(int $userId): array {
        $sql = "SELECT following_user_id FROM follows WHERE follower_user_id = :user_id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_COLUMN, 0) ?: [];
        } catch (\PDOException $e) {
            error_log("Error fetching followed IDs for user {$userId}: " . $e->getMessage());
            return [];
        }
    }

    public function isFollowing(int $followerUserId, int $followingUserId): bool {
        $sql = "SELECT COUNT(*) FROM follows WHERE follower_user_id = :follower_user_id AND following_user_id = :following_user_id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':follower_user_id', $followerUserId, PDO::PARAM_INT);
            $stmt->bindParam(':following_user_id', $followingUserId, PDO::PARAM_INT);
            $stmt->execute();
            return (int)$stmt->fetchColumn() > 0;
        } catch (\PDOException $e) {
            error_log("Error checking follow status between {$followerUserId} and {$followingUserId}: " . $e->getMessage());
            return false; 
        }
    }

    public function followUser(int $followerUserId, int $followingUserId): bool {
        if ($followerUserId === $followingUserId) { return false; }
        if ($this->isFollowing($followerUserId, $followingUserId)) { return true; }
        $sql = "INSERT INTO follows (follower_user_id, following_user_id, created_at) VALUES (:follower_user_id, :following_user_id, NOW())";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':follower_user_id', $followerUserId, PDO::PARAM_INT);
            $stmt->bindParam(':following_user_id', $followingUserId, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (\PDOException $e) {
            if ($e->getCode() == '23000') { return true; }
            error_log("Error following user: " . $e->getMessage());
            return false;
        }
    }

    public function unfollowUser(int $followerUserId, int $followingUserId): bool {
        $sql = "DELETE FROM follows WHERE follower_user_id = :follower_user_id AND following_user_id = :following_user_id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':follower_user_id', $followerUserId, PDO::PARAM_INT);
            $stmt->bindParam(':following_user_id', $followingUserId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->rowCount() > 0; 
        } catch (\PDOException $e) {
            error_log("Error unfollowing user: " . $e->getMessage());
            return false;
        }
    }

    public function getUserNotifications(int $userId, int $limit = 20, bool $unreadOnly = false): array {
        $sql = "SELECT id, type, message, related_entity_type, related_entity_id, is_read, created_at
                FROM notifications WHERE user_id = :user_id ";
        if ($unreadOnly) { $sql .= "AND is_read = 0 "; }
        $sql .= "ORDER BY created_at DESC LIMIT :limit";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (\PDOException $e) {
            error_log("Error fetching notifications for user {$userId}: " . $e->getMessage());
            return [];
        }
    }

    public function countUnreadNotifications(int $userId): int {
        $sql = "SELECT COUNT(*) FROM notifications WHERE user_id = :user_id AND is_read = 0";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->execute();
            return (int)$stmt->fetchColumn();
        } catch (\PDOException $e) {
            error_log("Error counting unread for user {$userId}: " . $e->getMessage());
            return 0;
        }
    }

    public function markNotificationAsRead(string $notificationId, int $userId): bool {
        $sql = "UPDATE notifications SET is_read = 1 WHERE id = :notification_id AND user_id = :user_id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':notification_id', $notificationId, PDO::PARAM_STR);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            return $stmt->execute() && $stmt->rowCount() > 0; 
        } catch (\PDOException $e) {
            error_log("Error marking notification {$notificationId} as read: " . $e->getMessage());
            return false;
        }
    }

    public function markAllNotificationsAsRead(int $userId): bool {
        $sql = "UPDATE notifications SET is_read = 1 WHERE user_id = :user_id AND is_read = 0";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->execute();
            return true; 
        } catch (\PDOException $e) {
            error_log("Error marking all as read for user {$userId}: " . $e->getMessage());
            return false;
        }
    }
    
    public function createNotification(int $userId, string $type, string $message, ?string $relatedEntityType = null, ?string $relatedEntityId = null): bool {
        $notificationId = bin2hex(random_bytes(18)); 
        $sql = "INSERT INTO notifications (id, user_id, type, message, related_entity_type, related_entity_id, created_at)
                VALUES (:id, :user_id, :type, :message, :related_entity_type, :related_entity_id, NOW())";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':id', $notificationId, PDO::PARAM_STR);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':type', $type, PDO::PARAM_STR);
            $stmt->bindParam(':message', $message, PDO::PARAM_STR);
            $stmt->bindParam(':related_entity_type', $relatedEntityType, ($relatedEntityType === null ? PDO::PARAM_NULL : PDO::PARAM_STR));
            $stmt->bindParam(':related_entity_id', $relatedEntityId, ($relatedEntityId === null ? PDO::PARAM_NULL : PDO::PARAM_STR));
            return $stmt->execute();
        } catch (\PDOException $e) {
            error_log("Error creating notification for user {$userId}: " . $e->getMessage());
            return false;
        }
    }

    public function getSuggestedFriends(int $loggedInUserId, int $limit = 5): array {
        $followedUserIds = $this->getFollowedUserIds($loggedInUserId);
        $excludedIds = $followedUserIds;
        $excludedIds[] = $loggedInUserId; 
        $placeholders = implode(',', array_fill(0, count($excludedIds), '?'));
        $sql = "SELECT id, username, full_name, profile_picture_url FROM users
                WHERE id NOT IN ({$placeholders}) AND is_active = 1 ORDER BY RAND() LIMIT ?";
        try {
            $stmt = $this->pdo->prepare($sql);
            $paramIndex = 1;
            foreach ($excludedIds as $id) { $stmt->bindValue($paramIndex++, (int)$id, PDO::PARAM_INT); }
            $stmt->bindValue($paramIndex, (int)$limit, PDO::PARAM_INT);
            $stmt->execute();
            $suggestions = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($suggestions as &$suggestion) {
                $suggestion['profile_picture_full_url'] = $this->prepareProfilePicUrl($suggestion['profile_picture_url'] ?? null);
            }
            unset($suggestion);
            return $suggestions ?: [];
        } catch (PDOException $e) {
            error_log("UserModel::getSuggestedFriends PDOException for {$loggedInUserId}: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Searches for users by username, excluding the current user.
     * Used for the boardroom new conversation modal.
     */
    public function searchUsersByUsername(string $searchTerm, int $loggedInUserId, int $limit = 7): array {
        $sql = "SELECT id, username, full_name, profile_picture_url 
                FROM users 
                WHERE username LIKE :searchTerm 
                  AND id != :loggedInUserId 
                  AND is_active = 1
                ORDER BY username ASC
                LIMIT :limit";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(':searchTerm', "%" . $searchTerm . "%", PDO::PARAM_STR);
            $stmt->bindValue(':loggedInUserId', $loggedInUserId, PDO::PARAM_INT);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($users as &$user) {
                $user['profile_picture_full_url'] = $this->prepareProfilePicUrl($user['profile_picture_url'] ?? null);
            }
            unset($user);
            return $users ?: [];
        } catch (PDOException $e) {
            error_log("UserModel::searchUsersByUsername PDOException for term '{$searchTerm}': " . $e->getMessage());
            return []; // Return empty array on error, controller will send success:false or handle
        }
    }
    
    public function getExplorableUsers(int $loggedInUserId, int $limit, int $offset): array {
        $followedUserIds = $this->getFollowedUserIds($loggedInUserId);
        $excludedIds = $followedUserIds;
        $excludedIds[] = $loggedInUserId;
        $placeholders = implode(',', array_fill(0, count($excludedIds), '?'));
        $sql = "SELECT id, username, full_name, profile_picture_url
                FROM users WHERE is_active = 1 AND id NOT IN ({$placeholders})
                ORDER BY created_at DESC LIMIT ? OFFSET ?";
        try {
            $stmt = $this->pdo->prepare($sql);
            $paramIndex = 1;
            foreach ($excludedIds as $id) { $stmt->bindValue($paramIndex++, (int)$id, PDO::PARAM_INT); }
            $stmt->bindValue($paramIndex++, (int)$limit, PDO::PARAM_INT);
            $stmt->bindValue($paramIndex, (int)$offset, PDO::PARAM_INT);
            $stmt->execute();
            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($users as &$user) {
                $user['profile_picture_full_url'] = $this->prepareProfilePicUrl($user['profile_picture_url'] ?? null);
            }
            unset($user);
            return $users ?: [];
        } catch (PDOException $e) {
            error_log("UserModel::getExplorableUsers PDOException for user {$loggedInUserId}: " . $e->getMessage());
            return [];
        }
    }

    public function countExplorableUsers(int $loggedInUserId): int {
        $followedUserIds = $this->getFollowedUserIds($loggedInUserId);
        $excludedIds = $followedUserIds;
        $excludedIds[] = $loggedInUserId;
        $placeholders = implode(',', array_fill(0, count($excludedIds), '?'));
        $sql = "SELECT COUNT(*) FROM users WHERE is_active = 1 AND id NOT IN ({$placeholders})";
        try {
            $stmt = $this->pdo->prepare($sql);
            $paramIndex = 1;
            foreach ($excludedIds as $id) { $stmt->bindValue($paramIndex++, (int)$id, PDO::PARAM_INT); }
            $stmt->execute();
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log("UserModel::countExplorableUsers PDOException for user {$loggedInUserId}: " . $e->getMessage());
            return 0;
        }
    }

    //oders
    public function findOrdersByUserId(int $userId): array {
        $sql = "SELECT
                    o.id as order_id,  -- Matching the view's expected key
                    o.total_amount,
                    o.status,
                    o.created_at,
                    (SELECT COUNT(*) FROM order_items oi_count WHERE oi_count.order_id = o.id) as item_count,
                    (SELECT GROUP_CONCAT(DISTINCT p.name ORDER BY p.name SEPARATOR ', ')
                     FROM order_items oi_items
                     JOIN products p ON oi_items.product_id = p.id
                     WHERE oi_items.order_id = o.id
                     -- You might want to limit the number of product names if it gets too long
                     -- LIMIT 3 
                    ) as product_summary 
                FROM orders o
                WHERE o.user_id = :user_id
                ORDER BY o.created_at DESC";
        
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->execute();
            $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $orders ?: [];
        } catch (PDOException $e) {
            error_log("OrderModel::findOrdersByUserId PDOException for UserID {$userId}: " . $e->getMessage());
            return [];
        }
    }


public function updateUserPassword(int $userId, string $newPasswordHash): bool {
    $sql = "UPDATE users SET password_hash = :password_hash, updated_at = NOW() WHERE id = :user_id";
    $stmt = $this->pdo->prepare($sql);
    $stmt->bindParam(':password_hash', $newPasswordHash, PDO::PARAM_STR);
    $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
    return $stmt->execute();
}
}
?>