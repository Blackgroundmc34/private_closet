<?php
// File: app/Models/OrderModel.php

class OrderModel {
    private $pdo;
    private $app_url; 

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
    }

    private function getBusinessIdForProduct(int $productId): ?int {
        if ($productId <= 0) return null;
        try {
            $stmt = $this->pdo->prepare("SELECT business_id FROM products WHERE id = :product_id LIMIT 1");
            $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
            $stmt->execute();
            $result = $stmt->fetchColumn();
            return $result ? (int)$result : null;
        } catch (PDOException $e) {
            error_log("OrderModel::getBusinessIdForProduct - Error for product {$productId}: " . $e->getMessage());
            return null;
        }
    }

    public function createOrder(
        int $userId,
        array $shippingAddress,
        array $billingAddress,
        string $paymentMethod,
        array $cartItems, 
        array $orderTotals, 
        string $initialOrderStatus = 'pending_payment',
        ?string $paymentGatewayRef = null
    ): int|false {
        
        if (empty($cartItems) || !isset($orderTotals['total'])) {
            error_log("OrderModel::createOrder - Cart items or order total missing for user ID: {$userId}.");
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Cannot create order: cart is empty or total is missing.'];
            return false;
        }

        $shippingAddressJson = json_encode($shippingAddress);
        $billingAddressJson = json_encode($billingAddress);

        try {
            $this->pdo->beginTransaction();
            error_log("OrderModel::createOrder - Transaction STARTED for user ID: {$userId}.");

            // Ensure shipping_provider and tracking_number columns exist in your 'orders' table
            $sqlOrder = "INSERT INTO orders (user_id, total_amount, status, shipping_address, billing_address, payment_method, payment_status, payment_gateway_ref, shipping_cost, created_at, updated_at, shipping_provider, tracking_number)
                         VALUES (:user_id, :total_amount, :status, :shipping_address, :billing_address, :payment_method, :payment_status, :payment_gateway_ref, :shipping_cost, NOW(), NOW(), NULL, NULL)";
            
            $stmtOrder = $this->pdo->prepare($sqlOrder);
            $stmtOrder->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmtOrder->bindParam(':total_amount', $orderTotals['total']); 
            $stmtOrder->bindParam(':status', $initialOrderStatus, PDO::PARAM_STR);
            $stmtOrder->bindParam(':shipping_address', $shippingAddressJson, PDO::PARAM_STR);
            $stmtOrder->bindParam(':billing_address', $billingAddressJson, PDO::PARAM_STR);
            $stmtOrder->bindParam(':payment_method', $paymentMethod, PDO::PARAM_STR);
            
            $initialPaymentStatus = ($initialOrderStatus === 'processing' || $initialOrderStatus === 'paid' || $initialOrderStatus === 'delivered' || $initialOrderStatus === 'shipped') ? 'paid' : 'pending';
            if ($initialOrderStatus === 'awaiting_payment') $initialPaymentStatus = 'pending';

            $stmtOrder->bindParam(':payment_status', $initialPaymentStatus, PDO::PARAM_STR);
            $stmtOrder->bindParam(':payment_gateway_ref', $paymentGatewayRef, $paymentGatewayRef === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
            $stmtOrder->bindParam(':shipping_cost', $orderTotals['shipping']);

            if (!$stmtOrder->execute()) {
                $errorInfo = $stmtOrder->errorInfo();
                error_log("OrderModel::createOrder - Failed to insert into orders table for user ID {$userId}: " . implode(" | ", $errorInfo));
                $this->pdo->rollBack();
                return false;
            }
            $orderId = (int)$this->pdo->lastInsertId();
            if ($orderId === 0) {
                error_log("OrderModel::createOrder - lastInsertId was 0 after orders insert for user ID {$userId}.");
                $this->pdo->rollBack();
                return false;
            }
            error_log("OrderModel::createOrder - Order #{$orderId} base record inserted for user ID {$userId}.");

            $sqlOrderItem = "INSERT INTO order_items (order_id, product_id, business_id, quantity, price_at_time_of_order, created_at)
                             VALUES (:order_id, :product_id, :business_id, :quantity, :price, NOW())";
            $stmtOrderItem = $this->pdo->prepare($sqlOrderItem);

            $sqlStockUpdate = "UPDATE products SET stock_quantity = stock_quantity - :quantity WHERE id = :product_id AND stock_quantity >= :quantity_check";
            $stmtStockUpdate = $this->pdo->prepare($sqlStockUpdate);

            foreach ($cartItems as $cartItemId => $item) { 
                $productId = (int)($item['product_id'] ?? 0);
                $quantity = (int)($item['quantity'] ?? 0);
                $priceAtTimeOfOrder = (float)($item['price'] ?? 0.00);
                
                $businessId = (int)($item['business_id'] ?? $this->getBusinessIdForProduct($productId) ?? 0); 
                
                if ($productId <= 0 || $quantity <= 0 || !$businessId || $businessId <= 0) {
                    error_log("OrderModel::createOrder - Invalid item data for order {$orderId}: product_id={$productId}, quantity={$quantity}, business_id=".($businessId ?: 'NOT_FOUND'));
                    $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Invalid product data in cart. Order cannot be placed. Item: '.htmlspecialchars($item['name'] ?? 'Unknown').'.'];
                    $this->pdo->rollBack();
                    return false;
                }

                $stmtStockUpdate->bindParam(':quantity', $quantity, PDO::PARAM_INT);
                $stmtStockUpdate->bindParam(':product_id', $productId, PDO::PARAM_INT);
                $stmtStockUpdate->bindParam(':quantity_check', $quantity, PDO::PARAM_INT); 

                if (!$stmtStockUpdate->execute() || $stmtStockUpdate->rowCount() === 0) {
                    $currentStockSql = "SELECT stock_quantity FROM products WHERE id = :pid_stock";
                    $stmtCheckStock = $this->pdo->prepare($currentStockSql);
                    $stmtCheckStock->bindParam(':pid_stock', $productId, PDO::PARAM_INT);
                    $stmtCheckStock->execute();
                    $actualStock = (int)$stmtCheckStock->fetchColumn();
                    error_log("OrderModel::createOrder - Stock update failed/insufficient for product {$productId} (order {$orderId}). Tried {$quantity}, actual: {$actualStock}.");
                    
                    $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Order failed. Item "'.htmlspecialchars($item['name'] ?? 'ID '.$productId).'" stock unavailable (available: '.$actualStock.').'];
                    $this->pdo->rollBack();
                    return false;
                }
                error_log("OrderModel::createOrder - Stock updated for product ID {$productId} for order #{$orderId}.");

                $stmtOrderItem->bindParam(':order_id', $orderId, PDO::PARAM_INT);
                $stmtOrderItem->bindParam(':product_id', $productId, PDO::PARAM_INT);
                $stmtOrderItem->bindParam(':business_id', $businessId, PDO::PARAM_INT); 
                $stmtOrderItem->bindParam(':quantity', $quantity, PDO::PARAM_INT);
                $stmtOrderItem->bindParam(':price', $priceAtTimeOfOrder);
                
                if (!$stmtOrderItem->execute()) {
                    $errorInfoItem = $stmtOrderItem->errorInfo();
                    error_log("OrderModel::createOrder - Failed to insert order item for order {$orderId}, product {$productId}: " . implode(" | ", $errorInfoItem));
                    $this->pdo->rollBack();
                    return false;
                }
                error_log("OrderModel::createOrder - Order item inserted for product ID {$productId} for order #{$orderId}.");
            }

            $this->pdo->commit();
            error_log("OrderModel::createOrder - Transaction COMMITTED. Order #{$orderId} created successfully for user ID: {$userId}.");
            return $orderId;

        } catch (PDOException $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
                error_log("OrderModel::createOrder - Transaction ROLLED BACK (PDOException).");
            }
            error_log("OrderModel::createOrder PDOException for user {$userId}: " . $e->getMessage());
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Database error placing order.'];
            return false;
        } catch (Throwable $e) { 
             if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
                error_log("OrderModel::createOrder - Transaction ROLLED BACK (Throwable).");
            }
            error_log("OrderModel::createOrder General Throwable for user {$userId}: " . $e->getMessage());
            $_SESSION['flash_message'] = ['type' => 'error', 'text' => 'Unexpected error placing order.'];
            return false;
        }
    }

    public function findOrderById(int $orderId, ?int $userId = null): array|false {
        $sql = "SELECT o.*, 
                       (SELECT GROUP_CONCAT(CONCAT(p.name, ' (Qty: ', oi.quantity, ')') SEPARATOR '; ') 
                        FROM order_items oi 
                        JOIN products p ON oi.product_id = p.id 
                        WHERE oi.order_id = o.id) as item_summary
                FROM orders o 
                WHERE o.id = :order_id";
        
        $params = [':order_id' => $orderId];

        if ($userId !== null) {
            $sql .= " AND o.user_id = :user_id";
            $params[':user_id'] = $userId;
        }
        $sql .= " LIMIT 1";

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            $order = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($order) {
                $sqlItems = "SELECT oi.*, p.name as product_name, p.slug as product_slug, p.sku as product_sku,
                                    (SELECT pi.image_url FROM product_images pi WHERE pi.product_id = oi.product_id AND pi.is_primary = 1 LIMIT 1) as product_image_relative
                             FROM order_items oi
                             JOIN products p ON oi.product_id = p.id
                             WHERE oi.order_id = :order_id_items";
                $stmtItems = $this->pdo->prepare($sqlItems);
                $stmtItems->bindParam(':order_id_items', $order['id'], PDO::PARAM_INT);
                $stmtItems->execute();
                $itemsData = $stmtItems->fetchAll(PDO::FETCH_ASSOC);
                
                if (class_exists('ProductModel')) {
                    $productModel = new ProductModel($this->pdo); 
                    foreach($itemsData as &$item) {
                        $item['product_image'] = $productModel->prepareFullUrl($item['product_image_relative'] ?? null);
                    }
                    unset($item); 
                } else { 
                     foreach($itemsData as &$item) {
                        $imgRelPath = $item['product_image_relative'] ?? null;
                        if (!empty($imgRelPath)) {
                            $item['product_image'] = (strpos($imgRelPath, 'http') === 0 ? $imgRelPath : $this->app_url . '/' . ltrim($imgRelPath, '/'));
                        } else {
                             $item['product_image'] = $this->app_url . '/assets/images/default_product_image.png';
                        }
                    }
                    unset($item);
                }
                $order['items'] = $itemsData;

                $order['shipping_address_details'] = @json_decode($order['shipping_address'], true) ?: [];
                $order['billing_address_details'] = @json_decode($order['billing_address'], true) ?: [];
            }
            return $order ?: false;
        } catch (PDOException $e) {
            error_log("OrderModel::findOrderById PDOException for OrderID {$orderId}: " . $e->getMessage());
            return false;
        }
    }

    

    /**
     * Updates an order's status, tracking number, AND shipping provider.
     */
    public function updateOrderStatus(int $orderId, string $newStatus, ?string $trackingNumber = null, ?string $shippingProvider = null): bool {
        $allowedStatuses = ['pending_payment', 'awaiting_payment', 'processing', 'shipped', 'delivered', 'completed', 'cancelled', 'on-hold', 'refunded'];
        if (!in_array($newStatus, $allowedStatuses)) {
            error_log("OrderModel::updateOrderStatus - Invalid status '{$newStatus}' for OrderID {$orderId}.");
            return false;
        }

        $sql = "UPDATE orders SET 
                    status = :status, 
                    tracking_number = :tracking_number, 
                    shipping_provider = :shipping_provider, 
                    updated_at = NOW() 
                WHERE id = :order_id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':status', $newStatus, PDO::PARAM_STR);
            $stmt->bindParam(':tracking_number', $trackingNumber, $trackingNumber === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
            $stmt->bindParam(':shipping_provider', $shippingProvider, $shippingProvider === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
            $stmt->bindParam(':order_id', $orderId, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log("OrderModel::updateOrderStatus PDOException for OrderID {$orderId}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Fetches orders that contain products from a specific business for supplier view.
     */
    public function getOrdersByBusinessId(int $businessId, int $limit = 15, int $offset = 0, array $filters = []): array {
        $params = [':business_id' => $businessId, ':business_id_subquery' => $businessId];
        $sql = "SELECT DISTINCT
                    o.id as order_id,
                    o.total_amount,
                    o.status,
                    o.created_at,
                    o.user_id, 
                    u.username as customer_username,
                    u.full_name as customer_full_name,
                    (SELECT COUNT(*) FROM order_items oi_count WHERE oi_count.order_id = o.id) as total_item_count_in_order,
                    (SELECT COUNT(DISTINCT oi_supplier.product_id) 
                     FROM order_items oi_supplier 
                     JOIN products p_supplier ON oi_supplier.product_id = p_supplier.id 
                     WHERE oi_supplier.order_id = o.id AND p_supplier.business_id = :business_id_subquery
                    ) as supplier_item_count 
                FROM orders o
                JOIN users u ON o.user_id = u.id
                JOIN order_items oi ON o.id = oi.order_id
                JOIN products p ON oi.product_id = p.id
                WHERE p.business_id = :business_id";

        if (!empty($filters['status'])) {
            $sql .= " AND o.status = :status_filter";
            $params[':status_filter'] = $filters['status'];
        }

        $sql .= " ORDER BY o.created_at DESC LIMIT :limit OFFSET :offset";
        $params[':limit'] = $limit; // PDO will bind as int if type is PDO::PARAM_INT
        $params[':offset'] = $offset; // PDO will bind as int if type is PDO::PARAM_INT

        try {
            $stmt = $this->pdo->prepare($sql);
            foreach ($params as $key => $value) {
                $type = PDO::PARAM_STR; 
                if ($key === ':business_id' || $key === ':business_id_subquery' || $key === ':limit' || $key === ':offset') {
                    $type = PDO::PARAM_INT;
                }
                $stmt->bindValue($key, $value, $type);
            }
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (PDOException $e) {
            error_log("OrderModel::getOrdersByBusinessId PDOException for BusinessID {$businessId}: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Counts orders containing products from a specific business.
     */
    public function countOrdersByBusinessId(int $businessId, array $filters = []): int {
        $params = [':business_id' => $businessId];
        $sql = "SELECT COUNT(DISTINCT o.id)
                FROM orders o
                JOIN order_items oi ON o.id = oi.order_id
                JOIN products p ON oi.product_id = p.id
                WHERE p.business_id = :business_id";
        
        if (!empty($filters['status'])) {
            $sql .= " AND o.status = :status_filter";
            $params[':status_filter'] = $filters['status'];
        }

        try {
            $stmt = $this->pdo->prepare($sql);
            foreach ($params as $key => $value) {
                $type = ($key === ':business_id') ? PDO::PARAM_INT : PDO::PARAM_STR;
                $stmt->bindValue($key, $value, $type);
            }
            $stmt->execute();
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log("OrderModel::countOrdersByBusinessId PDOException for BusinessID {$businessId}: " . $e->getMessage());
            return 0;
        }
    }


    public function findOrdersByUserId(int $userId, int $limit = 10, int $offset = 0): array {
        if ($userId <= 0) {
            return [];
        }

        // Select the columns you need for the order list page
        $sql = "SELECT id, user_id, total_amount, status, created_at, updated_at 
                FROM orders 
                WHERE user_id = :user_id
                ORDER BY created_at DESC
                LIMIT :limit OFFSET :offset";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return $orders ?: []; // Return empty array if no orders found

        } catch (PDOException $e) {
            error_log("OrderModel::findOrdersByUserId PDOException for UserID {$userId}: " . $e->getMessage());
            return []; // Return empty array on error
        }
    }

    /**
     * Counts the total number of orders for a specific user.
     * Needed for pagination.
     *
     * @param int $userId The ID of the user.
     * @return int Total number of orders.
     */
    public function countOrdersByUserId(int $userId): int {
        if ($userId <= 0) {
            return 0;
        }
        $sql = "SELECT COUNT(*) FROM orders WHERE user_id = :user_id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->execute();
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log("OrderModel::countOrdersByUserId PDOException for UserID {$userId}: " . $e->getMessage());
            return 0;
        }
    }

    // Ensure you have this method (or similar) from previous fixes for individual order viewing
    public function findOrderByIdForUser(int $orderId, int $userId): array|false {
        if ($orderId <= 0 || $userId <= 0) {
            return false;
        }
        $sql = "SELECT * FROM orders WHERE id = :order_id AND user_id = :user_id LIMIT 1";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':order_id', $orderId, PDO::PARAM_INT);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->execute();
            $order = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($order) {
                $itemSql = "SELECT oi.*, p.name as product_name, p.slug as product_slug,
                                   (SELECT pi.image_url FROM product_images pi WHERE pi.product_id = oi.product_id AND pi.is_primary = TRUE LIMIT 1) as product_image_url
                            FROM order_items oi
                            JOIN products p ON oi.product_id = p.id
                            WHERE oi.order_id = :order_id_items";
                $itemStmt = $this->pdo->prepare($itemSql);
                $itemStmt->bindParam(':order_id_items', $orderId, PDO::PARAM_INT);
                $itemStmt->execute();
                $order['items'] = $itemStmt->fetchAll(PDO::FETCH_ASSOC);

                $app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
                $default_product_image = $app_url . '/assets/images/default_product_image.png';

                foreach ($order['items'] as &$item) {
                    if (!empty($item['product_image_url'])) {
                        $isAbsolute = strpos($item['product_image_url'], 'http') === 0 || strpos($item['product_image_url'], '//') === 0;
                        $item['product_image_full_url'] = $isAbsolute ? $item['product_image_url'] : $app_url . '/' . ltrim($item['product_image_url'], '/');
                    } else {
                        $item['product_image_full_url'] = $default_product_image;
                    }
                }
                unset($item);

                if (isset($order['shipping_address']) && is_string($order['shipping_address'])) {
                    $decodedShipping = json_decode($order['shipping_address'], true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        $order['shipping_address_details'] = $decodedShipping;
                    } else { $order['shipping_address_details'] = []; }
                }
                if (isset($order['billing_address']) && is_string($order['billing_address'])) {
                     $decodedBilling = json_decode($order['billing_address'], true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        $order['billing_address_details'] = $decodedBilling;
                    } else { $order['billing_address_details'] = []; }
                }
            }
            return $order ?: false;
        } catch (PDOException $e) {
            error_log("OrderModel::findOrderByIdForUser PDOException for OrderID {$orderId}, UserID {$userId}: " . $e->getMessage());
            return false;
        }
    }
    

    /**
     * Fetches specific order details for a supplier, including only their items.
     */
    public function getOrderDetailsForSupplier(int $orderId, int $businessId): array|false {
        $orderSql = "SELECT o.*, u.username as customer_username, u.email as customer_email, u.full_name as customer_full_name
                     FROM orders o
                     JOIN users u ON o.user_id = u.id
                     WHERE o.id = :order_id 
                     AND EXISTS (
                         SELECT 1 FROM order_items oi 
                         JOIN products p ON oi.product_id = p.id 
                         WHERE oi.order_id = o.id AND p.business_id = :business_id_check
                     )
                     LIMIT 1";
        try {
            $stmtOrder = $this->pdo->prepare($orderSql);
            $stmtOrder->bindParam(':order_id', $orderId, PDO::PARAM_INT);
            $stmtOrder->bindParam(':business_id_check', $businessId, PDO::PARAM_INT);
            $stmtOrder->execute();
            $order = $stmtOrder->fetch(PDO::FETCH_ASSOC);

            if (!$order) {
                return false; 
            }

            $itemsSql = "SELECT oi.*, p.name as product_name, p.slug as product_slug, p.sku as product_sku,
                                (SELECT pi.image_url FROM product_images pi WHERE pi.product_id = oi.product_id AND pi.is_primary = 1 LIMIT 1) as product_image_relative
                         FROM order_items oi
                         JOIN products p ON oi.product_id = p.id
                         WHERE oi.order_id = :order_id AND p.business_id = :business_id_items";
            $stmtItems = $this->pdo->prepare($itemsSql);
            $stmtItems->bindParam(':order_id', $orderId, PDO::PARAM_INT);
            $stmtItems->bindParam(':business_id_items', $businessId, PDO::PARAM_INT);
            $stmtItems->execute();
            $order['items'] = $stmtItems->fetchAll(PDO::FETCH_ASSOC);

            if (class_exists('ProductModel')) {
                $productModel = new ProductModel($this->pdo); 
                foreach ($order['items'] as &$item) {
                    $item['product_image_full'] = $productModel->prepareFullUrl($item['product_image_relative'] ?? null);
                }
                unset($item);
            } else { // Fallback if ProductModel is not available
                foreach ($order['items'] as &$item) {
                    $imgRelPath = $item['product_image_relative'] ?? null;
                    if (!empty($imgRelPath)) {
                       $item['product_image_full'] = (strpos($imgRelPath, 'http') === 0 ? $imgRelPath : $this->app_url . '/' . ltrim($imgRelPath, '/'));
                    } else {
                        $item['product_image_full'] = $this->app_url . '/assets/images/default_product_image.png';
                    }
                }
                unset($item);
            }
            
            $order['shipping_address_details'] = @json_decode($order['shipping_address'], true) ?: [];
            $order['billing_address_details'] = @json_decode($order['billing_address'], true) ?: [];
            
            return $order;

        } catch (PDOException $e) {
            error_log("OrderModel::getOrderDetailsForSupplier PDOException for OrderID {$orderId}, BusinessID {$businessId}: " . $e->getMessage());
            return false;
        }
    }
}
?>