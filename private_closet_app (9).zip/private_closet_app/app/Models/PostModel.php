<?php
// File: app/Models/PostModel.php

class PostModel {
    private $pdo;
    private $app_url;
    private $default_avatar_full_url;

    public function __construct(PDO $pdo) {
        if (!$pdo) {
            error_log('PostModel FATAL: PDO object is null in constructor.');
            throw new InvalidArgumentException('PDO object cannot be null in PostModel.');
        }
        $this->pdo = $pdo;
        $this->app_url = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
        // Define default avatar path relative to the public directory
        $default_avatar_path = defined('DEFAULT_AVATAR_PATH') ? DEFAULT_AVATAR_PATH : 'assets/images/default_avatar.png';
        $this->default_avatar_full_url = $this->app_url . '/' . ltrim($default_avatar_path, '/');
    }

    private function prepareFullUrl(?string $relativePath): string {
        if (empty($relativePath)) return '';
        // Check if already a full URL
        if (preg_match('/^https?:\/\//', $relativePath)) {
            return $relativePath;
        }
        return $this->app_url . '/' . ltrim($relativePath, '/');
    }

    private function prepareProfilePicUrl(?string $relativePath): string {
        if (empty($relativePath)) return $this->default_avatar_full_url;
        if (preg_match('/^https?:\/\//', $relativePath)) {
            return $relativePath;
        }
        return $this->app_url . '/' . ltrim($relativePath, '/');
    }

    public function findById(int $postId, ?int $loggedInUserId = null): ?array {
        if ($postId <= 0) {
            error_log("PostModel::findById - Invalid PostID: {$postId}");
            return null;
        }

        $sql = "SELECT
                    p.id, p.user_id, p.description, p.media_url, p.media_type, p.location,
                    p.visibility, p.allow_comments, p.created_at, p.updated_at,
                    u.username AS author_username,
                    u.profile_picture_url AS author_profile_pic,
                    (SELECT COUNT(*) FROM post_likes pl WHERE pl.post_id = p.id) AS like_count,
                    (SELECT COUNT(*) FROM post_comments pc WHERE pc.post_id = p.id) AS comment_count";

        if ($loggedInUserId && $loggedInUserId > 0) {
            $sql .= ", (EXISTS(SELECT 1 FROM post_likes pl_user WHERE pl_user.post_id = p.id AND pl_user.user_id = :loggedInUserId)) AS is_liked_by_user";
        } else {
            $sql .= ", CAST(0 AS UNSIGNED) AS is_liked_by_user"; // Ensure the column exists even if no user
        }

        $sql .= " FROM posts p
                  JOIN users u ON p.user_id = u.id
                  WHERE p.id = :postId";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':postId', $postId, PDO::PARAM_INT);
            if ($loggedInUserId && $loggedInUserId > 0) {
                $stmt->bindParam(':loggedInUserId', $loggedInUserId, PDO::PARAM_INT);
            }
            $stmt->execute();
            $post = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($post) {
                $post['media_full_url'] = $this->prepareFullUrl($post['media_url'] ?? null);
                $post['author_profile_pic_full_url'] = $this->prepareProfilePicUrl($post['author_profile_pic'] ?? null);
                $post['is_liked_by_user'] = (bool)($post['is_liked_by_user'] ?? false);
                $post['allow_comments'] = (bool)($post['allow_comments'] ?? true); // Default to true if not set
                $post['like_count'] = (int)($post['like_count'] ?? 0);
                $post['comment_count'] = (int)($post['comment_count'] ?? 0);
            }
            return $post ?: null;

        } catch (PDOException $e) {
            error_log("PostModel::findById PDOException for PostID {$postId}: " . $e->getMessage() . "\nSQL: " . $sql);
            return null;
        }
    }

    public function toggleLike(int $postId, int $userId): array {
        if ($postId <= 0 || $userId <= 0) {
            return ['success' => false, 'message' => 'Invalid post or user ID for like operation.'];
        }
        $sqlCheck = "SELECT 1 FROM post_likes WHERE post_id = :postId AND user_id = :userId";
        try {
            $stmtCheck = $this->pdo->prepare($sqlCheck);
            $stmtCheck->bindParam(':postId', $postId, PDO::PARAM_INT);
            $stmtCheck->bindParam(':userId', $userId, PDO::PARAM_INT);
            $stmtCheck->execute();
            $isLiked = (bool)$stmtCheck->fetchColumn();

            if ($isLiked) {
                $sqlToggle = "DELETE FROM post_likes WHERE post_id = :postId AND user_id = :userId";
            } else {
                $sqlToggle = "INSERT INTO post_likes (post_id, user_id, created_at) VALUES (:postId, :userId, NOW())";
            }
            $stmtToggle = $this->pdo->prepare($sqlToggle);
            $stmtToggle->bindParam(':postId', $postId, PDO::PARAM_INT);
            $stmtToggle->bindParam(':userId', $userId, PDO::PARAM_INT);
            $executionSuccess = $stmtToggle->execute();

            if ($executionSuccess) {
                $newLikeCount = $this->getLikeCount($postId);
                return [
                    'success' => true,
                    'liked' => !$isLiked,
                    'like_count' => $newLikeCount,
                    'message' => $isLiked ? 'Post unliked.' : 'Post liked.'
                ];
            } else {
                $errorInfo = $stmtToggle->errorInfo();
                error_log("PostModel::toggleLike SQL Error: " . implode(" | ", $errorInfo));
                return ['success' => false, 'message' => 'Database error updating like.'];
            }
        } catch (PDOException $e) {
            error_log("PostModel::toggleLike PDOException for PostID {$postId}, UserID {$userId}: " . $e->getMessage());
            return ['success' => false, 'message' => 'Server error. Please try again.'];
        }
    }


    public function getLikeCount(int $postId): int {
        if ($postId <= 0) return 0;
        $sql = "SELECT COUNT(*) FROM post_likes WHERE post_id = :postId";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':postId', $postId, PDO::PARAM_INT);
            $stmt->execute();
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log("PostModel::getLikeCount PDOException for PostID {$postId}: " . $e->getMessage());
            return 0;
        }
    }

    public function addComment(int $postId, int $userId, string $commentText): ?array {
        if ($postId <= 0 || $userId <= 0 || empty(trim($commentText))) { return null; }
        if (strlen($commentText) > 1000) { return null; } // Basic validation
        if (!mb_check_encoding($commentText, 'UTF-8')) { // Ensure UTF-8
            $commentText = mb_convert_encoding($commentText, 'UTF-8', 'auto');
        }
        $sql = "INSERT INTO post_comments (post_id, user_id, comment_text, created_at, updated_at)
                VALUES (:postId, :userId, :commentText, NOW(), NOW())";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':postId', $postId, PDO::PARAM_INT);
            $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':commentText', $commentText, PDO::PARAM_STR);
            if ($stmt->execute()) {
                $commentId = (int)$this->pdo->lastInsertId();
                return ($commentId > 0) ? $this->getCommentById($commentId) : null;
            }
            error_log("PostModel::addComment SQL Error: " . implode(" | ", $stmt->errorInfo()));
            return null;
        } catch (PDOException $e) {
            error_log("PostModel::addComment PDOException: " . $e->getMessage());
            return null;
        }
    }

    public function getCommentById(int $commentId): ?array {
        if ($commentId <= 0) return null;
        $sql = "SELECT pc.id AS comment_id, pc.post_id, pc.user_id, pc.comment_text, pc.created_at,
                       u.username AS commenter_username, u.profile_picture_url AS commenter_profile_pic
                FROM post_comments pc JOIN users u ON pc.user_id = u.id
                WHERE pc.id = :commentId";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':commentId', $commentId, PDO::PARAM_INT);
            $stmt->execute();
            $comment = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($comment) {
                $comment['commenter_profile_pic_full_url'] = $this->prepareProfilePicUrl($comment['commenter_profile_pic'] ?? null);
            }
            return $comment ?: null;
        } catch (PDOException $e) {
            error_log("PostModel::getCommentById PDOException: " . $e->getMessage());
            return null;
        }
    }

    public function getComments(int $postId): array {
        if ($postId <= 0) return [];
        $sql = "SELECT pc.id AS comment_id, pc.comment_text, pc.created_at,
                       u.id as user_id, 
                       u.username AS commenter_username, 
                       u.profile_picture_url AS commenter_profile_pic 
                FROM post_comments pc JOIN users u ON pc.user_id = u.id
                WHERE pc.post_id = :postId ORDER BY pc.created_at ASC";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':postId', $postId, PDO::PARAM_INT);
            $stmt->execute();
            $comments = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($comments as &$comment) { 
                $comment['commenter_profile_pic_full_url'] = $this->prepareProfilePicUrl($comment['commenter_profile_pic'] ?? null);
                $comment['username'] = $comment['commenter_username']; // For consistency if view expects 'username'
                $comment['profile_picture_url'] = $comment['commenter_profile_pic_full_url']; // For consistency
            }
            unset($comment);
            return $comments ?: [];
        } catch (PDOException $e) {
            error_log("PostModel::getComments PDOException: " . $e->getMessage());
            return [];
        }
    }

    public function createPost(int $userId, string $description, ?string $mediaUrl, ?string $mediaType, ?string $location, bool $allowComments, string $visibility = 'public'): ?int {
        if ($userId <= 0) {
            error_log("PostModel::createPost - Invalid UserID: {$userId}");
            return null;
        }
        if (empty(trim($description)) && empty($mediaUrl)) {
            error_log("PostModel::createPost - Post must have either a description or media.");
            return null;
        }
        if (!mb_check_encoding($description, 'UTF-8')) {
            $description = mb_convert_encoding($description, 'UTF-8', 'auto');
        }

        $sql = "INSERT INTO posts (user_id, description, media_url, media_type, location, allow_comments, visibility, created_at, updated_at)
                VALUES (:user_id, :description, :media_url, :media_type, :location, :allow_comments, :visibility, NOW(), NOW())";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':description', $description, PDO::PARAM_STR);
            $stmt->bindParam(':media_url', $mediaUrl, $mediaUrl === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
            $stmt->bindParam(':media_type', $mediaType, $mediaType === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
            $stmt->bindParam(':location', $location, $location === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
            $stmt->bindParam(':allow_comments', $allowComments, PDO::PARAM_BOOL);
            $stmt->bindParam(':visibility', $visibility, PDO::PARAM_STR);

            if ($stmt->execute()) {
                $newPostId = (int)$this->pdo->lastInsertId();
                error_log("PostModel::createPost - Post created successfully with ID: {$newPostId}");
                return $newPostId > 0 ? $newPostId : null;
            } else {
                $errorInfo = $stmt->errorInfo();
                error_log("PostModel::createPost - SQL Error: " . implode(" | ", $errorInfo));
                return null;
            }
        } catch (PDOException $e) {
            error_log("PostModel::createPost - PDOException: " . $e->getMessage());
            return null;
        }
    }

    public function countPostsFromUsers(array $userIds): int {
        if (empty($userIds)) {
            return 0;
        }
        $placeholders = implode(',', array_fill(0, count($userIds), '?'));
        $sql = "SELECT COUNT(*) FROM posts WHERE user_id IN ({$placeholders})";

        try {
            $stmt = $this->pdo->prepare($sql);
            foreach ($userIds as $k => $id) {
                $stmt->bindValue(($k + 1), $id, PDO::PARAM_INT);
            }
            $stmt->execute();
            return (int)$stmt->fetchColumn();
        } catch (\PDOException $e) {
            error_log("Error in PostModel::countPostsFromUsers: " . $e->getMessage());
            return 0;
        }
    }

    public function getPostsFromUsers(array $userIds, int $limit, int $offset): array {
        if (empty($userIds)) {
            return [];
        }
        $placeholders = implode(',', array_fill(0, count($userIds), '?'));

        $sql = "SELECT
                    p.id, p.user_id, p.description, p.media_url, p.media_type, p.location,
                    p.visibility, p.allow_comments, p.created_at, p.updated_at,
                    u.username AS author_username,
                    u.profile_picture_url AS author_profile_pic,
                    (SELECT COUNT(*) FROM post_likes pl WHERE pl.post_id = p.id) AS like_count,
                    (SELECT COUNT(*) FROM post_comments pc WHERE pc.post_id = p.id) AS comment_count
                FROM posts p
                JOIN users u ON p.user_id = u.id
                WHERE p.user_id IN ({$placeholders})
                ORDER BY p.created_at DESC
                LIMIT ? OFFSET ?";

        try {
            $stmt = $this->pdo->prepare($sql);
            $paramIndex = 1;
            foreach ($userIds as $id) {
                $stmt->bindValue($paramIndex++, $id, PDO::PARAM_INT);
            }
            $stmt->bindValue($paramIndex++, $limit, PDO::PARAM_INT);
            $stmt->bindValue($paramIndex++, $offset, PDO::PARAM_INT);

            $stmt->execute();
            $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($posts as &$currentPost) { 
                $currentPost['media_full_url'] = $this->prepareFullUrl($currentPost['media_url'] ?? null);
                $currentPost['author_profile_pic_full_url'] = $this->prepareProfilePicUrl($currentPost['author_profile_pic'] ?? null);
                 // If you need is_liked_by_user here, you'll need to pass loggedInUserId and add the subquery
            }
            unset($currentPost); 

            return $posts ?: [];
        } catch (\PDOException $e) {
            error_log("Error in PostModel::getPostsFromUsers: " . $e->getMessage() . " SQL: " . $sql);
            return [];
        }
    }

    // ***** NEW METHODS FOR REELS *****
    /**
     * Counts the total number of video posts (reels).
     * You might want to add more conditions, e.g., visibility.
     *
     * @return int Total number of video posts.
     */
    public function countReels(): int {
        $sql = "SELECT COUNT(*) FROM posts p WHERE p.media_type = 'video'";
        // Example: If you want to count only public reels:
        // $sql = "SELECT COUNT(*) FROM posts p WHERE p.media_type = 'video' AND p.visibility = 'public'";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            return (int)$stmt->fetchColumn();
        } catch (\PDOException $e) {
            error_log("Error in PostModel::countReels: " . $e->getMessage());
            return 0;
        }
    }

    /**
     * Fetches video posts (reels) with pagination.
     *
     * @param int $limit Number of posts per page.
     * @param int $offset Offset for pagination.
     * @param ?int $loggedInUserId The ID of the currently logged-in user, for 'is_liked_by_user'.
     * @return array List of video posts.
     */
    public function getReels(int $limit, int $offset, ?int $loggedInUserId = null): array {
        $sql = "SELECT
                    p.id, p.user_id, p.description, p.media_url, p.media_type, p.location,
                    p.visibility, p.allow_comments, p.created_at, p.updated_at,
                    u.username AS author_username,
                    u.profile_picture_url AS author_profile_pic,
                    (SELECT COUNT(*) FROM post_likes pl WHERE pl.post_id = p.id) AS like_count,
                    (SELECT COUNT(*) FROM post_comments pc WHERE pc.post_id = p.id) AS comment_count";

        if ($loggedInUserId && $loggedInUserId > 0) {
            $sql .= ", (EXISTS(SELECT 1 FROM post_likes pl_user WHERE pl_user.post_id = p.id AND pl_user.user_id = :loggedInUserId)) AS is_liked_by_user";
        } else {
            $sql .= ", CAST(0 AS UNSIGNED) AS is_liked_by_user"; // Ensure the column exists
        }

        $sql .= " FROM posts p
                  JOIN users u ON p.user_id = u.id
                  WHERE p.media_type = 'video'  -- Key condition for reels
                  -- Example: If you want to fetch only public reels:
                  -- AND p.visibility = 'public' 
                  ORDER BY p.created_at DESC
                  LIMIT :limit OFFSET :offset";

        try {
            $stmt = $this->pdo->prepare($sql);

            if ($loggedInUserId && $loggedInUserId > 0) {
                $stmt->bindParam(':loggedInUserId', $loggedInUserId, PDO::PARAM_INT);
            }
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);

            $stmt->execute();
            $reels = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($reels as &$reel) { // Use reference to modify array directly
                $reel['media_full_url'] = $this->prepareFullUrl($reel['media_url'] ?? null);
                $reel['author_profile_pic_full_url'] = $this->prepareProfilePicUrl($reel['author_profile_pic'] ?? null);
                $reel['is_liked_by_user'] = (bool)($reel['is_liked_by_user'] ?? false); // Ensure boolean
                $reel['allow_comments'] = (bool)($reel['allow_comments'] ?? true);    // Ensure boolean
                $reel['like_count'] = (int)($reel['like_count'] ?? 0);                // Ensure int
                $reel['comment_count'] = (int)($reel['comment_count'] ?? 0);          // Ensure int
            }
            unset($reel); // Unset reference to last element

            return $reels ?: [];
        } catch (\PDOException $e) {
            error_log("Error in PostModel::getReels: " . $e->getMessage() . " SQL: " . $sql);
            return [];
        }
    }
    // ***** END OF NEW METHODS FOR REELS *****
}
?>