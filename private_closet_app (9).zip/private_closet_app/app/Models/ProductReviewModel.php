<?php // app/Models/ProductReviewModel.php

class ProductReviewModel {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    /**
     * Fetches all reviews for a given product ID, including reviewer's username and profile picture.
     */
    public function getReviewsByProductId(int $productId): array {
        // Select the 'comment' column and alias it as 'comment_text'
        $sql = "SELECT pr.id, pr.user_id, pr.product_id, pr.rating, 
                       pr.comment AS comment_text,  -- <<< THIS IS THE CHANGE
                       pr.created_at, pr.updated_at, 
                       u.username, u.profile_picture_url
                FROM product_reviews pr
                JOIN users u ON pr.user_id = u.id
                WHERE pr.product_id = :product_id
                ORDER BY pr.created_at DESC";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
        $stmt->execute();
        $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Construct full profile picture URL
        $appUrl = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
        // Ensure DEFAULT_AVATAR_PATH is defined in your config
        $defaultAvatarRel = defined('DEFAULT_AVATAR_PATH') ? DEFAULT_AVATAR_PATH : 'assets/images/default_avatar.png';
        $defaultAvatarFull = $appUrl . '/' . ltrim($defaultAvatarRel, '/');

        foreach ($reviews as &$review) { // Use reference to modify array directly
            if (!empty($review['profile_picture_url'])) {
                $isAbsolute = strpos($review['profile_picture_url'], 'http') === 0 || strpos($review['profile_picture_url'], '//') === 0;
                $review['reviewer_profile_pic_full_url'] = $isAbsolute ? $review['profile_picture_url'] : $appUrl . '/' . ltrim($review['profile_picture_url'], '/');
            } else {
                $review['reviewer_profile_pic_full_url'] = $defaultAvatarFull;
            }
        }
        unset($review); // Important to unset the reference
        return $reviews;
    }

    /**
     * Creates a new product review.
     * The form sends 'review_text', DB table has 'comment'.
     * This method correctly maps $reviewText (from form's 'review_text') to the 'comment' DB column.
     */
    public function createReview(int $userId, int $productId, int $rating, string $reviewText): bool {
        // Using :review_text as a placeholder for the value that goes into the 'comment' column.
        $sql = "INSERT INTO product_reviews (user_id, product_id, rating, comment, created_at, updated_at)
                VALUES (:user_id, :product_id, :rating, :review_text, NOW(), NOW())";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
        $stmt->bindParam(':rating', $rating, PDO::PARAM_INT);
        $stmt->bindParam(':review_text', $reviewText, PDO::PARAM_STR); // $reviewText is bound to :review_text placeholder

        try {
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log("ProductReviewModel::createReview ERROR: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Checks if a user has already reviewed a specific product.
     */
    public function hasUserReviewedProduct(int $userId, int $productId): bool {
        $sql = "SELECT COUNT(*) FROM product_reviews WHERE user_id = :user_id AND product_id = :product_id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchColumn() > 0;
    }
}