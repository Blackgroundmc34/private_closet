<?php
// File: app/Models/MessageModel.php

class MessageModel {
    private $pdo;

    public function __construct(PDO $pdo) {
        if (!$pdo) {
            error_log('MessageModel FATAL: PDO object is null in constructor.');
            throw new InvalidArgumentException('PDO object cannot be null.');
        }
        $this->pdo = $pdo;
    }

    public function getUserConversations(int $userId): array {
        // Using a simplified query for brevity, ensure your full query from previous versions is here
        // Important: Ensure recipient_profile_pic, recipient_username, last_message_text, unread_count, last_message_at are selected
        $sql = "SELECT
                    c.id as conversation_id,
                    cp_other.user_id as recipient_id,
                    u_other.username as recipient_username,
                    u_other.profile_picture_url as recipient_profile_pic,
                    c.last_message_at,
                    m_last.message_text as last_message_text,
                    m_last.sender_user_id as last_message_sender_id,
                    (SELECT COUNT(*)
                     FROM messages m_unread
                     WHERE m_unread.conversation_id = c.id
                       AND m_unread.sender_user_id != :userId_unread
                       AND m_unread.created_at > cp_self.last_read_at
                    ) as unread_count
                FROM conversations c
                JOIN conversation_participants cp_self ON c.id = cp_self.conversation_id AND cp_self.user_id = :userId_self
                JOIN conversation_participants cp_other ON c.id = cp_other.conversation_id AND cp_other.user_id != :userId_other
                JOIN users u_other ON cp_other.user_id = u_other.id
                LEFT JOIN messages m_last ON c.id = m_last.conversation_id AND m_last.created_at = (
                    SELECT MAX(m_inner.created_at) FROM messages m_inner WHERE m_inner.conversation_id = c.id
                )
                ORDER BY c.last_message_at DESC";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':userId_unread', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':userId_self', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':userId_other', $userId, PDO::PARAM_INT);
            $stmt->execute();
            $conversations = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $conversations ?: [];
        } catch (PDOException $e) {
            error_log("MessageModel::getUserConversations PDOException: " . $e->getMessage());
            return [];
        }
    }


    public function getMessages(int $conversationId, int $currentUserId): array {
        error_log("MessageModel::getMessages - ConvoID={$conversationId}, UserID={$currentUserId}");
        $sql = "SELECT
                    m.id as message_id,
                    m.sender_user_id,
                    u.username as sender_username,
                    u.profile_picture_url as sender_profile_pic,
                    m.message_text,
                    m.media_url,
                    m.media_type,
                    m.created_at,
                    UNIX_TIMESTAMP(m.created_at) as message_timestamp
                FROM messages m
                LEFT JOIN users u ON m.sender_user_id = u.id
                WHERE m.conversation_id = :conversation_id
                ORDER BY m.created_at ASC";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':conversation_id', $conversationId, PDO::PARAM_INT);
            $stmt->execute();
            $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($this->isUserParticipant($currentUserId, $conversationId)) {
                 $this->markMessagesAsRead($conversationId, $currentUserId);
            }
            return $messages ?: [];
        } catch (PDOException $e) {
            error_log("MessageModel::getMessages PDOException for ConvoID={$conversationId}: " . $e->getMessage());
            return [];
        }
    }

    public function getNewMessagesAfter(int $conversationId, int $currentUserId, string $lastSeenMessageTimestamp): array {
        error_log("MessageModel::getNewMessagesAfter - ConvoID={$conversationId}, UserID={$currentUserId}, AfterTS={$lastSeenMessageTimestamp}");
        $sql = "SELECT
                    m.id as message_id, m.sender_user_id,
                    u.username as sender_username, u.profile_picture_url as sender_profile_pic,
                    m.message_text, m.media_url, m.media_type, m.created_at,
                    UNIX_TIMESTAMP(m.created_at) as message_timestamp
                FROM messages m
                LEFT JOIN users u ON m.sender_user_id = u.id
                WHERE m.conversation_id = :conversation_id
                  AND m.created_at > FROM_UNIXTIME(:last_seen_ts)
                ORDER BY m.created_at ASC";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':conversation_id', $conversationId, PDO::PARAM_INT);
            $stmt->bindParam(':last_seen_ts', $lastSeenMessageTimestamp, PDO::PARAM_STR); // Timestamp can be int or string
            $stmt->execute();
            $newMessages = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (!empty($newMessages) && $this->isUserParticipant($currentUserId, $conversationId)) {
                $this->markMessagesAsRead($conversationId, $currentUserId);
            }
            return $newMessages ?: [];
        } catch (PDOException $e) {
            error_log("MessageModel::getNewMessagesAfter PDOException for ConvoID={$conversationId}: " . $e->getMessage());
            return [];
        }
    }

    public function markMessagesAsRead(int $conversationId, int $userId): bool {
        error_log("MessageModel::markMessagesAsRead - ConvoID={$conversationId}, UserID={$userId}");
        $sql = "UPDATE conversation_participants
                SET last_read_at = NOW()
                WHERE conversation_id = :conversation_id AND user_id = :user_id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':conversation_id', $conversationId, PDO::PARAM_INT);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log("MessageModel::markMessagesAsRead PDOException: " . $e->getMessage());
            return false;
        }
    }

    public function sendMessage(int $conversationId, int $senderUserId, string $messageText): ?array {
        error_log("MessageModel::sendMessage - ConvoID={$conversationId}, SenderID={$senderUserId}, Text(len):" . strlen($messageText));
        if (empty(trim($messageText))) {
             error_log("MessageModel::sendMessage - Message text is empty, aborting.");
             return null;
        }
        // Ensure messageText is UTF-8
        if (!mb_check_encoding($messageText, 'UTF-8')) {
            $messageText = mb_convert_encoding($messageText, 'UTF-8', 'auto');
            error_log("MessageModel::sendMessage - Converted message text to UTF-8.");
        }

        $this->pdo->beginTransaction();
        try {
            $sqlMessage = "INSERT INTO messages (conversation_id, sender_user_id, message_text, created_at)
                           VALUES (:conversation_id, :sender_user_id, :message_text, NOW())";
            $stmtMessage = $this->pdo->prepare($sqlMessage);
            $stmtMessage->bindParam(':conversation_id', $conversationId, PDO::PARAM_INT);
            $stmtMessage->bindParam(':sender_user_id', $senderUserId, PDO::PARAM_INT);
            $stmtMessage->bindParam(':message_text', $messageText, PDO::PARAM_STR);

            if (!$stmtMessage->execute()) {
                $errorInfo = $stmtMessage->errorInfo();
                error_log("MessageModel::sendMessage - SQL Error on message insert: " . implode(" | ", $errorInfo));
                $this->pdo->rollBack();
                return null;
            }
            $messageId = (int)$this->pdo->lastInsertId();
            if ($messageId === 0) {
                 error_log("MessageModel::sendMessage - lastInsertId returned 0 after apparently successful insert. Rolling back.");
                 $this->pdo->rollBack();
                 return null;
            }
            error_log("MessageModel::sendMessage - Message inserted with ID: {$messageId}");

            $sqlConversationUpdate = "UPDATE conversations SET last_message_at = NOW() WHERE id = :conversation_id";
            $stmtConversationUpdate = $this->pdo->prepare($sqlConversationUpdate);
            $stmtConversationUpdate->bindParam(':conversation_id', $conversationId, PDO::PARAM_INT);
            if (!$stmtConversationUpdate->execute()) {
                 error_log("MessageModel::sendMessage - Failed to update conversation last_message_at for convo ID {$conversationId}. Error: " . implode(" | ", $stmtConversationUpdate->errorInfo()));
                 // Not rolling back, message is sent, but this is an issue to note.
            }

            $this->pdo->commit(); // Commit before fetching, so fetched data is consistent

            // Fetch the newly created message to return it
            $sqlFetchMessage = "SELECT m.id as message_id, m.sender_user_id,
                                       u.username as sender_username,
                                       u.profile_picture_url as sender_profile_pic,
                                       m.message_text,
                                       m.media_url, m.media_type, m.created_at,
                                       UNIX_TIMESTAMP(m.created_at) as message_timestamp
                                FROM messages m
                                LEFT JOIN users u ON m.sender_user_id = u.id
                                WHERE m.id = :message_id";
            $stmtFetch = $this->pdo->prepare($sqlFetchMessage);
            $stmtFetch->bindParam(':message_id', $messageId, PDO::PARAM_INT);
            $stmtFetch->execute();
            $newMessage = $stmtFetch->fetch(PDO::FETCH_ASSOC);

            if (!$newMessage) {
                 error_log("MessageModel::sendMessage - CRITICAL: Failed to fetch message (ID: {$messageId}) immediately after insert and commit. This indicates a serious issue or race condition unlikely here.");
                 return null; // Or return minimal data if possible
            }
            error_log("MessageModel::sendMessage - Successfully fetched new message. Returning.");
            return $newMessage;

        } catch (PDOException $e) {
            if ($this->pdo->inTransaction()) { $this->pdo->rollBack(); }
            error_log("MessageModel::sendMessage - PDOException: " . $e->getMessage() . "\nTrace: " . $e->getTraceAsString());
            return null;
        } catch (Throwable $e) { // Catch any other general errors
            if ($this->pdo->inTransaction()) { $this->pdo->rollBack(); }
            error_log("MessageModel::sendMessage - General Throwable: " . $e->getMessage() . "\nTrace: " . $e->getTraceAsString());
            return null;
        }
    }

    public function findOrCreateConversation(int $userId1, int $userId2): ?int {
        error_log("MessageModel::findOrCreateConversation - User1: {$userId1}, User2: {$userId2}");
        if ($userId1 == $userId2) {
            error_log("MessageModel::findOrCreateConversation - Cannot create conversation with oneself.");
            return null;
        }
        // Ensure users are sorted to always get the same participant order for the query
        $u1 = min($userId1, $userId2);
        $u2 = max($userId1, $userId2);

        $sqlFind = "SELECT cp1.conversation_id
                    FROM conversation_participants cp1
                    JOIN conversation_participants cp2 ON cp1.conversation_id = cp2.conversation_id
                    WHERE cp1.user_id = :user_id1 AND cp2.user_id = :user_id2";
        try {
            $stmtFind = $this->pdo->prepare($sqlFind);
            $stmtFind->bindParam(':user_id1', $u1, PDO::PARAM_INT);
            $stmtFind->bindParam(':user_id2', $u2, PDO::PARAM_INT);
            $stmtFind->execute();
            $conversation = $stmtFind->fetch(PDO::FETCH_ASSOC);

            if ($conversation) {
                error_log("MessageModel::findOrCreateConversation - Found existing conversation ID: " . $conversation['conversation_id']);
                return (int)$conversation['conversation_id'];
            }

            $this->pdo->beginTransaction();
            $sqlCreateConv = "INSERT INTO conversations (created_at, last_message_at) VALUES (NOW(), NOW())";
            $this->pdo->exec($sqlCreateConv);
            $conversationId = (int)$this->pdo->lastInsertId();
            if ($conversationId === 0) {
                error_log("MessageModel::findOrCreateConversation - lastInsertId was 0 after conversation insert.");
                $this->pdo->rollBack(); return null;
            }

            $sqlAddParticipant = "INSERT INTO conversation_participants (conversation_id, user_id, joined_at, last_read_at)
                                  VALUES (:conversation_id, :user_id, NOW(), NOW())";
            $stmtAddP1 = $this->pdo->prepare($sqlAddParticipant);
            $stmtAddP1->bindParam(':conversation_id', $conversationId, PDO::PARAM_INT);
            $stmtAddP1->bindParam(':user_id', $userId1, PDO::PARAM_INT); // Original order for participants
            $stmtAddP1->execute();

            $stmtAddP2 = $this->pdo->prepare($sqlAddParticipant);
            $stmtAddP2->bindParam(':conversation_id', $conversationId, PDO::PARAM_INT);
            $stmtAddP2->bindParam(':user_id', $userId2, PDO::PARAM_INT);
            $stmtAddP2->execute();

            $this->pdo->commit();
            error_log("MessageModel::findOrCreateConversation - Created new conversation ID: {$conversationId}");
            return $conversationId;

        } catch (PDOException $e) {
            if ($this->pdo->inTransaction()) { $this->pdo->rollBack(); }
            error_log("MessageModel::findOrCreateConversation - PDOException: " . $e->getMessage());
            return null;
        }
    }

    public function getRecipientDetails(int $conversationId, int $currentUserId): ?array {
        $sql = "SELECT u.id, u.username, u.profile_picture_url
                FROM users u
                JOIN conversation_participants cp ON u.id = cp.user_id
                WHERE cp.conversation_id = :conversation_id AND cp.user_id != :current_user_id
                LIMIT 1";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':conversation_id', $conversationId, PDO::PARAM_INT);
            $stmt->bindParam(':current_user_id', $currentUserId, PDO::PARAM_INT);
            $stmt->execute();
            $recipient = $stmt->fetch(PDO::FETCH_ASSOC);
            return $recipient ?: null;
        } catch (PDOException $e) {
            error_log("MessageModel::getRecipientDetails PDOException: " . $e->getMessage());
            return null;
        }
    }

    public function isUserParticipant(int $userId, int $conversationId): bool {
        if ($userId <= 0 || $conversationId <= 0) { return false; }
        $sql = "SELECT 1 FROM conversation_participants WHERE user_id = :user_id AND conversation_id = :conversation_id";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':conversation_id', $conversationId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchColumn() !== false;
        } catch (PDOException $e) {
            error_log("MessageModel::isUserParticipant PDOException: " . $e->getMessage());
            return false;
        }
    }
}
?>