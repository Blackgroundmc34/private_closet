<?php
// File: app/Models/PasswordResetModel.php

class PasswordResetModel {
    private $pdo;
    // Token validity period (e.g., 1 hour)
    private const TOKEN_VALIDITY_SECONDS = 3600;


    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    /**
     * Stores a password reset token for a user.
     * Deletes any existing tokens for the same email before inserting.
     */
    public function storeToken(string $email, string $token, string $hashedToken): bool {
        $this->deleteTokensByEmail($email); // Remove old tokens for this email

        $sql = "INSERT INTO password_resets (email, token, created_at) VALUES (:email, :hashed_token, NOW())";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':hashed_token', $hashedToken, PDO::PARAM_STR); // Store the hashed token
        
        try {
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log("PasswordResetModel::storeToken ERROR: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Retrieves a token record by the selector part of the token.
     * Validates if the token has expired.
     */
    public function findUserByToken(string $token): array|false {
        // This method assumes the token passed is the one from the URL.
        // For enhanced security with selector/verifier, this logic would be more complex.
        // Here, we are checking against the hashed token directly.
        // We'd need to hash the provided token and compare, or store selector and hashed verifier.

        // Simpler approach for now: find by hashed token if that's what you store.
        // If you only store the hashed token, you can't retrieve by the raw token from URL directly
        // without enumerating or by email after user provides it on reset form.
        //
        // A common pattern:
        // 1. URL token: selector:verifier (raw)
        // 2. DB: email, selector (indexed), hashed_verifier, expires_at
        // 3. On reset form, user submits password + selector + verifier from URL.
        // 4. Find by selector, hash the submitted verifier, compare with DB hashed_verifier.

        // Given current DB schema (stores `token` which should be the hashed token):
        // We actually need to find the email by the *raw* token, then validate the hash.
        // The DB `token` column should store the HASHED token.
        // The user provides a raw token. We need a way to link raw token to user then verify.
        // Let's adjust: for now, this method might not be directly usable if you only store hashed token.
        // We'll typically retrieve the record by email on the *reset* page after token validation.

        // This method is more for validating token on the reset password page itself.
        // It should find a record based on the token's selector part and then verify the verifier part.
        // For simplicity with the current schema, let's assume `token` is a unique identifier
        // that we can validate against a hashed version of a raw token part.
        // The `token` column in `password_resets` should store the HASH of the token sent to user.

        // Let's refine the find and validate token logic for the reset step later.
        // For now, let's assume we get the record by email or token for validation.
        $sql = "SELECT email, token as hashed_db_token, created_at 
                FROM password_resets 
                WHERE email = (SELECT email FROM password_resets WHERE token = :hashed_token_attempt LIMIT 1) 
                AND created_at >= :expiry_time 
                LIMIT 1";
        // This query is a bit convoluted if we are only given a token.
        // A better way for reset password: user provides token. Find record by a *part* of the token (selector)
        // if you split token into selector and verifier.

        // For now, let's assume a simple token validation on the reset page by finding the record by the token itself (if it were not hashed in DB)
        // OR by email (if the reset page asks for email again, which is not ideal).
        // The user's current schema has `token` as PRIMARY KEY along with `email`. This implies token itself is searchable.
        // Let's assume the 'token' in DB is the one we can search for, and it expires.
        $expiryTimestamp = date('Y-m-d H:i:s', time() - self::TOKEN_VALIDITY_SECONDS);
        $stmt = $this->pdo->prepare("SELECT email, token, created_at FROM password_resets WHERE token = :token AND created_at >= :expiry_time LIMIT 1");
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);
        $stmt->bindParam(':expiry_time', $expiryTimestamp, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }


    /**
     * Deletes a token for a given email.
     */
    public function deleteTokensByEmail(string $email): bool {
        $sql = "DELETE FROM password_resets WHERE email = :email";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        return $stmt->execute();
    }
    
    /**
     * Deletes a specific token.
     */
    public function deleteToken(string $token): bool {
        $sql = "DELETE FROM password_resets WHERE token = :token";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);
        return $stmt->execute();
    }
}