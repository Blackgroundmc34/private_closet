<?php
// File: app/Models/FavoriteProductModel.php

class FavoriteProductModel {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    /**
     * Checks if a product is favorited by a specific user.
     */
    public function isFavorited(int $userId, int $productId): bool {
        $sql = "SELECT COUNT(*) FROM favorite_products WHERE user_id = :user_id AND product_id = :product_id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchColumn() > 0;
    }

    /**
     * Adds a product to a user's favorites.
     */
    public function addFavorite(int $userId, int $productId): bool {
        if ($this->isFavorited($userId, $productId)) {
            return true; // Already favorited
        }
        $sql = "INSERT INTO favorite_products (user_id, product_id) VALUES (:user_id, :product_id)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
        try {
            return $stmt->execute();
        } catch (PDOException $e) {
            // Log error if needed, e.g., if there's a constraint violation though isFavorited should prevent duplicates
            error_log("FavoriteProductModel::addFavorite ERROR: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Removes a product from a user's favorites.
     */
    public function removeFavorite(int $userId, int $productId): bool {
        $sql = "DELETE FROM favorite_products WHERE user_id = :user_id AND product_id = :product_id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
        try {
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log("FavoriteProductModel::removeFavorite ERROR: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Gets all favorite product IDs for a user.
     */
    public function getUserFavoriteProductIds(int $userId): array {
        $sql = "SELECT product_id FROM favorite_products WHERE user_id = :user_id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
}