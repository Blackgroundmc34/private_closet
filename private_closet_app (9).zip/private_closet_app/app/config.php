<?php
// File: app/config.php
// Purpose: Store application configuration, especially sensitive data like database credentials.
// IMPORTANT: In a real application, consider loading these from a .env file for better security.

// ... other defines ...
if (!defined('APP_ROOT_PATH')) {
    // This assumes config.php is in the 'app' directory, 
    // so dirname(__DIR__) gives the project root (e.g., C:/xampp/htdocs/private_closet_app)
    define('APP_ROOT_PATH', dirname(__DIR__)); 
}
// Database Configuration
define('DB_HOST', 'localhost'); // Or your database host (e.g., 127.0.0.1)
define('DB_PORT', '3306');      // Default MySQL/MariaDB port
define('DB_NAME', 'private_closet_db'); // Your database name
define('DB_USER', 'root');      // Your database username (use a dedicated user in production!)
define('DB_PASS', '');          // Your database password (use a strong password!)
define('DB_CHARSET', 'utf8mb4');

// Application Settings (Examples)
define('APP_NAME', 'Private Closet');
define('APP_URL', 'http://localhost/private_closet_app/public'); // Base URL of your app (adjust if needed)
define('DEBUG_MODE', true); // Set to false in production

// --- Add other configurations as needed ---
// E.g., API keys, email settings, etc.
?>
